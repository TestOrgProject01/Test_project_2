/**
 * MGM's package for maintaining error codes used throughout
 * client applications.
 *
 * ## TODO
 * - [ ] Review all SBS error codes with SBS team
 * - [ ] Review all RBS error codes with RBS team
 * - [ ] Review all Cart error codes with Cart service
 * - [ ] Review all MyVegas error codes with relevant team
 * - [ ] Update / review all error messages
 * - [ ] Add more test coverage
 * - [ ] Potentially add app specific errors
 *
 * @packageDocumentation
 */

import { CartCodes, MyVegasCodes, RoomCodes, ShowCodes } from './codes';
import {
  CartMessages,
  MyVegasMessages,
  RoomMessages,
  ShowMessages
} from './messages';
import { MessageType } from './types';
import { getErrorDomain, getErrorType } from './utils';

export type { MessageType };
export type { CartCodes, MyVegasCodes, RoomCodes, ShowCodes };

export { CartMessages, MyVegasMessages, RoomMessages, ShowMessages };
export { getErrorDomain, getErrorType };
