import { ShowCodes } from '../../codes/service/show';
import { MessageType } from '../../types';

/**
 * SBS error messages
 *
 * These messages map to the currently known service error codes.
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/1819247351/SBS+Error+codes}
 *
 * @public
 */
export const ShowMessages: MessageType<ShowCodes> = {
  [ShowCodes.sbs_unknown]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_request]: {
    message: {
      internal:
        'Please validate if the URL is correct and if all the required parameters have been provided.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_exception]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_system_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_runtime_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_authorization_error]: {
    message: {
      internal: 'An authorization error has occurred.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_source]: {
    message: {
      internal: 'Required source attribute is empty or invalid.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_channel]: {
    message: {
      internal: 'Channel header is invalid or empty.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_transaction_id]: {
    message: {
      internal: 'The transactionId is missing in the request header.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_program_id_or_property_id]: {
    message: {
      internal: 'The Program Id and Property Id is missing in the request.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_event_not_on_sale]: {
    message: {
      internal: 'The requested event is not on sale.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_program_no_results]: {
    message: {
      internal: 'No show results for reqested program.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_show_event_id_invalid]: {
    message: {
      internal: 'The requested showEventId is invalid.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_property_id]: {
    message: {
      internal: 'The provided propertyId is missing or invalid.',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_show_id_or_program_id_or_season_id_invalid]: {
    message: {
      internal:
        'The showId, programId or seasonId is either missing or invalid in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_events_missing_start_date]: {
    message: {
      internal: 'A startDate was not provided in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_events_missing_end_date_or_limit]: {
    message: {
      internal: 'The endDate or limit was not provided for events.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_reservation_fields]: {
    message: {
      internal:
        'The confirmation number along with first name/last name or guest token is mandatory to fetch reservation.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_reservation_not_found]: {
    message: {
      internal: 'The reservation was not found.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_mirage_reservation]: {
    message: {
      internal:
        'This reservation is for The Mirage which has been migrated to a different entity.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_tickets_not_found_for_reservation]: {
    message: {
      internal:
        'Tickets not found for the reservation. Reservation might have been cancelled.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_tickets]: {
    message: {
      internal: 'No tickets in the ticket list.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_show_ticket_fields]: {
    message: {
      internal:
        'Show Event id, Price Code, Ticket Type Code, Seat, Row and Section are required for a ticket.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_event_has_no_available_seats]: {
    message: {
      internal:
        'Seats requested is not available and there are no other available seats for the event.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_requested_min_max_ticket_mismatch]: {
    message: {
      internal:
        'Tickets requested do not match the min and max limit setup at the Show or Program level.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_program_id]: {
    message: {
      internal: 'Program Id is invalid',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_archtics_exception]: {
    message: {
      internal:
        'Errors from Archtics which are unrelated to seats not being available.',
      public: 'Our apologies, but this event is no longer on sale.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_offer_inelgible_for_user]: {
    message: {
      internal: 'User is not eligible for the offer.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_show_seats_unvailable]: {
    message: {
      internal: '_show_seats_unavailable',
      public: 'Please return to the previous screen and try again.'
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_show_unavailable]: {
    message: {
      internal: '_show_unavailable',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_program_multiple_exception]: {
    message: {
      internal:
        'Some programs have restrictions in place for the tickets to be booked only when they are a multiple of configured/specified number. Validation Error is expected when trying to reserve seats that are not a multiple of this configured/specified number.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_or_invalid_hold_id]: {
    message: {
      internal: 'The holdId is missing or invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_event_date]: {
    message: {
      internal: 'The requested eventDate is invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_total_price_mismatch]: {
    message: {
      internal: 'The base price and tax do not add up to Total Amount.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_archtics_invalid_delivery_method]: {
    message: {
      internal:
        'The delivery method set in show ticket is invalid or not permitted (by Archtics) for the ticket',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_payment_card]: {
    message: {
      internal: 'The payment card is not supported.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_email]: {
    message: {
      internal: 'The emailAddress is invalid or missing in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_billing_information]: {
    message: {
      internal: 'Billing information is missing in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_billing_address]: {
    message: {
      internal: 'Biiling Address information is missing in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_street]: {
    message: {
      internal: 'The street information in the address is missing or invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_city]: {
    message: {
      internal: 'The city information is missing in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_state]: {
    message: {
      internal: 'The provided state information is invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_postal_code]: {
    message: {
      internal: 'The provided Postal Code is invalid or missing.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_phone_type]: {
    message: {
      internal: 'The phone type is invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_address_type]: {
    message: {
      internal: 'The provided addressType is invalid in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_name]: {
    message: {
      internal: 'The first or last name is missing or invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_phone]: {
    message: {
      internal: 'The provided phone number is missing or invalid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_token]: {
    message: {
      internal: 'The API accepts service tokens only.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_myvegas_missing_mlife_number]: {
    message: {
      internal: 'The Mlife number is required for Myvegas booking.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_incomplete_profile]: {
    message: {
      internal:
        'Partial or complete profile information is missing in the request.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_redemption_code]: {
    message: {
      internal: 'The redemption code provided is not valid.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_missing_delivery_method]: {
    message: {
      internal: 'No permissible delivery methods were found.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_resend_ticket_not_allowed]: {
    message: {
      internal: 'Resend Ticket is not allowed.',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_address_char_limit_exceeded]: {
    message: {
      internal:
        'Character limit exceeded for one of these fields: state(2), country(8), city(20), streetAddress(40), postalCode(10), email(100), firstName(40), lastName(80), phone(15).',
      public: ''
    },
    type: 'sbs'
  },

  [ShowCodes.sbs_invalid_requets_attributes]: {
    message: {
      internal: 'Invalid or missing request attributes for reservation update.',
      public: ''
    },
    type: 'sbs'
  }
};
