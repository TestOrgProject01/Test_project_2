import { RoomCodes } from '../../codes/service/room';
import { MessageType } from '../../types';

/**
 * RBS error messages
 *
 * These messages map to the currently known service error codes for RBS.
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/681640143/RBS+Error+codes}
 *
 * @public
 */
export const RoomMessages: MessageType<RoomCodes> = {
  [RoomCodes.rbs_unknown]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_request]: {
    message: {
      internal:
        'Please validate if the URL is correct and if all the required parameters have been provided.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_system_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_runtime_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_aurora_exception]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_content_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_source]: {
    message: {
      internal: 'Required source attribute is empty or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_dates_invalid]: {
    message: {
      internal: 'Either the check in or check out date is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_channel]: {
    message: {
      internal: 'Channel header is invalid or empty.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_transaction_id]: {
    message: {
      internal: 'The transactionId is missing in the request header.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_user_inelgible_for_offer]: {
    message: {
      internal: 'Our apologies, but this offer is not available.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_property_id_for_prices]: {
    message: {
      internal: 'Unable to retrieve prices due to an invalid property id.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_guests]: {
    message: {
      internal: 'The number of guests should be greater than 0.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_not_authorized]: {
    message: {
      internal:
        'The authorization token does not contain the scope required to perform this operation.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_token]: {
    message: {
      internal: 'The API accepts service tokens only.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_customer_information]: {
    message: {
      internal:
        'Customer information is mandatory to get perpetual offer information.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_offer_invalid]: {
    message: {
      internal: 'The requested program is not valid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_room_type]: {
    message: {
      internal: 'The provided roomTypeId is missing or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_book_date]: {
    message: {
      internal: 'The booking date provided is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_travel_date]: {
    message: {
      internal: 'The travel date provided is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_property_id]: {
    message: {
      internal: 'The provided propertyId is missing or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_program_id_or_promo_code]: {
    message: {
      internal: 'The programId or promoCode is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_property_id_for_promo_code]: {
    message: {
      internal:
        'The promoCode exists in the request but the required propertyId was not provided.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_program_id]: {
    message: {
      internal: 'The provided programId is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_incomplete_profile]: {
    message: {
      internal:
        'Partial or complete profile information is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_billing_information]: {
    message: {
      internal: 'Billing information is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_billing_address]: {
    message: {
      internal: 'Biiling Address information is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_email]: {
    message: {
      internal: 'The emailAddress is invalid or missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_name]: {
    message: {
      internal: 'The first or last name is missing or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_phone]: {
    message: {
      internal: 'The provided phone number is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_card_number]: {
    message: {
      internal: 'The provided Card Number or Token is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_cart_holder_information]: {
    message: {
      internal: 'The Card holder information is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_street]: {
    message: {
      internal: 'The street information in the address is missing or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_city]: {
    message: {
      internal: 'The city information is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_state]: {
    message: {
      internal: 'The provided state information is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_postal_code]: {
    message: {
      internal: 'The provided Postal Code is invalid or missing.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_itinerary_id]: {
    message: {
      internal: 'The provided itineraryId is missing or invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_trip_details]: {
    message: {
      internal: 'The trip details is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_booking_information_not_available]: {
    message: {
      internal: 'The booking information is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_count_less_than_1_for_party_reservation]: {
    message: {
      internal:
        'The number of rooms should be greater than 1 for a party reservation.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_address_type]: {
    message: {
      internal: 'The provided addressType is invalid in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_customer_id]: {
    message: {
      internal: 'The customerId is missing or invalid in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_routing_instructions]: {
    message: {
      internal: 'The provided routingInstructions is invalid.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_age]: {
    message: {
      internal: 'The age provided is invalid, you must be over 21.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_transaction_not_authorized]: {
    message: {
      internal: 'The transaction is not authorized.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_anti_fraud_unable_to_process]: {
    message: {
      internal: 'Unable to process the transaction.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_functional_exception_occurred]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_payment_authorization_failed]: {
    message: {
      internal:
        'The payment authorization failed, please review your payment information.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_myvegas_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_multi_card_not_allowed_for_party_reservation]: {
    message: {
      internal: 'Multi card payment is not allowed for party reservations.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_not_found]: {
    message: {
      internal: 'The reservation was not found.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_acrs_reservation_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_blacklisted]: {
    message: {
      internal: 'An unexpected problem occurred with your reservation.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_confirmation_number]: {
    message: {
      internal: 'The confirmation number is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_first_name]: {
    message: {
      internal: 'The first name is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_last_name]: {
    message: {
      internal: 'The last name is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_booking_state]: {
    message: {
      internal: 'The booking state is invalid or missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_already_cancelled]: {
    message: {
      internal: 'The given reservation has already been cancelled.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_id_or_confirmation_number_mandatory]: {
    message: {
      internal:
        'Either the reservationId or confirmation number is missing in the request.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_customer_id_or_reservation_params_for_cancelling]: {
    message: {
      internal:
        'Either customerId or reservation params are invalid for cancelling the reservation.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_cannot_be_cancelled]: {
    message: {
      internal: 'Your reservation cannot be cancelled.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_one_or_more_dates_unavailable]: {
    message: {
      internal: 'One of more of the dates selected are not available.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_no_prices_found_for_dates]: {
    message: {
      internal: 'No prices found for dates in specified checkin-checkout range',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_cannot_be_modified]: {
    message: {
      internal: 'The reservation cannot be modified.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_already_cancelled_or_cannot_be_cancelled]: {
    message: {
      internal:
        'The reservation is already cancelled or in status which doesnt support modifications.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_components_not_applicable_for_modification]: {
    message: {
      internal:
        'One or more room components are not applicable for this modification.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_booking_engine_ruke_violation]: {
    message: {
      internal: 'An unexpected error has occured.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_with_1_or_more_comp_nights]: {
    message: {
      internal:
        'Modification not allowed for reservation with 1 or more comp nights.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_with_perpetual_pricing]: {
    message: {
      internal:
        'Modification are not allowed for reservation with perpetual pricing.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_with_multiple_program_pricing]: {
    message: {
      internal:
        'Modification are not allowed for reservation with multiple program pricing.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_missing_credit_card]: {
    message: {
      internal:
        'Modification are not allowed for reservations with no credit card on file.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_within_forfeit_window]: {
    message: {
      internal:
        'Modifications are not allowed for reservations within the forfeit window.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_modification_not_allowed_without_preview_total_and_deposit]: {
    message: {
      internal:
        'Modifications are not allowed without a preview total and deposit.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_price_changed_requires_review]: {
    message: {
      internal: 'A price change has been detected please review.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_cvv_required]: {
    message: {
      internal: 'A CVV is mandatory for updates to change in deposits.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_confirmation_number_or_opera_code]: {
    message: {
      internal:
        'Either the confirmation number or opera party code is mandatory.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_mandatory_search_criteria]: {
    message: {
      internal: 'At least one mandatory Search criterion must be used.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_invalid_start_date]: {
    message: {
      internal: 'The selected endDate must be after the chosen startDate.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_searching_group_failure]: {
    message: {
      internal: 'A failure occurred while searching groups.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_missing_confirmation_number_associate]: {
    message: {
      internal: 'The confirmation number is missing.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_reservation_already_associated]: {
    message: {
      internal: 'An unexpected problem has occured.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_association_mismatch]: {
    message: {
      internal: 'The provided firstName and lastName do match the reservation.',
      public: ''
    },
    type: 'rbs'
  },

  [RoomCodes.rbs_service_token_unsupported]: {
    message: {
      internal: 'The provided service token not supported.',
      public: ''
    },
    type: 'rbs'
  }
};
