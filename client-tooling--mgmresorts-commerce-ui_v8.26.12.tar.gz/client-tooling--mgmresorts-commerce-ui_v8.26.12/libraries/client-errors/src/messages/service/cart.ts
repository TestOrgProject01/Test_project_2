import { CartCodes } from '../../codes';
import { MessageType } from '../../types';

/**
 * Cart error messages
 *
 * These messages map to the currently known service error codes.
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/CA/pages/1190855658/Cart-Service+Error+Codes}
 *
 * @public
 */
export const CartMessages: MessageType<CartCodes> = {
  [CartCodes.cart_unknown]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_unexpected_problem]: {
    message: {
      internal: 'Something unexpected happened in the system.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_service_call_failed]: {
    message: {
      internal: 'Unable to complete call to cart service.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_request_or_payload]: {
    message: {
      internal: 'Invalid request or payload data.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_parameters_or_resource]: {
    message: {
      internal: 'Invalid parameters or resource not found.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_mandatory_information]: {
    message: {
      internal: 'Missing mandatory information in the service request.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_downstream_system_issue]: {
    message: {
      internal:
        'System is not permitting further requests because of downstream system issues.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_cart_id]: {
    message: {
      internal: 'No cart found with the specified id.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_removal_invalid_product_key]: {
    message: {
      internal:
        'Removal of the cart product failed due to an invalid product key.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_unable_to_add_room]: {
    message: {
      internal:
        'Unable to add room product to cart. Duration between check-in/check-out dates exceeds permitted values',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_product_field]: {
    message: {
      internal: 'One of the product fields is either wrong or missing.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_last_price_changed]: {
    message: {
      internal: 'There is a price mismatch calculation, please review.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_multiple_patron_promos_not_allowed]: {
    message: {
      internal:
        'Adding multiple Patron Promos in the same cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_user_not_authorized]: {
    message: {
      internal: 'User is not authorized to access this cart.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_resource]: {
    message: {
      internal: 'Invalid parameters or resource not found.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_two_customer_carts_merge_forbidden]: {
    message: {
      internal:
        'The logged in user attempted to merge a cart associated to a different mgmId than their own mgmId.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_reservation_release_failed]: {
    message: {
      internal:
        'Reservation release failed for reservation with confirmation number.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_unable_to_update_agentinfo]: {
    message: {
      internal: 'The IATA agent id validation failed during cart update.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_room_program_invalid]: {
    message: {
      internal: 'The program offer applied to the room is not valid.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_room_program_expired]: {
    message: {
      internal: 'The program offer applied to the room has expired.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_room_program_ineligible]: {
    message: {
      internal:
        'The user attempted to apply a program offer that they are not eligible for.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_redemption_code_invalid]: {
    message: {
      internal: 'The redemption code is not valid.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_redemption_code_expired]: {
    message: {
      internal: 'The redemption code is expired.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_redemption_code_inelgible]: {
    message: {
      internal: 'The redemption code is not eligible.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_redemption_code_already_redeemed]: {
    message: {
      internal: 'The redemption code requested has already been redeemed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_max_items_reached]: {
    message: {
      internal: 'Unable to add more item to cart! Max items reached.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_max_rooms_reached]: {
    message: {
      internal: 'Unable to add more room item to cart! Max room items reached.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_max_shows_reached]: {
    message: {
      internal: 'Unable to add more show item to cart! Max show items reached.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_max_others_reached]: {
    message: {
      internal:
        'Unable to add more others item to cart! Max cart line items reached for any type other than Room or Show items.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_unable_to_hold_product]: {
    message: {
      internal: 'A request to hold the product failed.',
      public: ''
    },
    relatedCodes: [
      'rbs_invalid_room_type',
      'rbs_invalid_room_type',
      'rbs_invalid_property_id',
      'rbs_invalid_program_id',
      'rbs_system_error',
      'rbs_no_prices_found_for_dates',
      'rbs_acrs_reservation_error'
    ],
    type: 'cart'
  },

  [CartCodes.cart_unable_to_add_product]: {
    message: {
      internal: 'Unable to add product. The response from RBS was null.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_multiple_myvegas_promos_not_allowed]: {
    message: {
      internal:
        'Adding multiple MyVegas promos in the same cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_jwb_forbidden_for_member]: {
    message: {
      internal: 'Join while booking is forbidden for a logged in customer.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_multiple_promo_codes_not_allowed]: {
    message: {
      internal:
        'Adding multiple Promos/Promo Code in the same cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_program_invalid]: {
    message: {
      internal: 'The program offer for this Show is not valid.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_program_expired]: {
    message: {
      internal: 'The program offer for this Show has expired.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_program_ineligible]: {
    message: {
      internal: 'The program offer for this Show is not eligible.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_acquire_token_failure]: {
    message: {
      internal: 'Failed to acquire a token from identity service.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_unable_to_hold_show_seats]: {
    message: {
      internal: 'Unable to hold seats for the selected show.',
      public: ''
    },
    relatedCodes: [
      'sbs_missing_show_ticket_fields',
      'sbs_event_has_no_available_seats',
      'sbs_requested_min_max_ticket_mismatch',
      'sbs_program_no_results'
    ],
    type: 'cart'
  },

  [CartCodes.cart_shows_unable_to_release_seats]: {
    message: {
      internal: 'Unable to release seats for the selected show.',
      public: ''
    },
    relatedCodes: ['sbs_archtics_exception', 'sbs_missing_or_invalid_hold_id'],
    type: 'cart'
  },

  [CartCodes.cart_package_config_inactive]: {
    message: {
      internal: 'The package config is not active.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_program_and_package_show_program_mismatch]: {
    message: {
      internal:
        'The programId passed in the request for the Show does not match the Show programId returned from content api call.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_event_date_and_package_event_date_mismatch]: {
    message: {
      internal:
        'The showEventDate passed in the request for the Show does not match the show event date returned from content api call.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_package_config]: {
    message: {
      internal: 'The package config details is not found.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_package_id_for_package_show_program]: {
    message: {
      internal: 'The packageId is not provided for a package Show program.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_non_package_product_in_package_cart_disallowed]: {
    message: {
      internal: 'Adding non package product to package cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_only_one_show_product_allowed_in_package_cart]: {
    message: {
      internal:
        'Adding more than one show product to package cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_wrong_cart_type_for_package_product_items]: {
    message: {
      internal: 'Cart type should be PACKAGE for package product items.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_removal_from_package_unsupported]: {
    message: {
      internal:
        'Removal of a Show product from a Show package is not supported',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_package_id_for_room_program]: {
    message: {
      internal: 'The packageId is not provided for a package room program.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_multiple_room_products_to_package_cart_not_allowed]: {
    message: {
      internal:
        'Adding more than one room product to a package cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_room_segment_and_package_segment_mismatch]: {
    message: {
      internal:
        'The associated Room program segment does not match the package config segment.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_segment_details_for_room_program]: {
    message: {
      internal: 'The segment details is not found for the room program.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_package_show_item]: {
    message: {
      internal: 'The package show item is not found in the cart.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_package_id_for_room_and_show_mismatch]: {
    message: {
      internal:
        'The packageId for the Room program does not match with show product packageId.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_member_offer_only]: {
    message: {
      internal: 'Only aan authenticated user can use this offer.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_missing_myvegas_code]: {
    message: {
      internal:
        'A MyVegas redemption code was not passed for program type MyVegas.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_not_allowed_to_merge_cart_types]: {
    message: {
      internal: 'One cart type is not allowed to merge in to another.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_input]: {
    message: {
      internal: 'Invalid input at Cart ID or Line Item ID.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_type_mismatch]: {
    message: {
      internal:
        'Mismatch between the cart type provided in the request and the cart type of the retrieved cart.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_show_season_unavailable]: {
    message: {
      internal: 'The requested Show season is unavailable.',
      public: ''
    },
    // relatedCodes: ['620-2-255'], // XXX - sbs missing
    type: 'cart'
  },

  [CartCodes.cart_show_event_unavailable]: {
    message: {
      internal: 'The requested Show event is not available.',
      public: ''
    },
    relatedCodes: ['sbs_show_unavailable'],
    type: 'cart'
  },

  [CartCodes.cart_show_seats_unavailable]: {
    message: {
      internal: 'The seats for this Show event are no longer available,',
      public: ''
    },
    relatedCodes: ['sbs_show_seats_unvailable'],
    type: 'cart'
  },

  [CartCodes.cart_package_show_programs_update_fail]: {
    message: {
      internal: 'Package show programs cannot be updated.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_invalid_cart_type]: {
    message: {
      internal: 'Invalid cart type. It should be either GLOBAL or PACKAGE.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_room_group_and_package_group_mismatch]: {
    message: {
      internal:
        'The associated room group block does not match with a package config group block.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_dining_product_not_allowed_in_package_cart]: {
    message: {
      internal: 'Adding a Dining product to a package cart is not allowed.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_restaurant_not_found_with_dining_reservation]: {
    message: {
      internal:
        'The restaurant was not found when the dining reservation was requested.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_reprice_with_timer_extension_has_price_expired]: {
    message: {
      internal:
        'The cart was repriced with a timer extension but at least one item is in the Price Expired state.',
      public: ''
    },
    type: 'cart'
  },

  [CartCodes.cart_upsell_item]: {
    message: {
      internal: 'Upsell is not available for package carts.',
      public: ''
    },
    type: 'cart'
  }
};
