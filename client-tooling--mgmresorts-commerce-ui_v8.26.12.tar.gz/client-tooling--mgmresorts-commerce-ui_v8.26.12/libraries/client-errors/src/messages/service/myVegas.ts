import { MyVegasCodes } from '../../codes/service/myVegas';
import { MessageType } from '../../types';

/**
 * MyVegas error messages
 *
 * These messages map to the currently known service error codes.
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/922190115/My+Vegas+Error+codes}
 *
 * @public
 */
export const MyVegasMessages: MessageType<MyVegasCodes> = {
  [MyVegasCodes.myvegas_invalid_request]: {
    message: {
      internal:
        'Please validate if the URL is correct and if all the required parameters have been provided.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_system_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_runtime_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_authorization_error]: {
    message: {
      internal: 'An authorization error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_channel]: {
    message: {
      internal: 'Channel header is invalid or empty.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_transaction_id]: {
    message: {
      internal: 'The transactionId is missing in the request header.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_redemption_in_progress]: {
    message: {
      internal: 'Redemption of the requested code is currently in progress.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_redemption_code]: {
    message: {
      internal: 'The redemption code is missing.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_user_inelgible_for_offer]: {
    message: {
      internal: 'The current user is not eligible for the offer.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_offer_not_available]: {
    message: {
      internal: 'The requested offer is not available.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_data]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_unknown_code]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_general_redemption_error]: {
    message: {
      internal: 'An unexpected error has occurred.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_fields]: {
    message: {
      internal: 'There are required fields missing in the request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_product]: {
    message: {
      internal: 'Reward for other than a room or show is being redeemed.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_already_redeemed]: {
    message: {
      internal: 'This code has already been redeemed.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_date]: {
    message: {
      internal: 'The reservation date is invalid.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_expired]: {
    message: {
      internal: 'The redemption code has expired.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_cancelled]: {
    message: {
      internal: 'The redemption code has been cancelled.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_in_refund]: {
    message: {
      internal: 'The redemption code is in refund request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_refunded]: {
    message: {
      internal: 'The redemption code has bee nrefunded refunded.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_gifted]: {
    message: {
      internal: 'The redemption code has been gifted.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_pending_email_confirmation]: {
    message: {
      internal: 'The email confirmation for the redemption is pending.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_on_hold]: {
    message: {
      internal: 'The redemption code is on hold.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_gifted_and_on_hold]: {
    message: {
      internal: 'The redemption code is gifted and on hold.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_code_unclaimed]: {
    message: {
      internal: 'The redemption code is unclaimed.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_code]: {
    message: {
      internal:
        'No redemption details returned. Verify redemption code and retry.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_coupon_code]: {
    message: {
      internal: 'The required coupon code is missing.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_confirmation_number]: {
    message: {
      internal: 'The confirmation number is missing.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_or_missing_date]: {
    message: {
      internal: 'Thge reservation date is invalid or missing.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_customer_information]: {
    message: {
      internal: 'The customer details are missing in the request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_first_name]: {
    message: {
      internal: 'The first name is missing in the request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_last_name]: {
    message: {
      internal: 'The last name is missing in the request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_invalid_dob]: {
    message: {
      internal:
        'The customers date of birth is invalid or missing in the request.',
      public: ''
    },
    type: 'myvegas'
  },

  [MyVegasCodes.myvegas_missing_member_id]: {
    message: {
      internal: 'The customers memberId is missing in the request.',
      public: ''
    },
    type: 'myvegas'
  }
};
