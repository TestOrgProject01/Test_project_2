/**
 * Cart error codes
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/CA/pages/1190855658/Cart-Service+Error+Codes}
 *
 * @public
 */
export enum CartCodes {
  cart_unknown = 'Unknown', // An unknown error has occurred
  cart_unexpected_problem = '123-0-1000', // Something unexpected happened in the system
  cart_service_call_failed = '123-0-1004', // Unable to complete backend call
  cart_invalid_request_or_payload = '123-1-1015', // Invalid request or payload data
  cart_invalid_parameters_or_resource = '123-1-1016', // Invalid parameters or resource not found
  cart_missing_mandatory_information = '123-1-1018', // Missing mandatory information in the request: check request
  cart_downstream_system_issue = '123-0-1023', // System is not permitting further requests because of downstream system issues
  cart_invalid_cart_id = '123-2-3001', // No cart found with cart id
  cart_removal_invalid_product_key = '123-2-3002', // No product found in the cart with key
  cart_unable_to_add_room = '123-2-3004', // Unable to add product [Could not validate room reservation hold.
  cart_invalid_product_field = '123-1-3005', // One of the product field is either wrong or missing {customer message}
  cart_last_price_changed = '123-1-3006', // Last price has been changed, please review the price again
  cart_multiple_patron_promos_not_allowed = '123-1-3007', // Adding multiple Patron Promos in the same cart is not allowed.
  cart_user_not_authorized = '123-2-3008', // User is not authorized to access this cart
  cart_invalid_resource = '123-3-3009', // Invalid parameters or resource not found {resource key/id}
  cart_two_customer_carts_merge_forbidden = '123-1-3011', // It is forbidden to merge the two customer carts
  cart_reservation_release_failed = '123-3-3012', // Reservation release failed for reservation with confirmation number
  cart_unable_to_update_agentinfo = '123-2-3013', // Unable to update the cart's AgentInfo Field.
  cart_room_program_invalid = '123-2-3014', // The room program offer is not valid.
  cart_room_program_expired = '123-2-3015', // The room program offer is expired.
  cart_room_program_ineligible = '123-2-3016', // The room program offer is not eligible.
  cart_redemption_code_invalid = '123-2-3017', // The redemption code is not valid.
  cart_redemption_code_expired = '123-2-3018', // The redemption code is expired
  cart_redemption_code_inelgible = '123-2-3019', // The redemption code is not eligible
  cart_redemption_code_already_redeemed = '123-2-3020', // The redemption code has already been redeemed
  cart_max_items_reached = '123-1-3021', // Unable to add more item to cart! Max item reached.
  cart_max_rooms_reached = '123-1-3022', // Unable to add more room item to cart! Max room item reached
  cart_max_shows_reached = '123-1-3023', // Unable to add more show item to cart! Max show item reached
  cart_max_others_reached = '123-1-3024', // Unable to add more others item to cart! Max others item reached
  cart_unable_to_hold_product = '123-2-3025', // Unable to hold product.
  cart_unable_to_add_product = '123-2-3026', // Unable to add product.
  cart_multiple_myvegas_promos_not_allowed = '123-1-3027', // Adding multiple MyVegas Promos in the same cart is not allowed.
  cart_jwb_forbidden_for_member = '123-1-3029', // Join while booking is forbidden for a logged in customer.
  cart_multiple_promo_codes_not_allowed = '123-1-3030', // Adding multiple Promos/Promo Code in the same cart is not allowed.
  cart_show_program_invalid = '123-2-3031', // The show program offer is not valid.
  cart_show_program_expired = '123-2-3032', // The show program offer is expired.
  cart_show_program_ineligible = '123-2-3033', // The show program offer is not eligible
  cart_acquire_token_failure = '123-3-3034', // Failed to acquire a token
  cart_unable_to_hold_show_seats = '123-2-3035', // Unable to hold seats for the selected show
  cart_shows_unable_to_release_seats = '123-2-3036', // Unable to release seats for the selected show.
  cart_package_config_inactive = '123-1-3038', // The package config is not active.
  cart_show_program_and_package_show_program_mismatch = '123-1-3039', // The input show program does not match with package config show program.
  cart_show_event_date_and_package_event_date_mismatch = '123-1-3040', // The input show event date does not match with package config show event date.
  cart_missing_package_config = '123-1-3041', // The package config details is not found.
  cart_missing_package_id_for_package_show_program = '123-1-3042', // The packageId is not provided for a package show program.
  cart_non_package_product_in_package_cart_disallowed = '123-2-3043', // Adding non package product to package cart is not allowed.
  cart_only_one_show_product_allowed_in_package_cart = '123-2-3044', // Adding more than one show product to package cart is not allowed.
  cart_wrong_cart_type_for_package_product_items = '123-2-3045', // Cart type should be PACKAGE for package product items.
  cart_show_removal_from_package_unsupported = '123-2-3046', // Show removal from a package is not supported
  cart_missing_package_id_for_room_program = '123-1-3047', // The packageId is not provided for a package room program.
  cart_multiple_room_products_to_package_cart_not_allowed = '123-2-3048', // Adding more than one room product to package cart is not allowed.
  cart_room_segment_and_package_segment_mismatch = '123-2-3050', // The associated input room program segment not match with package config segment.
  cart_missing_segment_details_for_room_program = '123-2-3051', // The segment details is not found for input room program.
  cart_missing_package_show_item = '123-2-3052', // The package show item is not found in cart.
  cart_package_id_for_room_and_show_mismatch = '123-2-3053', // The packageId for input room program not match with show product packageId.
  cart_member_offer_only = '123-2-3054', // Only a logged in user can use this offer
  cart_missing_myvegas_code = '123-2-3055', // MyVegas redemption code is not passed for program type MyVegas.
  cart_not_allowed_to_merge_cart_types = '123-2-3056', // One cart type is not allowed to merge in to another.
  cart_invalid_input = '123-1-3057', // Invalid input at {{cart id or line item id}}
  cart_type_mismatch = '123-2-3058', // One cart type is not allowed to read a cart of another cart type
  cart_show_season_unavailable = '123-2-3059', // Show season is unavailable
  cart_show_event_unavailable = '123-2-3060', // Show event is not available.
  cart_show_seats_unavailable = '123-2-3061', // Seats for Show Event are no longer available
  cart_package_show_programs_update_fail = '123-2-3062', // Package show programs cannot be updated
  cart_invalid_cart_type = '123-2-3063', // Invalid cart type. It should be either GLOBAL or PACKAGE.
  cart_room_group_and_package_group_mismatch = '123-2-3064', // The associated room group block does not match with package config group block
  cart_dining_product_not_allowed_in_package_cart = '123-2-3065', // If a dining product is being added to a PACKAGE cart.
  cart_restaurant_not_found_with_dining_reservation = '123-2-3066', // If a restaurant is not found when dining reservation is being called.
  cart_reprice_with_timer_extension_has_price_expired = '123-2-3068', // If a cart is repriced with timer extension but at least one item is in the Price Expired state.
  cart_upsell_item = '123-2-3069' // If addition of an upsell item is happening in a package cart.
}
