/**
 * SBS error codes
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/1819247351/SBS+Error+codes}
 *
 * @public
 */
export enum ShowCodes {
  sbs_unknown = 'Unknown', // An unknown error has occurred
  sbs_invalid_request = '620-1-400', // Please validate if the URL is correct and if all the required parameters have been provided.
  sbs_exception = '620-2-xyz', // General Business Exceptions mostly due to business logic contradiction in external systems like content api. Can be a range of exceptions.
  sbs_system_error = '620-3-101', // _system_error
  sbs_runtime_error = '620-3-102', // _runtime_error
  sbs_authorization_error = '620-7-103', // _authorization_error_
  sbs_invalid_source = '620-1-112', // Source is mandatory in the request object.
  sbs_invalid_channel = '620-1-113', // Channel is mandatory in the request object
  sbs_missing_transaction_id = '620-1-114', // Transaction id is mandatory in the request object
  sbs_missing_program_id_or_property_id = '620-1-231', // Program Id and Property Id is mandatory in the request
  sbs_event_not_on_sale = '620-2-256', // Event is not on sale.
  sbs_program_no_results = '620-2-107', // getShowProgram | no results available
  sbs_show_event_id_invalid = '620-1-122', // Show Event ID is invalid
  sbs_missing_property_id = '620-1-230', // Property id is missing
  sbs_show_id_or_program_id_or_season_id_invalid = '620-1-121', // Show Id or Program Id or Season Id is either missing or invalid in the request
  sbs_events_missing_start_date = '620-1-229', // Start date is not provided
  sbs_events_missing_end_date_or_limit = '620-1-255', // End date or limit is not provided
  sbs_missing_reservation_fields = '620-1-227', // confirmation number along with first name/last name or guest token is mandatory to fetch reservation
  sbs_reservation_not_found = '620-2-214', // reservation_not_found Not able to retrive reservation with given information
  sbs_mirage_reservation = '620-2-901', // This reservation is for The Mirage which has been migrated to a different entity
  sbs_tickets_not_found_for_reservation = '620-2-260', // Tickets not found for the reservation. Reservation might have been cancelled
  sbs_missing_tickets = '620-1-201', // No tickets in the ticket list
  sbs_missing_show_ticket_fields = '620-1-202', // Show Event id, Price Code, Ticket Type Code, Seat, Row and Section are required for a ticket
  sbs_event_has_no_available_seats = '620-2-139', // <_event_not_available>[ Seats requested is not available and there are no other available seats for the event ]
  sbs_requested_min_max_ticket_mismatch = '620-1-250', // Tickets requested do not match the min and max limit setup at the Show or Program level
  sbs_invalid_program_id = '620-1-124', // Program Id is invalid
  sbs_archtics_exception = '620-2-106', // Errors from Archtics which are unrelated to seats not being available
  sbs_offer_inelgible_for_user = '620-2-123', // <_offer_not_eligible>[ User is not eligible for the offer ]
  sbs_show_seats_unvailable = '620-2-253', // _show_seats_unavailable
  sbs_show_unavailable = '620-2-254', // _show_unavailable
  sbs_program_multiple_exception = '620-1-257', // Some programs have restrictions in place for the tickets to be booked only when they are a multiple of configured/specified number. Validation Error is expected when trying to reserve seats that are not a multiple of this configured/specified number.
  sbs_missing_or_invalid_hold_id = '620-1-206', // No hold id or invalid hold id in the list
  sbs_invalid_event_date = '620-1-226', // Event date is invalid
  sbs_total_price_mismatch = '620-1-211', // Base Price and Tax do not add up to Total Amount
  sbs_archtics_invalid_delivery_method = '620-1-212', // Delivery method set in show ticket is invalid or not permitted (by Archtics) for the ticket
  sbs_invalid_payment_card = '620-2-258', // Not supported paymentCard: abcd
  sbs_invalid_email = '620-1-215', // Email address is invalid or missing
  sbs_invalid_billing_information = '620-1-244', // Billing Details is missing or invalid
  sbs_missing_billing_address = '620-1-218', // Biiling Address information is missing
  sbs_missing_street = '620-1-219', // Street info in address is missing or invalid
  sbs_missing_city = '620-1-220', // City information is missing
  sbs_missing_state = '620-1-221', // State information is invalid
  sbs_missing_postal_code = '620-1-223', // Postal Code is invalid or missing
  sbs_invalid_phone_type = '620-1-224', // Invalid phone type
  sbs_invalid_address_type = '620-1-225', // Invalid address type
  sbs_invalid_name = '620-1-216', // Invalid/missing first name or last name
  sbs_invalid_phone = '620-1-217', // User phone is missing or invalid
  sbs_invalid_token = '620-1-243', // API accepts service tokens only
  sbs_myvegas_missing_mlife_number = '620-1-245', // Mlife Number is required for Myvegas booking
  sbs_incomplete_profile = '620-1-246', // Customer profile is invalid or missing
  sbs_invalid_redemption_code = '620-1-247', // Redemption code provided is not valid
  sbs_missing_delivery_method = '620-2-248', // No permissible delivery methods were found
  sbs_resend_ticket_not_allowed = '620-1-249', // Resend Ticket is not allowed
  sbs_address_char_limit_exceeded = '620-1-252', // Character limit exceeded for one of these fields: state(2), country(8), city(20), streetAddress(40), postalCode(10), email(100), firstName(40), lastName(80), phone(15).
  sbs_invalid_requets_attributes = '620-1-251' // Invalid or missing request attributes for reservation update.
}
