/**
 * RBS error codes
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/681640143/RBS+Error+codes}
 *
 * @public
 */
export enum RoomCodes {
  rbs_unknown = 'Unknown', // An unknown error has occurred
  rbs_invalid_request = '632-1-400', // Please validate if the URL is correct and if all the required parameters have been provided.
  rbs_system_error = '632-3-101', // _system_error
  rbs_runtime_error = '632-3-102', // _runtime_error
  rbs_aurora_exception = '632-3-103', // _aurora_exception
  rbs_content_error = '632-3-267', // content_error
  rbs_invalid_source = '632-1-104', // Required source attribute is empty or invalid.
  rbs_dates_invalid = '632-1-107', // CheckIn/Start or CheckOut/end date is invalid
  rbs_invalid_channel = '632-1-108', // Channel header is invalid or empty.
  rbs_missing_transaction_id = '632-1-233', // Transaction Id is mandatory in request header.
  rbs_user_inelgible_for_offer = '632-2-111', // User is not eligible for the offer
  rbs_invalid_property_id_for_prices = '632-1-109', // No property id or invalid property id to retrieve prices
  rbs_invalid_guests = '632-1-216', // numAdults/numGuests should be > 0
  rbs_not_authorized = '632-7-241', // The authorization token does not contain the scope required to perform this operation
  rbs_invalid_token = '632-7-268', // API accepts service tokens only
  rbs_missing_customer_information = '632-1-113', // Customer information is mandatory to get perpetual offer info
  rbs_offer_invalid = '632-2-110', // Offer is not available or invalid
  rbs_invalid_room_type = '632-1-114', // No room type id or invalid room type provided
  rbs_invalid_book_date = '632-1-217', // Book date is invalid
  rbs_invalid_travel_date = '632-1-218', // Travel date is invalid
  rbs_invalid_property_id = '632-1-220', // No property id or invalid property provided
  rbs_missing_program_id_or_promo_code = '632-1-105', // No program id or promo code
  rbs_missing_property_id_for_promo_code = '632-1-106', // No property id for promo code
  rbs_invalid_program_id = '632-1-181', // Program Id is missing or has an invalid format
  rbs_incomplete_profile = '632-1-120', // Partial or complete profile information is missing
  rbs_invalid_billing_information = '632-1-121', // Billing information not available
  rbs_missing_billing_address = '632-1-123', // Biiling Address information is missing
  rbs_invalid_email = '632-1-124', // Email address is invalid or missing
  rbs_invalid_name = '632-1-125', // Invalid/missing first name or last name
  rbs_invalid_phone = '632-1-126', // User phone is missing or invalid
  rbs_missing_card_number = '632-1-127', // Card Number/Token is missing
  rbs_invalid_cart_holder_information = '632-1-130', // Card holder information is missing
  rbs_missing_street = '632-1-135', // Street info in address is missing or invalid
  rbs_missing_city = '632-1-136', // City information is missing
  rbs_missing_state = '632-1-137', // State information is invalid
  rbs_missing_postal_code = '632-1-139', // Postal Code is invalid or missing
  rbs_invalid_itinerary_id = '632-1-219', // No itinerary id or invalid itinerary id provided
  rbs_missing_trip_details = '632-1-221', // Trip details not available
  rbs_booking_information_not_available = '632-1-223', // Bookings information not available
  rbs_count_less_than_1_for_party_reservation = '632-1-227', // numRooms should be > 1 for party reservation
  rbs_invalid_address_type = '632-1-229', // Invalid address type
  rbs_invalid_customer_id = '632-1-231', // Customer Id is invalid or missing
  rbs_invalid_routing_instructions = '632-1-234', // Invalid routingInstructions
  rbs_invalid_age = '632-1-244', // Invalid age. It should be over 21.
  rbs_transaction_not_authorized = '632-2-159', // The transaction is not authorized
  rbs_anti_fraud_unable_to_process = '632-2-160', // Anti-fraud service returned unable to process the transaction
  rbs_functional_exception_occurred = '632-2-242', // Functional exception occurred in the backend system.
  rbs_payment_authorization_failed = '632-2-243', // Payment authorization failed
  rbs_myvegas_error = '632-2-248', // _myvegas_backend_error
  rbs_multi_card_not_allowed_for_party_reservation = '632-1-230', // Multi card payment is not allowed for party reservations
  rbs_reservation_not_found = '632-2-140', // Reservation not found
  rbs_acrs_reservation_error = '632-2-142', // General reservation error -propagates backend ACRS errors
  rbs_reservation_blacklisted = '632-2-235', // Reservation blacklisted for retrieval by requesting channel
  rbs_missing_confirmation_number = '632-1-143', // No confirmation number
  rbs_missing_first_name = '632-1-144', // First name is missing
  rbs_missing_last_name = '632-1-145', // Last name is missing
  rbs_invalid_booking_state = '632-1-232', // Booking state is invalid or missing
  rbs_reservation_already_cancelled = '632-2-224', // The given reservation is already in cancelled state.
  rbs_reservation_id_or_confirmation_number_mandatory = '632-2-225', // Either reservation id or confirmation number is mandatory.
  rbs_invalid_customer_id_or_reservation_params_for_cancelling = '632-2-226', // Either customerId or reservation params are invalid for cancelling the reservation.
  rbs_reservation_cannot_be_cancelled = '632-2-266', // Reservation cannot be cancelled
  rbs_one_or_more_dates_unavailable = '632-2-146', // One of more dates are not available
  rbs_no_prices_found_for_dates = '632-2-147', // No prices found for dates in specified checkin-checkout range
  rbs_reservation_cannot_be_modified = '632-2-246', // Reservation cannot be modified
  rbs_reservation_already_cancelled_or_cannot_be_cancelled = '632-2-250', // Reservation is already cancelled or in status which doesn't support modifications
  rbs_components_not_applicable_for_modification = '632-2-251', // One or more components are not applicable for this modification
  rbs_booking_engine_ruke_violation = '632-2-252', // Booking engine reported unexpected business rule violations
  rbs_modification_not_allowed_with_1_or_more_comp_nights = '632-2-253', // Modification not allowed for reservation with 1 or more comp nights
  rbs_modification_not_allowed_with_perpetual_pricing = '632-2-254', // Modification not allowed for reservation with perpetual pricing
  rbs_modification_not_allowed_with_multiple_program_pricing = '632-2-255', // Modification not allowed for reservation with multiple program pricing
  rbs_modification_not_allowed_missing_credit_card = '632-2-256', // Modification not allowed for reservation with no credit card on file
  rbs_modification_not_allowed_within_forfeit_window = '632-2-257', // Modification not allowed for reservation within forfeit window
  rbs_modification_not_allowed_without_preview_total_and_deposit = '632-1-258', // Modification not allowed without preview total and deposit
  rbs_price_changed_requires_review = '632-2-259', // Price change detected since preview. Updated price should be reviewed by the user
  rbs_cvv_required = '632-2-260', // CVV is mandatory for updates with change in deposits
  rbs_missing_confirmation_number_or_opera_code = '632-1-222', // Either confirmation number or opera party code is mandatory. Not both.
  rbs_missing_mandatory_search_criteria = '632-1-209', // At least one mandatory Search criterion must be used
  rbs_invalid_start_date = '632-1-210', // Start Date must be older or equal to End Date
  rbs_searching_group_failure = '632-2-211', // Failure while searching group
  rbs_missing_confirmation_number_associate = '632-1-265', // No confirmation number
  rbs_reservation_already_associated = '632-2-262', // Association not allowed as the reservation is already associated
  rbs_association_mismatch = '632-2-264', // Association not allowed due to name mismatch
  rbs_service_token_unsupported = '632-1-263' // Service token not supported
}
