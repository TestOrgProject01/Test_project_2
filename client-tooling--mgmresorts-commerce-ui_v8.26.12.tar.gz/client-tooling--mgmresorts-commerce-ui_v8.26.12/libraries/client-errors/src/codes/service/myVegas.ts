/**
 * MyVegas error codes
 *
 * {@link https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/922190115/My+Vegas+Error+codes}
 *
 * @public
 */
export enum MyVegasCodes {
  myvegas_invalid_request = '635-1-400', // If URL is incorrect or mandatory params are missing
  myvegas_system_error = '635-3-101', // General system errors mostly due to upstream system failures
  myvegas_runtime_error = '635-3-102', // Runtime errors due to upstream system failures
  myvegas_authorization_error = '635-3-103', // Authorization header is invalid or missing
  myvegas_invalid_channel = '635-3-104', // Channel header is invalid or empty
  myvegas_missing_transaction_id = '635-3-105', // Transaction Id is mandatory in request header
  myvegas_redemption_in_progress = '635-3-108', // Redemption of the code is currently in progress
  myvegas_missing_redemption_code = '635-3-110', // Redemption code is missing
  myvegas_user_inelgible_for_offer = '635-2-109', // User is not eligible for the offer
  myvegas_offer_not_available = '635-2-120', // Offer not available
  myvegas_missing_data = '635-2-121', // No Data retrieved message
  myvegas_unknown_code = '635-2-122', // General redemption code error message (Unknown redemption code)
  myvegas_general_redemption_error = '635-2-123', // General redemption code error message (3 in 30 violation)
  myvegas_missing_fields = '635-2-124', // No Data retrieved message (Required data fields missing)
  myvegas_invalid_product = '635-2-125', // No Data retrieved message (reward for other than a room or show being redeemed)
  myvegas_already_redeemed = '635-2-126', // Already Redeemed message
  myvegas_invalid_date = '635-2-127', // No Data retrieved message (Invalid Reservation Date)
  myvegas_code_expired = '635-2-128', // Redemption code expired
  myvegas_code_cancelled = '635-2-129', // Redemption code cancelled
  myvegas_code_in_refund = '635-2-130', // Redemption code in refund request
  myvegas_code_refunded = '635-2-131', // Redemption code refunded
  myvegas_code_gifted = '635-2-132', // Redemption code gifted
  myvegas_pending_email_confirmation = '635-2-133', // Email confirmation for redemption is pending
  myvegas_code_on_hold = '635-2-134', // Redemption code is on hold
  myvegas_code_gifted_and_on_hold = '635-2-135', // Redemption code is gifted and on hold
  myvegas_code_unclaimed = '635-2-136', // Redemption code is unclaimed
  myvegas_invalid_code = '635-2-138', // No redemption details returned. Verify redemption code and retry
  myvegas_missing_coupon_code = '635-1-111', // Coupon code is missing
  myvegas_missing_confirmation_number = '635-1-112', // Confirmation number is missing
  myvegas_invalid_or_missing_date = '635-1-113', // Reservation date is invalid or missing
  myvegas_missing_customer_information = '635-1-114', // Customer Details are missing
  myvegas_missing_first_name = '635-1-115', // Customer's first name is missing
  myvegas_missing_last_name = '635-1-116', // Customer's last name is missing
  myvegas_invalid_dob = '635-1-117', // Customer's date of birth is invalid or missing
  myvegas_missing_member_id = '635-1-118' // Customer's membership Id is missing
}
