import { getErrorDomain } from './getErrorDomain';
import { getErrorType } from './getErrorType';

describe('utils', () => {
  describe('getErrorDomain', () => {
    it('should return the correct domain for error code', () => {
      const domain = getErrorDomain('620-6-453');
      expect(domain).toEqual('sbs');
    });
  });

  describe('getErrorType', () => {
    it('should return the correct type for error code', () => {
      const type = getErrorType('620-4-453');
      expect(type).toEqual('authentication');
    });
  });
});
