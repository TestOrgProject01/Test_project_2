import { slice } from 'rambdax';

import { ServiceErrorType } from '../types';

/**
 * Retreive the error type based on provided error code.
 *
 * @example
 * ```ts
 * getErrorType('620-1-123')
 * // => 'validation'
 * ```
 *
 * @public
 */
export const getErrorType = (code: string) => {
  const errorType = slice(4, 5, code) as keyof typeof ServiceErrorType;

  return ServiceErrorType[errorType] ?? 'unknown';
};
