import { slice } from 'rambdax';

import { ServiceErrorDomainCode } from '../types';

/**
 * Retreive the API service based on provided error code.
 *
 * @example
 * ```ts
 * getErrorDomain('620-1-123')
 * // => 'sbs'
 * ```
 *
 * @public
 */
export const getErrorDomain = (code: string) => {
  const domainFromCode = slice(
    0,
    3,
    code
  ) as keyof typeof ServiceErrorDomainCode;

  return ServiceErrorDomainCode[domainFromCode] ?? 'unknown';
};
