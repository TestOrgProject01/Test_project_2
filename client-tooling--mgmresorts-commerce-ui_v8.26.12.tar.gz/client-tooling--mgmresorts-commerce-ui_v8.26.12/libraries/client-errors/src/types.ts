import { MyVegasCodes } from './codes';
import { CartCodes } from './codes/service/cart';
import { RoomCodes } from './codes/service/room';
import { ShowCodes } from './codes/service/show';

/**
 * API Domain ([XXX]-X-XXX)
 *
 * https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/591265906/Booking+API+Common#1.-API-Domain(XXX-X-XXX)----3-digits-(-e.g.-600-for-Restaurants-in-current-enterprise-API)
 */
export enum ServiceErrorDomainCode {
  sbs = 620,
  rbs = 632,
  cart = 123,
  myvegas = 635
}

/**
 * Error Type (XXX-[X]-XXX)
 *
 * https://mgmdigitalventures.atlassian.net/wiki/spaces/UCP/pages/591265906/Booking+API+Common#2.-Error-Type(XXX-X-XXX)---1-digit-(e.g.-Validation-%3D-1-in-current-enterprise-API)
 */
export enum ServiceErrorType {
  unknown = 0,
  validation = 1,
  functional = 2,
  system = 3,
  authentication = 4,
  backend = 5,
  technical = 6,
  authoization = 7
}

/**
 * Message details
 */
interface Message {
  message: {
    /**
     * Copy to be displayed internally.
     */
    internal: string;
    /**
     * Copy to be displayed to our customers.
     */
    public?: string;
  };
  /**
   * Represents the service domain
   */
  type: keyof typeof ServiceErrorDomainCode;
  /**
   * Possible related error codes
   */
  relatedCodes?: Array<
    | keyof typeof RoomCodes
    | keyof typeof ShowCodes
    | keyof typeof MyVegasCodes
    | keyof typeof CartCodes
  >;
}

/**
 * Error code to message mapping
 *
 * @public
 */
export type MessageType<T extends string> = {
  [key in T]: Message;
};
