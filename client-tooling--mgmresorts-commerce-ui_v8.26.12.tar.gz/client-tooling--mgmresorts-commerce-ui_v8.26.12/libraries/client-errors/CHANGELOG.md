## 1.3.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 1.3.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- added Unknown service error code handling ([c4d80b95](https://github.com/MGMResorts/client-tooling/commit/c4d80b95))
- updated client-errors readme ([dda526fd](https://github.com/MGMResorts/client-tooling/commit/dda526fd))
- added new client-errors package ([3fa0622c](https://github.com/MGMResorts/client-tooling/commit/3fa0622c))

### 🩹 Fixes

- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Rob Fyffe

# Change Log - @mgmresorts/client-errors

This log was last generated on Tue, 03 Sep 2024 18:45:27 GMT and should not be manually modified.

## 1.2.14
Tue, 03 Sep 2024 18:45:27 GMT

_Version update only_

## 1.2.13
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 1.2.12
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 1.2.11
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 1.2.10
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 1.2.9
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 1.2.8
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 1.2.7
Thu, 08 Feb 2024 16:13:06 GMT

_Version update only_

## 1.2.6
Thu, 09 Nov 2023 23:02:38 GMT

_Version update only_

## 1.2.5
Thu, 09 Nov 2023 22:21:40 GMT

_Version update only_

## 1.2.4
Wed, 01 Nov 2023 13:00:43 GMT

_Version update only_

## 1.2.3
Tue, 31 Oct 2023 18:44:27 GMT

_Version update only_

## 1.2.2
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 1.2.1
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 1.2.0
Mon, 03 Jul 2023 18:41:43 GMT

### Minor changes

- added Unknown error handling for services

## 1.1.0
Thu, 29 Jun 2023 18:41:29 GMT

### Minor changes

- Initial commit for new client-errors package

