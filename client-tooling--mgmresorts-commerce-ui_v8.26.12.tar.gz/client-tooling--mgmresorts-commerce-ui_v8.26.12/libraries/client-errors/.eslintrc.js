// This is a workaround for https://github.com/eslint/eslint/issues/3458
require('@mgmresorts/eslint-config-cet/patch/modern-module-resolution');

/**
 * @type {import("eslint").Linter.Config}
 */
module.exports = {
  extends: ['@mgmresorts/eslint-config-cet/profiles/web-app/recommended'],
  parserOptions: { tsconfigRootDir: __dirname }
};
