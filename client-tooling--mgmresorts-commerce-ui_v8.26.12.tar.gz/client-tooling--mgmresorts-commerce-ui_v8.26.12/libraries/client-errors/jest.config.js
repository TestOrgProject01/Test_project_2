const esmModules = ['@mgmresorts/cart-shared'].join('|');

module.exports = {
  collectCoverage: true,
  coverageDirectory: 'temp/coverage',
  coverageReporters: ['html'],
  moduleNameMapper: {
    '^#root/(.*)$': '<rootDir>/$1'
  },
  modulePathIgnorePatterns: ['./constants.ts'],
  rootDir: 'src',
  testEnvironment: 'jsdom',
  transform: {
    '^.+\\.(t|j)sx?$': ['@swc/jest']
  },
  transformIgnorePatterns: [
    `/node_modules/(?!${esmModules})/`,
    `node_modules\\\\(?!${esmModules}).+\\.js$`
  ]
};
