import * as path from 'node:path';

import type { UserConfig } from 'vitest/config';

const config: UserConfig = {
  esbuild: {
    target: 'es2020'
  },
  test: {
    environment: 'happy-dom',
    fakeTimers: {
      toFake: undefined
    },
    globals: true,
    include: ['**/*.test.ts'],
    sequence: {
      concurrent: false
    },
    setupFiles: [path.join(__dirname, 'setupTests.ts')]
  }
};

export default config;
