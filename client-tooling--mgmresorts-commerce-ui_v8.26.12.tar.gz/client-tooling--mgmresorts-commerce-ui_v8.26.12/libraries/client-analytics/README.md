# Client Analytics Web Package

[:book:](https://mgmresorts.github.io/client-analytics)
