import * as it from '@effect/vitest';

it.addEqualityTesters();
