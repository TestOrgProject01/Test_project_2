import { DigitalData, RuntimeConfig } from './types';

declare global {
  export interface Window {
    /**
     * For adobe launch (analytics)
     */
    _satellite?:
      | {
          track(key: string, data?: any): void;
          setDebug(_: boolean): void;
          property?: {
            id: string;
            name: string;
          };
        }
      | undefined;
    digitalData?: DigitalData;
    mgmAppConfig?: RuntimeConfig | {};
    SSR_MODE?: boolean;
  }
}
