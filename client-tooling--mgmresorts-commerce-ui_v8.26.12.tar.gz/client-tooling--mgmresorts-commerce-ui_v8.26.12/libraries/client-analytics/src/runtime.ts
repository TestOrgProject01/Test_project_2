/**
 * Effect Runtime
 *
 * This module provides a managed Effect runtime with
 * [`ManagedRuntime`](https://effect-ts.github.io/effect/effect/ManagedRuntime.ts.html#managedruntime-overview)
 * to act as the interperability layer between React and Effect.
 *
 * For learnings, read:
 * - [Managing Layers](https://effect.website/docs/guides/context-management/layers)
 * - [Introduction to Runtime](https://effect.website/docs/guides/runtime)
 * - [Scopes](https://effect.website/docs/guides/resource-management/scope)
 *
 */

import { Layer, Effect, ManagedRuntime } from 'effect';

import { AnalyticsService } from './AnalyticsService.js';
import { DigitalDataManagerService } from './dataSetters/digitalDataManager.js';

const liveLayer = Layer.mergeAll(
  AnalyticsService.Live,
  DigitalDataManagerService.Live
);

const makeRuntime = <R, E>(layer: Layer.Layer<R, E>) => {
  const runtime = ManagedRuntime.make(layer);

  const effectAction = <A, E>(effect: Effect.Effect<A, E, R>) =>
    runtime.runPromise(effect);

  const effectSyncAction = <A, E>(effect: Effect.Effect<A, E, R>) =>
    runtime.runSync(effect);

  const dispose = runtime.dispose;

  return { dispose, effectAction, effectSyncAction } as const;
};

export const { effectAction, effectSyncAction, dispose } =
  makeRuntime(liveLayer);
