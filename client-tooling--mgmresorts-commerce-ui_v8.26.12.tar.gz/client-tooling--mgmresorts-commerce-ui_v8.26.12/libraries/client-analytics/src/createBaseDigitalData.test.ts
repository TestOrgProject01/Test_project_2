import { describe, it, expect } from 'vitest';

import { createBaseDigitalData } from './createBaseDigitalData.js';

describe('createBaseDigitalData ', () => {
  it('verify window object with sane defaults', () => {
    const result = createBaseDigitalData();
    expect(window.digitalData).toEqual(result);
  });
});
