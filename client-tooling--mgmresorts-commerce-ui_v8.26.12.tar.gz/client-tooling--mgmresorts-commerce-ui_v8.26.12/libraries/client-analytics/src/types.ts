import {
  JWBModalOpenEvent,
  JWBModalCloseEvent,
  JWBSignInEvent,
  JWBToggleClickEvent,
  JWBEmailSubmitEvent
} from './trackers/types.js';

type ApiEnvironment = 'DEV' | 'PREPROD' | 'PREVIEW' | 'QA4' | 'UAT' | 'PROD';

/**
 * @public
 */
export interface RuntimeConfig {
  /**
   * The API environment
   */
  apiEnv: ApiEnvironment;
  /**
   * Enable debug mode
   */
  debug: boolean;
  /**
   * Base API url
   */
  baseApiUrl: string;
  /**
   * Analytics script URL
   */
  analyticsScript: string;
  /**
   * Authentication redirect URI
   */
  authRedirectUri: string;
  /**
   * Log Rocket app ID
   */
  logRocketAppId: string;
  /**
   * Enable mock API
   */
  mockApi: boolean;
  /**
   * The deployment environment
   */
  deployEnv: string;
  /**
   *
   */
  smartSegment: string;
  /**
   *
   */
  smartSegmentEnabled: boolean;
  /**
   *
   */
  queueItAppId: string;
  /**
   *
   */
  fraudDetectionEnabled: boolean;
  /**
   *
   */
  wclIconStaticUrl: string;
  /**
   * The Contentstack branch.
   */
  csuContentstackBranch: string;
  /**
   * The Contentstack delivery token.
   */
  csuContentstackDeliveryToken: string;
  /**
   * The Contentstack stack.
   */
  csuContentstackStack: string;
}

/**
 * @public
 */
export type ReservationPageNames =
  | 'region'
  | 'dates'
  | 'room'
  | 'resort'
  | 'review'
  | 'checkout'
  | 'confirmation';
export type BookingExperience = 'multi-rate' | 'perpetual';

export const propertySlugs = [
  'aria',
  'beaurivage',
  'bellagio',
  'borgata',
  'cosmopolitanlasvegas',
  'delanolasvegas',
  'empirecitycasino',
  'excalibur',
  'goldstrike',
  'luxor',
  'mandalaybay',
  'mgmgrand',
  'mgmgranddetroit',
  'mgmnationalharbor',
  'mgmnorthfieldpark',
  'mgmresorts',
  'mgmspringfield',
  'mirage',
  'newyorknewyork',
  'nomadlasvegas',
  'parkmgm',
  'signaturemgmgrand',
  'vdara'
] as const;

export type PropertySlug = (typeof propertySlugs)[number];

/** @public */
export interface UserStored {
  loggedInStatus: boolean;
  mlifeNumber?: string;
  loyaltyTier?: string;
  email?: string;
  perpetual?: boolean;
  city?: string;
  state?: string;
  country?: string;
  postal?: string;
  isJwbSignup?: boolean;
  features: Array<{
    [k: string]: boolean | string | number;
  }>;
}

/**
 * @public
 */
export interface App {
  name?: string;
  version?: string;
  buildNumber?: string;
  deepLink: {
    cartId?: string;
    arrivalDate?: string;
    departureDate?: string;
    guestCount?: string;
    regionId?: string;
    resortId?: string;
    programId?: string;
    promo?: string;
    segmentId?: string;
    roomType?: string;
    member: boolean;
  };
}

/**
 * @public
 */
export interface Page {
  name?: string;
  destinationURL?: string;
  language: string;
  genericImpressions?: string[];
}

/**
 * @public
 */
export interface Property {
  id: string;
  name: PropertySlug;
}

/**
 * @public
 */
export interface ReservationSearchFlexibleDateWindow {
  isSelected: boolean;
  startDate: string;
  endDate: string;
  avgPrice: number;
  isValidOffer: boolean | string;
  comps: number;
}

/**
 * @public
 */
export interface ReservationSearchFilter {
  type: string;
  value: string[];
}

/**
 * @public
 */
export interface ReservationItem {
  id: string;
  itemId: string;
  roomProgramId: string;
  roomTypeId: string;
  roomTypeCode: string;
  propertyId: string;
  roomTypeName?: string;
  propertyName?: string;
  roomProgramName?: string;
  image?: string;
  confirmationId?: string;
  roomDetails: {
    reservationWindow?: number;
    nights: number;
    guests: number;
    arrivalDate: string;
    departureDate: string;
    subtotal: number;
    savings: number;
    resortFeeAndTax: number;
    roomChargeTax: number;
    depositDue: number;
    balanceDue: number;
    lowestPrice: number | string;
    details: string;
    specialRequests: string;
    requests: unknown; // TODO: we need to define this type
  };
}

/**
 * @public
 */
export interface ReservationSearch {
  arrivalDate?: string;
  departureDate?: string;
  flexibleDates?: {
    resortWindows: ReservationSearchFlexibleDateWindow[];
    roomWindows: ReservationSearchFlexibleDateWindow[];
    windowsAvailable: boolean;
    windowSelected: boolean;
  };
  guests?: number;
  region?: string; // TODO: we should map it based on the region id when its query is created
  reservationDuration?: number;
  reservationWindow?: number;
  resort?: {
    id: string;
    name: string;
  };
  selectedRoomProgram?: {
    id: string;
    name: string;
  };
  filters?: ReservationSearchFilter[];
  compNightsAvailable?: string;
}

/**
 * @public
 */
export interface PackageDetails {
  id?: string;
  category: string | undefined;
  minLos: number;
  tier: string | number;
}

/**
 * @public
 */
export interface ReservationProductContextItem {
  allDayEvent: boolean;
  id: string | undefined;
  packageDetails: PackageDetails | null | undefined;
  propertyId: string | undefined;
  seatingType: string | null | undefined;
  showDate: string | undefined;
  showDetails: {
    reservationWindow: number;
    tickets: number;
  };
  showProgramId: string;
  showTime: string | undefined;
  type: string | null | undefined;
  productCategory: string | null | undefined;
  propertyName: string | undefined;
  showName: string;
}

/** @public */
export interface Reservation<T, U> {
  search?: T; // Changes depending on consuming experience
  cart?: U; // Let consuming cart application specify type
  type: '';
  step?: ReservationPageNames;
  bookingExperience?: BookingExperience;
  paymentMethod?: string;
  isMlifeCard?: boolean;
  isSavedPaymentMethod?: boolean;
  productContext: {
    items: ReservationProductContextItem[];
  };
  resorts: Array<{
    name: string;
    lowestPrice?: number;
    programId?: string;
  }>;
  roomPrograms: Array<{
    id: string;
    name: string;
    startingPrice: string;
    customerAdded: boolean;
  }>;
  rooms: Array<{
    name: string;
    type: 'Room' | 'Suite';
    price?: number;
    accessible: boolean;
  }>;
  items: ReservationItem[];
  totalRevenue?: string | number;
  currency?: string;
  jwb?: {
    email: string | undefined;
    optin: true | false | '';
    toggle: boolean;
  };
  timeRemaining: number | undefined;
}

/** @public */
export interface EventAttributes {
  category?: string;
  clickType?: string;
  section?: string;
  subCategory?: string;
  title?: string;
}

/** @public */
export interface EventInfo {
  eventName?: string;
}

/** @public */
export interface Event {
  attributes: EventAttributes;
  eventInfo: EventInfo;
  wait?: boolean;
}

/** @public */
export enum DigitalDataKeysEnum {
  App = 'app',
  Event = 'event',
  Page = 'page',
  Property = 'property',
  Reservation = 'reservation',
  User = 'user'
}

/**
 * DigitalData window event
 *
 * @public
 */
export interface DigitalData<T, U> {
  [DigitalDataKeysEnum.App]: App;
  [DigitalDataKeysEnum.Event]?: Event[];
  [DigitalDataKeysEnum.Page]: Page;
  [DigitalDataKeysEnum.Property]: Property;
  [DigitalDataKeysEnum.Reservation]: Reservation<T, U>;
  [DigitalDataKeysEnum.User]: UserStored;
}

/**
 * @public
 */
export type TrackingActionData = 'increment' | 'decrement';

/**
 * @public
 */
export type SearchCriteriaChangedDescriptionLocation = 'preview' | 'overlay';

/**
 * @public
 */
interface AlertImpression {
  event: 'impression';
  description: {
    title: string;
  };
}

/**
 * @public
 */
interface AlertClick {
  event: 'click';
  description: {
    title: string;
    details: string;
  };
}

/**
 * @public
 */
interface ClickTracking {
  event: 'click';
  identifier: string;
  description: string;
  href?: string;
}

/**
 * @public
 */

export type ErrorDescription =
  | {
      title: string;
      errorDetails: string;
    }
  | {
      description: {
        title: string;
      };
    };

/**
 * @public
 */

export interface Error {
  event: 'click' | 'error' | 'impression';
  description: ErrorDescription;
}

/**
 * @public
 */
export enum EventDataKeysEnum {
  RoomResortDetails = 'room_resortDetails',
  RoomRateChange = 'room_rateChange',
  RoomRoomDetails = 'room_roomDetails',
  Login = 'login',
  Logout = 'logout',
  RoomAddRoom = 'room_addRoom',
  RoomRemoveRoom = 'room_removeRoom',
  RoomRoomFilter = 'room_roomFilter',
  UserStatusChanged = 'user-status-changed',
  RoomBookingPageReady = 'room-booking-page-ready',
  RcOverlay = 'rc_overlay',
  RoomPricingOverlay = 'room_pricingOverlay',
  ErrorMessage = 'error_message',
  RoomMrdOverlay = 'room_mrdOverlay',
  RoomEditDatesOverlay = 'room_editDatesOverlay',
  RoomOdOverlay = 'room_odOverlay',
  SegmentCard = 'segmentCard',
  RoomRemoveOfferCTA = 'room_removeOfferCTA',
  RoomResortNext = 'room_resort_next',
  SearchCriteriaChanged = 'search_criteria_changed',
  RoomTripAvailabilityLoaded = 'room_tripAvailabilityLoaded',
  JwbEvent = 'jwbEvent',
  RoomDestinationDropdown = 'room_destinationDropdown',
  RoomImageGallery = 'room_imageGallery',
  RoomResortImageGallery = 'room_resortImageGallery',
  UniversalClickTracking = 'universal_click_tracking',
  UniversalPageTracking = 'universal_page_tracking',
  PackagesSeats = 'packages_seats',
  PackagesRoomDates = 'packages_roomDates',
  RoomSelectResort = 'room_selectResort',
  RoomSelectRoom = 'room_selectRoom',
  GlobalNav = 'globalnav_clickevent',
  GlobalFooter = 'globalfooter_clickevent',
  Alert = 'alert',
  ErrorModal = 'error_modal',
  ToastAlert = 'toastAlert'
}

/**
 * EventData window event
 *
 * @public
 */
export interface EventData {
  [EventDataKeysEnum.RoomResortDetails]: {
    title: string;
  };
  [EventDataKeysEnum.RoomRateChange]: undefined;
  [EventDataKeysEnum.RoomRoomDetails]: {
    title: string;
    location: string;
    clickedon: 'img' | 'link';
  };
  [EventDataKeysEnum.Login]: undefined;
  [EventDataKeysEnum.Logout]: undefined;
  [EventDataKeysEnum.RoomAddRoom]: undefined;
  [EventDataKeysEnum.RoomRemoveRoom]: undefined;
  [EventDataKeysEnum.RoomRoomFilter]: undefined;
  [EventDataKeysEnum.UserStatusChanged]: undefined;
  [EventDataKeysEnum.RoomBookingPageReady]: undefined;
  [EventDataKeysEnum.RcOverlay]:
    | {
        event: 'impression';
      }
    | {
        event: 'click';
        description: {
          type: string;
          title: string;
        };
      };
  [EventDataKeysEnum.RoomPricingOverlay]: {
    description: {
      roomType: string;
      location: 'room details overlay' | 'inpage';
    };
  };
  [EventDataKeysEnum.ErrorMessage]: {
    description: {
      type: 'user flow';
      title?: string;
      details?: string;
    };
  };
  [EventDataKeysEnum.RoomMrdOverlay]: undefined;
  [EventDataKeysEnum.RoomEditDatesOverlay]: undefined;
  [EventDataKeysEnum.RoomOdOverlay]:
    | {
        event: 'click';
        description: {
          programName: string;
          title: string;
        };
      }
    | {
        event: 'impression';
        description: {
          programName: string;
        };
      };
  [EventDataKeysEnum.SegmentCard]: {
    description: {
      title: string;
      type: string;
    };
  };
  [EventDataKeysEnum.RoomRemoveOfferCTA]: {
    description: {
      title: string;
    };
  };
  [EventDataKeysEnum.RoomResortNext]: undefined;
  [EventDataKeysEnum.SearchCriteriaChanged]: {
    event: 'resort' | 'dates' | 'guests' | 'reservationDuration' | 'flexWindow';
    action?: TrackingActionData;
    description?: {
      property: string;
      roomType: string;
      location: SearchCriteriaChangedDescriptionLocation;
      checkinDate: string;
      selectedWindow?: ReservationSearchFlexibleDateWindow;
    };
  };
  [EventDataKeysEnum.RoomTripAvailabilityLoaded]: undefined;
  [EventDataKeysEnum.JwbEvent]:
    | JWBModalOpenEvent
    | JWBModalCloseEvent
    | JWBSignInEvent
    | JWBToggleClickEvent
    | JWBEmailSubmitEvent;
  [EventDataKeysEnum.RoomDestinationDropdown]: {
    event: 'clickedon';
    description: {
      property: string;
    };
  };
  [EventDataKeysEnum.RoomImageGallery]: {
    event: 'swiped';
    description: {
      property: string;
      roomType: string;
    };
  };
  [EventDataKeysEnum.RoomResortImageGallery]: {
    description: {
      property: string;
    };
    event: 'clickedon' | 'swiped';
  };
  [EventDataKeysEnum.GlobalNav]: ClickTracking;
  [EventDataKeysEnum.GlobalFooter]: ClickTracking;
  [EventDataKeysEnum.UniversalClickTracking]: ClickTracking;
  [EventDataKeysEnum.UniversalPageTracking]: {
    identifier: string;
  };
  [EventDataKeysEnum.Alert]: AlertImpression | AlertClick;
  [EventDataKeysEnum.ErrorModal]: Error;
  [EventDataKeysEnum.PackagesSeats]: undefined;
  [EventDataKeysEnum.PackagesRoomDates]: undefined;
  [EventDataKeysEnum.RoomSelectResort]: undefined;
  [EventDataKeysEnum.RoomSelectRoom]: undefined;
  [EventDataKeysEnum.ToastAlert]: Error;
}
