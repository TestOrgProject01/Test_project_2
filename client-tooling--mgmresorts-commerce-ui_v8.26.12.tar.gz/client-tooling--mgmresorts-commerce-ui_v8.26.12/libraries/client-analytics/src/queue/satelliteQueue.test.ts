import { nextTick } from 'node:process';

import { vi, describe, it, beforeEach, expect } from 'vitest';

vi.mock('../trackSatellite.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../trackSatellite.js')>()),
  trackSatellite: vi.fn()
}));

import { mockSatelliteObject, windowSpy } from '../testUtils.js';
import { TrackPayload, trackSatellite } from '../trackSatellite.js';
import { EventDataKeysEnum } from '../types.js';

describe('processQueue', () => {
  beforeEach(async () => {
    // Each test should start with a new `trackSatellite` mock function.
    vi.resetAllMocks();
    // This is needed in a top-level `beforeEach` to reset the `runtime` module
    // which is cached across tests.
    vi.resetModules();
    windowSpy.mockRestore();
    mockSatelliteObject();
  });

  const mockItems: TrackPayload[] = [
    {
      data: { identifier: '0' },
      event: EventDataKeysEnum.UniversalPageTracking
    },
    {
      data: { identifier: '1' },
      event: EventDataKeysEnum.UniversalPageTracking
    },
    {
      data: { identifier: '2' },
      event: EventDataKeysEnum.UniversalPageTracking
    }
  ];

  it('can be cleaned up', async () => {
    const { dispose } = await import('../runtime.js');
    const { addItem, processQueue } = await import('./satelliteQueue.js');

    const _ = processQueue();
    await addItem(mockItems[0]);

    await dispose();
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    expect(_).rejects.toThrowError();
  });

  it('can be cleaned up 2', async () => {
    const { dispose } = await import('../runtime.js');
    const { addItem, processQueue } = await import('./satelliteQueue.js');

    const _ = processQueue();
    await addItem(mockItems[0]);

    await dispose();
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    expect(_).rejects.toThrowError();
  });

  it('check if the queue is properly called', async () => {
    const { dispose } = await import('../runtime.js');
    const { addItem, processQueue } = await import('./satelliteQueue.js');

    const _ = processQueue();

    await addItem(mockItems[0]);
    await addItem(mockItems[1]);

    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    addItem(mockItems[2]);

    expect(trackSatellite).toHaveBeenCalledTimes(2);

    await new Promise(nextTick);

    expect(trackSatellite).toHaveBeenCalledTimes(3);

    await dispose();
    await expect(_).rejects.toThrowError();
  });

  it('check if the queue has the expected number of items', async () => {
    const { dispose } = await import('../runtime.js');
    const { addItem, processQueue, size } = await import('./satelliteQueue.js');

    /* eslint-disable @typescript-eslint/no-floating-promises */
    addItem(mockItems[0]);
    addItem(mockItems[1]);
    /* eslint-enable @typescript-eslint/no-floating-promises */

    const queueSize = await size();

    expect(queueSize).toBe(2);

    expect(trackSatellite).toHaveBeenCalledTimes(0);

    const _ = processQueue();

    await new Promise(nextTick);

    expect(trackSatellite).toHaveBeenCalledTimes(2);

    await dispose();
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    expect(_).rejects.toThrowError();
  });

  it('check if the queue item is called with the right params', async () => {
    const { dispose } = await import('../runtime.js');
    const { addItem, processQueue } = await import('./satelliteQueue.js');

    const firstItem = addItem(mockItems[2]);

    const _ = processQueue();

    await firstItem;

    expect(trackSatellite).toHaveBeenCalledTimes(1);
    expect(trackSatellite).toHaveBeenCalledWith(mockItems[2]);

    await dispose();
    await expect(_).rejects.toThrowError();
  });
});
