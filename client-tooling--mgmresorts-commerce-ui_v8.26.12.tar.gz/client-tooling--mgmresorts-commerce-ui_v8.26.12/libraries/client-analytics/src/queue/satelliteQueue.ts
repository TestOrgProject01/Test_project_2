import { Effect, pipe } from 'effect';

import { AnalyticsService } from '../AnalyticsService.js';
import { effectAction } from '../runtime.js';
import { TrackPayload, trackSatellite } from '../trackSatellite.js';

/**
 * Asynchronously triggers {@link trackSatellite} for items in the queue.
 *
 * @remarks
 * - This will wait to dequeue until `window._satellite.track` is defined as a
 *   function.
 * - Do not `await` this. This can be destroyed with `await runtime.dispose()`.
 *
 * @public
 */
export const processQueue = () =>
  effectAction(
    pipe(
      AnalyticsService,
      Effect.andThen((analytics) =>
        analytics.processItems((item) =>
          pipe(
            Effect.log(
              `Processing item: [${item.event}] ${JSON.stringify(item.data)}`
            ),
            Effect.map(() => trackSatellite(item)),
            Effect.as(JSON.stringify(item))
          )
        )
      )
    )
  );

export const addItem = (item: TrackPayload) =>
  effectAction(
    pipe(
      AnalyticsService,
      Effect.andThen((analytics) =>
        pipe(
          analytics.enqueueItem(item),
          Effect.tap(
            Effect.log(`add item: [${item.event}] ${JSON.stringify(item.data)}`)
          )
        )
      )
    )
  );

export const size = () =>
  effectAction(
    pipe(
      AnalyticsService,
      Effect.andThen((analytics) => analytics.size())
    )
  );
