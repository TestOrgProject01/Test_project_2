import { Effect, pipe } from 'effect';
import { TaggedError } from 'effect/Data';

import { EventData } from './types.js';

export type EventKeys = keyof EventData;
export type EventKeyData<K extends EventKeys> = EventData[K];
export interface TrackPayloadWithEvent<E extends EventKeys> {
  event: E;
  data?: EventKeyData<E>;
  cb?: (e: Error) => void;
}

export type TrackPayload = TrackPayloadWithEvent<EventKeys>;

class SatelliteUndefinedError extends TaggedError('SatelliteUndefinedError')<{
  message: string;
}> {}

/**
 * Monadic wrapper for `window?.satellite.track()` to handle `undefined` and
 * `catch` scenarios.
 *
 * @internal
 */
const trySatelliteTrack = <Event extends string, Data>(
  event: Event,
  data: Data
): Effect.Effect<void, Error | SatelliteUndefinedError, never> =>
  pipe(
    Effect.if(typeof window._satellite?.track === 'function', {
      onFalse: () => Effect.log(`_satellite.track is not a function.`),
      onTrue: () => {
        try {
          return Effect.succeed(window!._satellite!.track(event, data));
        } catch (error) {
          return Effect.log(
            `trySatelliteTrack called ${event} ${JSON.stringify(data)}`
          );
        }
      }
    })
  );

/**
 * Effectful wrapper for coercing `_satellite.track()` calls to be made with
 * appropriate input data.
 *
 * TODO:
 * - Add satelitte debugging
 *
 * @public
 */
const trackSatellite = <E extends EventKeys>({
  event,
  data
}: Omit<TrackPayloadWithEvent<E>, 'cb'>) =>
  pipe(trySatelliteTrack(event, data), Effect.runSync);

export { trackSatellite };
