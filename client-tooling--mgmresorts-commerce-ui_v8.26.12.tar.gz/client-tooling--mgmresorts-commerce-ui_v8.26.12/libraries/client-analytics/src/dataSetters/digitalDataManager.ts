import { Context, Effect, Layer, pipe, SynchronizedRef } from 'effect';
import { equals, mergeDeepRight } from 'rambdax';

import { createBaseDigitalData } from '../createBaseDigitalData.js';
import { addItem, processQueue } from '../queue/satelliteQueue.js';
import { TrackPayload } from '../trackSatellite.js';
import { DigitalData } from '../types.js';

import { DigitalDataKeys, DigitalDataValue, SetDigitalData } from './types.js';

const make = Effect.gen(function* (_: Effect.Adapter) {
  const digitalData = yield* SynchronizedRef.make<
    DigitalData<unknown, unknown>
  >(window?.digitalData ?? {});

  const getCurrentData = pipe(digitalData, SynchronizedRef.get);

  const getCurrentDataValue = <
    K extends DigitalDataKeys<T, U>,
    T = unknown,
    U = unknown
  >(
    key: K
  ) =>
    pipe(
      getCurrentData,
      Effect.map((data) => data[key])
    );

  const log = (label: string) =>
    Effect.gen(function* () {
      const data = yield* getCurrentData;

      return yield* Effect.log(`${label} get: ${JSON.stringify(data)}`);
    });

  const setDigitalData = <
    K extends DigitalDataKeys<T, U>,
    V extends Partial<DigitalDataValue<K>>,
    T = unknown,
    U = unknown
  >(
    key: K,
    data: V
  ) =>
    pipe(
      log(`digital manager set digitalData ${key} called`),
      Effect.andThen(
        SynchronizedRef.updateEffect(digitalData, (currentData) =>
          // XXX: this is wrong and requires a yield for satisfying the generator
          // eslint-disable-next-line require-yield
          Effect.gen(function* () {
            createBaseDigitalData();

            if (window && window.digitalData) {
              // we ensure to set values to window.digitalData
              // in deployment latest setDigitalData does not exposed in window.digitalData
              window.digitalData[key] = mergeDeepRight(
                window.digitalData[key],
                data
              );
            }

            return mergeDeepRight(currentData, { [key]: data });
          })
        )
      ),
      Effect.andThen(log(`digital manager set digitalData ${key} done`))
    );

  const managedSetDigitalData: SetDigitalData = (key, value) => {
    const data = pipe(getCurrentDataValue(key), Effect.runSync);

    const digitalDataValue = typeof value === 'function' ? value(data) : value;

    if (!equals(data, digitalDataValue)) {
      pipe(setDigitalData(key, digitalDataValue), Effect.runSync);
    }
  };

  const managedTrackSatellite = async (params: TrackPayload) => {
    // we don't await this because we want to process this item
    // on the process queue fiber/thread
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    pipe(params, addItem);
  };

  const setManager = () => {
    // let's process the queue when we call the manager
    // so then the processQueue will be called only once
    // and it will process all the items in the queue as a watcher
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    processQueue();

    return {
      setDigitalData: managedSetDigitalData,
      trackSatellite: managedTrackSatellite
    };
  };

  return { setManager } as const;
});

export class DigitalDataManagerService extends Context.Tag(
  'DigitalDataManagerService'
)<DigitalDataManagerService, Effect.Effect.Success<typeof make>>() {
  static readonly Live: Layer.Layer<DigitalDataManagerService, never, never> =
    pipe(Layer.scoped(DigitalDataManagerService, make));
}
