import { vi, describe, expect, it, afterEach, beforeEach } from 'vitest';

vi.mock('../trackSatellite.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../trackSatellite.js')>()),
  trackSatellite: vi.fn()
}));

import { createBaseDigitalData } from '../createBaseDigitalData.js';
import { size } from '../queue/satelliteQueue.js';
import { mockSatelliteObject, windowSpy } from '../testUtils.js';
import { EventKeyData, trackSatellite } from '../trackSatellite.js';
import {
  DigitalDataKeysEnum,
  EventDataKeysEnum,
  Page,
  propertySlugs
} from '../types.js';

import { setManager } from './actions.js';

const key = DigitalDataKeysEnum.Page;

const value = {
  destinationURL: 'http://localhost/',
  language: 'en',
  name: 'test page'
};

const propertyKey = DigitalDataKeysEnum.Property;

const propertyValue = {
  id: 'test id',
  name: propertySlugs[0]
};

describe('digitalDataManager', async () => {
  const { setDigitalData, trackSatellite: managedTrackSatellite } =
    setManager();

  beforeEach(() => {
    windowSpy.mockRestore();
    createBaseDigitalData(true);
    mockSatelliteObject();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it('setDigitalData updates window.digitalData correctly', async () => {
    setDigitalData(key, value);
    expect(window.digitalData[key]).toStrictEqual(value);

    const updatedValue: Page = {
      ...value,
      genericImpressions: ['test']
    };

    const updateValue = (page: Page): Page => ({
      ...page,
      genericImpressions: ['test']
    });

    setDigitalData(key, updateValue);

    expect(window.digitalData[key]).toStrictEqual(updatedValue);
  });

  it('check if the manager calls all the queued items when we update the window digital data', async () => {
    const event = EventDataKeysEnum.SearchCriteriaChanged;

    const data = {
      event: 'resort'
    } satisfies EventKeyData<EventDataKeysEnum.SearchCriteriaChanged>;

    const params = {
      data,
      event
    };

    await managedTrackSatellite(params);
    let queueSize = await size();

    expect(queueSize).toBe(0);
    expect(trackSatellite).toHaveBeenCalledTimes(1);

    const secondEvent = EventDataKeysEnum.UniversalPageTracking;

    const secondData = {
      identifier: 'test id'
    } satisfies EventKeyData<EventDataKeysEnum.UniversalPageTracking>;

    const secondParamsSet = {
      data: secondData,
      event: secondEvent
    };

    await managedTrackSatellite(secondParamsSet);
    queueSize = await size();
    expect(queueSize).toBe(0);
    expect(trackSatellite).toHaveBeenCalledTimes(2);

    setDigitalData(key, value);
    expect(window.digitalData[key]).toStrictEqual(value);

    setDigitalData(propertyKey, propertyValue);
    expect(window.digitalData[propertyKey]).toStrictEqual(propertyValue);

    expect(trackSatellite).toHaveBeenCalledTimes(2);

    expect(trackSatellite).toHaveBeenCalledWith({
      data,
      event
    });

    expect(trackSatellite).toHaveBeenCalledWith({
      data: secondData,
      event: secondEvent
    });

    queueSize = await size();
    expect(queueSize).toBe(0);
  });

  it('managedTrackSatellite adds the parameters to the queue if the event is defined and the system is not shutdown', async () => {
    const event = EventDataKeysEnum.SearchCriteriaChanged;

    const data = {
      event: 'resort'
    } satisfies EventKeyData<EventDataKeysEnum.SearchCriteriaChanged>;

    const params = {
      data,
      event
    };

    await managedTrackSatellite(params);

    const queueSize = await size();

    expect(trackSatellite).toHaveBeenCalledWith(params);
    expect(queueSize).toBe(0);
  });
});
