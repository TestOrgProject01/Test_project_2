import { trackSatellite } from '../trackSatellite.js';
import { DigitalData } from '../types.js';

export type DigitalDataKeys<T, U> = keyof DigitalData<T, U>;

export type DigitalDataValue<
  K extends DigitalDataKeys<T, U>,
  T = unknown,
  U = unknown
> = DigitalData<T, U>[K];

export type Value<K extends DigitalDataKeys<T, U>, T = unknown, U = unknown> =
  | Partial<DigitalDataValue<K>>
  | ((_: DigitalDataValue<K>) => DigitalDataValue<K>);

export type SetDigitalData = <
  K extends DigitalDataKeys<T, U>,
  T = unknown,
  U = unknown
>(
  key: K,
  value: Value<K, T, U>
) => void;

export type trackSatelliteParams = Parameters<typeof trackSatellite>;
