import { pipe, Effect } from 'effect';

import { effectSyncAction } from '../runtime.js';

import { DigitalDataManagerService } from './digitalDataManager.js';

export const setManager = () =>
  effectSyncAction(
    pipe(
      DigitalDataManagerService,
      Effect.andThen((dataManager) => dataManager.setManager())
    )
  );
