import { trackSatellite } from '../trackSatellite.js';

import type { SetDigitalData } from './types.js';

export interface AnalyticsService {
  trackSatellite: typeof trackSatellite;
  setDigitalData: SetDigitalData;
}
