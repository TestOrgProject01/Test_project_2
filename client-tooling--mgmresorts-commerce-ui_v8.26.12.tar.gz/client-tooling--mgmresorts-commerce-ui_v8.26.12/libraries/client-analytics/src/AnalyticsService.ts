/**
 * Analytics Service
 *
 * This is an Effect service allows for
 * asynchronous queue processing of `_satellite.track()` payloads.
 *
 * For learnings, read:
 * - [Context Management](https://effect.website/docs/guides/context-management)
 * - The [`Deferred`](https://effect.website/docs/guides/concurrency/deferred)
 *   synchronization primitive.
 * - The [`Queue`](https://effect.website/docs/guides/concurrency/queue) data
 *   structure.
 *
 * Maxwell Brown (github: IMax153) discusses use of `Deferred` in [Effect TypeScript
 * Library: Advanced Workshop](https://www.youtube.com/watch?v=7jOD5okJC00) to
 * supplement example code in
 * [`advanced-effect-workshop/workshop/solutions/session-02/exercise-02/advanced.ts`](https://github.com/IMax153/advanced-effect-workshop/blob/7f366837319f9088ecf3c1ef4469cdd00a017150/workshop/solutions/session-02/exercise-02/advanced.ts).
 */

import { Context, Deferred, Effect, Layer, Queue, flow, pipe } from 'effect';

import type { TrackPayload } from './trackSatellite.js';

const make = Effect.gen(function* (_: Effect.Adapter) {
  const queue = yield* Effect.acquireRelease(
    Queue.unbounded<[TrackPayload, Deferred.Deferred<string>]>(),
    (queue) => Queue.shutdown(queue)
  );

  const size = (): Effect.Effect<number> =>
    pipe(
      Queue.size(queue),
      Effect.flatMap((size) =>
        Effect.if(size < 0, {
          onFalse: () => Effect.succeed(size),
          onTrue: () => Effect.succeed(0)
        })
      )
    );

  /**
   * Enqueue an item.
   *
   * @param item - {@link TrackPayload}
   *
   * @returns void effect
   *
   * @internal
   */
  const enqueueItem = (item: TrackPayload): Effect.Effect<void> =>
    // Create a deferred to synchronize the completion of the item processing,
    // locking the queue until the deferred is completed.
    pipe(
      Deferred.make<string>(),
      Effect.flatMap((deferred) =>
        pipe(
          Queue.offer(queue, [item, deferred]),
          Effect.zipRight(Deferred.await(deferred)),
          Effect.onInterrupt(() =>
            pipe(
              Effect.log(
                `Addition of item ${JSON.stringify(item)} was interrupted!`
              ),
              Effect.zipRight(Deferred.interrupt(deferred))
            )
          )
        )
      )
    );

  /**
   * Process items in the queue.
   *
   * @param processor - function with which to process {@link TrackPayload}
   *
   * @returns An effect than runs forever, until interrupted.
   *
   * @remarks
   * This effect expects the `processor` to never fail. Handle errors in the
   * `processor` function.
   *
   * @internal
   */
  const processItems = (
    processor: (item: TrackPayload) => Effect.Effect<string>
  ): Effect.Effect<void> => {
    // side-effect to complete the deferred and dequeue the item
    const completeDeferredDequeue = (deferred: Deferred.Deferred<string>) =>
      flow(
        processor,
        Effect.exit,
        Effect.flatMap((result) => Deferred.complete(deferred, result)),
        Effect.race(Deferred.await(deferred)),
        Effect.fork
      );

    // check if the window is defined and the _satellite property is defined.
    // Thus, we know that the Adobe Launch script has loaded.
    const validation = () => {
      return (
        typeof window !== 'undefined' &&
        !!window?._satellite &&
        typeof window?._satellite.property?.name === 'string'
      );
    };

    // We unlock and process the queue item only if the validation is true
    // and the deferred is not done/completed.
    return pipe(
      Queue.take(queue),
      Effect.flatMap(([item, deferred]) =>
        Effect.if(Deferred.isDone(deferred) && !validation(), {
          onFalse: () => completeDeferredDequeue(deferred)(item),
          onTrue: () => Effect.void
        })
      ),
      Effect.forever
    );
  };

  return { enqueueItem, processItems, size } as const;
});

export class AnalyticsService extends Context.Tag('AnalyticsService')<
  AnalyticsService,
  Effect.Effect.Success<typeof make>
>() {
  static readonly Live: Layer.Layer<AnalyticsService, never, never> = pipe(
    Layer.scoped(AnalyticsService, make)
  );
}
