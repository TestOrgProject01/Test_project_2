/**
 * MGM's package for initalization analytics in Clients
 *
 * @packageDocumentation
 */
import { createBaseDigitalData } from './createBaseDigitalData.js';
import { setupAnalytics, AnalyticsConfig } from './setupAnalytics.js';
import { populateTrackers, getTrackers } from './trackers/main.js';
import { trackSatellite } from './trackSatellite.js';
import {
  App,
  Page,
  Property,
  Reservation,
  UserStored,
  EventData,
  DigitalData,
  DigitalDataKeysEnum,
  EventDataKeysEnum
} from './types.js';

export type {
  DigitalData,
  AnalyticsConfig,
  App,
  Page,
  Property,
  Reservation,
  UserStored,
  EventData
};
export {
  trackSatellite,
  createBaseDigitalData,
  setupAnalytics,
  populateTrackers,
  getTrackers,
  DigitalDataKeysEnum,
  EventDataKeysEnum
};
