import { merge } from 'rambdax';

import { default as getDefaultApp } from './defaults/getDefaultApp.js';
import { default as getDefaultEvent } from './defaults/getDefaultEvent.js';
import { default as getDefaultPage } from './defaults/getDefaultPage.js';
import { default as getDefaultProperty } from './defaults/getDefaultProperty.js';
import { default as getDefaultReservation } from './defaults/getDefaultReservation.js';
import { default as getDefaultUser } from './defaults/getDefaultUser.js';
import type { DigitalData } from './types.js';

/**
 * Creates a base for the window digitalData object
 *
 * @public
 */
export const createBaseDigitalData = (
  resetData = false
): DigitalData<unknown, unknown> | undefined => {
  if (!window) {
    return;
  }

  if (!window.digitalData || resetData) {
    window.digitalData = {
      app: getDefaultApp(),
      event: [getDefaultEvent()],
      page: getDefaultPage(),
      property: getDefaultProperty(),
      reservation: getDefaultReservation(),
      user: getDefaultUser()
    };

    return window.digitalData;
  }

  window.digitalData = {
    ...window.digitalData,
    app: {
      ...getDefaultApp(),
      ...window.digitalData.app
    },
    event: [merge(getDefaultEvent(), (window.digitalData?.event ?? []).at(-1))],
    page: {
      ...getDefaultPage(),
      ...window.digitalData.page
    },
    property: {
      ...getDefaultProperty(),
      ...window.digitalData.property
    },
    reservation: {
      ...getDefaultReservation(),
      ...window.digitalData.reservation
    },
    user: {
      ...getDefaultUser(),
      ...window.digitalData.user
    }
  };

  return window.digitalData;
};
