import { Effect, Console, Schedule, pipe } from 'effect';

import addScript from './addScript.js';
import { createBaseDigitalData } from './createBaseDigitalData.js';
import { populateTrackers } from './trackers/main.js';

const defaultScriptUrl =
  '//assets.adobedtm.com/ce7ab6763665/01b6ba55e78a/launch-60f2b3bc6eef-staging.min.js';

/**
 * Initial configuration for analytics
 *
 * @public
 */
export interface AnalyticsConfig {
  /**s
   * Analytic script URL
   */
  scriptUrl: string;
  /**
   * If analytics script should be loaded
   */
  loadScript?: boolean;
}

const satelliteObserver = () => {
  const action = Console.log('loading satellite observer...');

  const schedule = Schedule.intersect(
    Schedule.tapOutput(Schedule.fixed('1 second'), () => action),
    Schedule.recurs(3)
  );

  const validation = () => {
    return (
      typeof window !== 'undefined' &&
      !!window?._satellite &&
      typeof window?._satellite.property?.name === 'string'
    );
  };

  class CustomError extends Error {
    // XXX: this lint should not be ignored
    // eslint-disable-next-line @typescript-eslint/parameter-properties
    constructor(message: string, readonly status: boolean) {
      super(message);
    }
  }

  const validationLayer = () =>
    Effect.tryPromise({
      catch: (e) => e as CustomError,
      try: async () => {
        if (validation()) {
          pipe(
            Effect.log('Satellite loaded'),
            Effect.map(() => populateTrackers()),
            Effect.runSync
          );

          return;
        }

        throw new CustomError('Satellite not loaded', false);
      }
    });

  const check = () =>
    validationLayer().pipe(
      Effect.retry({ schedule, while: (err) => err.status === false })
    );

  return Effect.runPromise(check());
};

/**
 * Setup Analytics with base window digitalData object
 * and required script tag
 *
 * @public
 */
export const setupAnalytics = (config: AnalyticsConfig) => {
  const { scriptUrl = defaultScriptUrl, loadScript } = config;

  createBaseDigitalData();

  // XXX: this is wrong and needs promise handling
  // eslint-disable-next-line @typescript-eslint/no-floating-promises
  satelliteObserver().then(() =>
    pipe(Effect.log('Trackers loaded'), Effect.runSync)
  );

  if (!loadScript) return;

  addScript(scriptUrl);
};

export default setupAnalytics;
