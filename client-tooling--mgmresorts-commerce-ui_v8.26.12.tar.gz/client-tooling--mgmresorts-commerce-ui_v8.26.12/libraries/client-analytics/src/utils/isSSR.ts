export const isSSR = () => {
  return (
    !window || !document || !document.body || !!(window && window.SSR_MODE)
  );
};
