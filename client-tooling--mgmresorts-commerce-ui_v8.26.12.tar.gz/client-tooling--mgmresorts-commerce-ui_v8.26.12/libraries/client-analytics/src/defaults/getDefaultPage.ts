import { Page } from '../types.js';

/**
 * Provides default Page values for window object
 *
 * @internal
 */
const getDefaultPage = (): Page => ({
  destinationURL: window?.location?.href ?? '',
  language: 'en'
});

export default getDefaultPage;
