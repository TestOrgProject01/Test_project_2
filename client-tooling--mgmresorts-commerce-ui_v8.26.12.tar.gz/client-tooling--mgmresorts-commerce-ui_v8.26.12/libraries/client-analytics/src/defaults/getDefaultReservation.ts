import { DigitalData } from '../types.js';

/**
 * Provides detault Reservation values for window object
 *
 * @internal
 */
const getDefaultReservation = (): DigitalData<{}, {}>['reservation'] => ({
  cart: {},
  items: [],
  productContext: {
    items: []
  },
  resorts: [],
  roomPrograms: [],
  rooms: [],
  search: {
    resort: {},
    selectedRoomProgram: {
      id: '',
      name: ''
    }
  },
  timeRemaining: undefined,
  type: ''
});

export default getDefaultReservation;
