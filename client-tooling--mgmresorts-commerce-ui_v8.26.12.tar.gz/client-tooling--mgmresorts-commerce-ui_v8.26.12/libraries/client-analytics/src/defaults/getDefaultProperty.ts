import { Property } from '../types.js';

/**
 * Provides default Property values for window object
 *
 * @internal
 */
const getDefaultProperty = (): Property => ({
  id: 'mgmresorts',
  name: 'mgmresorts'
});

export default getDefaultProperty;
