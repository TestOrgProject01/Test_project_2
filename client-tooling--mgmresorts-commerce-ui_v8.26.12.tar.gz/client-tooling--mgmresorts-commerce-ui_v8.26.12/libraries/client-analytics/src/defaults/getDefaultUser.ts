import { DigitalData } from '../types.js';

/**
 * Provides detault User values for window object
 *
 * @internal
 */
const getDefaultUser = (): DigitalData<{}, {}>['user'] => ({
  features: [],
  loggedInStatus: false
});

export default getDefaultUser;
