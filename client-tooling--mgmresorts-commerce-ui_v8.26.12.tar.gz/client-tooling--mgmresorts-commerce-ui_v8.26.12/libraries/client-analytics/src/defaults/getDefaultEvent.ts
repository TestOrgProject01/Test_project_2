import { Event } from '../types.js';

/**
 * Provides default App values for window object
 *
 * @internal
 */
export const getDefaultEvent = (): Event => ({
  attributes: {
    category: '',
    clickType: '',
    section: '',
    subCategory: '',
    title: ''
  },
  eventInfo: {
    eventName: ''
  },
  wait: false
});

export default getDefaultEvent;
