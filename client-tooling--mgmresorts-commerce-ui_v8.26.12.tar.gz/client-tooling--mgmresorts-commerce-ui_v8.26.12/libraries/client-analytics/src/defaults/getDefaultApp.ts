import { App } from '../types.js';

/**
 * Provides default App values for window object
 *
 * @internal
 */
export const getDefaultApp = (): App => ({
  buildNumber: '',
  deepLink: {
    member: false
  },
  name: '',
  version: ''
});

export default getDefaultApp;
