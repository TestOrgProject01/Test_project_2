import { vi, expect, describe, it, afterEach, beforeEach } from 'vitest';

vi.mock('../trackSatellite.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../trackSatellite.js')>()),
  trackSatellite: vi.fn()
}));

import { createBaseDigitalData } from '../createBaseDigitalData.js';
import { mockSatelliteObject, windowSpy } from '../testUtils.js';
import { EventKeyData, trackSatellite } from '../trackSatellite.js';
import {
  DigitalDataKeysEnum,
  EventDataKeysEnum,
  Page,
  propertySlugs
} from '../types.js';

import { getTrackers } from './main.js';

describe('globalTrackSatellite', () => {
  beforeEach(() => {
    windowSpy.mockRestore();
    createBaseDigitalData(true);
    mockSatelliteObject();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it('should call trackSatellite when calling globalTrackSatellite', async () => {
    const { globalTrackSatellite } = getTrackers();

    const data = {
      action: 'increment',
      event: 'reservationDuration'
    } satisfies EventKeyData<EventDataKeysEnum.SearchCriteriaChanged>;

    const propertyKey = DigitalDataKeysEnum.Property;

    const propertyValue = {
      id: 'test id',
      name: propertySlugs[0]
    };

    const digitalData = {
      key: propertyKey,
      value: propertyValue
    };

    await globalTrackSatellite(
      EventDataKeysEnum.SearchCriteriaChanged,
      data,
      digitalData
    );

    expect(window.digitalData[digitalData.key]).toStrictEqual(
      digitalData.value
    );

    expect(trackSatellite).toHaveBeenCalledTimes(1);
  });

  it('should call trackSatellite when calling globalTrackSatellite and update the digitalData correctly if we call globalSetDigitalData', async () => {
    const { globalTrackSatellite } = getTrackers();

    const data = {
      action: 'increment',
      event: 'reservationDuration'
    } satisfies EventKeyData<EventDataKeysEnum.SearchCriteriaChanged>;

    const newValue: Partial<Page> = { genericImpressions: ['test'] };

    const updateValue = (page: Page): Page => ({
      ...page,
      ...newValue
    });

    const digitalData = {
      key: DigitalDataKeysEnum.Page as const,
      value: updateValue
    };

    await globalTrackSatellite(
      EventDataKeysEnum.SearchCriteriaChanged,
      data,
      digitalData
    );

    expect(window.digitalData[digitalData.key]).toStrictEqual({
      ...window.digitalData[digitalData.key],
      ...newValue
    });

    expect(trackSatellite).toHaveBeenCalledTimes(1);
  });
});
