export type AnalyticsKeys =
  | 'room_bookingConfirmation'
  | 'room_bookingPayment'
  | 'room_reviewReservation'
  | 'room_selectDates'
  | 'room_selectRegion'
  | 'room_selectResort'
  | 'room_selectRoom';

export interface JWBModalOpenEvent {
  event: 'modalOpen';
}

export interface JWBModalCloseEvent {
  event: 'modalClose';
}

export interface JWBSignInEvent {
  event: 'signIn';
}

export interface JWBToggleClickEvent {
  event: 'toggleClick';
  description: {
    state: 'on' | 'off';
  };
}

export interface JWBEmailSubmitEvent {
  event: 'emailSubmit';
  description: {
    location: 'modal' | 'banner';
  };
}
