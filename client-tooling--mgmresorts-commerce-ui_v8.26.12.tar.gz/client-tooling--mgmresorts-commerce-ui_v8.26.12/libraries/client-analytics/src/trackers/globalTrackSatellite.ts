import { Effect, pipe } from 'effect';
import { TrackPayload } from 'src/trackSatellite.js';

import { SetDigitalData, Value } from '../dataSetters/types.js';
import { DigitalData, EventData, EventDataKeysEnum } from '../types.js';

export const globalSetDigitalData =
  (setDigitalData: SetDigitalData) =>
  <K extends keyof DigitalData<T, U>, T = unknown, U = unknown>(digitalData: {
    key: K;
    value: Value<K, T, U>;
  }) =>
    pipe(
      Effect.log(
        `globalTrackSatellite setDigitalData: ${JSON.stringify(digitalData)}`
      ),
      Effect.map(() => setDigitalData(digitalData.key, digitalData.value)),
      Effect.runSync
    );

export const globalTrackSatellite =
  (
    setDigitalData: SetDigitalData,
    managedTrackSatellite: (params: TrackPayload) => Promise<void>
  ) =>
  async <
    E extends EventDataKeysEnum,
    K extends keyof DigitalData<T, U>,
    T = unknown,
    U = unknown
  >(
    event: E,
    data: EventData[E],
    digitalData?: {
      key: K;
      value: Value<K, T, U>;
    }
  ) => {
    if (digitalData) {
      globalSetDigitalData(setDigitalData)(digitalData);
    }

    await pipe(
      Effect.log(`globalTrackSatellite`),
      Effect.map(() =>
        managedTrackSatellite({
          data,
          event
        })
      ),
      Effect.runPromise
    );
  };
