import { Effect, Context, Ref, pipe } from 'effect';

import { setManager } from '../dataSetters/actions.js';

import {
  globalTrackSatellite,
  globalSetDigitalData
} from './globalTrackSatellite.js';

interface GlobalTrackers {
  globalTrackSatellite?: ReturnType<typeof globalTrackSatellite>;
  globalSetDigitalData?: ReturnType<typeof globalSetDigitalData>;
}

// Create a Tag for our state
class Trackers extends Context.Tag('Trackers')<
  Trackers,
  Ref.Ref<GlobalTrackers>
>() {}

// Create a Ref instance with an initial value
const initialState = Ref.make({});

/**
 * @public
 */
const populateTrackers = () =>
  pipe(
    Effect.gen(function* () {
      const state = yield* Trackers;

      const { setDigitalData, trackSatellite: managedTrackSatellite } =
        setManager();

      yield* Ref.update(state, (currentState) => {
        const globalTrackFunc = globalTrackSatellite(
          setDigitalData,
          managedTrackSatellite
        );

        const globalSetDigitalDataFunc = globalSetDigitalData(setDigitalData);

        currentState.globalTrackSatellite = globalTrackFunc;
        currentState.globalSetDigitalData = globalSetDigitalDataFunc;

        return currentState;
      });
    }),
    (setTrackers) =>
      Effect.provideServiceEffect(setTrackers, Trackers, initialState),
    Effect.runSync
  );

/**
 * @public
 */
const getTrackers = () =>
  pipe(
    Effect.gen(function* () {
      const state = yield* Trackers;
      const value = yield* Ref.get(state);

      // check if state is empty
      if (Object.keys(value).length === 0) {
        populateTrackers();
      }

      const result = yield* Ref.get(state);

      return result as Required<GlobalTrackers>;
    }),
    (getFunction) =>
      Effect.provideServiceEffect(getFunction, Trackers, initialState),
    Effect.runSync
  );

export { populateTrackers, getTrackers };
