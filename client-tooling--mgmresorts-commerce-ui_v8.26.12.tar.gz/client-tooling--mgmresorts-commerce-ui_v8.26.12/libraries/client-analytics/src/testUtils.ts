import { mergeDeepRight } from 'rambdax';
import { vi } from 'vitest';

const originalWindow = { ...global.window };

const randomString = (length = 6) =>
  Math.random().toString(20).substring(2, length);

export const createSatelliteObject = (
  data?: Partial<typeof window._satellite>
): typeof window._satellite =>
  mergeDeepRight(
    {
      property: { id: randomString(), name: randomString() },
      setDebug: vi.fn(),
      track: vi.fn()
    },
    data ?? {}
  );

export const windowSpy = vi.spyOn(global, 'window', 'get');

export const mockWindowObject = (newConfig: unknown) => {
  windowSpy.mockReturnValue({
    ...originalWindow,
    ...(newConfig as object)
  });

  global.window = originalWindow;
};

export const mockSatelliteObject = (
  data?: Partial<typeof window._satellite>
) => {
  if (!window) {
    return;
  }

  if (typeof window?._satellite === 'undefined') {
    window._satellite = createSatelliteObject(data);
  }
};
