## 1.10.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 1.10.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **analytics:** added new event data key (WP-5062) (PATCH) ([#542](https://github.com/MGMResorts/client-tooling/pull/542))
- manual bump (CSBP-3880) (MINOR) ([d05efb09](https://github.com/MGMResorts/client-tooling/commit/d05efb09))
- manual bump (CSBP-3880) (MINOR) ([0889fe9d](https://github.com/MGMResorts/client-tooling/commit/0889fe9d))
- **analytics:** added new event data key (WP-5062) (PATCH) ([#539](https://github.com/MGMResorts/client-tooling/pull/539))
- **analytics:** added new event data key (WP-5062) (PATCH) ([#538](https://github.com/MGMResorts/client-tooling/pull/538))
- **analytics:** error tracking generic function (CSBP-3365) (MINOR) ([#514](https://github.com/MGMResorts/client-tooling/pull/514))
- **analytics:** types updated (CSBP-3365) (MINOR) ([#503](https://github.com/MGMResorts/client-tooling/pull/503))
- **analytics:** types updated (CSBP-3982) (MINOR) ([#496](https://github.com/MGMResorts/client-tooling/pull/496))
- **analytics:** types updated (CSBP-3982) (MINOR) ([#494](https://github.com/MGMResorts/client-tooling/pull/494))
- **commerce-ui:** timer and analytics queue updated (CSBP-3980) (MINOR) ([#369](https://github.com/MGMResorts/client-tooling/pull/369))
- **analytics:** script load check (CSBP-3431) (MINOR) ([#332](https://github.com/MGMResorts/client-tooling/pull/332))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **analytics:** added web-utils lib (WP-4125) (MINOR) ([#235](https://github.com/MGMResorts/client-tooling/pull/235))
- **analytics:** added new propertySlugs (WP-4125) (PATCH) ([#234](https://github.com/MGMResorts/client-tooling/pull/234))
- **analytics:** update digital data mapping (WP-4125) (MINOR) ([#233](https://github.com/MGMResorts/client-tooling/pull/233))
- **analytics:** minor updates (CSBP-3047) (MINOR) ([#208](https://github.com/MGMResorts/client-tooling/pull/208))
- **commerce-ui:** package header price loading (CSBP-3672) (MINOR) ([#197](https://github.com/MGMResorts/client-tooling/pull/197))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **analytics:** minor updates (CSBP-3739) (MINOR) ([#189](https://github.com/MGMResorts/client-tooling/pull/189))
- **analytics:** types export update (CSBP-3709) (MINOR) ([#185](https://github.com/MGMResorts/client-tooling/pull/185))
- **analytics:** minor updates (CSBP-3709) (MINOR) ([#184](https://github.com/MGMResorts/client-tooling/pull/184))
- **analytics:** minor updates (CSBP-3709) (MINOR) ([#183](https://github.com/MGMResorts/client-tooling/pull/183))
- **analytics:** control logic (CSBP-3709) (MINOR) ([#170](https://github.com/MGMResorts/client-tooling/pull/170))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- Add checks to commerce ui - CSBP-2287 ([#48](https://github.com/MGMResorts/client-tooling/pull/48))
- **vega-tailwind:** initial package release ([#19](https://github.com/MGMResorts/client-tooling/pull/19))
- removed empty changelog files ([b8a58fb6](https://github.com/MGMResorts/client-tooling/commit/b8a58fb6))
- correcting publishh problem ([0e062851](https://github.com/MGMResorts/client-tooling/commit/0e062851))
- added new analytics package ([#16](https://github.com/MGMResorts/client-tooling/pull/16))

### 🩹 Fixes

- **urql,client-utils:** provision source header correctly for URQL (PATCH (NONE) ([#284](https://github.com/MGMResorts/client-tooling/pull/284))
- **ci:** docs (PATCH) (NONE) ([#280](https://github.com/MGMResorts/client-tooling/pull/280))
- **analytics:** event destructuring  (WP-4125) (PATCH) ([#264](https://github.com/MGMResorts/client-tooling/pull/264))
- **analytics:** change event data to be an array (WP-4125) (PATCH) ([#261](https://github.com/MGMResorts/client-tooling/pull/261))
- **analytics:** fixing event props (WP-4125) (PATCH) ([#259](https://github.com/MGMResorts/client-tooling/pull/259))
- **analytics:** changing event enum and props (WP-4125) (PATCH) ([#255](https://github.com/MGMResorts/client-tooling/pull/255))
- **analytics:** bumping version manually (WP-4125) (PATCH) ([#253](https://github.com/MGMResorts/client-tooling/pull/253))
- **analytics:** added the defaultEvent digitalData (WP-4125) (PATCH) ([#251](https://github.com/MGMResorts/client-tooling/pull/251))
- **analytics:** minor updates (CSBP-3814) (MINOR) ([#239](https://github.com/MGMResorts/client-tooling/pull/239))
- **analytics:** added the defaultEvent func (WP-4125) (PATCH) ([#236](https://github.com/MGMResorts/client-tooling/pull/236))
- **analytics:** minor updates (CSBP-3814) (MINOR) ([#231](https://github.com/MGMResorts/client-tooling/pull/231))
- **analytics:** bug fixes (CSBP-3709) (MINOR) ([#181](https://github.com/MGMResorts/client-tooling/pull/181))
- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Gustavo Arellano @GustavoFSLCo
- Lukas Machado @lukasmachado-mgm
- Rob Fyffe @rfyffe-mgmresorts
- Thomas Kelly
- voliveira-mgm @voliveira-mgm

# Change Log - @mgmresorts/client-analytics

This log was last generated on Fri, 20 Dec 2024 15:00:45 GMT and should not be manually modified.

## 1.9.11
Fri, 20 Dec 2024 15:00:45 GMT

### Patches

- reverting change

## 1.9.10
Wed, 18 Dec 2024 13:37:25 GMT

### Patches

- added new event data key
- added new event data key
- added eventdata payload

## 1.9.6
Mon, 25 Nov 2024 16:22:25 GMT

### Patches

- Updating error event id

## 1.9.5
Mon, 25 Nov 2024 15:04:08 GMT

### Patches

- Updating events type for analytics

## 1.9.4
Wed, 20 Nov 2024 05:42:47 GMT

### Patches

- PackageDetails interface updated

## 1.9.3
Wed, 20 Nov 2024 05:32:53 GMT

### Patches

- ReservationProductContextItem interface updated

## 1.9.2
Wed, 20 Nov 2024 04:08:51 GMT

### Patches

- Analytics types updated
- Adding public tag for new types

## 1.9.1
Fri, 18 Oct 2024 16:24:25 GMT

### Patches

- Bump dependencies

## 1.9.0
Tue, 24 Sep 2024 15:34:18 GMT

### Minor changes

- updating analytics queue

## 1.8.15
Wed, 04 Sep 2024 19:54:19 GMT

### Patches

- Adding check to load the analytics script

## 1.8.14
Tue, 03 Sep 2024 18:45:27 GMT

_Version update only_

## 1.8.13
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 1.8.12
Sat, 10 Aug 2024 03:47:47 GMT

### Patches

- Upgrade `effect` and `vitest`

## 1.8.11
Fri, 09 Aug 2024 02:51:20 GMT

### Patches

- Add missing api-extractor dependency to devDependencies

## 1.8.10
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 1.8.9
Wed, 31 Jul 2024 19:23:27 GMT

### Patches

- Fix peer dependencies

## 1.8.8
Tue, 30 Jul 2024 19:58:12 GMT

### Patches

- fixing event destructuring

## 1.8.7
Mon, 29 Jul 2024 22:38:21 GMT

### Patches

- changed event prop to be an array

## 1.8.6
Mon, 29 Jul 2024 19:40:27 GMT

### Patches

- fixing event props

## 1.8.5
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish
- changing event enum and props
- bumping version manually
- adding default digitalData

## 1.8.2
Mon, 22 Jul 2024 15:24:21 GMT

### Patches

- rollback to grab property slugs

## 1.8.1
Fri, 19 Jul 2024 14:59:25 GMT

### Patches

- added the defaultEvent func to init the event property

## 1.8.0
Thu, 18 Jul 2024 20:07:21 GMT

### Minor changes

- added web-utils lib to reuse propertySlugs
- added a new DigitalData object for an event

### Patches

- added new property slugs
- updating types to new defaults

## 1.5.0
Tue, 25 Jun 2024 01:09:05 GMT

### Minor changes

- Adding validation layer to check if the satellite script was loaded

## 1.4.0
Tue, 18 Jun 2024 18:14:52 GMT

### Minor changes

- Adding loading prop for package header

## 1.3.5
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 1.3.4
Mon, 10 Jun 2024 19:51:16 GMT

### Patches

- Minor update on how we start the analytics trackers

## 1.3.3
Thu, 06 Jun 2024 20:19:45 GMT

### Patches

- Updating export types

## 1.3.2
Thu, 06 Jun 2024 18:05:16 GMT

### Patches

- Decoupling global functionalities

## 1.3.1
Thu, 06 Jun 2024 16:08:10 GMT

### Patches

- Refactoring track satellite call since the previous try catch was not being called

## 1.3.0
Thu, 06 Jun 2024 03:25:03 GMT

### Minor changes

- bug fixes into new analytics app

## 1.2.0
Wed, 05 Jun 2024 21:37:48 GMT

### Minor changes

- updating analytics control logic

## 1.1.12
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 1.1.11
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 1.1.10
Thu, 08 Feb 2024 16:13:06 GMT

_Version update only_

## 1.1.9
Thu, 09 Nov 2023 23:02:38 GMT

_Version update only_

## 1.1.8
Thu, 09 Nov 2023 22:21:40 GMT

_Version update only_

## 1.1.7
Wed, 01 Nov 2023 13:00:43 GMT

_Version update only_

## 1.1.6
Tue, 31 Oct 2023 18:44:27 GMT

_Version update only_

## 1.1.5
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 1.1.4
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 1.1.3
Wed, 07 Jun 2023 06:34:34 GMT

_Version update only_

## 1.1.2
Wed, 07 Jun 2023 02:29:28 GMT

_Version update only_

## 1.1.1
Wed, 24 May 2023 12:41:01 GMT

_Version update only_

## 1.1.0
Tue, 09 May 2023 20:22:41 GMT

### Minor changes

- initial commit of new package
- Updated Readme title
- removed empty changelog files

