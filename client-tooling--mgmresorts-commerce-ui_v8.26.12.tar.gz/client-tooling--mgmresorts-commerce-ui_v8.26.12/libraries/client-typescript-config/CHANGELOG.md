## 2.6.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 2.6.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- removed rushstack dependencies ([11231af6](https://github.com/MGMResorts/client-tooling/commit/11231af6))
- added variations of tsconfig ([cf14563c](https://github.com/MGMResorts/client-tooling/commit/cf14563c))
- moved rush rig dependency from dev ([bc5d6db9](https://github.com/MGMResorts/client-tooling/commit/bc5d6db9))
- added new testing package ([10ca1f5d](https://github.com/MGMResorts/client-tooling/commit/10ca1f5d))
- added new typescript config package ([a79f8c45](https://github.com/MGMResorts/client-tooling/commit/a79f8c45))

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Rob Fyffe

# Change Log - @mgmresorts/client-typescript-config

This log was last generated on Wed, 07 Aug 2024 20:50:00 GMT and should not be manually modified.

## 2.5.5
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 2.5.4
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 2.5.3
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 2.5.2
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 2.5.1
Thu, 20 Apr 2023 18:51:09 GMT

### Patches

- removed index file

## 2.5.0
Fri, 14 Apr 2023 04:59:47 GMT

### Minor changes

- removed rushstack dependencies

## 2.4.0
Fri, 14 Apr 2023 04:45:04 GMT

### Minor changes

- added variations of tsconfig

## 2.3.0
Fri, 14 Apr 2023 03:46:03 GMT

### Minor changes

- moved rush heft rig to dependency

## 2.2.0
Wed, 12 Apr 2023 20:03:37 GMT

### Minor changes

- updated base configuration to remove options

## 2.1.0
Mon, 10 Apr 2023 22:54:54 GMT

### Minor changes

- added new package for managing typescript configuration

