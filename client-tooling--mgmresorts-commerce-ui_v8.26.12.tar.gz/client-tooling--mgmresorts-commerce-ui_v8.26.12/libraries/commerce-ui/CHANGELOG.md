## 8.26.12 (2025-04-03)

### 🩹 Fixes

- add focus indicator for all sections (CSBP-4406) (PATCH) ([#606](https://github.com/MGMResorts/client-tooling/pull/606))
- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1
- Updated vega-tailwind to 0.7.1

### ❤️ Thank You

- Daniel Roma @danielromafsl
- David Morales @davidamorales

## 8.26.11 (2025-03-26)

### 🩹 Fixes

- **section-selection-map:** add aria hidden only for the section label ([#601](https://github.com/MGMResorts/client-tooling/pull/601))

### ❤️ Thank You

- Irving Caamal

## 8.26.10 (2025-03-24)

### 🩹 Fixes

- **commerce-ui:** Add forwardRef to RoomsResortBottomPanel (PATCH) (DBXB-4872) ([#600](https://github.com/MGMResorts/client-tooling/pull/600))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.26.9 (2025-03-18)

### 🩹 Fixes

- **commerce-ui:** Fix map resort card close button position (PATCH) (DBXB-4791) ([#599](https://github.com/MGMResorts/client-tooling/pull/599))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.26.8 (2025-03-14)

### 🩹 Fixes

- **commerce-ui:** dependencies updated (CSBP-4643) (MINOR) ([#598](https://github.com/MGMResorts/client-tooling/pull/598))

### ❤️ Thank You

- Lukas Machado @lukasmachado-mgm

## 8.26.7 (2025-03-14)

### 🩹 Fixes

- **commerce-ui:** UI fixes (PATCH) (DBXB-4791) ([#597](https://github.com/MGMResorts/client-tooling/pull/597))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.26.6 (2025-03-14)

### 🩹 Fixes

- update accessibility attributes from checkmark of selected secton (PATCH) (CSBP-4402) ([#596](https://github.com/MGMResorts/client-tooling/pull/596))

### ❤️ Thank You

- Irving Caamal

## 8.26.5 (2025-03-11)

### 🩹 Fixes

- **commerce-ui:** fix UI issues (PATCH) (DBXB-4791) ([#595](https://github.com/MGMResorts/client-tooling/pull/595))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.26.4 (2025-03-10)

### 🩹 Fixes

- **commerce-ui:** components updated (CSBP-4693) (MINOR) ([#594](https://github.com/MGMResorts/client-tooling/pull/594))

### ❤️ Thank You

- Lukas Machado @lukasmachado-mgm

## 8.26.3 (2025-03-10)

### 🩹 Fixes

- **accessibility:** components updated (CSBP-4373) (MINOR) ([#593](https://github.com/MGMResorts/client-tooling/pull/593))

### ❤️ Thank You

- Lukas Machado @lukasmachado-mgm

## 8.26.2 (2025-03-07)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- **accessibility:** components updated (CSBP-4373) (MINOR) ([#592](https://github.com/MGMResorts/client-tooling/pull/592))

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Lukas Machado @lukasmachado-mgm

## 8.26.1 (2025-03-03)

### 🩹 Fixes

- **accessibility:** update heading level in the previuos step indicator component (CSBP-4439)(MINOR) ([#591](https://github.com/MGMResorts/client-tooling/pull/591))

### ❤️ Thank You

- Gustavo Arellano @GustavoFSLCo

## 8.26.0 (2025-02-28)

### 🚀 Features

- **commerce-ui:** New Map variant for Rooms Resort Card (MINOR) (DBXB-4791) ([#588](https://github.com/MGMResorts/client-tooling/pull/588))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.25.4 (2025-02-27)

### 🩹 Fixes

- **commerce-ui:** Restore href for already member link (PATCH) (DBXB-4600) ([#589](https://github.com/MGMResorts/client-tooling/pull/589))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.25.3 (2025-02-26)

### 🩹 Fixes

- add disabled property and adjust design (CSBP-4626) (PATCH) ([#586](https://github.com/MGMResorts/client-tooling/pull/586))

### ❤️ Thank You

- David Morales @davidamorales

## 8.25.2 (2025-02-25)

### 🩹 Fixes

- **a11y:** improve accessibility attributes for section selection (CSBP-4402) ([#587](https://github.com/MGMResorts/client-tooling/pull/587))

### ❤️ Thank You

- Irving Caamal

## 8.25.1 (2025-02-19)

### 🩹 Fixes

- user transparent included resort card design  (CSBP-4557) (PATCH) ([#585](https://github.com/MGMResorts/client-tooling/pull/585))

### ❤️ Thank You

- David Morales @davidamorales

## 8.25.0 (2025-02-17)

### 🚀 Features

- implemented resort fee in the change resort dropdown (MINOR) (DBXB-4764) ([#583](https://github.com/MGMResorts/client-tooling/pull/583))

### ❤️ Thank You

- Daniel Silva @dsilvamgm

## 8.24.6 (2025-02-14)

### 🩹 Fixes

- **commerce-ui:** Accessibility focus fix (PATCH) (DBXB-4576) ([#582](https://github.com/MGMResorts/client-tooling/pull/582))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.24.5 (2025-02-12)

### 🩹 Fixes

- **section-selection-map:** hide a11y toggle when there's no a11y seats (MINOR) (CSBP-4404) (CSBP-4402) ([#578](https://github.com/MGMResorts/client-tooling/pull/578))

### ❤️ Thank You

- Irving Caamal

## 8.24.4 (2025-02-12)

### 🩹 Fixes

- **commerce-ui:** event-info-card hotfix (CSBP-4458) (MINOR) ([#580](https://github.com/MGMResorts/client-tooling/pull/580))

### ❤️ Thank You

- Lukas Machado @lukasmachado-mgm

## 8.24.3 (2025-02-12)

### 🩹 Fixes

- **commerce-ui:** event-inof-card hotfix (CSBP-4458) (MINOR) ([#579](https://github.com/MGMResorts/client-tooling/pull/579))

### ❤️ Thank You

- Lukas Machado @lukasmachado-mgm

## 8.24.2 (2025-02-06)

### 🩹 Fixes

- fixed accessibility issues in the offer radio buttons (PATCH) (DBXB-4628) ([#577](https://github.com/MGMResorts/client-tooling/pull/577))

### ❤️ Thank You

- Daniel Silva @dsilvamgm

## 8.24.1 (2025-02-05)

### 🩹 Fixes

- **commerce-ui:** Loading skeleton for Offer Carousel (MINOR) (DBXB-4711) ([#576](https://github.com/MGMResorts/client-tooling/pull/576))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.24.0 (2025-01-31)

### 🚀 Features

- improve heading structure for accessibility (CSBP-4358) (MINOR) ([#575](https://github.com/MGMResorts/client-tooling/pull/575))

### ❤️ Thank You

- Italo Andrade @italoiz-mgm

## 8.23.1 (2025-01-30)

### 🩹 Fixes

- **commerce-ui:** Add missing stopPropagation to 'More details' handler (PATCH) (DBXB-4751) ([#574](https://github.com/MGMResorts/client-tooling/pull/574))

### ❤️ Thank You

- Guido Quispe @guido-mgm

## 8.23.0 (2025-01-28)

### 🚀 Features

- ticket type price align adjustments (CSBP-4236) (MINOR) ([#572](https://github.com/MGMResorts/client-tooling/pull/572))

### ❤️ Thank You

- David Morales @davidamorales

## 8.22.0 (2025-01-27)

### 🚀 Features

- ticket type new component (CSBP-4236) (MINOR) ([#571](https://github.com/MGMResorts/client-tooling/pull/571))

### ❤️ Thank You

- David Morales @davidamorales

## 8.21.0 (2025-01-27)

### 🚀 Features

- **commerce-ui:** minor updates (CSBP-4360) (MINOR) ([#570](https://github.com/MGMResorts/client-tooling/pull/570))
- restored the no thanks button on the jwb modal (MINOR) (DBXB-4725) ([#569](https://github.com/MGMResorts/client-tooling/pull/569))

### 🩹 Fixes

- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))
- **commerce-ui:** Rollback for Room Booking release v4.12.2 (PATCH) (DBXB-4711) ([#567](https://github.com/MGMResorts/client-tooling/pull/567))

### ❤️ Thank You

- Daniel Silva @dsilvamgm
- Guido Quispe @guido-mgm
- Lukas Machado @lukasmachado-mgm

## 8.20.0 (2025-01-22)

### 🚀 Features

- rush cleanup & arbitrary release (MINOR) (CET-492) ([ccfb8fe3](https://github.com/MGMResorts/client-tooling/commit/ccfb8fe3))
- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))

### 🩹 Fixes

- fixed scroll issue in the carousel when scrolling the entire page (PATCH) (DBXB-4732) ([#566](https://github.com/MGMResorts/client-tooling/pull/566))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0
- Updated vega-tailwind to 0.7.0

### ❤️ Thank You

- Daniel Silva @dsilvamgm
- Eric Hegnes @ehegnes-mgm
- Rob Fyffe

## 9.0.1 (2025-01-22)

### 🩹 Fixes

- fixed scroll issue in the carousel when scrolling the entire page (PATCH) (DBXB-4732) ([#566](https://github.com/MGMResorts/client-tooling/pull/566))

### ❤️ Thank You

- Daniel Silva @dsilvamgm

# 9.0.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **map:** section selection update zoom and drag section map (CSBP-4126)(MINOR) ([#549](https://github.com/MGMResorts/client-tooling/pull/549))
- feature design change stay price clarity transparent flow (CSBP-3920) (MINOR) ([#546](https://github.com/MGMResorts/client-tooling/pull/546))
- feature design change stay price clarity transparent flow (CSBP-3920) (MINOR) ([#545](https://github.com/MGMResorts/client-tooling/pull/545))
- **commerce-ui:** room card button state updated  (CSBP-3998) (MINOR) ([#540](https://github.com/MGMResorts/client-tooling/pull/540))
- **resort-bottom-panel:** adjust styles (PATCH) (DBXB-4609) ([#535](https://github.com/MGMResorts/client-tooling/pull/535))
- fixed room card styling issue on Safari (PATCH) (DBXB-4186) ([#532](https://github.com/MGMResorts/client-tooling/pull/532))
- improve accessibility for event and price filters (CSBP-3955) (MINOR) ([#524](https://github.com/MGMResorts/client-tooling/pull/524))
- ensure accessibility for section ga map (CSBP-3918) (MINOR) ([#486](https://github.com/MGMResorts/client-tooling/pull/486))
- **rooms-resort-selection-summary:** add desktop support (MINOR) (DBXB-4403) ([#480](https://github.com/MGMResorts/client-tooling/pull/480))
- section selection available sections (CSBP-4059) (MINOR) ([#477](https://github.com/MGMResorts/client-tooling/pull/477))
- **commerce-ui:** PriceAndSeatsBottomSheet updated (CSBP-2323) (MINOR) ([#474](https://github.com/MGMResorts/client-tooling/pull/474))
- **commerce-ui:** PriceAndSeatsBottomSheet updated (CSBP-2323) (MINOR) ([#473](https://github.com/MGMResorts/client-tooling/pull/473))
- handle section ga map prevent hidden (CSBP-3762) (MINOR) ([#466](https://github.com/MGMResorts/client-tooling/pull/466))
- **commerce-ui:** timer color thresholds (CSBP-3990) (MINOR) ([#459](https://github.com/MGMResorts/client-tooling/pull/459))
- **commerce-ui:** minor updates (CSBP-3990) (MINOR) ([#458](https://github.com/MGMResorts/client-tooling/pull/458))
- **commerce-ui:** minor updates (CSBP-3990) (MINOR) ([#457](https://github.com/MGMResorts/client-tooling/pull/457))
- **commerce-ui:** minor updates (CSBP-3990) (MINOR) ([#456](https://github.com/MGMResorts/client-tooling/pull/456))
- **commerce-ui:** minor updates (CSBP-3990) (MINOR) ([#455](https://github.com/MGMResorts/client-tooling/pull/455))
- **commerce-ui:** minor updates (CSBP-3990) (MINOR) ([#454](https://github.com/MGMResorts/client-tooling/pull/454))
- **timer:** minor updates (CSBP-3990) (MINOR) ([#452](https://github.com/MGMResorts/client-tooling/pull/452))
- handle section ga map (CSBP-3762) (MINOR) ([#435](https://github.com/MGMResorts/client-tooling/pull/435))
- **rooms-available-room-rates:** start using the carousel component from mgm-ui (MINOR) (DBXB-4335) ([#431](https://github.com/MGMResorts/client-tooling/pull/431))
- **commerce-ui:** event info and price seats (CSBP-2319) (MINOR) ([#434](https://github.com/MGMResorts/client-tooling/pull/434))
- **contentstack:** continue passing data-cms to more components (MINOR) (DBXB-4348) ([#418](https://github.com/MGMResorts/client-tooling/pull/418))
- fixed styling issues in the select room page components (PATCH) (DBXB-4184) ([#404](https://github.com/MGMResorts/client-tooling/pull/404))
- **contentstack:** add data-cms (MINOR) (DBXB-4340) ([#409](https://github.com/MGMResorts/client-tooling/pull/409))
- fixed tablet styling issues (PATCH) (DBXB-4264) ([#398](https://github.com/MGMResorts/client-tooling/pull/398))
- **rooms-segment-banner:** add mobile variant (MINOR) (DBXB-4325) ([#393](https://github.com/MGMResorts/client-tooling/pull/393))
- **commerce-ui:** accessibility updates  (CSBP-3957) (MINOR) ([#389](https://github.com/MGMResorts/client-tooling/pull/389))
- fixed comp scenarios in the room details modal and resort dropdown (PATCH) (DBXB-4213) ([#388](https://github.com/MGMResorts/client-tooling/pull/388))
- fixed small styling issues in the room details modal (PATCH) (DBXB-4213) ([#383](https://github.com/MGMResorts/client-tooling/pull/383))
- implemented comp scenarios for the resort dropdown (MINOR) (DBXB-4205) ([#381](https://github.com/MGMResorts/client-tooling/pull/381))
- add accessibility requirements for resort components (CSBP-3956) (MAJOR) ([#373](https://github.com/MGMResorts/client-tooling/pull/373))
- implemented comp scenarios in the room details modal for desktop (MINOR) (DBXB-4213) ([#375](https://github.com/MGMResorts/client-tooling/pull/375))
- implemented dates selected and no resort selected state for the calendar bottom panel (PATCH) (DBXB-4252) ([#376](https://github.com/MGMResorts/client-tooling/pull/376))
- implemented room selected panel for desktop (MINOR) (DBXB-4270) ([#371](https://github.com/MGMResorts/client-tooling/pull/371))
- **commerce-ui:** event info updates (CSBP-3930) (MINOR) ([#372](https://github.com/MGMResorts/client-tooling/pull/372))
- **commerce-ui:** timer and analytics queue updated (CSBP-3980) (MINOR) ([#369](https://github.com/MGMResorts/client-tooling/pull/369))
- implemented calendar bottom panel (MINOR) (DBXB-4252) ([#368](https://github.com/MGMResorts/client-tooling/pull/368))
- **commerce-ui:** timer analytics callback (CSBP-3980) (MINOR) ([#359](https://github.com/MGMResorts/client-tooling/pull/359))
- **rooms-filters-control-modal:** add desktop variant (MINOR) (DBXB-4170) ([#330](https://github.com/MGMResorts/client-tooling/pull/330))
- implemented disabled room selection button (MINOR) (DBXB-4174) ([#348](https://github.com/MGMResorts/client-tooling/pull/348))
- **rooms-tooltip:** add component (MINOR) (DBXB-4180) ([#331](https://github.com/MGMResorts/client-tooling/pull/331))
- implemented room selection button (MINOR) (DBXB-4174) ([#346](https://github.com/MGMResorts/client-tooling/pull/346))
- implemented room selected panel (MINOR) (DBXB-4255) ([#344](https://github.com/MGMResorts/client-tooling/pull/344))
- PB - feature design change seat selection panel bayg price update (CSBP-3921) (MINOR) ([#343](https://github.com/MGMResorts/client-tooling/pull/343))
- added desktop guest count in the storybook (MINOR) (DBXB-4175) ([#335](https://github.com/MGMResorts/client-tooling/pull/335))
- implemented comp stay at other resorts alert for desktop (MINOR) (DBXB-4169) ([#334](https://github.com/MGMResorts/client-tooling/pull/334))
- **rooms-footer:** add component (MINOR) (DBXB-4167) ([#322](https://github.com/MGMResorts/client-tooling/pull/322))
- start using mgm-ui ([#309](https://github.com/MGMResorts/client-tooling/pull/309))
- integrated modal from mgm-ui into room details component (MINOR) (DBXB-4149) ([#297](https://github.com/MGMResorts/client-tooling/pull/297))
- **commerce-ui:** Dates Overlay component (MINOR) (DBXB-4131) ([#276](https://github.com/MGMResorts/client-tooling/pull/276))
- set up design tokens provider in the storybook  (MINOR) (DBXB-4133) ([#294](https://github.com/MGMResorts/client-tooling/pull/294))
- **jwb-modal:** add desktop variant (MINOR) (DBXB-4153) ([#269](https://github.com/MGMResorts/client-tooling/pull/269))
- added cta button in the offer details page for unselected offer (MINOR) (DBXB-4133) ([#292](https://github.com/MGMResorts/client-tooling/pull/292))
- created room details modal content for desktop (MINOR) (DBXB-4149) ([#288](https://github.com/MGMResorts/client-tooling/pull/288))
- fixed styling issue in the sort by pricing dropdown (MINOR) (DBXB-4171) ([#289](https://github.com/MGMResorts/client-tooling/pull/289))
- **rooms-pricing-details-modal:** add desktop variant (MINOR) (DBXB-4150) ([#270](https://github.com/MGMResorts/client-tooling/pull/270))
- **jwb-banner:** add desktop variant (MINOR) (DBXB-4152) ([#279](https://github.com/MGMResorts/client-tooling/pull/279))
- **rooms-available-room-rates-modal:** support for desktop (MINOR) (DBXB-4137) ([#247](https://github.com/MGMResorts/client-tooling/pull/247))
- created sort by pricing dropdown (MINOR) (DBXB-4171) ([#286](https://github.com/MGMResorts/client-tooling/pull/286))
- **commerce-ui:** CSS fixes to match Figma design (PATCH) (DBXB-3964) ([#281](https://github.com/MGMResorts/client-tooling/pull/281))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- created region dropdown for desktop (MINOR) (DBXB-4154) ([#274](https://github.com/MGMResorts/client-tooling/pull/274))
- fixed resort dropdown styling issues (MINOR) (DBXB-4138) ([#275](https://github.com/MGMResorts/client-tooling/pull/275))
- **commerce-ui:** Rooms destination dropdown improvements (MINOR) (DBXB-4173) ([#262](https://github.com/MGMResorts/client-tooling/pull/262))
- **commerce-ui:** roon card cta selected state design discrepancy (CSBP-3891)(MINOR) ([#272](https://github.com/MGMResorts/client-tooling/pull/272))
- **rooms-resort-fee-information-modal:** support desktop variant (MINOR) (DBXB-4151) ([#250](https://github.com/MGMResorts/client-tooling/pull/250))
- **commerce-ui:** Rooms Tabs & PO Tab components (MINOR) (DBXB-4179) ([#252](https://github.com/MGMResorts/client-tooling/pull/252))
- **commerce-ui:** Dates input component (MINOR) (DBXB-4131) ([#245](https://github.com/MGMResorts/client-tooling/pull/245))
- **rooms-filters-control-modal:** update accessibility filter (MINOR) (DBXB-4172) ([#246](https://github.com/MGMResorts/client-tooling/pull/246))
- created resort dropdown component for desktop (MINOR) (DBXB-4138) ([#267](https://github.com/MGMResorts/client-tooling/pull/267))
- **commerce-ui:** discrepancies in landing page (CSBP-3879)(MINOR) ([#265](https://github.com/MGMResorts/client-tooling/pull/265))
- **rooms-available-room-rates:** add component (MINOR) (DBXB-4126) ([#229](https://github.com/MGMResorts/client-tooling/pull/229))
- created a new dropdown component for room booking (MINOR) (DBXB-4138) ([#260](https://github.com/MGMResorts/client-tooling/pull/260))
- fixed carousel styling and refactored room booking carousel (MINOR) (DBXB-4111) ([#254](https://github.com/MGMResorts/client-tooling/pull/254))
- **commerce-ui:** Rooms PO at other resorts component (MINOR) (DBXB-4156) ([#257](https://github.com/MGMResorts/client-tooling/pull/257))
- **commerce-ui:** Alert component (MINOR) (DBXB-4156) ([#256](https://github.com/MGMResorts/client-tooling/pull/256))
- created desktop segment modal (MINOR) (DBXB-4130) ([#248](https://github.com/MGMResorts/client-tooling/pull/248))
- fixed resort card styling (PATCH) (DBXB-4107) ([#249](https://github.com/MGMResorts/client-tooling/pull/249))
- **commerce-ui:** Rooms JWB Banner (MINOR) (DBXB-4121) ([#221](https://github.com/MGMResorts/client-tooling/pull/221))
- created desktop offer details modal (MINOR) (DBXB-4132) ([#244](https://github.com/MGMResorts/client-tooling/pull/244))
- **room-resort-details-modal:** support desktop variant (MINOR) (DBXB-4123) ([#223](https://github.com/MGMResorts/client-tooling/pull/223))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- fixed styling issues in the resort card for desktop (PATCH) (DBXB-4107) ([#237](https://github.com/MGMResorts/client-tooling/pull/237))
- add enablePriceAnimation prop to control price animation (CSBP-3671) (MINOR) ([#238](https://github.com/MGMResorts/client-tooling/pull/238))
- fixed styling issues for the applied offer section (PATCH) (DBXB-4103) ([#230](https://github.com/MGMResorts/client-tooling/pull/230))
- **analytics:** added web-utils lib (WP-4125) (MINOR) ([#235](https://github.com/MGMResorts/client-tooling/pull/235))
- created room cards for desktop (MINOR) (DBXB-4124) ([#228](https://github.com/MGMResorts/client-tooling/pull/228))
- **rooms-available-room-rates-modal:** add component (MINOR) (DBXB-4085) ([#218](https://github.com/MGMResorts/client-tooling/pull/218))
- created applied offer section for desktop po users (MINOR) (DBXB-4125) ([#225](https://github.com/MGMResorts/client-tooling/pull/225))
- created unavailable resort card variant for desktop (MINOR) (DBXB-4107) ([#224](https://github.com/MGMResorts/client-tooling/pull/224))
- created segment banner component for desktop (MINOR) (DBXB-4103) ([#222](https://github.com/MGMResorts/client-tooling/pull/222))
- **jwb-modal:** add component (MINOR) (DBXB-4122) ([#214](https://github.com/MGMResorts/client-tooling/pull/214))
- added swiping feature to the rooms carousel (MINOR) (DBXB-4071) ([#220](https://github.com/MGMResorts/client-tooling/pull/220))
- **rooms-pricing-details-modal:** add component (MINOR) (DBXB-4086) ([#211](https://github.com/MGMResorts/client-tooling/pull/211))
- implemented rooms resort card for desktop (MINOR) (DBXB-4107) ([#217](https://github.com/MGMResorts/client-tooling/pull/217))
- **commerce-ui:** minor updates on room card (CSBP-3049) (MINOR) ([#216](https://github.com/MGMResorts/client-tooling/pull/216))
- **commerce-ui:** minor updates on room card (CSBP-3049) (MINOR) ([#215](https://github.com/MGMResorts/client-tooling/pull/215))
- fixed decimal places in the room details pricing (MINOR) (DBXB-4110) ([#213](https://github.com/MGMResorts/client-tooling/pull/213))
- fixed room details styling issue (MINOR) (DBXB-4110) ([#212](https://github.com/MGMResorts/client-tooling/pull/212))
- added po scenarios for the room details modal (MINOR) (DBXB-4110) ([#206](https://github.com/MGMResorts/client-tooling/pull/206))
- fixed small styling issue in the resort dropdown (MINOR) (DBXB-4088) ([#207](https://github.com/MGMResorts/client-tooling/pull/207))
- **rooms-filters-control:** add component (MINOR) (DBXB-4034) ([#174](https://github.com/MGMResorts/client-tooling/pull/174))
- fixed amenities responsive behavior for the room details modal (MINOR) (DBXB-4033) ([#205](https://github.com/MGMResorts/client-tooling/pull/205))
- created change resort dropdown component (MINOR) (DBXB-4088) ([#202](https://github.com/MGMResorts/client-tooling/pull/202))
- **rooms-resort-fee-information-modal:** add component (MINOR) (DBXB-4087) ([#201](https://github.com/MGMResorts/client-tooling/pull/201))
- **commerce-ui:** Rooms Resort details component (MINOR) (DBXB-3967) ([#176](https://github.com/MGMResorts/client-tooling/pull/176))
- **commerce-ui:** package header price loading (CSBP-3672) (MINOR) ([#197](https://github.com/MGMResorts/client-tooling/pull/197))
- implemented room details modal content (MINOR) (DBXB-4033) ([#190](https://github.com/MGMResorts/client-tooling/pull/190))
- created story for displaying multiple resort cards (MINOR) (DBX3965) ([#193](https://github.com/MGMResorts/client-tooling/pull/193))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **commerce-ui:** RoomsResortSelectionSummary component (MINOR) (DBXB-3966) ([#158](https://github.com/MGMResorts/client-tooling/pull/158))
- fixed rooms resort card styling issues (MINOR) (DBXB-3965) ([#192](https://github.com/MGMResorts/client-tooling/pull/192))
- fixed rooms dropdown styling issues (MINOR) (DBXB-4032) ([#191](https://github.com/MGMResorts/client-tooling/pull/191))
- fixed small styling issues in the rooms card (MINOR) (DBXB-4016) ([#187](https://github.com/MGMResorts/client-tooling/pull/187))
- **commerce-ui:** Rooms Markdown component (MINOR) (DBXB-4101) ([#178](https://github.com/MGMResorts/client-tooling/pull/178))
- **commerce-ui:** add disable state for bayg seat card  (CSBP-3648)(MINOR) ([#186](https://github.com/MGMResorts/client-tooling/pull/186))
- created change destination dropdown for room booking (MINOR) (DBXB-4032) ([#179](https://github.com/MGMResorts/client-tooling/pull/179))
- **commerce-ui:** color threshold prop for Timer component (MINOR) (CAPL-6139) ([#180](https://github.com/MGMResorts/client-tooling/pull/180))
- fixed rooms resort card styling (MINOR) (DBXB-3965) ([#165](https://github.com/MGMResorts/client-tooling/pull/165))
- **header-global:** add mobile version of the account menu (CSBP-3414) (MINOR) ([#168](https://github.com/MGMResorts/client-tooling/pull/168))
- **commerce-ui:** zero value does not include plus sign (CSBP-3701)(MINOR) ([#167](https://github.com/MGMResorts/client-tooling/pull/167))
- **commerce-ui:** package error displaying decrement in resort card (CSBP-3701)(MINOR) ([#166](https://github.com/MGMResorts/client-tooling/pull/166))
- created room card for room booking using the vega design (MINOR) (DBXB-4016) ([#164](https://github.com/MGMResorts/client-tooling/pull/164))
- add applied offer section (MINOR) (DBXB-4044) ([#162](https://github.com/MGMResorts/client-tooling/pull/162))
- loading state resorts and rooms (CSBP-3253) (MINOR) ([#161](https://github.com/MGMResorts/client-tooling/pull/161))
- created new resort card for room booking using the vega design (MINOR) (DBXB-3965) ([#154](https://github.com/MGMResorts/client-tooling/pull/154))
- **commerce-ui:** package header desktop centered (CSBP-3655) (MINOR) ([#157](https://github.com/MGMResorts/client-tooling/pull/157))
- **commerce-ui:** resort card min height updated (CSBP-3660) (MINOR) ([#156](https://github.com/MGMResorts/client-tooling/pull/156))
- DatePicker Bar for Rooms (MINOR) (DBXB-3971) ([#155](https://github.com/MGMResorts/client-tooling/pull/155))
- **global-header:** add account menu interaction (CSBP-3396) (MINOR) ([#152](https://github.com/MGMResorts/client-tooling/pull/152))
- **commerce-ui:** added new property to resort card to display custom price labels (CSBP-3444)(MINOR) ([#149](https://github.com/MGMResorts/client-tooling/pull/149))
- **commerce-ui:** updated resort container to fill all available height (CSBP-3444)(MINOR) ([#148](https://github.com/MGMResorts/client-tooling/pull/148))
- **commerce-ui:** resize resort columns (CSBP-3444)(MINOR) ([#147](https://github.com/MGMResorts/client-tooling/pull/147))
- **commerce-ui:** update bayg variant in resort card component (CSBP-3444)(PATCH) ([#144](https://github.com/MGMResorts/client-tooling/pull/144))
- **component:** add seat number prop to bayg seat card - (CSBP-3352)(PATCH) ([#142](https://github.com/MGMResorts/client-tooling/pull/142))
- **commerce-ui:** add variants for the price seat bottom component (CSBP-2416)(MINOR) ([#140](https://github.com/MGMResorts/client-tooling/pull/140))
- **commerce-ui:** added selected filters property to price filter component (CSBP-3362)(PATCH) ([#137](https://github.com/MGMResorts/client-tooling/pull/137))
- add BaygSeatCard component (CSBP-2412) (MINOR) ([#134](https://github.com/MGMResorts/client-tooling/pull/134))
- **commerce-ui:** resort card and package header (CSBP-3425) (MINOR) ([#135](https://github.com/MGMResorts/client-tooling/pull/135))
- **commerce-ui:** add class property to event info card component (CSBP-3345)(MINOR) ([#133](https://github.com/MGMResorts/client-tooling/pull/133))
- update price filter state to use id instead of whole object to filter (CSBP-2409)(PATCH) ([#130](https://github.com/MGMResorts/client-tooling/pull/130))
- **price-filter:** update chip to receive bg string and price filters to allow multiselect (CSBP-2409)(PATCH) ([#129](https://github.com/MGMResorts/client-tooling/pull/129))
- **commerce-ui:** seat map interaction components - (CSBP-2410) (MINOR) ([#126](https://github.com/MGMResorts/client-tooling/pull/126))
- **chip:** create chip component with tests and stories (CSBP-2409)(MINOR) ([#124](https://github.com/MGMResorts/client-tooling/pull/124))
- **commerce-ui:** updated styles from event info card component (CSBP-2415) (MINOR) ([#125](https://github.com/MGMResorts/client-tooling/pull/125))
- **commerce-ui:** resort card not available (CSBP-3242) (MINOR) ([#122](https://github.com/MGMResorts/client-tooling/pull/122))
- **global-header:** add on logo click to the logo link (CSBP-3039)(PATCH) ([#121](https://github.com/MGMResorts/client-tooling/pull/121))
- **rooms:** update mobile view for the room card (CSBP-3244)(PATCH) ([#118](https://github.com/MGMResorts/client-tooling/pull/118))
- **room:** add new flag for unavailable state (CSBP-3244) (MINOR) ([#117](https://github.com/MGMResorts/client-tooling/pull/117))
- global header signin desktop props - (CSBP-3131) (MINOR) ([#116](https://github.com/MGMResorts/client-tooling/pull/116))
- global header signin desktop create tier-tag component - (CSBP-3131) (MINOR) ([#115](https://github.com/MGMResorts/client-tooling/pull/115))
- **commerce-ui:** minor updates (CSBP-2978) (MINOR) ([#101](https://github.com/MGMResorts/client-tooling/pull/101))
- add desktop version for PackageHeader component (CSBP-2949) (MAJOR) ([#99](https://github.com/MGMResorts/client-tooling/pull/99))
- **resort-card:** change the selected state to outside of the component (CSBP-2972)(PATCH) ([#95](https://github.com/MGMResorts/client-tooling/pull/95))
- **resorts-card:** add desktop responsiveness and update button to handle selected state (CSBP-2972)(MINOR) ([#94](https://github.com/MGMResorts/client-tooling/pull/94))
- **modal:** layout updates (CSBP-2752) (PATCH) ([#93](https://github.com/MGMResorts/client-tooling/pull/93))
- **ResortDetails:** add experiences row (CSBP-2752) ([#76](https://github.com/MGMResorts/client-tooling/pull/76))
- **commerce-ui:** new global header (CSBP-2948) (MINOR) ([#88](https://github.com/MGMResorts/client-tooling/pull/88))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- adding new chromatic workflow (NONE) ([#80](https://github.com/MGMResorts/client-tooling/pull/80))
- add clickable title on RoomCard component (CSBP-3086) (MINOR) ([#79](https://github.com/MGMResorts/client-tooling/pull/79))
- **component:** added auto-pan callback to section selection component - (CSBP-3083) ([#77](https://github.com/MGMResorts/client-tooling/pull/77))
- **ResortDetails:** add amenities row (CSBP-2752) ([#75](https://github.com/MGMResorts/client-tooling/pull/75))
- **ResortDetails:** add initial parts of component (CSBP-2752) ([#74](https://github.com/MGMResorts/client-tooling/pull/74))
- **component:** updated style of image carousel controls - (CSBP-2923) ([#73](https://github.com/MGMResorts/client-tooling/pull/73))
- **section-selection-map:** add auto pan when select section (CSBP-2650) ([#68](https://github.com/MGMResorts/client-tooling/pull/68))
- correct margin and scroll of landing page (CSBP-2853) ([#69](https://github.com/MGMResorts/client-tooling/pull/69))
- add room card component (CSBP-2840) ([#64](https://github.com/MGMResorts/client-tooling/pull/64))
- update resort card width (CSBP-2858) ([#60](https://github.com/MGMResorts/client-tooling/pull/60))
- **package-header:** update link url to be a onclick handler - CSBP-2828 ([#57](https://github.com/MGMResorts/client-tooling/pull/57))
- Implement event info carousel design update - CSBP-2820 ([#58](https://github.com/MGMResorts/client-tooling/pull/58))
- Implement event info carousel design update - CSBP-2820 ([#55](https://github.com/MGMResorts/client-tooling/pull/55))
- **commerce-ui:** update resort card (CSBP-2858) ([#56](https://github.com/MGMResorts/client-tooling/pull/56))
- **commerce-ui:** implement package header design update - CSBP-2819 ([#53](https://github.com/MGMResorts/client-tooling/pull/53))
- added missing exports for seat selection component - CSBP-2646 ([#54](https://github.com/MGMResorts/client-tooling/pull/54))
- Implement event info carousel design update - CSBP-2820 ([#50](https://github.com/MGMResorts/client-tooling/pull/50))
- Implement Section Selection Map component - CSBP-2647 ([#51](https://github.com/MGMResorts/client-tooling/pull/51))
- Implement selected seats card and sheet design update - CSBP-2821 ([#52](https://github.com/MGMResorts/client-tooling/pull/52))
- Add checks to commerce ui - CSBP-2287 ([#48](https://github.com/MGMResorts/client-tooling/pull/48))
- Update step indicator color for latest design - CSBP-2813 ([#47](https://github.com/MGMResorts/client-tooling/pull/47))
- add ResortCard component - CSBP-2644 ([#45](https://github.com/MGMResorts/client-tooling/pull/45))
- **commerce-ui:** create grandstand selection map component - CSBP-2641 ([#44](https://github.com/MGMResorts/client-tooling/pull/44))
- **commerce-ui:** create price and seats bottom sheet export - CSBP-2643 ([#43](https://github.com/MGMResorts/client-tooling/pull/43))
- **commerce-ui:** Create Price and Seats Bottom Sheet Component - CSBP - 2643 ([#42](https://github.com/MGMResorts/client-tooling/pull/42))
- **commerce-ui:** Create Button Component - CSBP-2690 ([#40](https://github.com/MGMResorts/client-tooling/pull/40))
- **commerce-ui:** create slot reel price component - CSBP-2613 ([#32](https://github.com/MGMResorts/client-tooling/pull/32))
- **commerce-ui:** add SelectedSeatsCard component - CSBP-2642 ([#34](https://github.com/MGMResorts/client-tooling/pull/34))
- **commerce-ui:** add event info carousel component ([#26](https://github.com/MGMResorts/client-tooling/pull/26))
- Set up Jest in commerce-ui package - CSBP-2567 ([#28](https://github.com/MGMResorts/client-tooling/pull/28))
- **commerce-ui:** Update step indicator color - CSBP-2633 ([#29](https://github.com/MGMResorts/client-tooling/pull/29))
- **commerce-ui:** add Icon and StepIndicator components - CSBP-2571 ([#25](https://github.com/MGMResorts/client-tooling/pull/25))
- **vega-tailwind:** initial package release ([#19](https://github.com/MGMResorts/client-tooling/pull/19))
- added initial commerce-ui package ([54ff4485](https://github.com/MGMResorts/client-tooling/commit/54ff4485))

### 🩹 Fixes

- align ResortCard design with Figma specs (CSBP-4331) (PATCH) ([#562](https://github.com/MGMResorts/client-tooling/pull/562))
- fixed vertical scroll issue in the carousel for mobile (PATCH) (DBXB-4732) ([#565](https://github.com/MGMResorts/client-tooling/pull/565))
- **commerce-ui:** Fix carousel skeleton loading (PATCH) (DBXB-4711) ([#564](https://github.com/MGMResorts/client-tooling/pull/564))
- **commerce-ui:** Update the width card when isLoading changes  (PATCH) (DBXB-4711) ([#563](https://github.com/MGMResorts/client-tooling/pull/563))
- **commerce-ui:** Add loading skeleton to rooms available room rate (PATCH) (DBXB-7411) ([#561](https://github.com/MGMResorts/client-tooling/pull/561))
- fixed select offer button focus ring (PATCH) (DBXB-4602) ([#560](https://github.com/MGMResorts/client-tooling/pull/560))
- mobile ios & safari rooms card images wrong aspect ratio (CSBP-4269) (PATCH) ([#559](https://github.com/MGMResorts/client-tooling/pull/559))
- resort dropdown being cut off on ipad air (PATCH) (DBXB-4693) ([#558](https://github.com/MGMResorts/client-tooling/pull/558))
- **map:** fix section selection init zoom handler (CSBP-4126)(MINOR) ([#557](https://github.com/MGMResorts/client-tooling/pull/557))
- fixed room rates carousel styling issue (PATCH) (DBXB-4602) ([#555](https://github.com/MGMResorts/client-tooling/pull/555))
- **rooms-filters-control-modal:** use icon from mgm-ui (PATCH) (DBXB-4685) ([#556](https://github.com/MGMResorts/client-tooling/pull/556))
- replaced existing radio button from room rates carousel with mgm-ui version (PATCH) (DBXB-4602) ([#552](https://github.com/MGMResorts/client-tooling/pull/552))
- **map:** fix section selection zoomed handler (CSBP-4126)(MINOR) ([#554](https://github.com/MGMResorts/client-tooling/pull/554))
- **rooms-filters-control-modal:** use icon from mgm-ui (PATCH) (DBXB-4685) ([#553](https://github.com/MGMResorts/client-tooling/pull/553))
- fixed focus ring in the select room page (PATCH) (DBXB-4602) ([#547](https://github.com/MGMResorts/client-tooling/pull/547))
- **rooms-filters-control-modal:** change the way components are being rendered (PATCH) (DBXB-4685) ([#551](https://github.com/MGMResorts/client-tooling/pull/551))
- **map:** fixed zoom behavior on section map (CSBP-4126)(MINOR) ([#550](https://github.com/MGMResorts/client-tooling/pull/550))
- fixed some text alignments (PATCH) (DBXB-4694) ([#548](https://github.com/MGMResorts/client-tooling/pull/548))
- **accesibility:** add missing attributes (PATCH) (DBXB-4605) ([#544](https://github.com/MGMResorts/client-tooling/pull/544))
- fixed focus ring in the resort details modal (PATCH) (DBXB-4539) ([#543](https://github.com/MGMResorts/client-tooling/pull/543))
- accessibility - fixed incorrect html elements in the rooms page (PATCH) (DBXB-4622) ([#541](https://github.com/MGMResorts/client-tooling/pull/541))
- fixed unnecessary roles and tabindexes in the html elements (PATCH) (DBXB-4509) ([#537](https://github.com/MGMResorts/client-tooling/pull/537))
- **commerce-ui:** Make offer details content focusable when showing legal info (PATCH) (DBXB-4578) ([#536](https://github.com/MGMResorts/client-tooling/pull/536))
- **commerce-ui:** Use variant button for TextLink (PATCH) (DBXB-4576) ([#533](https://github.com/MGMResorts/client-tooling/pull/533))
- fixed screen reader issue related to bullet point on the resort dropdown (PATCH) (DBXB-4492) ([#531](https://github.com/MGMResorts/client-tooling/pull/531))
- sync packages versions with published (NONE) (PATCH) ([#530](https://github.com/MGMResorts/client-tooling/pull/530))
- fixed small issues related to mobile dropdown accessibility (PATCH) (DBXB-4492) ([#523](https://github.com/MGMResorts/client-tooling/pull/523))
- **center-modals:** adjust width (PATCH) (DBXB-4473) ([#525](https://github.com/MGMResorts/client-tooling/pull/525))
- created room card skeleton for room booking (PATCH) (DBXB-4484) ([#520](https://github.com/MGMResorts/client-tooling/pull/520))
- **rooms-resort-bottom-panel:** adjust styles (PATCH) (DBXB-4403) ([#518](https://github.com/MGMResorts/client-tooling/pull/518))
- fixed voice over safari issue for the desktop dropdowns (PATCH) (DBXB-4391) ([#517](https://github.com/MGMResorts/client-tooling/pull/517))
- **rooms-resort-bottom-panel:** adjust styles (PATCH) (DBXB-4403) ([#516](https://github.com/MGMResorts/client-tooling/pull/516))
- **rooms-resort-bottom-panel:** adjust styles (PATCH) (DBXB-4403) ([#515](https://github.com/MGMResorts/client-tooling/pull/515))
- fixed mobile dropdown accessibility issues (PATCH) (DBXB-4492) ([#500](https://github.com/MGMResorts/client-tooling/pull/500))
- **commerce-ui:** Update commerce-ui version manually (PATCH) (NONE) ([#513](https://github.com/MGMResorts/client-tooling/pull/513))
- **commerce-ui:** Fix aspect ratio (PATCH) (DBXB-4405) ([#511](https://github.com/MGMResorts/client-tooling/pull/511))
- **rooms-resort-bottom-panel:** adjust text styles (PATCH) (DBXB-4403) ([#499](https://github.com/MGMResorts/client-tooling/pull/499))
- **rooms-resort-bottom-panel:** adjust styles for the message props (PATCH) (DBXB-4403) ([#498](https://github.com/MGMResorts/client-tooling/pull/498))
- fixed resort dropdown to display the trigger label when the resort is unavailable (PATCH) (DBXB-4388) ([#493](https://github.com/MGMResorts/client-tooling/pull/493))
- fixed offer carousel styling when pricing is not available (PATCH) (DBXB-4184) ([#491](https://github.com/MGMResorts/client-tooling/pull/491))
- fixed dropdown accessibility issues for desktop (PATCH) (DBXB-4391) ([#485](https://github.com/MGMResorts/client-tooling/pull/485))
- **commerce-ui:** Add onOpenDropdownCallback in Rooms Resort Dropdown (PATCH) (DBXB-4368) ([#487](https://github.com/MGMResorts/client-tooling/pull/487))
- **use-component-size:** adjust width of the center modals (PATCH) (DBXB-4473) ([#488](https://github.com/MGMResorts/client-tooling/pull/488))
- **commerce-ui:** Remove conditional render in Rooms Offer Details Modal (PATCH) (DBXB-4406) ([#483](https://github.com/MGMResorts/client-tooling/pull/483))
- **rooms-resort-bottom-panel:** add desktop support (PATCH) (DBXB-4403) ([#484](https://github.com/MGMResorts/client-tooling/pull/484))
- **rooms-resort-selection-summary:** rollback the change in favor of a new component (PATCH) (DBXB-4403) ([#482](https://github.com/MGMResorts/client-tooling/pull/482))
- **commerce-ui:** Workaround for bottom modal in iPhone with notch (PATCH) (DBXB-4368) ([#481](https://github.com/MGMResorts/client-tooling/pull/481))
- control resort dropdown from a parent component (PATCH) (DBXB-4184) ([#478](https://github.com/MGMResorts/client-tooling/pull/478))
- **rooms-resort-card:** make aria-label optional (PATCH) (DBXB-4392) ([#476](https://github.com/MGMResorts/client-tooling/pull/476))
- fixed empty view more offers modal state (PATCH) (DBXB-4184) ([#472](https://github.com/MGMResorts/client-tooling/pull/472))
- **carousel:** scroll into the selected offer (PATCH) (DBXB-4335) ([#471](https://github.com/MGMResorts/client-tooling/pull/471))
- **rooms-available-room-rates:** scroll to the selected offer (PATCH) (DBXB-4335) ([#469](https://github.com/MGMResorts/client-tooling/pull/469))
- fixed dropdown accessibility issue related to tab key (PATCH) (DBXB-4391) ([#470](https://github.com/MGMResorts/client-tooling/pull/470))
- fixed desktop dropdown accessibility issues (PATCH) (DBXB-4391) ([#467](https://github.com/MGMResorts/client-tooling/pull/467))
- **commerce-ui:** Accessibility - Allow pass props to Carousel (PATCH) (DBXB-4399) ([#468](https://github.com/MGMResorts/client-tooling/pull/468))
- fixed room page desktop styling issues (PATCH) (DBXB-4184) ([#465](https://github.com/MGMResorts/client-tooling/pull/465))
- fixed room page styling issues for mobile (PATCH) (DBXB-4184) ([#462](https://github.com/MGMResorts/client-tooling/pull/462))
- **rooms-available-room-rates:** adjust width (PATCH) (DBXB-4335) ([#463](https://github.com/MGMResorts/client-tooling/pull/463))
- **data-cms:** provide more data-cms values (PATCH) (DBXB-4348) ([#461](https://github.com/MGMResorts/client-tooling/pull/461))
- **data-cms:** receive more data-cms from props (PATCH) (DBXB-4348) ([#460](https://github.com/MGMResorts/client-tooling/pull/460))
- **commerce-ui:** Fix dropdown update (PATCH) (DBXB-4222) ([#450](https://github.com/MGMResorts/client-tooling/pull/450))
- **rooms-available-room-rates:** adjust width (PATCH) (DBXB-4335) ([#449](https://github.com/MGMResorts/client-tooling/pull/449))
- fixed tablet styling issues (PATCH) (DBXB-4264) ([#447](https://github.com/MGMResorts/client-tooling/pull/447))
- **rooms-available-room-rates:** adjust width (PATCH) (DBXB-4335) ([#448](https://github.com/MGMResorts/client-tooling/pull/448))
- **rooms-available-room-rates:** adjust width (PATCH) (DBXB-4335) ([#446](https://github.com/MGMResorts/client-tooling/pull/446))
- fixed resort and price dropdown styling (PATCH) (DBXB-4184) ([#445](https://github.com/MGMResorts/client-tooling/pull/445))
- **commerce-ui:** Use react-popper for region dropdown (PATCH) (DBXB-4222) ([#444](https://github.com/MGMResorts/client-tooling/pull/444))
- **rooms-availbale-room-rates:** adjust width (PATCH) (DBXB-4335) ([#443](https://github.com/MGMResorts/client-tooling/pull/443))
- **commerce-ui:** Adjust dates bar picker styles (PATCH) (DBXB-4222) ([#441](https://github.com/MGMResorts/client-tooling/pull/441))
- set max size for resort dropdown desktop version (PATCH) (DBXB-4264) ([#440](https://github.com/MGMResorts/client-tooling/pull/440))
- fixed styling issues in the room booking components (PATCH) (DBXB-4184) ([#439](https://github.com/MGMResorts/client-tooling/pull/439))
- **commerce-ui:** Segment banner and Resort Details modal fixes (PATCH) (DBXB-4262) ([#438](https://github.com/MGMResorts/client-tooling/pull/438))
- added data cms field in the amenities list in the rooms card (PATCH) (DBXB-4184) ([#437](https://github.com/MGMResorts/client-tooling/pull/437))
- **commerce-ui:** Fix breakpoint (PATCH) (DBXB-4183) ([#436](https://github.com/MGMResorts/client-tooling/pull/436))
- **timer:** adding change file (CSBP-3041) (PATCH) ([#433](https://github.com/MGMResorts/client-tooling/pull/433))
- **timer:** minor update (CSBP-3041) (PATCH) ([#432](https://github.com/MGMResorts/client-tooling/pull/432))
- **rooms-pricing-details-modal:** pass data-cms (PATCH) (DBXB-4348) ([#430](https://github.com/MGMResorts/client-tooling/pull/430))
- **timer:** minor update (CSBP-3041) (PATCH) ([#429](https://github.com/MGMResorts/client-tooling/pull/429))
- update offer details modal actions (PATCH) (DBXB-4184) ([#428](https://github.com/MGMResorts/client-tooling/pull/428))
- change hook call placement (PATCH) (DBXB-4184) ([#427](https://github.com/MGMResorts/client-tooling/pull/427))
- **timer:** minor update (CSBP-3041) (PATCH) ([#426](https://github.com/MGMResorts/client-tooling/pull/426))
- **timer:** minor update (CSBP-3041) (PATCH) ([#425](https://github.com/MGMResorts/client-tooling/pull/425))
- meet room vega components requirements (PATCH) (NONE) ([#423](https://github.com/MGMResorts/client-tooling/pull/423))
- **rooms-calendar-bottom-panel:** pass data-cms (PATCH) (DBXB-4348) ([#422](https://github.com/MGMResorts/client-tooling/pull/422))
- update resort dropdown types (PATCH) (NONE) ([#421](https://github.com/MGMResorts/client-tooling/pull/421))
- **rooms-tooltip:** pass data-cms as prop (PATCH) (DBXB-4348) ([#419](https://github.com/MGMResorts/client-tooling/pull/419))
- meet accessibility requirements for rooms (PATCH) (NONE) ([#417](https://github.com/MGMResorts/client-tooling/pull/417))
- fixed room details calendar badge (PATCH) (DBXB-4184) ([#411](https://github.com/MGMResorts/client-tooling/pull/411))
- fixed broken rooms carousel styling (PATCH) (DBXB-4184) ([#408](https://github.com/MGMResorts/client-tooling/pull/408))
- **rooms-segment-banner:** adjust styles (PATCH) (NONE) ([#405](https://github.com/MGMResorts/client-tooling/pull/405))
- room card image aspect ratio (CSBP-3992) (PATCH) ([#400](https://github.com/MGMResorts/client-tooling/pull/400))
- **commerce-ui:** Allow pass custom loading component (PATCH) (DBXB-4074) ([#402](https://github.com/MGMResorts/client-tooling/pull/402))
- **commerce-ui:** Add loading indicator to resort bottom panel (PATCH) (DBXB-4074) ([#399](https://github.com/MGMResorts/client-tooling/pull/399))
- **commerce-ui:** UI adjustments segment banner for small tablet. ([#396](https://github.com/MGMResorts/client-tooling/pull/396))
- **commerce-ui:** Hide CTA when label is not provided (PATCH) (DBXB-4262) ([#395](https://github.com/MGMResorts/client-tooling/pull/395))
- **commerce-ui:** Hide resort bottom details CTA panel when cta label is empty (PATCH) (DBXB-4183) ([#391](https://github.com/MGMResorts/client-tooling/pull/391))
- **commerce-ui:** Fix font color in Rooms Bottom panel (PATCH) (DBXB-4074) ([#387](https://github.com/MGMResorts/client-tooling/pull/387))
- **roomDetails:** make calendar icon clickable (PATCH) (DBXB-4184) ([#386](https://github.com/MGMResorts/client-tooling/pull/386))
- **commerce-ui:** Fix Rooms Footer (PATCH) (DBXB-4074) ([#384](https://github.com/MGMResorts/client-tooling/pull/384))
- **previous-step:** correct the element type for the change button (CSBP-3956) (PATCH) ([#382](https://github.com/MGMResorts/client-tooling/pull/382))
- **availableRoomsOffers:** hide prices when null (PATCH) (NONE) ([#380](https://github.com/MGMResorts/client-tooling/pull/380))
- add id to room filter types (PATCH) (NONE) ([#379](https://github.com/MGMResorts/client-tooling/pull/379))
- make links clickable on rooms details (PATCH) (NONE) ([#378](https://github.com/MGMResorts/client-tooling/pull/378))
- set loading state for room details (PATCH) (NONE) ([#377](https://github.com/MGMResorts/client-tooling/pull/377))
- **commerce-ui:** Making resort name clickable when unavailable (PATCH) (DBXB-4074) ([#374](https://github.com/MGMResorts/client-tooling/pull/374))
- **commerce-ui:** Fix contrast gradiant in carousel (PATCH) (DBXB-4074) ([#370](https://github.com/MGMResorts/client-tooling/pull/370))
- **commerce-ui:** Resort card enhancements & expose utils functions (PATCH) (DBXB-4074) ([#367](https://github.com/MGMResorts/client-tooling/pull/367))
- **roooms-room-detail:** ajust amenities styles (PATCH) (DBXB-4318) ([#366](https://github.com/MGMResorts/client-tooling/pull/366))
- **commerce-ui:** Footer is added to resort details (PATCH) (DBXB-4074) ([#364](https://github.com/MGMResorts/client-tooling/pull/364))
- **rooms-room-detail:** adjust styles (PATCH) (DBXB-4318) ([#365](https://github.com/MGMResorts/client-tooling/pull/365))
- **commerce-ui:** Expose Rooms Footer component (PATCH) (DBXB-4074) ([#363](https://github.com/MGMResorts/client-tooling/pull/363))
- **commerce-ui:** Resort card style fixes (PATCH) (DBXB-4074) ([#361](https://github.com/MGMResorts/client-tooling/pull/361))
- adjustments post vega integration into RB (PATCH) (NONE) ([#356](https://github.com/MGMResorts/client-tooling/pull/356))
- **commerce-ui:** Adjust responsive scenarios for resort card (PATCH) (DBXB-4185) ([#347](https://github.com/MGMResorts/client-tooling/pull/347))
- **rooms-resort-details-modal:** adjust horizontal scroll within the experiences section (PATCH) (DBXB-4237) ([#341](https://github.com/MGMResorts/client-tooling/pull/341))
- **commerce-ui:** Make resort dropdown looks inline (PATCH) (DBXB-4185) ([#345](https://github.com/MGMResorts/client-tooling/pull/345))
- **commerce-ui:** Pass MouseEvent in onClickCTA (PATCH) (DBXB-4074) ([#342](https://github.com/MGMResorts/client-tooling/pull/342))
- **commerce-ui:** Expose swipe event and add click to image carousel (PATCH) (DBXB-4074) ([#340](https://github.com/MGMResorts/client-tooling/pull/340))
- **commerce-ui:** add forwardRef to RoomsResortCard (PATCH) (DBXB-4074) ([#336](https://github.com/MGMResorts/client-tooling/pull/336))
- **commerce-ui:** timer update (CAPL-6139) (MINOR) ([#333](https://github.com/MGMResorts/client-tooling/pull/333))
- adjust components during the mgm-ui migration (MINOR) (NONE) ([#323](https://github.com/MGMResorts/client-tooling/pull/323))
- **commerce-ui:** Add multiple lines to resort detail address (PATCH) (DBXB-4074) ([#328](https://github.com/MGMResorts/client-tooling/pull/328))
- migrate offer details to mgm-ui (PATCH) (DBXB-4184) ([#324](https://github.com/MGMResorts/client-tooling/pull/324))
- **commerce-ui:** Expose RoomsResortDetailsModal (PATCH) (DBXB-4074) ([#320](https://github.com/MGMResorts/client-tooling/pull/320))
- **commerce-ui:** Expose ViewportContext and css fix (DBXB-4074) ([#318](https://github.com/MGMResorts/client-tooling/pull/318))
- migrate dates overlay to mgm-ui modal (PATCH) (DBXB-4184) ([#315](https://github.com/MGMResorts/client-tooling/pull/315))
- **commerce-ui:** Using TextLink component from mgm-ui (PATCH) (DBXB-4248) ([#305](https://github.com/MGMResorts/client-tooling/pull/305))
- **commerce-ui:** Using Tabs from mgm-ui for PO Tabs (PATCH) (DBXB-4250) ([#306](https://github.com/MGMResorts/client-tooling/pull/306))
- **commerce-ui:** Using mgm-ui Button for Rooms Resort Selection Summary (PATCH) (DBXB-4251) ([#307](https://github.com/MGMResorts/client-tooling/pull/307))
- **commerce-ui:** Fix @mgmresorts/vega-tokens in peerDependencies (PATCH) (NONE) ([#312](https://github.com/MGMResorts/client-tooling/pull/312))
- expose rooms components (PATCH) (DBXB-4184) ([#310](https://github.com/MGMResorts/client-tooling/pull/310))
- **commerce-ui:** Add more storybook variants (PATCH) (DBXB-4131) ([#299](https://github.com/MGMResorts/client-tooling/pull/299))
- **commerce-ui:** Using Alert component from mgm-ui (PATCH) (DBXB-4249) ([#303](https://github.com/MGMResorts/client-tooling/pull/303))
- **commerce-ui:** Divider and link button migrated to mgm-ui (PATCH) (DBXB-4247) ([#301](https://github.com/MGMResorts/client-tooling/pull/301))
- **commerce-ui:** expose `<Skeleton />` component as path import (PATCH) (NONE) ([#285](https://github.com/MGMResorts/client-tooling/pull/285))
- correct the current version of commerce-ui (CSBP-3941) (PATCH) ([#298](https://github.com/MGMResorts/client-tooling/pull/298))
- **commerce-ui:** Making Tier tag and user info a hover element (PATCH) (DBXB-4102) ([#296](https://github.com/MGMResorts/client-tooling/pull/296))
- **commerce-ui:** changelog (CAPL-6636, CAPL-6637) (PATCH) ([#295](https://github.com/MGMResorts/client-tooling/pull/295))
- **commerce-ui:** Click do not close profile menu (PATCH) (DBXB-4102) ([#293](https://github.com/MGMResorts/client-tooling/pull/293))
- **commerce-ui:** add accessibility props to the Icon component (CAPL-6636, CAPL-6637) (PATCH) ([#291](https://github.com/MGMResorts/client-tooling/pull/291))
- **commerce-ui:** Expose components in ./src/index.ts (PATCH) (DBXB-4074) ([#290](https://github.com/MGMResorts/client-tooling/pull/290))
- **commerce-ui:** Fix paddings (PATCH) (DBXB-3964) ([#283](https://github.com/MGMResorts/client-tooling/pull/283))
- **commerce-ui:** Fix font issues for PO Tab (PATCH) (DBXB-4179) ([#271](https://github.com/MGMResorts/client-tooling/pull/271))
- **rooms-segment-modal:** use the rooms-modal component (MINOR) (NONE) ([#273](https://github.com/MGMResorts/client-tooling/pull/273))
- **commerce-ui:** Rooms Guest Counter component (MINOR) (DBXB-4131) ([#226](https://github.com/MGMResorts/client-tooling/pull/226))
- **analytics:** minor updates (CSBP-3814) (MINOR) ([#232](https://github.com/MGMResorts/client-tooling/pull/232))
- **rooms-resort-fee-information-modal:** adjust close icon (MINOR) (DBXB-4087) ([#210](https://github.com/MGMResorts/client-tooling/pull/210))
- **commerce-ui:** Using react lazy to load react-markdown avoid SSR error (MINOR) (DBXB-4101) ([#203](https://github.com/MGMResorts/client-tooling/pull/203))
- **commerce-ui:** fix commerce-ui api docs (PATCH) (NONE) ([#200](https://github.com/MGMResorts/client-tooling/pull/200))
- **rooms-applied-offer:** adjust styles (MINOR) (DBXB-4044) ([#175](https://github.com/MGMResorts/client-tooling/pull/175))
- ⚠️  **commerce-ui:** ensure click event for non-touch devices (CSBP-3661) (MAJOR) ([#177](https://github.com/MGMResorts/client-tooling/pull/177))
- **account-menu:** close menu using escape key (CSBP-3396) (PATCH) ([#173](https://github.com/MGMResorts/client-tooling/pull/173))
- adjust styles (MINOR) (DBXB-4044) ([#172](https://github.com/MGMResorts/client-tooling/pull/172))
- **header-global:** hide the mobile menu button when userInfo is not available (CSBP-3414) (MINOR) ([#171](https://github.com/MGMResorts/client-tooling/pull/171))
- Style fixes RoomsDatePickerBar (MINOR) (DBXB-3971) ([#160](https://github.com/MGMResorts/client-tooling/pull/160))
- digits in package total go missing sometimes - (CSBP-3614) (PATCH) ([#153](https://github.com/MGMResorts/client-tooling/pull/153))
- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- update price chip padding on hover (CSBP-2409)(PATCH) ([#136](https://github.com/MGMResorts/client-tooling/pull/136))
- **commerce-ui:** resort card style updated (CSBP-3242) (MINOR) ([#123](https://github.com/MGMResorts/client-tooling/pull/123))
- **commerce-ui:** design updates (CSBP-3286) (PATCH) ([#114](https://github.com/MGMResorts/client-tooling/pull/114))
- **commerce-ui:** design updates (CSBP-3286) (PATCH) ([#113](https://github.com/MGMResorts/client-tooling/pull/113))
- **packages:** commerce-ui update (CSBP-3285) (PATCH) ([#112](https://github.com/MGMResorts/client-tooling/pull/112))
- **packages:** design updates (CSBP-3285) (PATCH) ([#111](https://github.com/MGMResorts/client-tooling/pull/111))
- **commerce-ui:** design updates (CSBP-3286) (PATCH) ([#110](https://github.com/MGMResorts/client-tooling/pull/110))
- **commerce-ui:** updating timer (CSBP-3225) (PATCH) ([#108](https://github.com/MGMResorts/client-tooling/pull/108))
- **commerce-ui:** change file (CSBP-3225) (PATCH) ([#107](https://github.com/MGMResorts/client-tooling/pull/107))
- **commerce-ui:** updating slot text (CSBP-3225) (PATCH) ([#106](https://github.com/MGMResorts/client-tooling/pull/106))
- **commerce-ui:** updating timer and slot text ([#105](https://github.com/MGMResorts/client-tooling/pull/105))
- **commerce-ui:** resort card background (CSBP-3221) (PATCH) ([#104](https://github.com/MGMResorts/client-tooling/pull/104))
- **commerce-ui:** resort card aspect ratio and minor fixes (CSBP-3232) (PATCH) ([#103](https://github.com/MGMResorts/client-tooling/pull/103))
- **commerce-ui:** slot text width (CSBP-2979) (PATCH) ([#102](https://github.com/MGMResorts/client-tooling/pull/102))
- export package header test ids utils (CSBP-2949) (MINOR) ([#100](https://github.com/MGMResorts/client-tooling/pull/100))
- **resort-card:** update label to show if its included in package when is tagged (CSBP-2972)(PATCH) ([#97](https://github.com/MGMResorts/client-tooling/pull/97))
- **component:** remove event listener from global header - (CSBP-2988) (PATCH) ([#92](https://github.com/MGMResorts/client-tooling/pull/92))
- **component:** The carousel skips an image while swiping through - (CSBP-3121) ([#89](https://github.com/MGMResorts/client-tooling/pull/89))
- **section-map:** update section map toggle icon (CSBP-3100)(PATCH) ([#84](https://github.com/MGMResorts/client-tooling/pull/84))
- **component:** added onTransitionEnd event to svg container - (CSBP-3083) ([#78](https://github.com/MGMResorts/client-tooling/pull/78))
- **component:** removed unneccesary margin from step indicator component - (CSBP-3010) ([#72](https://github.com/MGMResorts/client-tooling/pull/72))
- **commerce-ui:** fix the digital gradient buttons (CSBP-2886) ([#67](https://github.com/MGMResorts/client-tooling/pull/67))
- **component:** added bg to price and seats bottom sheet component - CSBP-2646 ([#66](https://github.com/MGMResorts/client-tooling/pull/66))
- seat section selection refactor - CSBP-2646 ([#61](https://github.com/MGMResorts/client-tooling/pull/61))
- **grandstand-selection-map:** set default sizes do 100% - CSBP-2809 ([#46](https://github.com/MGMResorts/client-tooling/pull/46))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))
- **build:** use vite over parcel or swc ([#38](https://github.com/MGMResorts/client-tooling/pull/38))
- **commerce-ui:** update commerce UI bundler - CSBP-2613 ([#36](https://github.com/MGMResorts/client-tooling/pull/36))
- **commerce-ui:** update css files import - CSBP-2613 ([#35](https://github.com/MGMResorts/client-tooling/pull/35))

### ⚠️  Breaking Changes

- ⚠️  **commerce-ui:** ensure click event for non-touch devices (CSBP-3661) (MAJOR) ([#177](https://github.com/MGMResorts/client-tooling/pull/177))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0
- Updated vega-tailwind to 0.7.0

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Silva @dsilvamgm
- David Morales @davidamorales
- Diana Naranjo @dnaranjo-mgm
- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Gustavo Arellano @GustavoFSLCo
- Italo Andrade @italoiz-mgm
- Lukas Machado @lukasmachado-mgm
- Matheus Laureano
- Renan Britz @renan-britz-mgm
- Rob Fyffe @rfyffe-mgmresorts
- Rurik Pinheiro @rkpinheiro-mgm
- Thomas Kelly
- voliveira-mgm @voliveira-mgm

# Change Log - @mgmresorts/commerce-ui

This log was last generated on Tue, 21 Jan 2025 14:08:09 GMT and should not be manually modified.

## 8.19.15
Tue, 21 Jan 2025 14:08:09 GMT

### Patches

- fix: align ResortCard design with Figma specs (CSBP-4331) (PATCH)

## 8.19.14
Tue, 21 Jan 2025 13:12:09 GMT

### Patches

- fixed vertical scroll issue in the carousel for mobile

## 8.19.13
Mon, 20 Jan 2025 15:45:44 GMT

### Patches

- Fix Room rates carousel

## 8.19.12
Thu, 16 Jan 2025 22:29:19 GMT

### Patches

- Update the width card when isLoading changes in Rooms Available Room Rates

## 8.19.11
Thu, 16 Jan 2025 18:49:51 GMT

### Patches

- Add loading skeleton to Rooms Available Room Rates

## 8.19.10
Thu, 16 Jan 2025 12:28:47 GMT

### Patches

- fixed select offer button focus ring

## 8.19.9
Wed, 15 Jan 2025 01:12:18 GMT

### Patches

- fix: mobile ios & safari room images wrong aspect ratio (CSBP-4269) (PATCH)

## 8.19.8
Fri, 10 Jan 2025 16:25:40 GMT

### Patches

- dropdown being cut off on ipad air

## 8.19.7
Wed, 08 Jan 2025 01:29:21 GMT

### Patches

- updated translateExtent values in zoom init handler

## 8.19.6
Tue, 07 Jan 2025 23:16:31 GMT

### Patches

- fixed room rates styling issue

## 8.19.5
Tue, 07 Jan 2025 22:57:18 GMT

### Patches

- adjust icons within rooms-filters-control-modal

## 8.19.4
Tue, 07 Jan 2025 18:45:53 GMT

### Patches

- replaced existing radio button from room rates carousel with mgm-ui version

## 8.19.3
Tue, 07 Jan 2025 17:03:58 GMT

### Patches

- fixed zoomed handler condition

## 8.19.2
Tue, 07 Jan 2025 16:27:42 GMT

### Patches

- use icon from mgm-ui for rooms-filters-control-modal

## 8.19.1
Mon, 06 Jan 2025 20:28:06 GMT

### Patches

- fixed focus ring in the select room page

## 8.19.0
Mon, 06 Jan 2025 18:45:43 GMT

### Minor changes

- change the way components are rendered in rooms-filters-control-modal

## 8.18.1
Fri, 03 Jan 2025 03:15:20 GMT

### Patches

- fixed zoom behavior when the viewport has changed

## 8.18.0
Thu, 02 Jan 2025 20:21:41 GMT

### Minor changes

- added zoom and drag features to the section map

## 8.17.1
Tue, 31 Dec 2024 21:45:19 GMT

### Patches

- fixed some text alignment

## 8.17.0
Fri, 27 Dec 2024 17:13:21 GMT

### Minor changes

- feat: add resort transparent price component and mobile adjustment (CSBP-3920) (MINOR)

## 8.16.0
Thu, 26 Dec 2024 17:00:09 GMT

### Minor changes

- feat: remove fixed height from resort content card (CSBP-3920) (MINOR)

## 8.15.6
Thu, 26 Dec 2024 15:29:03 GMT

### Patches

- add missing aria attributes

## 8.15.5
Mon, 23 Dec 2024 14:41:08 GMT

### Patches

- fixed focus ring in the resort details modal

## 8.15.4
Fri, 20 Dec 2024 14:04:19 GMT

### Patches

- fixed incorrect html elements in the rooms page in terms of acessibility

## 8.15.3
Wed, 18 Dec 2024 16:02:45 GMT

### Patches

- adding loading and disabled state for room card component.

## 8.15.2
Wed, 18 Dec 2024 13:37:25 GMT

### Patches

- fixed unnecessary roles and tabindexes in the html elements

## 8.15.1
Tue, 17 Dec 2024 02:52:05 GMT

### Patches

- Make offer details content focusable when showing legal info

## 8.15.0
Mon, 16 Dec 2024 18:35:07 GMT

### Minor changes

- adjust resort-bottom-panel styles

## 8.14.0
Thu, 12 Dec 2024 21:27:14 GMT

### Minor changes

- chore: small font weight adjustment for event info card (CSBP-4058) (MINOR)

## 8.13.3
Wed, 11 Dec 2024 21:33:07 GMT

### Patches

- Use variant button for TextLink for offer details legal

## 8.13.2
Wed, 11 Dec 2024 21:08:10 GMT

### Patches

- fixed room card styling issue on Safari

## 8.13.1
Wed, 11 Dec 2024 17:04:37 GMT

### Patches

- fixed screen reader issue related to bullet point on the resort dropdown

## 8.13.0
Tue, 10 Dec 2024 18:26:01 GMT

### Minor changes

- improve accessibility for event and price filters

### Patches

- fix(commerce-ui): sync commerce-ui package version with published package

## 8.11.5
Fri, 06 Dec 2024 14:59:07 GMT

### Patches

- fixed small issues related to mobile dropdown accessibility

## 8.11.4
Thu, 05 Dec 2024 17:35:03 GMT

### Patches

- adjust center modal widths

## 8.11.3
Wed, 04 Dec 2024 14:08:43 GMT

### Patches

- created room card skeleton for room booking

## 8.11.2
Tue, 03 Dec 2024 19:09:02 GMT

### Patches

- adjust styles for the rooms-resort-botoom-panel component

## 8.11.1
Tue, 03 Dec 2024 18:39:56 GMT

### Patches

- arbitrary code formatting change

## 8.11.0
Tue, 03 Dec 2024 18:23:48 GMT

### Minor changes

- cleanup of code comments

## 8.10.7
Tue, 03 Dec 2024 13:20:10 GMT

### Patches

- fixed voice over safari issue on the desktop dropdowns

## 8.10.6
Tue, 03 Dec 2024 01:14:07 GMT

### Patches

- arbitrary documentation text update

## 8.10.4
Fri, 22 Nov 2024 15:50:06 GMT

### Patches

- adjust the button style for the rooms-resort-bottom-panel

## 8.10.3
Thu, 21 Nov 2024 15:17:22 GMT

### Patches

- adjust style for the message of the rooms-resort-bottom-panel

## 8.10.2
Tue, 19 Nov 2024 20:23:12 GMT

### Patches

- fixed resort dropdown to display the trigger label when the resort is unavailable

## 8.10.1
Mon, 18 Nov 2024 15:12:27 GMT

### Patches

- fixed select room page style issues for desktop

## 8.10.0
Mon, 18 Nov 2024 14:43:27 GMT

### Minor changes

- feat: ensure accessibility for section ga map (CSBP-3918) (MINOR)

## 8.9.6
Mon, 18 Nov 2024 13:58:26 GMT

### Patches

- fixed dropdown accessibility issues

## 8.9.5
Fri, 15 Nov 2024 19:28:49 GMT

### Patches

- Add onOpenDropdownCallback to rooms ResortDropdown

## 8.9.4
Fri, 15 Nov 2024 17:13:13 GMT

### Patches

- adjust the width of the center modals

## 8.9.3
Thu, 14 Nov 2024 15:47:20 GMT

### Patches

- Remove conditional render in Rooms Offer Details Modal

## 8.9.2
Thu, 14 Nov 2024 14:40:04 GMT

### Patches

- add desktop variant for rooms-resort-bottom-panel

## 8.9.1
Wed, 13 Nov 2024 19:15:19 GMT

### Patches

- rollback the rooms-resort-selection-summary in favor of creating a new one

## 8.9.0
Wed, 13 Nov 2024 14:42:20 GMT

### Minor changes

- add desktop support for rooms-resort-selection-summary

## 8.8.2
Wed, 13 Nov 2024 14:33:23 GMT

### Patches

- Workaround for Rooms offer details in iphone with notch

## 8.8.1
Fri, 08 Nov 2024 12:40:05 GMT

### Patches

- control resort dropdown from a parent component

## 8.8.0
Fri, 08 Nov 2024 00:10:37 GMT

### Minor changes

- feat: reset sections when availableSections updates (CSBP-4059) (MINOR)

## 8.7.10
Thu, 07 Nov 2024 17:01:42 GMT

### Patches

- make aria-label optional

## 8.7.9
Wed, 06 Nov 2024 16:52:15 GMT

### Patches

- PriceAndSeatsBottomSheet updated

## 8.7.8
Wed, 06 Nov 2024 16:19:03 GMT

### Patches

- fixed empty view more offers modal

## 8.7.7
Wed, 06 Nov 2024 16:13:29 GMT

### Patches

- Minor design updates for the PriceAndSeatsBottomSheet component.

## 8.7.6
Tue, 05 Nov 2024 17:26:32 GMT

### Patches

- let carousel scrolls into the selected offer

## 8.7.5
Tue, 05 Nov 2024 14:21:11 GMT

### Patches

- scroll to the selected offer automatically

## 8.7.4
Tue, 05 Nov 2024 11:42:11 GMT

### Patches

- fixed dropdown accessibility issue related to tab key

## 8.7.3
Mon, 04 Nov 2024 16:36:05 GMT

### Patches

- fixed desktop dropdown accessibilitie issues

## 8.7.2
Mon, 04 Nov 2024 16:13:41 GMT

### Patches

- Allow pass html props to Carousel

## 8.7.1
Thu, 31 Oct 2024 12:50:30 GMT

### Patches

- fixed room page desktop styling issues

## 8.7.0
Wed, 30 Oct 2024 21:11:06 GMT

### Minor changes

- feat: handle section ga prevent hidden (CSBP-3762) (MINOR)

## 8.6.14
Wed, 30 Oct 2024 12:39:50 GMT

### Patches

- fixed small styling issues in the rooms page

## 8.6.13
Tue, 29 Oct 2024 22:26:07 GMT

### Patches

- adjust width of the rooms-available-room-rates component

## 8.6.12
Tue, 29 Oct 2024 16:24:24 GMT

### Patches

- add more data-cms to the rooms-filters-control-modal

## 8.6.11
Tue, 29 Oct 2024 15:37:01 GMT

### Patches

- provide more data-cms properties

## 8.6.10
Tue, 29 Oct 2024 03:25:48 GMT

### Patches

- updating timer color thresholds to handle floats

## 8.6.9
Tue, 29 Oct 2024 02:19:13 GMT

### Patches

- fixing float percentage of timer check to be a percentage

## 8.6.8
Tue, 29 Oct 2024 02:12:33 GMT

### Patches

- checking the one third time trigger for the timer component based on the total time in seconds

## 8.6.7
Tue, 29 Oct 2024 01:25:29 GMT

### Patches

- add logic into the timer to check for float percentages

## 8.6.6
Mon, 28 Oct 2024 23:51:03 GMT

### Patches

- adding new logic for timer on expired trigger

## 8.6.5
Mon, 28 Oct 2024 23:41:02 GMT

### Patches

- adding max height into room card for its header

## 8.6.4
Mon, 28 Oct 2024 22:51:34 GMT

### Patches

- fixing comment on use timer hook

## 8.6.3
Mon, 28 Oct 2024 22:44:48 GMT

### Patches

- parsing one third of the timer total if the same results in a float number

## 8.6.2
Mon, 28 Oct 2024 18:15:56 GMT

### Patches

- Fix selected value update for resort dropdown

## 8.6.1
Mon, 28 Oct 2024 15:34:34 GMT

### Patches

- adjust width of the rooms-available-room-rates component

## 8.6.0
Fri, 25 Oct 2024 22:32:05 GMT

### Minor changes

- feat: handle section ga map (CSBP-3762) (MINOR)

## 8.5.13
Fri, 25 Oct 2024 21:26:18 GMT

### Patches

- fixed tablet styling issues

## 8.5.12
Fri, 25 Oct 2024 20:03:44 GMT

### Patches

- adjust width of the rooms-available-room-rates component

## 8.5.11
Fri, 25 Oct 2024 17:53:58 GMT

### Patches

- adjust rooms-available-room-rates width

## 8.5.10
Fri, 25 Oct 2024 16:50:42 GMT

### Patches

- fixed resort and price dropdown styling

## 8.5.9
Fri, 25 Oct 2024 15:46:19 GMT

### Patches

- Use react-popper for Rooms Region Dropdown

## 8.5.8
Thu, 24 Oct 2024 22:45:46 GMT

### Patches

- adjust width of the rooms-available-room-rates component

## 8.5.7
Thu, 24 Oct 2024 17:45:15 GMT

### Patches

- minor update for the event info card types

## 8.5.6
Wed, 23 Oct 2024 21:15:51 GMT

### Patches

- Adjust Rooms Datepicker Bar styles

## 8.5.5
Wed, 23 Oct 2024 18:15:03 GMT

### Patches

- set max size for resort dropdown desktop version

## 8.5.4
Wed, 23 Oct 2024 15:38:18 GMT

### Patches

- fixed styling issues in the room booking components

## 8.5.3
Tue, 22 Oct 2024 22:21:25 GMT

### Patches

- Segment banner and Resort Details Modal fixes

## 8.5.2
Tue, 22 Oct 2024 20:15:14 GMT

### Patches

- added data cms field in the amenities list in the rooms card

## 8.5.1
Tue, 22 Oct 2024 19:58:44 GMT

### Patches

- Fix breakpoint width

## 8.5.0
Tue, 22 Oct 2024 17:16:57 GMT

### Minor changes

- implement carousel on the rooms-available-room-rates component

## 8.4.14
Tue, 22 Oct 2024 17:09:32 GMT

### Patches

- Updating logic for transparent pricing for event info cards

## 8.4.13
Tue, 22 Oct 2024 16:36:39 GMT

### Patches

- Snapshot updated

## 8.4.12
Tue, 22 Oct 2024 16:29:02 GMT

### Patches

- minor update on unit test

## 8.4.11
Tue, 22 Oct 2024 13:42:01 GMT

### Patches

- pass data-cms to the rooms-pricing-details-modal component

## 8.4.10
Mon, 21 Oct 2024 23:36:55 GMT

### Patches

- minor update on how we track the timer ticks

## 8.4.9
Mon, 21 Oct 2024 21:38:28 GMT

### Patches

- update offer details modal actions logic

## 8.4.8
Mon, 21 Oct 2024 20:37:54 GMT

### Patches

- fixing a runtime error issue because of a hook call

## 8.4.7
Mon, 21 Oct 2024 19:05:46 GMT

### Patches

- Minor fix for the timer time tracking

## 8.4.6
Mon, 21 Oct 2024 17:34:00 GMT

### Patches

- Updating timer tick handler logic

## 8.4.5
Mon, 21 Oct 2024 15:29:41 GMT

### Patches

- meet room vega design 

## 8.4.4
Sat, 19 Oct 2024 01:37:41 GMT

### Patches

- pass data-cms to rooms-calendar-bottom-panel component

## 8.4.3
Fri, 18 Oct 2024 18:30:25 GMT

### Patches

- make resort dropdown receive selected option as undefined

## 8.4.2
Fri, 18 Oct 2024 16:24:25 GMT

### Patches

- Bump dependencies

## 8.4.1
Thu, 17 Oct 2024 16:59:57 GMT

### Patches

- pass data-cms to rooms-tooltip

## 8.4.0
Thu, 17 Oct 2024 15:19:12 GMT

### Minor changes

- continue passing data-cms to more labels

## 8.3.5
Wed, 16 Oct 2024 22:14:01 GMT

### Patches

- fix: room card design mismatch (CSBP-4018) (PATCH)

## 8.3.4
Wed, 16 Oct 2024 20:05:02 GMT

### Patches

- meet accessibility requirements for rooms

## 8.3.3
Tue, 15 Oct 2024 16:23:47 GMT

### Patches

- fixed room details calendar badge

## 8.3.2
Mon, 14 Oct 2024 16:03:40 GMT

### Patches

- fixed styling issues in the select room page components

## 8.3.1
Mon, 14 Oct 2024 14:48:06 GMT

### Patches

- fixed broken rooms carousel styling

## 8.3.0
Mon, 14 Oct 2024 14:00:02 GMT

### Minor changes

- let components receive data-cms attribute

## 8.2.7
Fri, 11 Oct 2024 00:06:18 GMT

### Patches

- fix rooms-segment-banner styles

## 8.2.6
Wed, 09 Oct 2024 22:45:11 GMT

### Patches

- feat: room card image aspect ratio (CSBP-3992) (PATCH)

## 8.2.5
Wed, 09 Oct 2024 20:19:47 GMT

### Patches

- Allow pass custom loading component in Resort bottom panel

## 8.2.4
Wed, 09 Oct 2024 16:19:47 GMT

### Patches

- Add loading indicator to resort bottom panel

## 8.2.3
Tue, 08 Oct 2024 18:34:06 GMT

### Patches

- fixed tablet styling issues

## 8.2.2
Fri, 04 Oct 2024 16:54:51 GMT

### Patches

- UI adjustments segment banner for small tablet.

## 8.2.1
Thu, 03 Oct 2024 20:01:08 GMT

### Patches

- Hide "Select offer" cta when label is not provided

## 8.2.0
Thu, 03 Oct 2024 16:12:29 GMT

### Minor changes

- add mobile variant to rooms-segment-banner

## 8.1.9
Wed, 02 Oct 2024 16:31:53 GMT

### Patches

- fixed room details styling issues in the offer section

## 8.1.8
Wed, 02 Oct 2024 15:44:34 GMT

### Patches

- adjust font-size of the jwb-banner

## 8.1.7
Wed, 02 Oct 2024 15:16:15 GMT

### Patches

- Hide bottom cta area in resort detaisl when cta label is empty/undefined

## 8.1.6
Tue, 01 Oct 2024 14:27:44 GMT

### Patches

- Previous Steps, Resort and Room Cards updated to mirror accessibility concerns.

## 8.1.5
Tue, 01 Oct 2024 13:42:33 GMT

### Patches

- enable apply button after clearing all

## 8.1.4
Mon, 30 Sep 2024 22:59:23 GMT

### Patches

- Fix font color in Rooms resort summary bottom panel

## 8.1.3
Mon, 30 Sep 2024 22:40:55 GMT

### Patches

- fixed comp scenarios in the room details modal and resort dropdown

## 8.1.2
Mon, 30 Sep 2024 18:52:24 GMT

### Patches

- make calendar icon clickable on room details modal

## 8.1.1
Mon, 30 Sep 2024 16:28:02 GMT

### Patches

- Fix Rooms footer

## 8.1.0
Mon, 30 Sep 2024 15:18:55 GMT

### Minor changes

- implemented comp scenarios for the resort dropdown

### Patches

- fixed small styling issues in the room details modal

## 8.0.1
Mon, 30 Sep 2024 13:30:32 GMT

### Patches

- fix(previous-step): correct the element type for the change button (CSBP-3956) (PATCH)

## 8.0.0
Fri, 27 Sep 2024 17:19:25 GMT

### Breaking changes

- feat: add accessibility requirements for resort components (CSBP-3956) (MAJOR)

## 7.59.1
Fri, 27 Sep 2024 14:38:42 GMT

### Patches

- hide prices when applicable on available room offers modal

## 7.59.0
Fri, 27 Sep 2024 14:05:15 GMT

### Minor changes

- implemented comp scenarios in the room details modal for desktop

### Patches

- add id to room filter modal types

## 7.58.4
Fri, 27 Sep 2024 13:41:37 GMT

### Patches

- implemented dates selected and no resort selected state for the calendar bottom panel

## 7.58.3
Thu, 26 Sep 2024 21:11:11 GMT

### Patches

- make links clickable on room details modal

## 7.58.2
Thu, 26 Sep 2024 19:54:10 GMT

### Patches

- set loading state for room details modal

## 7.58.1
Wed, 25 Sep 2024 19:24:48 GMT

### Patches

- Making resort name clickable when unavailable

## 7.58.0
Wed, 25 Sep 2024 18:15:14 GMT

### Minor changes

- implemented room selected panel for desktop

## 7.57.4
Wed, 25 Sep 2024 15:47:34 GMT

### Patches

- Updating event info card and carousel to hide the price if needed

## 7.57.3
Tue, 24 Sep 2024 20:26:51 GMT

### Patches

- Move carousel contrast gradiant from css file to tailwind class

## 7.57.2
Tue, 24 Sep 2024 15:34:18 GMT

### Patches

- adding callback for analytics into the timer component

## 7.57.1
Tue, 24 Sep 2024 14:45:38 GMT

### Patches

- Resort card enhancements  and expose util folder

## 7.57.0
Tue, 24 Sep 2024 13:25:36 GMT

### Minor changes

- implemented calendar bottom panel

## 7.56.9
Mon, 23 Sep 2024 16:42:42 GMT

### Patches

- fix rooms-room-detail styles

## 7.56.8
Mon, 23 Sep 2024 16:28:25 GMT

### Patches

- A footer component added to Resort Details modal

## 7.56.7
Mon, 23 Sep 2024 16:03:01 GMT

### Patches

- adjust rooms-room-detail component styles

## 7.56.6
Thu, 19 Sep 2024 18:51:21 GMT

### Patches

- Expose Rooms Footer

## 7.56.5
Thu, 19 Sep 2024 14:32:03 GMT

### Patches

- Resort Card style fixes

## 7.56.4
Wed, 18 Sep 2024 18:26:58 GMT

### Patches

- add general fixes

## 7.56.3
Wed, 18 Sep 2024 16:59:38 GMT

### Patches

- fixed z index issues in the carousel

## 7.56.2
Tue, 17 Sep 2024 19:46:48 GMT

### Patches

- adding callback for analytics into the timer component

## 7.56.1
Tue, 17 Sep 2024 16:13:52 GMT

### Patches

- fixed dropdown styling issues

## 7.56.0
Fri, 13 Sep 2024 18:57:22 GMT

### Minor changes

- add desktop variant to rooms-filters-control-modal component

## 7.55.2
Fri, 13 Sep 2024 18:41:30 GMT

### Patches

- implemented disabled room selection button

## 7.55.1
Thu, 12 Sep 2024 18:46:41 GMT

### Patches

- Adjust resort card for responsive scenario.

## 7.55.0
Thu, 12 Sep 2024 16:36:14 GMT

### Minor changes

- add rooms-tooltip component

### Patches

- adjust horizontal scroll within the experiences section

## 7.54.0
Thu, 12 Sep 2024 15:39:58 GMT

### Minor changes

- created room selection button

## 7.53.1
Wed, 11 Sep 2024 21:27:42 GMT

### Patches

- Make region dropdown inline

## 7.53.0
Wed, 11 Sep 2024 14:46:02 GMT

### Minor changes

- created room selected panel

## 7.52.0
Tue, 10 Sep 2024 14:25:06 GMT

### Minor changes

- feat: PB - feature design change - seat selection panel bayg price update (CSBP-3921) (MINOR)

## 7.51.2
Mon, 09 Sep 2024 18:27:34 GMT

### Patches

- Pass MouseEvent in onClickCTA

## 7.51.1
Fri, 06 Sep 2024 22:02:35 GMT

### Patches

- Expose swipe and click image carousel events

## 7.51.0
Fri, 06 Sep 2024 12:44:08 GMT

### Minor changes

- added desktop guest count

## 7.50.1
Fri, 06 Sep 2024 12:40:20 GMT

### Patches

- implemented fixed tax disclaimer in the resort dropdown

## 7.50.0
Fri, 06 Sep 2024 12:33:10 GMT

### Minor changes

- Implemented comp stay at other resorts alert for desktop

## 7.49.1
Thu, 05 Sep 2024 20:33:51 GMT

### Patches

- Add forwardRef to RoomsResortCard

## 7.49.0
Thu, 05 Sep 2024 16:21:42 GMT

### Minor changes

- add rooms-footer component

## 7.48.8
Wed, 04 Sep 2024 20:06:37 GMT

### Patches

- adding check for timer threshold

## 7.48.7
Wed, 04 Sep 2024 15:12:38 GMT

### Patches

- adjust components during mgm-ui migration

## 7.48.6
Wed, 04 Sep 2024 15:01:47 GMT

### Patches

- fixed small styling issues in the resort card

## 7.48.5
Tue, 03 Sep 2024 19:42:06 GMT

### Patches

- refactored region dropdown to use mgm-ui components

## 7.48.4
Tue, 03 Sep 2024 18:45:27 GMT

### Patches

- Add multiple lines to Rooms resort details address

## 7.48.3
Mon, 02 Sep 2024 20:27:13 GMT

### Patches

- refactored resort dropdown to use mgm-ui components

## 7.48.2
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 7.48.1
Mon, 02 Sep 2024 18:52:35 GMT

### Patches

- migrate offer details to mgm-ui modal

## 7.48.0
Mon, 02 Sep 2024 14:48:30 GMT

### Minor changes

- integrate the mgm-ui library

## 7.47.21
Mon, 02 Sep 2024 14:11:46 GMT

### Patches

- refactored rooms segment modal to use mgm-ui components

## 7.47.20
Thu, 29 Aug 2024 21:42:27 GMT

### Patches

- Expose RoomsResortDetailsModal

## 7.47.19
Thu, 29 Aug 2024 18:13:17 GMT

### Patches

- refactored segment banner to use mgm-ui components

## 7.47.18
Thu, 29 Aug 2024 16:06:18 GMT

### Patches

- implemented gradients to contrast carousel pagination
- refactored rooms card to use mgm-ui components

## 7.47.17
Thu, 29 Aug 2024 16:00:20 GMT

### Patches

- Expose ViewportContext and css fix

## 7.47.16
Wed, 28 Aug 2024 21:37:10 GMT

_Version update only_

## 7.47.15
Wed, 28 Aug 2024 19:16:42 GMT

### Patches

- migrate dates overlay to mgm-ui modal

## 7.47.14
Wed, 28 Aug 2024 02:25:28 GMT

### Patches

- Using TextLink component from mgm-ui

## 7.47.13
Tue, 27 Aug 2024 20:28:16 GMT

### Patches

- refactored resort cards to use mgm-ui components

## 7.47.12
Tue, 27 Aug 2024 15:39:35 GMT

### Patches

- Using Tabs from mgm-ui for PO Tabs

## 7.47.11
Tue, 27 Aug 2024 15:24:17 GMT

### Patches

- Using mgm-ui Button for Rooms Resort Selection Summary

## 7.47.10
Mon, 26 Aug 2024 22:17:33 GMT

### Patches

- Fix vega-tokens peerDependencies in commerce-ui

## 7.47.9
Mon, 26 Aug 2024 20:23:56 GMT

### Patches

- fixed room details modal open state

## 7.47.8
Mon, 26 Aug 2024 19:28:57 GMT

### Patches

- export more room booking components

## 7.47.7
Mon, 26 Aug 2024 19:11:09 GMT

### Patches

- Add more storybook variants for Dates Overlay

## 7.47.6
Mon, 26 Aug 2024 16:13:41 GMT

### Patches

- fixed carousel pagination buttons

## 7.47.5
Fri, 23 Aug 2024 20:10:02 GMT

### Patches

- Using Alert component from mgm-ui

## 7.47.4
Fri, 23 Aug 2024 18:28:14 GMT

### Patches

- rooms-datepicker-bar uses mgm-ui components

## 7.47.3
Fri, 23 Aug 2024 18:15:59 GMT

### Patches

- fixed carousel image height and aspect ratio

## 7.47.2
Fri, 23 Aug 2024 16:31:30 GMT

### Patches

- refactored room details modal to use mgm-ui components
- Expose `<Skeleton />` on `@mgmresorts/commerce-ui/skeleton`

## 7.47.1
Thu, 22 Aug 2024 23:52:51 GMT

### Patches

- integrated modal from mgm-ui into room details component

## 7.47.0
Thu, 22 Aug 2024 17:22:13 GMT

### Minor changes

- Rooms Dates Overlay
- set up design tokens provider in the storybook
- add desktop variant to jwb-modal

### Patches

- Making tier tag hoverable to display user menu
- Fix accessibility props for the Icon component
- correct the current version of commerce-ui (CSBP-3941) (PATCH)

## 7.45.0
Tue, 20 Aug 2024 10:50:58 GMT

### Minor changes

- added cta button in the offer details page for unselected offer

## 7.44.3
Mon, 19 Aug 2024 22:35:31 GMT

### Patches

- Click on header user info does not close account menu

## 7.44.2
Mon, 19 Aug 2024 14:20:42 GMT

### Patches

- Add accessibility props to the Icon component

## 7.44.1
Thu, 15 Aug 2024 20:35:49 GMT

### Patches

- Expose component in index.ts

## 7.44.0
Thu, 15 Aug 2024 18:01:57 GMT

### Minor changes

- created room details modal content for desktop

## 7.43.1
Thu, 15 Aug 2024 15:11:04 GMT

### Patches

- fixed styling issue in the sort by pricing dropdown

## 7.43.0
Thu, 15 Aug 2024 13:28:22 GMT

### Minor changes

- add desktop variant for rooms-pricing-details-modal

## 7.42.0
Thu, 15 Aug 2024 06:23:02 GMT

### Minor changes

- add desktop variant for jwb-banner

### Patches

- updated jwb banner logo

## 7.41.0
Wed, 14 Aug 2024 15:05:07 GMT

### Minor changes

- add available-room-rates-modal support for dekstop

## 7.40.0
Tue, 13 Aug 2024 02:03:47 GMT

### Minor changes

- created sort by pricing dropdown

## 7.39.3
Mon, 12 Aug 2024 14:11:56 GMT

### Patches

- Fix paddings in Global Header

## 7.39.2
Fri, 09 Aug 2024 18:22:00 GMT

### Patches

- UI Fixes for Global Header

## 7.39.1
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 7.39.0
Tue, 06 Aug 2024 16:36:25 GMT

### Minor changes

- created region dropdown component for desktop

## 7.38.2
Tue, 06 Aug 2024 16:13:35 GMT

### Patches

- fixed resort dropdown styling issues

## 7.38.1
Tue, 06 Aug 2024 14:10:36 GMT

### Patches

- Rooms destination dropdown improvements
- Rooms Tabs UI fixes

## 7.38.0
Mon, 05 Aug 2024 18:12:11 GMT

### Minor changes

- use rooms-modal for rooms-segment-modal component

## 7.37.0
Mon, 05 Aug 2024 17:48:02 GMT

### Minor changes

- added selected property to the room card component

## 7.36.0
Mon, 05 Aug 2024 15:37:02 GMT

### Minor changes

- support desktop variant for rooms-resort-fee-information-modal

## 7.35.0
Sun, 04 Aug 2024 21:26:12 GMT

### Minor changes

- Rooms Tabs component & Rooms PO Tab

## 7.34.0
Sun, 04 Aug 2024 21:06:44 GMT

### Minor changes

- Rooms Dates Input component

## 7.33.0
Fri, 02 Aug 2024 04:12:03 GMT

### Minor changes

- update accessibily filter

## 7.32.0
Thu, 01 Aug 2024 17:11:29 GMT

### Minor changes

- created desktop dropdown for desktop

## 7.31.0
Wed, 31 Jul 2024 20:04:52 GMT

### Minor changes

- Updated components styles to match figma design

## 7.30.0
Wed, 31 Jul 2024 17:28:37 GMT

### Minor changes

- add rooms-available-room-rates component

## 7.29.0
Tue, 30 Jul 2024 18:10:12 GMT

### Minor changes

- refactored room booking dropdown component

## 7.28.0
Mon, 29 Jul 2024 21:41:58 GMT

### Minor changes

- fixed rooms carousel styling and refactored carousel component for room booking

## 7.27.0
Mon, 29 Jul 2024 19:45:06 GMT

### Minor changes

- Rooms PO At Other Resorts component

## 7.26.0
Mon, 29 Jul 2024 17:07:05 GMT

### Minor changes

- Alert component

## 7.25.0
Mon, 29 Jul 2024 16:28:21 GMT

### Minor changes

- Rooms JWB Banner
- support desktop variant for rooms-resort-details-modal component
- Rooms Guest Counter
- created desktop offer details modal
- created rooms segment modal

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish
- fixed resort card styling

## 7.24.1
Mon, 22 Jul 2024 19:51:53 GMT

### Patches

- fixed styling issues in the resort cards

## 7.24.0
Fri, 19 Jul 2024 22:28:20 GMT

### Minor changes

- feat: add enablePriceAnimation prop to control price animation (CSBP-3671) (MINOR)

## 7.23.1
Fri, 19 Jul 2024 13:50:16 GMT

### Patches

- fixed styling issues for the segment banner

## 7.23.0
Thu, 18 Jul 2024 20:07:21 GMT

### Minor changes

- add rooms-available-room-rates-modal component
- created segment banner component
- add jwb-modal component
- created room cards for desktop
- created applied offer section for desktop po users
- version bump

### Patches

- created unavailable resort card variant for desktop
- bumping commerce-ui
- Resort details bottom padding fix
- minor updates

## 7.20.0
Fri, 05 Jul 2024 20:10:38 GMT

### Minor changes

- added swiping feature to the rooms carousel

## 7.19.0
Tue, 02 Jul 2024 12:56:09 GMT

### Minor changes

- add rooms-pricing-details-modal component

## 7.18.0
Mon, 01 Jul 2024 19:24:45 GMT

### Minor changes

- implemented rooms resort card for desktop

## 7.17.5
Thu, 27 Jun 2024 21:09:18 GMT

### Patches

- adding callback on room card

## 7.17.4
Thu, 27 Jun 2024 20:42:52 GMT

### Patches

- Adding a callback when we change the room card image

## 7.17.3
Wed, 26 Jun 2024 18:24:46 GMT

### Patches

- fixed decimal places in the room details pricing

## 7.17.2
Wed, 26 Jun 2024 16:13:44 GMT

### Patches

- fixed room details styling issue

## 7.17.1
Tue, 25 Jun 2024 16:09:00 GMT

### Patches

- fix rooms-resort-fee-information-modal close icon

## 7.17.0
Tue, 25 Jun 2024 15:20:20 GMT

### Minor changes

- added comp scenarios in the room details modal

## 7.16.1
Mon, 24 Jun 2024 21:02:43 GMT

### Patches

- fixed small styling issue in the resort dropdown

## 7.16.0
Mon, 24 Jun 2024 16:06:44 GMT

### Minor changes

- add rooms-filters-control component

## 7.15.1
Fri, 21 Jun 2024 19:01:24 GMT

### Patches

- fixed small styling issues in the room details content

## 7.15.0
Fri, 21 Jun 2024 15:39:28 GMT

### Minor changes

- created change resort dropdown component

## 7.14.0
Thu, 20 Jun 2024 17:02:32 GMT

### Minor changes

- Using react lazy to load react-markdown.

## 7.13.0
Thu, 20 Jun 2024 16:54:28 GMT

### Minor changes

- add rooms-resort-fee-information-modal component

## 7.12.0
Thu, 20 Jun 2024 15:34:30 GMT

### Minor changes

- Rooms Resort Details

## 7.11.1
Tue, 18 Jun 2024 21:17:19 GMT

### Patches

- expose timer hooks
- fix api declaration docs

## 7.11.0
Tue, 18 Jun 2024 18:14:52 GMT

### Minor changes

- Loading for package header mobile and desktop.

## 7.10.0
Mon, 17 Jun 2024 14:26:32 GMT

### Minor changes

- implemented room details modal content

## 7.9.1
Wed, 12 Jun 2024 18:48:05 GMT

### Patches

- created story for displaying multiple resort cards

## 7.9.0
Wed, 12 Jun 2024 16:05:07 GMT

### Minor changes

- RoomsOfferDetails component

### Patches

- Bump build dependencies

## 7.8.0
Wed, 12 Jun 2024 15:34:31 GMT

### Minor changes

- RoomsResortSelectionSummary component

## 7.7.0
Tue, 11 Jun 2024 21:34:24 GMT

### Minor changes

- fixed small styling issues in the rooms resort card

## 7.6.0
Tue, 11 Jun 2024 14:37:59 GMT

### Minor changes

- fixed rooms dropdown styling

## 7.5.1
Tue, 11 Jun 2024 12:36:33 GMT

### Patches

- adjust styles of the rooms-applied-offer

## 7.5.0
Sat, 08 Jun 2024 14:23:39 GMT

### Minor changes

- set up default vega viewports
- fixed room card styling issues

## 7.4.0
Thu, 06 Jun 2024 22:30:15 GMT

### Minor changes

- Rooms Markdown component

## 7.3.0
Thu, 06 Jun 2024 21:59:58 GMT

### Minor changes

- added disable option for bayg seat card

## 7.2.0
Thu, 06 Jun 2024 16:13:36 GMT

### Minor changes

- created change destination dropdown for room booking

## 7.1.0
Wed, 05 Jun 2024 20:27:50 GMT

### Minor changes

- allow defining color threshold for Timer component

## 7.0.0
Tue, 04 Jun 2024 18:39:53 GMT

### Breaking changes

- feat(commerce-ui)!: ensure click event for non-touch devices (CSBP-3661) (MAJOR)

## 6.9.2
Thu, 30 May 2024 16:23:12 GMT

### Patches

- fix(account-menu): close menu using escape key (CSBP-3396) (PATCH)

## 6.9.1
Wed, 29 May 2024 14:31:36 GMT

### Patches

- adjust rooms-applied-offer styles

## 6.9.0
Tue, 28 May 2024 16:48:58 GMT

### Minor changes

- Fixed rooms resort card styling

## 6.8.1
Tue, 28 May 2024 16:29:45 GMT

### Patches

- fix(header-global): hide the mobile menu button when userInfo is not available

## 6.8.0
Tue, 28 May 2024 15:45:32 GMT

### Minor changes

- feat(header-global): add mobile version of the account menu (CSBP-3414) (MINOR)

## 6.7.2
Mon, 27 May 2024 20:55:16 GMT

### Patches

- updated format currency check

## 6.7.1
Mon, 27 May 2024 17:56:09 GMT

### Patches

- updated format currency function

## 6.7.0
Mon, 27 May 2024 14:19:08 GMT

### Minor changes

- created room card for room booking using the vega design

## 6.6.0
Mon, 27 May 2024 11:21:48 GMT

### Minor changes

- add rooms-applied-offer component

## 6.5.0
Wed, 22 May 2024 17:47:07 GMT

### Minor changes

- feat: loading state room and resorts cards (CSBP-3253) (MINOR)

## 6.4.1
Tue, 21 May 2024 18:38:52 GMT

### Patches

- Style fixes for RoomsDatePickerBar

## 6.4.0
Fri, 17 May 2024 13:58:11 GMT

### Minor changes

- Created the new resort card for room booking using the vega design

## 6.3.2
Thu, 16 May 2024 19:43:56 GMT

### Patches

- centering the package header main content

## 6.3.1
Thu, 16 May 2024 19:33:00 GMT

### Patches

- resort card min height updated

## 6.3.0
Tue, 14 May 2024 18:12:11 GMT

### Minor changes

- Rooms Datepicker Bar

## 6.2.0
Tue, 14 May 2024 13:11:16 GMT

### Minor changes

- feat(global-header): add account menu interaction

## 6.1.3
Mon, 06 May 2024 15:49:59 GMT

### Patches

- fix(commerce-ui): digits in package total go missing sometimes (CSBP-3614) (PATCH)

## 6.1.2
Tue, 09 Apr 2024 20:01:54 GMT

### Patches

- added new property to resort card to display custom price labels

## 6.1.1
Wed, 03 Apr 2024 21:51:05 GMT

### Patches

- updated resort container to use all available height 

## 6.1.0
Wed, 03 Apr 2024 21:05:10 GMT

### Minor changes

- added rezise columns for resort cards

## 6.0.2
Fri, 29 Mar 2024 17:02:45 GMT

### Patches

- updated bayg style from resort card component

## 6.0.1
Tue, 19 Mar 2024 23:43:46 GMT

### Patches

- added seat number prop to bayg sear card

## 6.0.0
Thu, 14 Mar 2024 20:06:05 GMT

### Breaking changes

- **BREAKING IMPORT:** `@mgmresorts/commerce-ui/lib/style.css` -> `@mgmresorts/commerce-ui/styles`

### Patches

- Bump build dependencies

## 5.10.0
Mon, 11 Mar 2024 22:42:10 GMT

### Minor changes

- added variant support for price seat bottom component

## 5.9.3
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 5.9.2
Thu, 07 Mar 2024 16:41:43 GMT

### Patches

- added new property selectedFilters to load values from the parent instead of manage them locally

## 5.9.1
Tue, 05 Mar 2024 18:06:50 GMT

### Patches

- fix: update chip padding to not increase width on hover (CSBP-2409)(PATCH)

## 5.9.0
Tue, 05 Mar 2024 17:39:51 GMT

### Minor changes

- feat: add BaygSeatCard component

## 5.8.0
Tue, 05 Mar 2024 14:48:27 GMT

### Minor changes

- updating resort card width and adding package header disabled prop

## 5.7.1
Tue, 05 Mar 2024 12:58:38 GMT

### Patches

- fix: export package header test ids utils

## 5.7.0
Thu, 29 Feb 2024 17:05:25 GMT

### Minor changes

- added new property and id to event info card component

## 5.6.2
Tue, 27 Feb 2024 19:42:05 GMT

### Patches

- update chip component to receive any color, update price filter to allow multiple selection (CSBP-2409) (PATCH)
- feat: update price filter state to use id instead of whole object to filter (CSBP-2409)(PATCH)

## 5.6.1
Mon, 26 Feb 2024 19:36:15 GMT

### Patches

- update chip component to receive any color, update price filter to allow multiple selection (CSBP-2409) (PATCH)

## 5.6.0
Wed, 21 Feb 2024 15:53:42 GMT

### Minor changes

- add chip and price-filter components

## 5.5.0
Tue, 20 Feb 2024 14:30:54 GMT

### Minor changes

- feat(chip): create chips component, add tests, update icons to have width and height props (CSBP-2409)(PATCH)
- feat(chip): add animations to the chip, update tests and icon to receive testids (CSBP-2409)(MINOR)

### Patches

- feat(chip): add transition to chip width(CSBP-2409)(PATCH)

## 5.4.0
Fri, 16 Feb 2024 21:49:19 GMT

### Minor changes

- event info card styles updated 

## 5.3.5
Thu, 15 Feb 2024 19:54:43 GMT

### Patches

- minor style update for resorct card unavailable text

## 5.3.4
Thu, 15 Feb 2024 15:08:10 GMT

### Patches

- resort card error case updated

## 5.3.3
Mon, 12 Feb 2024 16:34:50 GMT

### Patches

- feat(global-header): add on logo click to the logo link (CSBP-3039)(PATCH)

## 5.3.2
Thu, 08 Feb 2024 16:13:06 GMT

_Version update only_

## 5.3.1
Tue, 30 Jan 2024 20:43:53 GMT

### Patches

- feat(rooms): update mobile view for the room card (CSBP-3244) (PATCH)

## 5.3.0
Mon, 29 Jan 2024 19:27:21 GMT

### Minor changes

- feat(room): add new flag for unavailable state (CSBP-3244) (MINOR)

## 5.2.0
Mon, 29 Jan 2024 16:44:05 GMT

### Minor changes

- Move tier to userInfo props

## 5.1.0
Mon, 29 Jan 2024 15:45:03 GMT

### Minor changes

- feat: add tier-tag component to use in global-header (CSBP-3131) (MINOR)

## 5.0.15
Tue, 23 Jan 2024 22:25:59 GMT

### Patches

- resort card title height update

## 5.0.14
Tue, 23 Jan 2024 19:20:09 GMT

### Patches

- properly adding justify content for price bottom header wrapper

## 5.0.13
Tue, 23 Jan 2024 17:02:11 GMT

### Patches

- global header color update

## 5.0.12
Tue, 23 Jan 2024 16:31:40 GMT

### Patches

- minor design updates

## 5.0.11
Tue, 23 Jan 2024 14:11:47 GMT

### Patches

- updating design constraints

## 5.0.10
Thu, 04 Jan 2024 16:20:50 GMT

### Patches

- update timer

## 5.0.9
Thu, 04 Jan 2024 15:30:16 GMT

### Patches

- updating timer close to expire logic

## 5.0.8
Thu, 04 Jan 2024 14:56:28 GMT

### Patches

- updating timer duration left function

## 5.0.7
Thu, 04 Jan 2024 14:26:19 GMT

### Patches

- roll back for slot text changes

## 5.0.6
Thu, 04 Jan 2024 13:45:43 GMT

### Patches

- updating timer and slot text to cover edge cases

## 5.0.5
Thu, 21 Dec 2023 13:35:19 GMT

### Patches

- changing the resort card background only for desktop

## 5.0.4
Tue, 19 Dec 2023 16:37:05 GMT

### Patches

- fix resort card aspect ratio and minor fixes

## 5.0.3
Thu, 07 Dec 2023 19:02:12 GMT

### Patches

- updating the logic to generate the letter width inside the slot text component

## 5.0.2
Thu, 07 Dec 2023 14:11:24 GMT

### Patches

- minor design and functionalities updates

## 5.0.1
Wed, 06 Dec 2023 17:49:51 GMT

### Patches

- fix: export package header test ids utils

## 5.0.0
Wed, 29 Nov 2023 17:30:42 GMT

### Breaking changes

- add desktop version for PackageHeader component

## 4.12.2
Mon, 27 Nov 2023 21:47:20 GMT

### Patches

- update the selected state to outside of the component
- feat(resort-card): update label to show if its included in package when is tagged (CSBP-2972)(PATCH)

## 4.12.1
Thu, 23 Nov 2023 17:40:38 GMT

### Patches

- update the selected state to outside of the component

## 4.12.0
Wed, 22 Nov 2023 13:22:55 GMT

### Minor changes

- update resort cart with selected state and desktop responsivity (CSBP-2972)(MINOR)

## 4.11.2
Tue, 21 Nov 2023 17:14:06 GMT

### Patches

- minor layout updates on resort details modal

## 4.11.1
Tue, 21 Nov 2023 15:00:08 GMT

### Patches

- removed event listener from global header

## 4.11.0
Tue, 21 Nov 2023 05:42:42 GMT

### Minor changes

- add experiences to ResortDetails

## 4.10.2
Tue, 14 Nov 2023 18:57:57 GMT

### Patches

- updating padding of global header on mobile

## 4.10.1
Mon, 13 Nov 2023 21:15:17 GMT

### Patches

- added onTouchEnd event to image carousel

## 4.10.0
Mon, 13 Nov 2023 18:57:58 GMT

### Minor changes

- adding new global header

## 4.9.6
Thu, 09 Nov 2023 23:02:38 GMT

_Version update only_

## 4.9.5
Thu, 09 Nov 2023 22:21:40 GMT

_Version update only_

## 4.9.4
Tue, 07 Nov 2023 23:58:38 GMT

### Patches

- fix(section-map): update toggle icon from section map (CSBP-3100) (PATCH)
- fix(section-selection-map): update icon name to person-wheelchair and add an as any to ignore the type verification (CSBP-3100)(PATCH)

## 4.9.2
Wed, 01 Nov 2023 13:00:43 GMT

_Version update only_

## 4.9.1
Tue, 31 Oct 2023 18:44:27 GMT

_Version update only_

## 4.9.0
Thu, 19 Oct 2023 03:07:55 GMT

### Minor changes

- added new chroamtic workflow

## 4.8.0
Tue, 17 Oct 2023 20:54:30 GMT

### Minor changes

- feat: add clickable title on RoomCard component

## 4.7.1
Mon, 16 Oct 2023 22:23:52 GMT

### Patches

- added onTransitionEnds event to svg container

## 4.7.0
Fri, 13 Oct 2023 21:53:23 GMT

### Minor changes

- added new callback to section selection component

## 4.6.0
Thu, 12 Oct 2023 18:02:25 GMT

### Minor changes

- add amenities to ResortDetails

## 4.5.0
Thu, 12 Oct 2023 16:48:14 GMT

### Minor changes

- add ResortDetails component

## 4.4.2
Wed, 11 Oct 2023 22:45:29 GMT

### Patches

- room's image carousel controls updated

## 4.4.1
Wed, 11 Oct 2023 18:24:43 GMT

### Patches

- removed unneccesary margin from step indicator component

## 4.4.0
Fri, 08 Sep 2023 19:21:04 GMT

### Minor changes

- feat(section-selection-map): add auto pan when select section

## 4.3.0
Thu, 07 Sep 2023 16:35:14 GMT

### Minor changes

- Correct margin of carousel and grandstand map components

## 4.2.3
Wed, 06 Sep 2023 21:05:46 GMT

### Patches

- updating timer component isExpiring trigger logic

## 4.2.2
Wed, 06 Sep 2023 15:51:52 GMT

### Patches

- fix button primary gradient stops

## 4.2.1
Mon, 04 Sep 2023 21:19:47 GMT

### Patches

- added bg color to price and seats bottom sheet component

## 4.2.0
Thu, 31 Aug 2023 16:56:55 GMT

### Minor changes

- feat: add room card component

## 4.1.0
Mon, 28 Aug 2023 17:43:13 GMT

### Minor changes

- adding timer component

## 4.0.0
Fri, 25 Aug 2023 17:18:28 GMT

### Breaking changes

- seat section selection refactor

## 3.0.1
Tue, 22 Aug 2023 19:51:53 GMT

### Patches

- updating resort card width

## 3.0.0
Fri, 18 Aug 2023 19:32:04 GMT

### Breaking changes

- feat(package-header): change link url to on link click - CSBP-2828

### Patches

- Applied default background to event carousel

## 2.8.1
Fri, 18 Aug 2023 16:47:41 GMT

### Patches

- Removed background from carousel card

## 2.8.0
Fri, 18 Aug 2023 14:50:15 GMT

### Minor changes

- update resort card component

## 2.7.0
Thu, 17 Aug 2023 15:06:54 GMT

### Minor changes

- update package header design

## 2.6.1
Wed, 16 Aug 2023 22:48:37 GMT

### Patches

- added missing exports for seat selection component

## 2.6.0
Mon, 14 Aug 2023 17:33:06 GMT

### Minor changes

- Implement event info carousel design update

## 2.5.0
Mon, 14 Aug 2023 17:19:20 GMT

### Minor changes

- feat(seat-section-map): create seat section map component - CSBP-2647

### Patches

- fix: update story arg type name CSBP-2647
- update cta and map behavior - CSBP-2647

## 2.4.0
Fri, 11 Aug 2023 22:55:57 GMT

### Minor changes

- Implement selected seats card and sheet design update

## 2.3.0
Thu, 10 Aug 2023 18:27:44 GMT

### Minor changes

- creating of the previous step component

## 2.2.0
Wed, 09 Aug 2023 22:42:53 GMT

### Minor changes

- Add checks to commerce-ui

## 2.1.0
Mon, 07 Aug 2023 18:11:10 GMT

### Minor changes

- Update step indicator color for latest design

## 2.0.0
Fri, 04 Aug 2023 22:51:07 GMT

### Breaking changes

- fix(grandstand-selection-map): set default sizes do 100% - CSBP-2809

## 1.14.0
Thu, 03 Aug 2023 17:44:26 GMT

### Minor changes

- add ResortCard component

## 1.13.0
Fri, 28 Jul 2023 19:23:12 GMT

### Minor changes

- feat: create grandstand selection map component

## 1.12.0
Tue, 18 Jul 2023 16:32:44 GMT

### Minor changes

- chore: add export to new component

## 1.11.0
Fri, 14 Jul 2023 19:04:13 GMT

### Minor changes

- feat: create price and seats bottom sheet component

## 1.10.0
Tue, 11 Jul 2023 22:47:41 GMT

### Minor changes

- feat: create button component

## 1.9.4
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 1.9.3
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 1.9.2
Tue, 04 Jul 2023 19:58:54 GMT

### Patches

- Use vite for bundling

## 1.9.1
Tue, 04 Jul 2023 17:17:13 GMT

### Patches

- adding parcel to act as a bundler

## 1.9.0
Tue, 04 Jul 2023 04:18:49 GMT

### Minor changes

- feat: add tailwind for storybook to commerce-ui package

## 1.8.0
Mon, 03 Jul 2023 20:58:24 GMT

### Minor changes

- updating css files import

## 1.7.0
Mon, 03 Jul 2023 17:49:59 GMT

### Minor changes

- adding slot text component
- change for vega tailwind

## 1.6.0
Fri, 30 Jun 2023 23:48:19 GMT

### Minor changes

- add SelectedSeatsCard component

## 1.5.0
Tue, 27 Jun 2023 22:23:34 GMT

### Minor changes

- chore: update storybook to be a tool and to be used from anywhere - CSBP-2566

## 1.4.0
Tue, 27 Jun 2023 14:42:03 GMT

### Minor changes

- feat: create packageHeader and link components

## 1.3.0
Mon, 26 Jun 2023 23:42:08 GMT

### Minor changes

- feat(commerce-ui): add event carousel component

## 1.2.0
Fri, 23 Jun 2023 16:09:59 GMT

### Minor changes

- chore: update indicator color number icon

## 1.1.0
Tue, 13 Jun 2023 22:03:22 GMT

### Minor changes

- add StepIndicator and Icon components

