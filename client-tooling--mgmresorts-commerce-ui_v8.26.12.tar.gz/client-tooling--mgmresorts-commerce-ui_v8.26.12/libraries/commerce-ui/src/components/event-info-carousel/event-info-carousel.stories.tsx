import React, { useState } from 'react';

import { Meta } from '@storybook/react';

import { EventInfoCarousel } from './event-info-carousel';
import {
  storyBuildAsYouGoMockProps,
  storyTransparentMockProps
} from './event-info-carousel.mock';
import {
  EventInfoCarouselDataProp,
  EventInfoCarouselProps
} from './event-info-carousel.types';

export default {
  argTypes: {
    onChange: { action: 'changed' }
  },
  component: EventInfoCarousel,
  title: 'Components/EventInfoCarousel'
} as Meta<typeof EventInfoCarousel>;

export const Transparent = (
  args: EventInfoCarouselProps<
    'transparent',
    EventInfoCarouselDataProp<'transparent'>
  >
) => {
  const [value, setValue] = useState<
    EventInfoCarouselDataProp<'transparent'> | undefined
  >();

  return (
    <EventInfoCarousel
      {...args}
      value={value}
      onChange={async (newValue) => {
        setValue(newValue);
        await args?.onChange?.(newValue);
      }}
    />
  );
};

Transparent.args = { ...storyTransparentMockProps };

export const BuildAsYouGo = (
  args: EventInfoCarouselProps<
    'build-as-you-go',
    EventInfoCarouselDataProp<'build-as-you-go'>
  >
) => {
  const [value, setValue] = useState<
    EventInfoCarouselDataProp<'build-as-you-go'> | undefined
  >();

  return (
    <EventInfoCarousel
      {...args}
      value={value}
      onChange={async (newValue) => {
        setValue(newValue);
        await args?.onChange?.(newValue);
      }}
    />
  );
};

BuildAsYouGo.args = { ...storyBuildAsYouGoMockProps };

export const BuildAsYouGoPriceTextHidden = (
  args: EventInfoCarouselProps<
    'build-as-you-go',
    EventInfoCarouselDataProp<'build-as-you-go'>
  >
) => {
  const [value, setValue] = useState<
    EventInfoCarouselDataProp<'build-as-you-go'> | undefined
  >();

  return (
    <EventInfoCarousel
      {...args}
      value={value}
      onChange={async (newValue) => {
        setValue(newValue);
        await args?.onChange?.(newValue);
      }}
    />
  );
};

BuildAsYouGoPriceTextHidden.args = {
  ...storyBuildAsYouGoMockProps,
  showPrice: false
};
