import { EventInfoCardProps, EventInfoCardVariants } from '../event-info-card';

/**
 * @public
 */
export type EventInfoCarouselDataProp<T extends EventInfoCardVariants> = Omit<
  EventInfoCardProps<T>,
  'variant'
> & {
  id: any;
  [key: string]: any;
};

/**
 * @public
 */
export interface EventInfoCarouselProps<
  V extends EventInfoCardVariants,
  T extends EventInfoCarouselDataProp<V>
> {
  cardVariant: V;
  data?: T[];
  value?: T;
  onChange?: (value: T) => Promise<void> | void;
  showPrice?: boolean;
}
