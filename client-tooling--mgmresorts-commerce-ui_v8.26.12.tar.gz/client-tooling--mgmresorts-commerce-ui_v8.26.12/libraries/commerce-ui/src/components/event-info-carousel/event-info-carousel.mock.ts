import { addDays } from 'date-fns';

import {
  EventInfoCarouselDataProp,
  EventInfoCarouselProps
} from './event-info-carousel.types';

const sampleData = [
  {
    date: new Date(),
    id: 1,
    label: 'Example #1',
    price: 2987,
    surchargeText: 'Included in package'
  },
  {
    date: new Date(),
    id: 2,
    label: 'Example #2',
    price: 2987,
    surchargeText: 'Included in package'
  },
  { date: new Date(), id: 3, label: 'Example #3', price: 2987 },
  { date: new Date(), id: 4, label: 'Example #4', price: 2987 },
  { date: new Date(), id: 5, label: 'Example #5', price: 2987 }
].map((data, i) => ({ ...data, date: addDays(data.date, i + 1) }));

const transparentProps: EventInfoCarouselProps<
  'transparent',
  EventInfoCarouselDataProp<'transparent'>
> = {
  cardVariant: 'transparent',
  data: sampleData.map(({ id, label, price, surchargeText }) => ({
    id,
    price,
    section: label,
    surcharge: price * 0.1,
    surchargeText: surchargeText
  }))
};

const buildAsYouGoProps: EventInfoCarouselProps<
  'build-as-you-go',
  EventInfoCarouselDataProp<'build-as-you-go'>
> = {
  cardVariant: 'build-as-you-go',
  data: sampleData.map(({ id, price, date }) => ({
    date,
    id,
    price
  }))
};

export const storyTransparentMockProps: EventInfoCarouselProps<
  'transparent',
  EventInfoCarouselDataProp<'transparent'>
> = {
  ...transparentProps
};

export const storyBuildAsYouGoMockProps: EventInfoCarouselProps<
  'build-as-you-go',
  EventInfoCarouselDataProp<'build-as-you-go'>
> = {
  ...buildAsYouGoProps
};
