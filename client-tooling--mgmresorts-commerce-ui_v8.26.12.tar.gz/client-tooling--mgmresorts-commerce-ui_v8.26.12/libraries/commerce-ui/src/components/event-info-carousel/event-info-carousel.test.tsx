import React, { useState } from 'react';

import { fireEvent, render, screen } from '@testing-library/react';

import { EventInfoCardTestIds } from '../event-info-card';

import {
  EventInfoCarousel,
  EventInfoCarouselTestIds
} from './event-info-carousel';

describe('<EventInfoCarousel /> component', () => {
  it('should not broke when `data` property was not informed', () => {
    render(<EventInfoCarousel cardVariant="transparent" />);

    const containerEl = screen.getByTestId(EventInfoCarouselTestIds.component);
    expect(containerEl.childNodes.length).toEqual(0);
  });

  it('should render the correctly quantity of <EventCardInfo /> components', () => {
    render(
      <EventInfoCarousel
        cardVariant="transparent"
        data={[
          { id: 1, price: 100, section: 'Section Title', surcharge: 50 },
          { id: 2, price: 100, section: 'Section Title', surcharge: 50 }
        ]}
      />
    );

    const containerEl = screen.getByTestId(EventInfoCarouselTestIds.component);
    expect(containerEl.childNodes.length).toEqual(2);
  });

  it('should render the correct variant based on `cardVariant` property', () => {
    render(
      <EventInfoCarousel
        cardVariant="transparent"
        data={[{ id: 1, price: 100, section: 'Section Title', surcharge: 50 }]}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.component)).toBeDefined();

    expect(
      screen.getByTestId(EventInfoCardTestIds.sectionTitle).textContent
    ).toBe('Section Title');
  });

  it('should call `onChange` when one of rendered card was clicked', () => {
    const onChangeSpy = jest.fn();

    render(
      <EventInfoCarousel
        cardVariant="transparent"
        onChange={onChangeSpy}
        data={[{ id: 1, price: 100, section: 'Section Title', surcharge: 50 }]}
      />
    );

    fireEvent.click(screen.getByTestId(EventInfoCardTestIds.component));

    expect(onChangeSpy).toHaveBeenCalledWith({
      id: 1,
      price: 100,
      section: 'Section Title',
      surcharge: 50
    });
  });

  it('should scroll to element when element is not aligned', async () => {
    const MockedEventInfoCarousel = () => {
      const [value, setValue] = useState<any>();

      return (
        <EventInfoCarousel
          cardVariant="transparent"
          onChange={setValue}
          value={value}
          data={[
            { id: 1, price: 100, section: 'Section Title', surcharge: 50 },
            { id: 2, price: 100, section: 'Section Title', surcharge: 50 }
          ]}
        />
      );
    };

    render(<MockedEventInfoCarousel />);

    const container = screen.getByTestId(EventInfoCarouselTestIds.component);

    const elements = await screen.findAllByTestId(
      EventInfoCardTestIds.component
    );

    container.scrollTo = jest.fn();
    fireEvent.click(elements[1]);
    expect(container.scrollTo).toHaveBeenCalled();
  });

  it('should scroll to 0 (zero) offset when value was not found', async () => {
    const MockedEventInfoCarousel = () => {
      const [value, setValue] = useState<any>();

      return (
        <EventInfoCarousel
          cardVariant="transparent"
          onChange={() => {
            setValue({
              id: 3,
              price: 100,
              section: 'Section Title',
              surcharge: 50
            });
          }}
          value={value}
          data={[
            { id: 1, price: 100, section: 'Section Title', surcharge: 50 },
            { id: 2, price: 100, section: 'Section Title', surcharge: 50 }
          ]}
        />
      );
    };

    render(<MockedEventInfoCarousel />);

    const container = screen.getByTestId(EventInfoCarouselTestIds.component);

    const elements = await screen.findAllByTestId(
      EventInfoCardTestIds.component
    );

    container.scrollTo = jest.fn();
    fireEvent.click(elements[1]);

    expect(container.scrollTo).toHaveBeenCalledWith(
      expect.objectContaining({ left: 0 })
    );
  });
});
