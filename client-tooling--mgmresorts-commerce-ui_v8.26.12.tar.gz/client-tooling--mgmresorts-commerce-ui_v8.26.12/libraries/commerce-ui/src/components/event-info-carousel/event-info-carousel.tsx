import React, { MutableRefObject, useRef } from 'react';

import { useDraggable } from 'react-use-draggable-scroll';

import { useScrollToSelected } from '../../util/use-scroll-to-selection';

import { EventInfoCard, EventInfoCardVariants } from '../event-info-card';

import {
  EventInfoCarouselDataProp,
  EventInfoCarouselProps
} from './event-info-carousel.types';

const componentId = 'EventInfoCarousel';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const EventInfoCarouselTestIds = {
  component: componentId
};

/**
 * @public
 */
export const EventInfoCarousel = <
  V extends EventInfoCardVariants,
  T extends EventInfoCarouselDataProp<V>
>({
  data,
  cardVariant,
  value,
  onChange,
  showPrice = true
}: EventInfoCarouselProps<V, T>) => {
  const ref = useRef<HTMLDivElement>(null);

  const draggableProps = useDraggable(ref as MutableRefObject<HTMLDivElement>, {
    applyRubberBandEffect: true
  });

  useScrollToSelected(ref, value, data);

  return (
    <div
      {...draggableProps.events}
      ref={ref}
      data-testid={EventInfoCarouselTestIds.component}
      className={`overflow-x-scroll flex gap-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]`}
    >
      {data?.map((eventData) => (
        // avoid typescript errors because it is not able to infer the correct dynamic typings.
        // @ts-ignore
        <EventInfoCard
          {...eventData}
          key={`eventinfo-${eventData.id}`}
          variant={cardVariant}
          isSelected={value?.id === eventData.id}
          onClick={async () => {
            if (typeof onChange === 'function') await onChange(eventData);
          }}
          showPrice={showPrice}
        />
      ))}
    </div>
  );
};
