import React from 'react';

import { Meta } from '@storybook/react';

import { Icon } from './icon';
import { allAvailableIcons, defaultProps } from './icon.mock';
import { IconProps } from './icon.types';

export default {
  argTypes: {},
  component: Icon,
  title: 'Components/Icon'
} as Meta<typeof Icon>;

export const Default = (args: IconProps) => <Icon {...args} />;
Default.args = { ...defaultProps };
/**
 * An list of available icons
 */
export const AllIcons = (args: IconProps) => (
  <div className="flex flex-row flex-wrap gap-2">
    {allAvailableIcons.map((iconName) => (
      <div
        className="border border-default rounded p-space-component-s"
        key={iconName}
        title={iconName}
      >
        <Icon {...args} name={iconName} />
      </div>
    ))}
  </div>
);
AllIcons.args = { ...defaultProps };
