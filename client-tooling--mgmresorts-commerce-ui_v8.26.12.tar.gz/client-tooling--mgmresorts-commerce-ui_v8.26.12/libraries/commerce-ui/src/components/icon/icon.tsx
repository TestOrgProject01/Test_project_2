import * as React from 'react';

import SVG from 'react-inlinesvg';

import { IconProps } from './icon.types';

// This is copied from mgm-ui.
// They note that this will change when the CMS gets changed.
const urlPrefix =
  'https://static.mgmresorts.com/content/dam/MGM/direct/vega/icons';

/**
 * @public
 */
export const Icon = ({
  color,
  name,
  variant,
  size,
  width,
  height,
  testId,
  className,
  ariaLabel
}: IconProps) => {
  const iconSize = size === 'large' ? 48 : 24;

  const iconProps = {
    height: height || iconSize,
    width: width || iconSize
  };

  const accessibilityProps = ariaLabel
    ? { 'aria-label': ariaLabel, role: 'img' }
    : { 'aria-hidden': true };

  return (
    <SVG
      src={`${urlPrefix}/${name}-${size}-${variant}.svg`}
      preProcessor={(code) =>
        code.replace(/fill=".*?"/g, 'fill="currentColor"')
      }
      color={color}
      data-testid={testId}
      {...iconProps}
      className={className}
      {...accessibilityProps}
    />
  );
};
