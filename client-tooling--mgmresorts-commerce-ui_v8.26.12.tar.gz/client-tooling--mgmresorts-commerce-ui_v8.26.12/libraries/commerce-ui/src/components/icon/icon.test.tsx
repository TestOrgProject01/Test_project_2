import React from 'react';

import { axe, create, renderToHtml, screen } from '../../util/test-utils';

import { Icon } from './icon';
import { IconProps } from './icon.types';

describe('<Icon/> component', () => {
  const renderIconComponent = (props: IconProps) => create(<Icon {...props} />);

  const renderIconComponentToHtml = (props: IconProps) =>
    renderToHtml(<Icon {...props} />);

  const baseProps: IconProps = {
    name: 'airplane-clouds',
    size: 'small',
    variant: 'filled'
  };

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <Icon/> component', () => {
      renderIconComponent(baseProps);

      expect(screen.getByTestId('mocked-svg')).toBeTruthy();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderIconComponentToHtml({
        ...baseProps,
        ariaLabel: 'label'
      });

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
