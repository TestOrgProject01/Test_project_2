import type {
  IconNameTuple,
  IconSizeTuple,
  IconVariantTuple
} from '@mgmresorts/mgm-ui/lib/esm/atoms/Icon/Icon.lists';

/**
 * @public
 */
export type IconName = IconNameTuple[number];

/**
 * @public
 */
export type IconSize = IconSizeTuple[number];

/**
 * @public
 */
export type IconVariant = IconVariantTuple[number];

/**
 * @public
 */
export interface IconProps {
  name: IconName;
  size: IconSize;
  variant: IconVariant;
  color?: string;
  width?: number;
  height?: number;
  testId?: string;
  className?: string;
  ariaLabel?: string;
}
