import React from 'react';

interface Props {
  src: string;
  preProcessor?: (code: string) => string;
}

const InlineSvgMock = ({ src, preProcessor }: Props): React.ReactElement => {
  let processedCode = src;

  if (preProcessor) {
    processedCode = preProcessor(processedCode);
  }

  return <div data-testid="mocked-svg">{processedCode}</div>;
};

// This component needs a default export,
// if it is exported with export const the mock doesn't work
// eslint-disable-next-line import/no-default-export
export default InlineSvgMock;
