import React from 'react';

import { faker } from '@faker-js/faker';

import {
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen
} from '../../util/test-utils';

import { ChipTestIds } from '../chip';

import { PriceFilter, PriceFilterTestIds } from './price-filter';
import { PriceFilterProps } from './price-filter.types';

describe('<PriceFilter/> component', () => {
  const renderPriceFilter = (props: PriceFilterProps) =>
    create(<PriceFilter {...props} />);

  const renderPriceFilterToHtml = (props: PriceFilterProps) =>
    renderToHtml(<PriceFilter {...props} />);

  const defaultProps = {
    data: [
      { id: 'under_10', label: 'Under $10', value: 'under_10' },
      { id: '10_20', label: '$10 - $20', value: '10_20' },
      { id: '20_30', label: '$20 - $30', value: '20_30' },
      { id: 'over_30', label: 'Over $30', value: 'over_30,' }
    ],
    helperLabel: '',
    onChange: jest.fn()
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      expect(renderPriceFilter(defaultProps)).toMatchSnapshot();
    });

    it('renders the PriceFilter component', () => {
      renderPriceFilter(defaultProps);

      const priceFilterComponent = screen.getByTestId(
        PriceFilterTestIds.component
      );

      expect(priceFilterComponent).toBeInTheDocument();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('calls the onChange function when a price range is selected', () => {
      const onChangeMock = jest.fn();

      renderPriceFilter({
        ...defaultProps,
        helperLabel: 'Select a price range',
        onChange: onChangeMock
      });

      const priceRangeButton = screen.getByText('Under $10');
      fireEvent.click(priceRangeButton);

      expect(onChangeMock).toHaveBeenCalledWith(defaultProps.data[0]);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      expect(
        await axe(renderPriceFilterToHtml(defaultProps))
      ).toHaveNoViolations();
    });

    it('should have accessibility attribute `role=checkbox`', () => {
      renderPriceFilter(defaultProps);

      const chips = screen.getAllByTestId(ChipTestIds.chip);

      chips.forEach((chip) => expect(chip).toHaveAttribute('role', 'checkbox'));
    });

    it('should have accessibility `aria-checked=false` if there are no selected values', () => {
      renderPriceFilter({
        ...defaultProps,
        selectedFilters: []
      });

      const chips = screen.getAllByTestId(ChipTestIds.chip);

      chips.forEach((chip) =>
        expect(chip).toHaveAttribute('aria-checked', 'false')
      );
    });

    it('should have accessibility `aria-checked=true` on the selected values', () => {
      const data: PriceFilterProps['data'] = new Array(
        faker.datatype.number({ max: 10, min: 1 })
      )
        .fill('')
        .map(() => ({
          id: faker.datatype.uuid(),
          label: faker.lorem.word(),
          value: faker.datatype.uuid()
        }));

      const selectedFilters = faker.helpers
        .arrayElements(data)
        .map((item) => item.id);

      renderPriceFilter({
        ...defaultProps,
        data,
        selectedFilters
      });

      const chips = screen
        .getAllByTestId(ChipTestIds.chip)
        .filter((el) => el.getAttribute('aria-checked') === 'true');

      expect(chips.length).toStrictEqual(selectedFilters.length);
    });
  });
});
