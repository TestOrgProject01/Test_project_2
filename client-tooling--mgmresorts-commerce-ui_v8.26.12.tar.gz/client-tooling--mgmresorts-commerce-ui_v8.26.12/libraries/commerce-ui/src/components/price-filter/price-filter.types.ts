import { ChipProps } from '../chip';

/**
 * @public
 */
export interface PriceFilterProps {
  /**
   * The data for the chips in the PriceFilter component.
   */
  data?: ChipProps[];
  /**
   * The currently selected chip in the PriceFilter component.
   */
  value?: ChipProps;
  /**
   * A callback function that is called when the selected chip in the PriceFilter component changes.
   * The function receives the new selected chip as a parameter.
   * It can optionally return a Promise that resolves when the change is complete.
   */
  onChange?: (value: ChipProps) => Promise<void> | void;
  /**
   * A helper label to provide additional information or instructions for the PriceFilter component.
   */

  helperLabel?: string;
  /**
   * Applied filters, these values prevent to render the filter with no selected values.
   * Also, it's allows rendering pre-selected filters.
   */
  selectedFilters?: string[];
}
