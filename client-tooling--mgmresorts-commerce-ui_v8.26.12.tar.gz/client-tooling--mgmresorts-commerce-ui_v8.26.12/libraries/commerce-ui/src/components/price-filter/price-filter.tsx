import React, { MutableRefObject, useCallback, useRef } from 'react';

import { useDraggable } from 'react-use-draggable-scroll';

import { useScrollToSelected } from '../../util/use-scroll-to-selection';

import { Chip, ChipProps } from '../chip';

import { PriceFilterProps } from './price-filter.types';

const componentId = 'PriceFilter';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const PriceFilterTestIds = {
  component: componentId
};

/**
 * @public
 */
export const PriceFilter = ({
  data,
  value,
  onChange,
  helperLabel,
  selectedFilters
}: PriceFilterProps) => {
  const ref = useRef<HTMLDivElement>(null);

  const draggableProps = useDraggable(ref as MutableRefObject<HTMLDivElement>, {
    applyRubberBandEffect: true
  });

  useScrollToSelected(ref, value, data);

  const handleChange = useCallback(
    async (newValue: ChipProps) => {
      if (onChange && typeof onChange === 'function') await onChange(newValue);
    },
    [onChange]
  );

  return (
    <div
      {...draggableProps.events}
      data-testid={PriceFilterTestIds.component}
      className="flex flex-col gap-2"
    >
      <div
        ref={ref}
        className="overflow-x-scroll flex gap-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
      >
        {data?.map((eventData) => (
          <Chip
            {...eventData}
            key={`eventinfo-${eventData.id}`}
            selected={selectedFilters?.includes(eventData.id)}
            onClick={async () => {
              await handleChange(eventData);
            }}
            buttonProps={{
              'aria-checked': !!selectedFilters?.includes(eventData.id),
              role: 'checkbox'
            }}
            size="small"
          />
        ))}
      </div>
      {helperLabel && (
        <div className="text-body-regular-s text-gray-600">{helperLabel}</div>
      )}
    </div>
  );
};
