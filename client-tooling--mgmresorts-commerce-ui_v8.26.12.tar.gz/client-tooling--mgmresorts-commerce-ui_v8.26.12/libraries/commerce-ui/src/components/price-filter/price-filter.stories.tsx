import React, { useCallback, useState } from 'react';

import { Meta } from '@storybook/react';

import { ChipProps } from '../chip';

import { PriceFilter } from './price-filter';
import { PriceFilterProps } from './price-filter.types';

export default {
  argTypes: {
    onChange: { action: 'changed' }
  },
  component: PriceFilter,
  title: 'Components/PriceFilter'
} as Meta<typeof PriceFilter>;

export const Default = (args: PriceFilterProps) => {
  const [value, setValue] = useState<ChipProps>();
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  const checkSelectedFilters = useCallback(
    (newValue) => {
      if (selectedFilters.includes(newValue.id)) {
        setSelectedFilters(
          selectedFilters.filter((filter) => filter !== newValue.id)
        );

        return;
      }

      setSelectedFilters([...selectedFilters, newValue.id]);
    },
    [selectedFilters, setSelectedFilters]
  );

  return (
    <PriceFilter
      {...args}
      value={value}
      onChange={async (newValue) => {
        setValue(newValue);
        checkSelectedFilters(newValue);
        await args?.onChange?.(newValue);
      }}
      selectedFilters={selectedFilters}
    />
  );
};

Default.args = {
  data: [
    {
      id: 'blue-seat',
      label: (
        <div className="flex gap-1 items-center">
          <span className="text-label-regular-s">Blue Seat:</span>
          <span className="text-label-regular-s text-gray-600">
            +$0 per seat*
          </span>
        </div>
      ),
      seatColor: 'blue',
      secondaryLabel: '+$0 per seat*'
    },
    {
      id: 'vip-seat',
      label: (
        <div className="flex gap-1 items-center">
          <span className="text-label-regular-s">VIP:</span>
          <span className="text-label-regular-s text-gray-600">
            +$50 per seat*
          </span>
        </div>
      ),
      seatColor: 'purple'
    },
    {
      id: 'banquet-seat',
      label: (
        <div className="flex gap-1 items-center">
          <span className="text-label-regular-s">Banquet:</span>
          <span className="text-label-regular-s text-gray-600">
            +$200 per seat*
          </span>
        </div>
      ),
      seatColor: 'yellow'
    }
  ],
  helperLabel: '*Additional charges apply for extra seats'
};
