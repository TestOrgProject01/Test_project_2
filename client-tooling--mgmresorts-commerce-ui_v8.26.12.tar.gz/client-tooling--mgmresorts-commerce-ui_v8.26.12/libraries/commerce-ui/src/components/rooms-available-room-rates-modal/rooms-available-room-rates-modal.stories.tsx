import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsAvailableRoomRatesModal } from './rooms-available-room-rates-modal';

export default {
  argTypes: {},
  component: RoomsAvailableRoomRatesModal,
  parameters: {
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/RoomsAvailableRoomRatesModal'
} as Meta<typeof RoomsAvailableRoomRatesModal>;

const Template: StoryFn<typeof RoomsAvailableRoomRatesModal> = (args) => {
  return (
    <div>
      <RoomsAvailableRoomRatesModal {...args} />
    </div>
  );
};

export const Mobile = Template.bind({});

Mobile.args = {
  apply: { label: 'Apply' },
  defaultSelectedOfferId: '1',
  moreDetails: { label: 'More details' },
  offers: [
    {
      averagePrice: '$100 average room rate',
      description: `Enjoy up to 2 Complimentary Nights in a Luxurious Resort Room with $30 in FREEPLAY® and $50 in MGM Rewards Resort Credit. Book your getaway online now or contact your Bellagio Marketing Executive or MGM Rewards VIP Services at 888.987.7887.

**FREEPLAY® valid on first trip only. Must maintain historical play level to redeem on subsequent trips.**`,
      id: '1',
      name: 'Your MGM Reward offer!',
      resortFee: '+$45 daily resort fee',
      subtotal: '$145 average per night'
    },
    {
      averagePrice: '$319 average room rate',
      description: `Guaranteed best rates`,
      id: '2',
      name: 'Flexible rate',
      resortFee: '+$50 daily resort fee',
      subtotal: '$369 average per night'
    },
    {
      averagePrice: 'Comp',
      description:
        'Treat yourself with $75 in food and beverage credit per night.',
      id: '3',
      name: '$75 daily with F&B benefits',
      resortFee: '+$45 daily resort fee',
      subtotal: '$45 average per night'
    },
    {
      averagePrice: undefined,
      description: 'This is a test offer with fully comp nights',
      id: '4',
      name: 'Fully comp nights',
      resortFee: undefined,
      subtotal: '**Comp**'
    },
    {
      averagePrice: undefined,
      description: `AAA Members enjoy up to 10% off our flexible rate.

AAA membership card must be presented at check-in.


Offer code: TAASB`,
      id: '5',
      name: 'SKYLOFTS AAA Member Discount',
      resortFee: undefined,
      subtotal: undefined
    }
  ],
  open: true,
  taxDisclaimer: 'Excludes taxes',
  title: 'Available room rates'
};

export const Desktop = Template.bind({});

Desktop.args = {
  apply: { label: 'Apply' },
  defaultSelectedOfferId: '1',
  moreDetails: { label: 'More details' },
  offers: [
    {
      averagePrice: '$100 average room rate',
      description: `Enjoy up to 2 Complimentary Nights in a Luxurious Resort Room with $30 in FREEPLAY® and $50 in MGM Rewards Resort Credit. Book your getaway online now or contact your Bellagio Marketing Executive or MGM Rewards VIP Services at 888.987.7887.

**FREEPLAY® valid on first trip only. Must maintain historical play level to redeem on subsequent trips.**`,
      id: '1',
      name: 'Your MGM Reward offer!',
      resortFee: '+$45 daily resort fee',
      subtotal: '$145 average per night'
    },
    {
      averagePrice: '$319 average room rate',
      description: `Guaranteed best rates`,
      id: '2',
      name: 'Flexible rate',
      resortFee: '+$50 daily resort fee',
      subtotal: '$369 average per night'
    },
    {
      averagePrice: 'Comp',
      description:
        'Treat yourself with $75 in food and beverage credit per night.',
      id: '3',
      name: '$75 daily with F&B benefits',
      resortFee: '+$45 daily resort fee',
      subtotal: '$45 average per night'
    },
    {
      averagePrice: undefined,
      description: 'This is a test offer with fully comp nights',
      id: '4',
      name: 'Fully comp nights',
      resortFee: undefined,
      subtotal: '**Comp**'
    },
    {
      averagePrice: undefined,
      description: `AAA Members enjoy up to 10% off our flexible rate. AAA membership card must be presented at check-in.
<br />
Offer code: TAASB`,
      id: '5',
      name: 'SKYLOFTS AAA Member Discount',
      resortFee: undefined,
      subtotal: undefined
    }
  ],
  open: true,
  taxDisclaimer: 'Excludes taxes',
  title: 'Available room rates'
};

Desktop.parameters = {
  viewport: { defaultViewport: 'lg' }
};
