/**
 * @public
 */
export interface RoomsAvailableRoomRatesModalProps {
  title: string;
  titleDataCMS?: string;
  defaultSelectedOfferId?: string;
  offers: {
    id: string;
    name: string;
    description: string;
    averagePrice: string | undefined;
    averagePriceDataCMS?: string;
    resortFee: string | undefined;
    resortFeeDataCMS?: string;
    subtotal: string | undefined;
    subtotalDataCMS?: string;
  }[];
  moreDetails: {
    'data-cms'?: string;
    label: string;
    onClick?: (id: string) => string;
  };
  taxDisclaimer: string;
  taxDisclaimerDataCMS?: string;
  apply: {
    'data-cms'?: string;
    label: string;
    onClick?: (id: string) => void;
  };
  open: boolean;
  onClose?: () => void;
}
