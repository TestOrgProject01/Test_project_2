import React, { useCallback, useEffect, useMemo, useState } from 'react';

import {
  Button,
  CenterModal,
  FullScreenModal,
  TextLink,
  Typography,
  Radio
} from '@mgmresorts/mgm-ui';
import clsx from 'clsx';
import { nanoid } from 'nanoid';
import { nop } from 'rambdax';

import { useMediaQuery } from '../../util';
import { userPressedEnterOrSpace } from '../../util/rooms-dropdown';

import { RoomsMarkdown } from '../rooms-markdown';

import type { RoomsAvailableRoomRatesModalProps } from './rooms-available-room-rates-modal.types';

/**
 * @public
 */
export const RoomsAvailableRoomRatesModal = (
  props: RoomsAvailableRoomRatesModalProps
) => {
  const isSmallTablet = useMediaQuery('(min-width: 768px)');
  const isLargeTablet = useMediaQuery('(min-width: 1024px)');
  const isDesktop = useMediaQuery('(min-width: 1440px)');

  const [offerId, setOfferId] = useState(props.defaultSelectedOfferId ?? '');

  const onApplyClick = useCallback(() => {
    if (offerId === '') return;

    const onClick = props.apply.onClick;
    if (onClick === undefined) return;

    onClick(offerId);
  }, [offerId, props.apply.onClick]);

  const onMoreDetailsClick: React.MouseEventHandler<HTMLAnchorElement> = useCallback(
    (event) => {
      const offerId = event.currentTarget.dataset.offerId;
      if (offerId === undefined) return;

      const onClick = props.moreDetails.onClick;
      if (onClick === undefined) return;

      onClick(offerId);
    },
    [props.moreDetails.onClick]
  );

  useEffect(() => {
    if (!props.open) return;
    setOfferId(props.defaultSelectedOfferId ?? '');
  }, [props.defaultSelectedOfferId, props.open]);

  const offerUniqueIds = useMemo(() => {
    return props.offers.map(() => `rate-id-${nanoid()}`);
  }, [props.offers]);

  const children = (
    <div className="flex flex-col items-center self-stretch">
      <div className="flex flex-col items-start gap-4 self-stretch">
        {props.offers.map((o, index) => {
          const isPricingAvailable = !!(
            (o.averagePrice ?? false) ||
            (o.resortFee ?? false) ||
            (o.subtotal ?? false)
          );

          return (
            <div
              key={o.id}
              className="flex p-2x flex-col items-start gap-4 self-stretch rounded-lg bg-white"
            >
              <div
                className="flex w-full justify-between items-center gap-4 cursor-pointer [&_div[variant=large]:nth-child(2)]:self-start"
                onClick={() => {
                  setOfferId(o.id);
                }}
              >
                <Radio
                  label={
                    <Typography
                      variant="body-medium-l"
                      className="text-digital-900 line-clamp-2"
                    >
                      {o.name}
                    </Typography>
                  }
                  labelPosition={'left'}
                  fullWidth={true}
                  id={offerUniqueIds[index]}
                  variant={'large'}
                  checked={o.id === offerId}
                  onChange={() => {
                    setOfferId(o.id);
                  }}
                  value={o.id}
                  disabled={false}
                  onKeyDown={(e) => {
                    if (o.id !== offerId && userPressedEnterOrSpace(e)) {
                      setOfferId(o.id);
                    }
                  }}
                  data-testid={`input.offer.${o.id}`}
                  className="focus-visible:!outline-offset-[0px] focus-visible:!outline-[0px]"
                />
              </div>

              <RoomsMarkdown
                removePTag={false}
                strictMode={true}
                className="text-body-regular-s flex flex-col items-start gap-2 self-stretch text-digital-900 [&_a]:!outline-none"
              >
                {o.description}
              </RoomsMarkdown>

              {/* PRICING */}
              {isPricingAvailable && (
                <div className="flex flex-col items-start self-stretch">
                  {o.averagePrice !== undefined && (
                    <Typography
                      variant="body-regular-s"
                      className="text-gray-600 min-h-[21px]"
                      data-cms={o.averagePriceDataCMS}
                    >
                      <RoomsMarkdown strictMode={true}>
                        {o.averagePrice}
                      </RoomsMarkdown>
                    </Typography>
                  )}

                  {o.resortFee !== undefined && (
                    <Typography
                      variant="body-regular-s"
                      className="text-gray-600 min-h-[21px]"
                      data-cms={o.resortFeeDataCMS}
                    >
                      <RoomsMarkdown strictMode={true}>
                        {o.resortFee}
                      </RoomsMarkdown>
                    </Typography>
                  )}

                  {o.subtotal !== undefined && (
                    <Typography
                      variant="body-medium-s"
                      className="text-digital-900 min-h-[21px]"
                      data-cms={o.subtotalDataCMS}
                    >
                      <RoomsMarkdown strictMode={true}>
                        {o.subtotal}
                      </RoomsMarkdown>
                    </Typography>
                  )}
                </div>
              )}

              {/* TAX DISCLAIMER */}
              <div className={clsx('flex items-start gap-4 self-stretch')}>
                {isPricingAvailable && (
                  <Typography
                    variant="body-regular-s"
                    className="text-digital-900"
                    data-cms={props.taxDisclaimerDataCMS}
                  >
                    {props.taxDisclaimer}
                  </Typography>
                )}

                <Typography
                  variant="body-regular-s"
                  className="flex justify-end items-center gap-1 flex-1 leading-[20px]"
                  data-cms={props.moreDetails['data-cms']}
                >
                  <TextLink
                    onClick={onMoreDetailsClick}
                    variant="large"
                    className="!leading-5 !p-[0] !text-body-regular-s !outline-none"
                    data-offer-id={o.id}
                    data-testid={`link.offer.${o.id}`}
                    button={true}
                  >
                    {props.moreDetails.label}
                  </TextLink>
                </Typography>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const actions = (fullWidth?: boolean) => (
    <div className={clsx('w-full flex justify-end m-lg:pt-2x')}>
      <Button
        label={props.apply.label}
        data-cms={props.apply['data-cms']}
        onClick={onApplyClick}
        fullWidth={fullWidth}
        variant="primary"
        size="large"
        disabled={offerId === ''}
      />
    </div>
  );

  if (isSmallTablet || isLargeTablet || isDesktop) {
    return (
      <CenterModal
        open={props.open}
        onClose={props.onClose ?? nop}
        title={<span data-cms={props.titleDataCMS}>{props.title}</span>}
        actions={actions()}
        size={isDesktop ? 'large' : isLargeTablet ? 'medium' : 'small'}
      >
        {children}
      </CenterModal>
    );
  }

  return (
    <FullScreenModal
      open={props.open}
      onClose={props.onClose ?? nop}
      title={<span data-cms={props.titleDataCMS}>{props.title}</span>}
      actions={actions(true)}
    >
      {children}
    </FullScreenModal>
  );
};
