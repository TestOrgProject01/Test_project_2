import React from 'react';

import { screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import {
  axe,
  createWithDesignTokensProvider,
  renderToHtmlWithDesignTokensProvider
} from '../../util/test-utils';

import { RoomsAvailableRoomRatesModal } from './rooms-available-room-rates-modal';
import { RoomsAvailableRoomRatesModalProps } from './rooms-available-room-rates-modal.types';

describe('<RoomsAvailableRoomRatesModal/> component', () => {
  const renderComponent = (props: RoomsAvailableRoomRatesModalProps) =>
    createWithDesignTokensProvider(<RoomsAvailableRoomRatesModal {...props} />);

  const renderHTML = (props: RoomsAvailableRoomRatesModalProps) =>
    renderToHtmlWithDesignTokensProvider(
      <RoomsAvailableRoomRatesModal {...props} />
    );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderComponent({
        apply: { label: 'apply.label' },
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        open: true,
        taxDisclaimer: 'taxDisclaimer',
        title: 'title'
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('custom labels', () => {
      renderComponent({
        apply: { label: 'apply.label' },
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        open: true,
        taxDisclaimer: 'taxDisclaimer',
        title: 'title'
      });

      screen.getByText('apply.label');
      screen.getByText('moreDetails.label');
      screen.getByText('offer.1.averagePrice');
      screen.getByText('offer.1.description');
      screen.getByText('offer.1.name');
      screen.getByText('offer.1.resortFee');
      screen.getByText('offer.1.subtotalt');
    });
  });

  /**
   * Actions tests.
   */
  describe('actions', () => {
    it('onApplyClick', () => {
      const onApplyClick = jest.fn();

      renderComponent({
        apply: { label: 'apply.label', onClick: onApplyClick },
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        open: true,
        taxDisclaimer: 'taxDisclaimer',
        title: 'title'
      });

      const applyButton = screen.getByText('apply.label');
      expect(applyButton).toBeDisabled();

      const input = screen.getByTestId('input.offer.1');
      fireEvent.click(input);

      expect(applyButton).toBeEnabled();

      fireEvent.click(applyButton);
      expect(onApplyClick).toHaveBeenCalledWith('1');
    });

    it('onMoreDetailsClick', () => {
      const onMoreDetailsClick = jest.fn();

      renderComponent({
        apply: { label: 'apply.label' },
        moreDetails: {
          label: 'moreDetails.label',
          onClick: onMoreDetailsClick
        },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        open: true,
        taxDisclaimer: 'taxDisclaimer',
        title: 'title'
      });

      const input = screen.getByTestId('link.offer.1');
      fireEvent.click(input);

      expect(onMoreDetailsClick).toHaveBeenCalledWith('1');
    });
  });

  /**
   * Accessibility tests
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderHTML({
        apply: { label: 'apply.label' },
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        open: true,
        taxDisclaimer: 'taxDisclaimer',
        title: 'title'
      });

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
