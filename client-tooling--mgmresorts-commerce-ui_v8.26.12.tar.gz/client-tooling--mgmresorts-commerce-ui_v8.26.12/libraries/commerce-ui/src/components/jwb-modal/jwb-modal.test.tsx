import React from 'react';

import { screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import {
  axe,
  createWithDesignTokensProvider,
  renderToHtmlWithDesignTokensProvider
} from '../../util/test-utils';

import { JWBModal } from './jwb-modal';
import { JWBModalProps } from './jwb-modal.types';

describe('<JWBModal/> component', () => {
  const renderComponent = (props: JWBModalProps) =>
    createWithDesignTokensProvider(<JWBModal {...props} />);

  const renderHTML = (props: JWBModalProps) =>
    renderToHtmlWithDesignTokensProvider(<JWBModal {...props} />);

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderComponent({
        alreadyMemberLink: {
          href: 'alreadyMemberLink.href',
          label: 'alreadyMemberLink.label'
        },
        description: 'description',
        email: {
          errors: {
            invalid: 'errors.email',
            maxLength: 'errors.maxLenght',
            minLength: 'errors.minLength'
          },
          placeholder: 'email.placeholder'
        },
        hint: 'hint',
        logoImage: { alt: 'alt', url: 'url' },
        noThanksButton: {
          'data-cms': 'noThanksButton.data-cms',
          label: 'No thanks',
          onClick: jest.fn()
        },
        open: true,
        title: 'title',
        unlockButton: { label: 'unlockButton.label' }
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('custom labels', () => {
      renderComponent({
        alreadyMemberLink: {
          href: 'alreadyMemberLink.href',
          label: 'alreadyMemberLink.label'
        },
        description: 'description',
        email: {
          errors: {
            invalid: 'errors.email',
            maxLength: 'errors.maxLenght',
            minLength: 'errors.minLength'
          },
          placeholder: 'email.placeholder'
        },
        hint: 'hint',
        logoImage: { alt: 'alt', url: 'url' },
        noThanksButton: {
          'data-cms': 'noThanksButton.data-cms',
          label: 'No thanks',
          onClick: jest.fn()
        },
        open: true,
        title: 'title',
        unlockButton: { label: 'unlockButton.label' }
      });

      screen.getByText('alreadyMemberLink.label');
      screen.getByText('description');
      screen.getByText('hint');
      screen.getByText('title');
      screen.getByText('unlockButton.label');
    });
  });

  /**
   * Actions tests.
   */
  describe('actions', () => {
    it('onUnlockButtonClick', () => {
      const onUnlockButtonClick = jest.fn();

      const noThanksButtonHandler = jest.fn();

      renderComponent({
        alreadyMemberLink: {
          href: 'alreadyMemberLink.href',
          label: 'alreadyMemberLink.label'
        },
        description: 'description',
        email: {
          errors: {
            invalid: 'errors.email',
            maxLength: 'errors.maxLenght',
            minLength: 'errors.minLength'
          },
          placeholder: 'email.placeholder'
        },
        hint: 'hint',
        logoImage: { alt: 'alt', url: 'url' },
        noThanksButton: {
          'data-cms': 'noThanksButton.data-cms',
          label: 'No thanks',
          onClick: noThanksButtonHandler
        },
        open: true,
        title: 'title',
        unlockButton: {
          label: 'unlockButton.label',
          onClick: onUnlockButtonClick
        }
      });

      fireEvent.change(screen.getByTestId('JWBModal.email'), {
        target: { value: 'test@test.com' }
      });

      fireEvent.click(screen.getByText('unlockButton.label'));
      expect(onUnlockButtonClick).toHaveBeenCalledTimes(1);

      fireEvent.click(screen.getByText('No thanks'));
      expect(noThanksButtonHandler).toHaveBeenCalledTimes(1);
    });
  });

  /**
   * Accessibility tests
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderHTML({
        alreadyMemberLink: {
          href: 'alreadyMemberLink.href',
          label: 'alreadyMemberLink.label'
        },
        'data-modal-title': 'title',
        description: 'description',
        email: {
          errors: {
            invalid: 'errors.email',
            maxLength: 'errors.maxLenght',
            minLength: 'errors.minLength'
          },
          placeholder: 'email.placeholder'
        },
        hint: 'hint',
        logoImage: { alt: 'alt', url: 'url' },
        noThanksButton: {
          'data-cms': 'noThanksButton.data-cms',
          label: 'No thanks',
          onClick: jest.fn()
        },
        open: true,
        title: 'title',
        unlockButton: { label: 'unlockButton.label' }
      });

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
