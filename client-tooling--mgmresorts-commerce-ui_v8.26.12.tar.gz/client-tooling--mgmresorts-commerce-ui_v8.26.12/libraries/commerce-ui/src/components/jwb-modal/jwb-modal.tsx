import React, { useCallback, useMemo, useState } from 'react';

import {
  Button,
  FullScreenModal,
  Image,
  TextInput,
  TextLink,
  Typography
} from '@mgmresorts/mgm-ui';
import clsx from 'clsx';
import { nop } from 'rambdax';

import { useMediaQuery } from '../../util';

import { Rewards } from './jwb-modal.rewards';
import { JWBModalProps } from './jwb-modal.types';

/**
 * @public
 */
export const emailRegExp = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

/**
 * @public
 */
export const JWBModal = (props: JWBModalProps) => {
  const isDesktop = useMediaQuery('(min-width: 768px)');

  const [email, setEmail] = useState('');

  const onChange: React.ChangeEventHandler<HTMLInputElement> = useCallback(
    (event) => setEmail(event.target.value),
    []
  );

  const onClick = useCallback(() => {
    const onUnlockClick = props.unlockButton.onClick;
    if (onUnlockClick === undefined) return;
    onUnlockClick(email);
  }, [email, props.unlockButton.onClick]);

  const disabled = useMemo(
    () => email.length <= 0 || email.length > 100 || !emailRegExp.test(email),
    [email]
  );

  const alreadyMemberLinkOnClick = useCallback(() => {
    const onClick = props.alreadyMemberLink.onClick;
    onClick?.();

    return false;
  }, [props.alreadyMemberLink.onClick]);

  const error = useMemo(() => {
    if (email.length <= 0) return props.email.errors.minLength;
    if (email.length > 100) return props.email.errors.maxLength;
    if (!emailRegExp.test(email)) return props.email.errors.invalid;

    return undefined;
  }, [
    email,
    props.email.errors.invalid,
    props.email.errors.maxLength,
    props.email.errors.minLength
  ]);

  return (
    <FullScreenModal
      open={props.open}
      onClose={props.onClose ?? nop}
      title={props['data-modal-title']}
    >
      <div
        className={clsx('flex flex-col justify-center items-center gap-8', {
          'flex-auto mx-auto max-w-[432px] min-h-full': isDesktop,
          'p-2x': !isDesktop
        })}
      >
        {/* TITLE */}
        <div className="flex flex-col justify-center items-center gap-2 self-stretch">
          {/* LOGO */}
          <Image
            className="!w-[82px] !h-[30px] flex items-center justify-center"
            src={props.logoImage.url}
            alt={props.logoImage.alt}
            lazyLoading={true}
          />

          {/* TITLE */}
          <Typography
            variant="heading-medium-3"
            className="text-digital-900 text-center"
            as="h1"
            data-cms={props.titleDataCMS}
          >
            {props.title}
          </Typography>
        </div>

        {/* REWARDS */}
        <Rewards />

        {/* BODY */}
        <div className="flex flex-col justify-center items-center gap-8 self-stretch">
          {/* DESCRIPTION */}
          <Typography
            variant="body-regular-m"
            className="self-stretch text-digital-900"
            data-cms={props.descriptionDataCMS}
          >
            {props.description}
          </Typography>

          {/* FORM */}
          <div className="flex flex-col justify-center items-center gap-4 self-stretch">
            <div className="flex flex-col justify-center items-center gap-4 self-stretch">
              <div className="flex flex-col items-start gap-2 self-stretch">
                <TextInput
                  variant="default"
                  aria-label="Email"
                  data-testid="JWBModal.email"
                  type="text"
                  label={props.email.placeholder}
                  name="email"
                  value={email}
                  onChange={onChange}
                  hint={error}
                  error={!!error}
                  className="focus-visible:!outline-none"
                />
              </div>
            </div>

            <Button
              data-cms={props.unlockButton['data-cms']}
              fullWidth={true}
              label={props.unlockButton.label}
              onClick={onClick}
              size="large"
              variant="primary"
              disabled={disabled}
              className="focus-visible:!outline focus-visible:!outline-[1.5px] focus-visible:!outline-offset-[2px] focus-visible:!outline-[#292cb7]"
            />
            <Button
              data-cms={props.noThanksButton['data-cms']}
              fullWidth={true}
              label={props.noThanksButton.label}
              onClick={props.noThanksButton.onClick}
              size="large"
              variant="secondary"
              className="focus-visible:!outline focus-visible:!outline-[1.5px] focus-visible:!outline-offset-[2px] focus-visible:!outline-[#292cb7]"
            />
          </div>

          {/* LINK */}
          <div className="flex justify-center items-center gap-1 self-stretch">
            <Typography variant="body-regular-m">
              <TextLink
                variant="large"
                className="!leading-6 !p-[0] !text-body-regular-m !outline-none"
                onClick={alreadyMemberLinkOnClick}
                data-cms={props.alreadyMemberLink['data-cms']}
                button={true}
                href={props.alreadyMemberLink.href}
              >
                {props.alreadyMemberLink.label}
              </TextLink>
            </Typography>
          </div>
        </div>

        {/* FOOTER */}
        <div className="flex items-start gap-[10px] self-stretch">
          <Typography
            variant="body-regular-s"
            className="flex-grow text-gray-600"
            data-cms={props.hintDataCMS}
          >
            {props.hint}
          </Typography>
        </div>
      </div>
    </FullScreenModal>
  );
};
