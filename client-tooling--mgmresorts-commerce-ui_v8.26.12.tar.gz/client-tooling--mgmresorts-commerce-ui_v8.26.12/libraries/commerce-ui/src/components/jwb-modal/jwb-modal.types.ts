/**
 * @public
 */
export interface JWBModalProps {
  open: boolean;
  title: string;
  titleDataCMS?: string;
  description: string;
  descriptionDataCMS?: string;
  hint: string;
  hintDataCMS?: string;
  email: {
    placeholder: string;
    errors: Partial<{
      invalid: string;
      invalidDataCMS?: string;
      maxLength: string;
      maxLengthDataCMS?: string;
      minLength: string;
      minLengthDataCMS?: string;
    }>;
  };
  unlockButton: {
    'data-cms'?: string;
    label: string;
    onClick?: (email: string) => void;
  };
  alreadyMemberLink: {
    'data-cms'?: string;
    label: string;
    onClick?: () => void;
    href?: string;
  };
  noThanksButton: {
    'data-cms': string;
    label: string;
    onClick: () => void;
  };
  onClose?: () => void;
  logoImage: { url: string; alt: string };
  'data-modal-title'?: string;
}
