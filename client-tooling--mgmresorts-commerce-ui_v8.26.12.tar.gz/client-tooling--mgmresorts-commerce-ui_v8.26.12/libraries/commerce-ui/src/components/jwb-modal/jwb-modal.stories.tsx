import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { JWBModal } from './jwb-modal';

export default {
  argTypes: {},
  component: JWBModal,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/JWBModal'
} as Meta<typeof JWBModal>;

const Template: StoryFn<typeof JWBModal> = (args) => (
  <div>
    <JWBModal {...args} />
  </div>
);

export const Mobile = Template.bind({});

Mobile.args = {
  alreadyMemberLink: {
    href: '#',
    label: 'Already a member? Sign in'
  },
  description:
    'Unlock special room rates, exclusive access, and incredible perks with a free MGM Rewards membership. Enter your email to see what you’ll save.',
  email: {
    errors: { invalid: 'Invalid email', maxLength: 'Invalid email' },
    placeholder: 'Email address'
  },
  hint:
    'Providing your email address unlocks MGM Rewards discounts. We will only email you if you complete your purchase.',
  logoImage: {
    alt: 'the mgm logo',
    url:
      'https://www.mgmresorts.com/identity/static/media/mgm-resorts.bbd080f916381c304dc48f866f21c774.svg'
  },
  noThanksButton: {
    label: 'No thanks'
  },
  open: true,
  title: 'Save up to 15%',
  unlockButton: { label: 'Unlock' }
};

export const Desktop = Template.bind({});

Desktop.args = {
  alreadyMemberLink: {
    href: '#',
    label: 'Already a member? Sign in'
  },
  description:
    'Unlock special room rates, exclusive access, and incredible perks with a free MGM Rewards membership. Enter your email to see what you’ll save.',
  email: {
    errors: { invalid: 'Invalid email', maxLength: 'Invalid email' },
    placeholder: 'Email address'
  },
  hint:
    'Providing your email address unlocks MGM Rewards discounts. We will only email you if you complete your purchase.',
  logoImage: {
    alt: 'the mgm logo',
    url:
      'https://www.mgmresorts.com/identity/static/media/mgm-resorts.bbd080f916381c304dc48f866f21c774.svg'
  },
  noThanksButton: {
    label: 'No thanks'
  },
  open: true,
  title: 'Save up to 15%',
  unlockButton: { label: 'Unlock' }
};

Desktop.parameters = {
  viewport: { defaultViewport: 'lg' }
};
