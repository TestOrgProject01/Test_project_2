import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo
} from 'react';

import './amenities-list.css';
import clsx from 'clsx';
import { nanoid } from 'nanoid';

import { Button } from '../button';
import { Icon } from '../icon';
import { AmenitiesListInfo } from '../resort-details';

const renderBulletText = (text: string, i: number) => (
  <li className="amenities-list__item-wrapper" key={`${text}-${i}`}>
    <span className="amenities-list__bullet-text">{text}</span>
  </li>
);

export interface AmenitiesListProps {
  list: AmenitiesListInfo;
}

const defaultProps = {
  initialItemsLimit: 8
};

/**
 * [Documentation](https://mgmdigitalventures.atlassian.net/wiki/spaces/KB/pages/112525716/Amenities+List)
 */
export const AmenitiesList = (props: AmenitiesListProps) => {
  const [collapsed, setCollapsed] = useState(true);
  const expandableWrapperRef = useRef<HTMLUListElement>(null);
  const expanderId = useMemo(() => `amenities-list-expander-${nanoid()}`, []);

  const list = {
    ...defaultProps,
    ...props.list
  };

  useEffect(() => {
    if (!expandableWrapperRef.current) return;

    if (!collapsed) {
      expandableWrapperRef.current.focus();
      expandableWrapperRef.current.style.maxHeight = `${expandableWrapperRef.current.scrollHeight}px`;
    }
  }, [collapsed]);

  const onClick = useCallback(() => {
    if (!expandableWrapperRef.current) return;

    if (collapsed) {
      setCollapsed(false);

      return;
    }

    expandableWrapperRef.current.style.maxHeight = `0px`;
    setTimeout(() => setCollapsed(true), 300);
  }, [collapsed]);

  return (
    <>
      {list.variant === 'icon-list' && (
        <ul className="amenities-list__wrapper">
          {
            // limit number of icon-amenities to 5
            list.icons.slice(0, 5).map(({ icon, title }, i) => (
              <li className="amenities-list__item-wrapper" key={i}>
                <div className="amenities-list__icon-wrapper">
                  <img aria-hidden src={icon} />
                </div>
                <span className="amenities-list__icon-text">{title}</span>
              </li>
            ))
          }
        </ul>
      )}
      {list.variant === 'bullet-list' && (
        <div className="amenities-list__wrapper">
          <ul>
            {list.items.slice(0, list.initialItemsLimit).map(renderBulletText)}
          </ul>

          {list.items.length > list.initialItemsLimit && (
            <div>
              <ul
                className={clsx('amenities-list__expandable-wrapper', {
                  'amenities-list__expandable-wrapper--expanded': !collapsed
                })}
                ref={expandableWrapperRef}
                id={expanderId}
              >
                {list.items.slice(list.initialItemsLimit).map(renderBulletText)}
              </ul>
              <div className="amenities-list__hr" />
              <div className="amenities-list__expand-button-wrapper">
                <Button
                  onClick={onClick}
                  buttonProps={{
                    'aria-controls': expanderId,
                    'aria-expanded': !collapsed
                  }}
                  label={
                    collapsed ? (
                      <>
                        {list.expandLabel}{' '}
                        <Icon
                          name="chevron-down"
                          size="small"
                          variant="filled"
                        />
                      </>
                    ) : (
                      <>
                        {list.collapseLabel?.replace(
                          '{count}',
                          (
                            list.items.length - list.initialItemsLimit
                          ).toString()
                        ) ?? ''}
                        <Icon name="chevron-up" size="small" variant="filled" />
                      </>
                    )
                  }
                  variant="tertiary"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};

AmenitiesList.defaultProps = defaultProps;
