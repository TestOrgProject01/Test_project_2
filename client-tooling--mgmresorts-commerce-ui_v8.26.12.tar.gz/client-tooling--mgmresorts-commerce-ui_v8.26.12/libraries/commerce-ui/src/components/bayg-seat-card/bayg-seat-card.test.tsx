import React from 'react';

import { faker } from '@faker-js/faker';
import { fireEvent, render, screen } from '@testing-library/react';

import { BaygSeatCard, TestIds as BaygSeatCardTestsId } from './bayg-seat-card';
import {
  BaygSeatCardCarousel,
  TestIds as BaygSeatCardCarouselTestsId
} from './bayg-seat-card-carousel';
import {
  getRandomRequiredProps,
  getRandomSeatsArray
} from './bayg-seat-card.mock';

describe('<BaygSeatCard /> component', () => {
  it('should render the card title correctly', () => {
    const randomProps = getRandomRequiredProps();

    render(<BaygSeatCard {...randomProps} />);

    expect(screen.getByTestId(BaygSeatCardTestsId.title).textContent).toBe(
      randomProps.title
    );
  });

  it('should render the card subtitle correctly', () => {
    const randomProps = getRandomRequiredProps();

    render(<BaygSeatCard {...randomProps} />);

    expect(screen.getByTestId(BaygSeatCardTestsId.subtitle).textContent).toBe(
      randomProps.subtitle
    );
  });

  it('should has the specified minWidth', () => {
    const randomMinWidth = faker.datatype.number({ max: 500, min: 100 });

    render(
      <BaygSeatCard {...getRandomRequiredProps()} minWidth={randomMinWidth} />
    );

    expect(screen.getByTestId(BaygSeatCardTestsId.component)).toHaveStyle({
      minWidth: `${randomMinWidth}px`
    });
  });

  it('should has the specified maxWidth', () => {
    const randomMaxWidth = faker.datatype.number({ max: 500, min: 100 });

    render(
      <BaygSeatCard {...getRandomRequiredProps()} maxWidth={randomMaxWidth} />
    );

    expect(screen.getByTestId(BaygSeatCardTestsId.component)).toHaveStyle({
      maxWidth: `${randomMaxWidth}px`
    });
  });

  it('should has the specified maxWidth', () => {
    const onCloseClickFn = jest.fn();

    render(
      <BaygSeatCard
        {...getRandomRequiredProps()}
        onCloseClick={onCloseClickFn}
      />
    );

    fireEvent.click(screen.getByTestId(BaygSeatCardTestsId.button));

    expect(onCloseClickFn).toHaveBeenCalled();
  });
});

describe('<BaygSeatCardCarousel />', () => {
  it('should render the carousel correctly', () => {
    const seats = getRandomSeatsArray();

    render(<BaygSeatCardCarousel {...{ seats }} />);

    expect(screen.getAllByTestId(BaygSeatCardTestsId.component)).toHaveLength(
      seats.length
    );
  });

  it('should trigger onCloseClick correctly when using carousel', () => {
    const seats = getRandomSeatsArray();

    const onCloseClick = jest.fn();

    render(<BaygSeatCardCarousel {...{ onCloseClick, seats }} />);

    fireEvent.click(screen.getAllByTestId(BaygSeatCardTestsId.button)[0]);

    expect(onCloseClick).toHaveBeenCalledWith(seats[0]);
  });

  it('should have the correctly classes', () => {
    const seats = getRandomSeatsArray();

    render(<BaygSeatCardCarousel {...{ seats }} />);

    const classNames =
      'w-full scroll-smooth flex overflow-x-auto whitespace-nowrap space-x-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]';

    expect(
      screen.getByTestId(BaygSeatCardCarouselTestsId.component)
    ).toHaveClass(classNames, { exact: true });
  });
});
