import React from 'react';

import { Meta } from '@storybook/react';

import { BaygSeatCard } from './bayg-seat-card';
import { storyDefaultMockProps } from './bayg-seat-card.mock';
import { BaygSeatCardProps } from './bayg-seat-card.types';

export default {
  argTypes: {
    onCloseClick: { action: 'clicked' }
  },
  component: BaygSeatCard,
  title: 'Components/BaygSeatCard'
} as Meta<typeof BaygSeatCard>;

export const Default = (args: BaygSeatCardProps) => <BaygSeatCard {...args} />;

Default.args = { ...storyDefaultMockProps };
