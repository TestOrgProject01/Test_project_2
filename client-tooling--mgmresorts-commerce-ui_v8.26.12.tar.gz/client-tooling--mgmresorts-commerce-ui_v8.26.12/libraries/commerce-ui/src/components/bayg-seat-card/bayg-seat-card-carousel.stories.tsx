import React from 'react';

import { Meta } from '@storybook/react';

import { BaygSeatCard } from './bayg-seat-card';
import { BaygSeatCardCarousel } from './bayg-seat-card-carousel';
import {
  storyCarouselMockProps,
  storyVerticalCarouselMockProps
} from './bayg-seat-card.mock';
import { BaygSeatCardCarouselProps } from './bayg-seat-card.types';

export default {
  argTypes: {
    onCloseClick: { action: 'clicked' }
  },
  component: BaygSeatCardCarousel,
  title: 'Components/BaygSeatCardCarousel'
} as Meta<typeof BaygSeatCardCarousel>;

export const Default = (args: BaygSeatCardCarouselProps) => (
  <BaygSeatCardCarousel {...args} />
);

Default.args = { ...storyCarouselMockProps };

export const CustomCardProps = (args: BaygSeatCardCarouselProps) => (
  <BaygSeatCardCarousel {...args} />
);

CustomCardProps.args = {
  ...storyCarouselMockProps,
  cardProps: { minWidth: 500 }
};

export const VerticalCarousel = ({
  seats,
  cardProps,
  onCloseClick
}: BaygSeatCardCarouselProps) => (
  <div className="flex text-left flex-col gap-4 overflow-y-auto no-scrollbar h-80 w-96">
    {seats.map((seat) => (
      <BaygSeatCard
        {...seat}
        {...cardProps}
        key={seat.id}
        onCloseClick={async () => {
          if (onCloseClick && typeof onCloseClick === 'function') {
            await onCloseClick(seat);
          }
        }}
      />
    ))}
  </div>
);

VerticalCarousel.args = { ...storyVerticalCarouselMockProps };
