import * as React from 'react';

import { BaygSeatCard } from './bayg-seat-card';
import { BaygSeatCardCarouselProps } from './bayg-seat-card.types';

const componentId = 'BaygSeatCardCarousel';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const TestIds = {
  component: componentId
};

/**
 * @public
 */
export const BaygSeatCardCarousel = ({
  seats,
  onCloseClick,
  cardProps
}: BaygSeatCardCarouselProps) => {
  return (
    <div
      data-testid={TestIds.component}
      className="w-full scroll-smooth flex overflow-x-auto whitespace-nowrap space-x-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
    >
      {seats.map((seat) => (
        <BaygSeatCard
          {...seat}
          {...cardProps}
          key={seat.id}
          onCloseClick={async () => {
            if (onCloseClick && typeof onCloseClick === 'function') {
              await onCloseClick(seat);
            }
          }}
        />
      ))}
    </div>
  );
};
