/**
 * @public
 */
export interface BaygSeatCardProps {
  maxWidth?: number;
  minWidth?: number;
  onCloseClick?: () => Promise<void> | void;
  subtitle?: string;
  title: string;
  isDisabled?: boolean;
}

/**
 * @public
 */
export type BaygSeatProps = Omit<BaygSeatCardProps, 'onCloseClick'> & {
  id: string;
  seatNumber: number;
};

/**
 * @public
 */
export interface BaygSeatCardCarouselProps {
  seats: BaygSeatProps[];
  onCloseClick?: (seat: BaygSeatProps) => Promise<void> | void;
  cardProps?: Partial<Omit<BaygSeatCardProps, 'onCloseClick'>>;
}
