import { faker } from '@faker-js/faker';

import {
  BaygSeatCardCarouselProps,
  BaygSeatCardProps,
  BaygSeatProps
} from './bayg-seat-card.types';

const titleList = [
  'Sec BTH2, Row TBL, Seat 1',
  'Sec 204, Row J, Seat 2',
  'Sec 204, Row J, Seat 3',
  'Sec 204, Row J, Seat 4',
  'Sec 204, Row J, Seat 5'
];

const subtitleList = ['+$200', '+$300', '+$400', '+$500'];

const getRandomItem = <T extends Array<any>>(items: T) =>
  items[Math.floor(Math.random() * items.length)];

export const getRandomRequiredProps = (): BaygSeatCardProps => ({
  subtitle: getRandomItem(subtitleList),
  title: getRandomItem(titleList)
});

export const getRandomSeatPropsCarousel = (): BaygSeatProps => ({
  ...getRandomRequiredProps(),
  id: faker.datatype.uuid(),
  seatNumber: parseInt(faker.random.numeric())
});

export const getRandomSeatVerticalPropsCarousel = (): BaygSeatProps => ({
  id: faker.datatype.uuid(),
  seatNumber: parseInt(faker.random.numeric()),
  title: getRandomItem(titleList)
});

export const getRandomSeatsArray = () =>
  new Array(faker.datatype.number({ max: 10, min: 1 }))
    .fill('')
    .map(getRandomSeatPropsCarousel);

export const getRandomSeatsVerticalArray = () =>
  new Array(faker.datatype.number({ max: 10, min: 1 }))
    .fill('')
    .map(getRandomSeatVerticalPropsCarousel);

const transparentProps: BaygSeatCardProps = {
  maxWidth: 250,
  subtitle: '+$600',
  title: 'Sec 204, Row J, Seat 4'
};

export const storyDefaultMockProps: BaygSeatCardProps = {
  ...transparentProps
};

export const storyCarouselMockProps: BaygSeatCardCarouselProps = {
  seats: getRandomSeatsArray()
};

export const storyVerticalCarouselMockProps: BaygSeatCardCarouselProps = {
  seats: getRandomSeatsVerticalArray()
};
