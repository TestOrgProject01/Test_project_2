import * as React from 'react';

import { Icon } from '../icon';

import { BaygSeatCardProps } from './bayg-seat-card.types';

const componentId = 'BaygSeatCard';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const TestIds = {
  button: `${componentId}:close-button`,
  component: componentId,
  subtitle: `${componentId}:subtitle`,
  title: `${componentId}:title`
};

/**
 * @public
 */
export const BaygSeatCard = ({
  title,
  subtitle,
  minWidth,
  maxWidth,
  onCloseClick,
  isDisabled
}: BaygSeatCardProps) => {
  const removeDelimiters = (input: string): string => {
    return input.replace(/[\s,]+/g, '');
  };

  const titleId = removeDelimiters(title);

  return (
    <div
      className="bg-white rounded-lg p-2x border-default border-gray-100 flex flex-col space-y-1"
      style={{
        maxWidth,
        minWidth
      }}
      data-testid={TestIds.component}
    >
      <div className="flex flex-row items-center justify-between">
        <span
          id={titleId}
          className="text-m font-sans text-digital-900 pr-2x"
          data-testid={TestIds.title}
        >
          {title}
        </span>
        <button
          onClick={onCloseClick}
          data-testid={TestIds.button}
          disabled={isDisabled ?? false}
          aria-label="Remove Seat"
          aria-describedby={titleId}
        >
          <Icon
            name="symbol-x"
            size="small"
            variant="outlined"
            width={20}
            height={20}
          />
        </button>
      </div>
      {subtitle && (
        <span
          className="text-s font-sans text-gray-600"
          data-testid={TestIds.subtitle}
        >
          {subtitle}
        </span>
      )}
    </div>
  );
};
