import { ReactNode } from 'react';

/**
 * @public
 */
export interface HighlightedExperience {
  /**
   * the URL for the experience image
   */
  image: string;
  /**
   * the alt text for the experience image
   */
  imageAlt: string;
  /**
   * the title of the experience
   */
  heading: string;
  /**
   * the content describing the experience
   */
  description: string;
}

/**
 * @public
 */
export interface HighlightedExperienceSection {
  /**
   * The title above the highlighted experience carousel
   */
  header: string;
  /**
   * the list of experiences in a carousel
   */
  list: HighlightedExperience[];
}

/**
 * @public
 */
export interface Amenity {
  /**
   * URL for the amenity icon
   */
  icon: string;
  /**
   * Text for the icon
   */
  title: string;
}

/**
 * @public
 */
export type AmenitiesListInfo =
  | {
      variant: 'icon-list';
      /**
       * List of icons with text for each amenity
       */
      icons: Amenity[];
    }
  | {
      variant: 'bullet-list';
      /**
       * The text for a bulleted list of amenities
       */
      items: string[];
      /**
       * The number of items displayed in a list when collapsed
       */
      initialItemsLimit?: number;
      /**
       * The label for the button to expand the bulleted list
       */
      expandLabel?: string;
      /**
       * The label for the button to collapse the bulleted list
       */
      collapseLabel?: string;
    };

/**
 * @public
 */
export interface HotelAmenitiesSection {
  /**
   * Subsections for lists of amenities
   */
  amenities: {
    /**
     * The title text for the subsection
     */
    title: string;
    /**
     * The subsubsections for amenity lists
     */
    amenitiesList: AmenitiesListInfo[];
  }[];
}

/**
 * @public
 */
export interface ResortDetailsProps {
  /**
   * the URL for the resort logo
   *
   * typically the `colorVectorLogo`
   */
  logoImage?: string;
  /**
   * the alt text for the logo image
   */
  logoAlt?: string;
  /**
   * the URL for the hero image for the resort
   *
   * typically the overview image
   */
  heroImage?: string;
  /**
   * the alt text for the hero image for the resort
   *
   * typically describes the overview image
   */
  heroAlt?: string;
  /**
   * the overview text
   */
  overview: string;
  /**
   * the URL for the lazy river image
   *
   * typically the first image of the property's `unifiedGallery`
   */
  lazyRiverImage?: string;
  /**
   * the address string, in US address format
   */
  address: string;
  /**
   * The phone number, as it will be shown
   */
  phoneText: string;
  /**
   * the content for the highlighted experiences section
   */
  highlightedExperiences?: HighlightedExperienceSection;
  /**
   * the content for the amenities section
   */
  amenityGroups?: HotelAmenitiesSection;
  /**
   * The text for the location header
   */
  locationHeader: string;
  /**
   * The contents of the footer
   */
  footerChildren: ReactNode;
}
