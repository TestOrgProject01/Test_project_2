import React from 'react';

import { AmenitiesList } from '../amenities-list/amenities-list';

import {
  HighlightedExperienceSection,
  HotelAmenitiesSection
} from './resort-details.types';

/**
 * @internal
 */
export const _HighlightedExperiences = ({
  highlightedExperiences
}: {
  highlightedExperiences: HighlightedExperienceSection;
}) => (
  <div className="overflow-y-hidden flex flex-col">
    <h5 className="text-heading-medium-1 pb-3x">
      {highlightedExperiences.header}
    </h5>

    <div className="flex flex-nowrap overflow-y-hidden overflow-x-scroll gap-6 pb-2x -mb-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
      {highlightedExperiences.list.map((exp, index) => (
        <div key={index} className="flex flex-col min-w-[18.5rem] m-md:w-1/3">
          <img
            className="aspect-16x9 bg-cover rounded-[0.313rem]"
            src={exp.image}
            alt={exp.imageAlt}
          />

          <h3 className="text-heading-medium-1 leading-6 pt-2x pb-1x">
            {exp.heading}
          </h3>

          <p className="text-body-medium-xs leading-5 text-[#606060]">
            {exp.description}
          </p>
        </div>
      ))}
    </div>
  </div>
);

/**
 * @internal
 */
export const _AmenitiesRow = ({
  amenityGroups
}: {
  amenityGroups: HotelAmenitiesSection;
}) => (
  <>
    {amenityGroups.amenities.map((amenityInfo) => (
      <div key={amenityInfo.title}>
        <h2 className="text-heading-medium-1 mb-8">{amenityInfo.title}</h2>

        <div className="flex flex-col m-md:items-start gap-12 m-md:grid m-md:grid-cols-2 m-md:gap-4 d-md:gap-8 d-md:grid-cols-3">
          {amenityInfo.amenitiesList.map((list, amenityListKey) => (
            <AmenitiesList key={amenityListKey} list={list} />
          ))}
        </div>
      </div>
    ))}
  </>
);
