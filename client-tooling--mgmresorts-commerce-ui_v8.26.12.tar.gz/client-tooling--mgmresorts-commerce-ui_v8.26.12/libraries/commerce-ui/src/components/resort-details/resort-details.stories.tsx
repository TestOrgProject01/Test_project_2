import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { ResortDetails } from './resort-details';
import { ResortDetailsMockData } from './resort-details.mocks';

export default {
  component: ResortDetails,
  parameters: {
    actions: { argTypesRegex: null },
    backgrounds: {
      default: 'white'
    },
    layout: 'fullscreen'
  },
  title: 'Components/ResortDetails'
} as Meta<typeof ResortDetails>;

const Template: StoryFn<typeof ResortDetails> = (args) => (
  <div>
    <ResortDetails {...args} />
  </div>
);

export const Default = Template.bind({});

Default.args = {
  ...ResortDetailsMockData
};
