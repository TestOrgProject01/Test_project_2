import React from 'react';

import {
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen
} from '../../util/test-utils';

import { ResortDetails, ResortDetailsTestIds } from './resort-details';
import { ResortDetailsMockData } from './resort-details.mocks';
import { ResortDetailsProps } from './resort-details.types';

describe('<ResortDetails/> component', () => {
  const renderResortDetails = (props: ResortDetailsProps) =>
    create(<ResortDetails {...props} />);

  const renderDetailsToHtml = (props: ResortDetailsProps) =>
    renderToHtml(<ResortDetails {...props} />);

  const baseProps: ResortDetailsProps = {
    ...ResortDetailsMockData
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with minimum content', () => {
      const actual = renderResortDetails({
        address: '1234 S Las Vegas Blvd, Las Vegas, NV, 89101',
        footerChildren: 'ALL RIGHTS RESERVED',
        locationHeader: 'Location',
        overview:
          'MGM Resorts International is an American global hospitality and entertainment company operating destination resorts in Las Vegas, Massachusetts, Michigan, Mississippi, Maryland, Ohio, and New Jersey, including Bellagio, Mandalay Bay, MGM Grand, and Park MGM.',
        phoneText: '702.555.5555'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with full content', () => {
      const actual = renderResortDetails(ResortDetailsMockData);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the amenities expander', () => {
      renderResortDetails({
        ...ResortDetailsMockData
      });

      const element = screen.getByTestId(ResortDetailsTestIds.amenities);
      const button = screen.getByText('View 2 More');
      expect(element).toBeTruthy();
      expect(button).toBeTruthy();
      fireEvent.click(button);
      expect(element).toContainHTML('Collapse');
    });

    it('should not render the amenities expander if not needed', () => {
      renderResortDetails({
        ...ResortDetailsMockData,
        amenityGroups: {
          amenities: [
            {
              amenitiesList: [
                {
                  collapseLabel: 'Collapse',
                  expandLabel: 'Expand',
                  // One item
                  items: ['Item'],
                  variant: 'bullet-list'
                }
              ],
              title: 'Amenities'
            }
          ]
        }
      });

      const element = screen.getByTestId(ResortDetailsTestIds.amenities);
      const button = element.querySelector('button');
      expect(button).toBeFalsy();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderDetailsToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
