import React from 'react';

import { ResortDetailsProps } from './resort-details.types';

export const ResortDetailsMockData: ResortDetailsProps = {
  address: '3770 S Las Vegas Blvd, Las Vegas, NV 89101',
  amenityGroups: {
    amenities: [
      {
        amenitiesList: [
          {
            icons: [
              {
                icon: 'https://static.mgmresorts.com/content/dam/MGM/corporate/website-graphics/icons/gen3-icons/icon-g3-pool.svg',
                title: 'Pool'
              },
              {
                icon: 'https://static.mgmresorts.com/content/dam/MGM/corporate/website-graphics/icons/gen3-icons/icon-g3-pet-friendly.svg',
                title: 'Pet Friendly'
              },
              {
                icon: 'https://static.mgmresorts.com/content/dam/MGM/corporate/website-graphics/icons/gen3-icons/icon-g3-spa.svg',
                title: 'Spa'
              }
            ],
            variant: 'icon-list'
          },
          {
            collapseLabel: 'Collapse',
            expandLabel: 'View 2 More',
            initialItemsLimit: 8,
            items: [
              'Ergonomic desk/workstation',
              'Sitting area with side table',
              'Laptop-friendly nightstand safe',
              'Automatic drapery and sheer controls',
              'Generously stocked mini-bar',
              '50" LED television in bedroom',
              'Furnishings crafted from Eucalyptus -- a fast growing, renewable resource',
              'G-Link Connectivity Panel for HDMI video and Bluetooth audio',
              'Wireless high-speed internet access',
              'Convenient media-hubs'
            ],
            variant: 'bullet-list'
          }
        ],
        title: 'Bellagio Hotel & Casino Amenities'
      }
    ]
  },
  footerChildren: (
    <>
      <img
        className="h-8 mb-4"
        alt="Green Advantage Certified"
        src="https://static.mgmresorts.com/content/dam/MGM/corporate/corporate-initiatives/misc/mgm-resorts-green-advantage.svg"
      />
      <div className="text-body-medium-xs text-gray-700 leading-relaxed">
        COPYRIGHT © 2023 MGM RESORTS INTERNATIONAL ALL RIGHT RESERVED
      </div>
    </>
  ),
  heroAlt:
    'Bellagio Las Vegas is a AAA Five Diamond Resort & Casino with a variety of things to do on The Strip including the iconic Bellagio Fountains.',
  heroImage:
    'https://static.mgmresorts.com/content/dam/MGM/bellagio/hotel/exterior/bellagio-hotel-exterior-south-angle-lagoon-close-up.tif',
  highlightedExperiences: {
    header: 'Experience Bellagio Hotel & Casino',
    list: [
      {
        description:
          'Each season, the enormously talented horticulturalists and designers who make up the Bellagio Conservatory team transform this 14,000-square-foot floral playground into a showcase of the distinctive sights and colors of spring, summer, fall and winter—along with a special display for Chinese New Year. ',
        heading: 'Benvenuti a Las Vegas',
        image:
          'https://static.mgmresorts.com/content/dam/MGM/bellagio/entertainment/attractions/conservatory/2020/chinese-new-year/bellagio-entertainment-conservatory-cny-2020-main-bed.jpg',
        imageAlt: 'Bellagio Conservatory Chinese New Year Display'
      },
      {
        description:
          'Inspired by the concept of infinity and the elegance of water\'s pure form, "O" plays tribute to the beauty of the theater - from the simplest street performance to the most lavish of operas - where anything is possible and where the drama of life plays itself out before our very eyes.  An international cast of world-class acrobats, synchronized swimmers and divers perform in , on, and above the water in this breathtaking production.',
        heading: '"O" by Cirque du Soleil',
        image:
          'https://static.mgmresorts.com/content/dam/MGM/bellagio/entertainment/shows/o-by-cirque-du-soleil/bellagio-entertainment-shows-o-by-cirque-du-soleil-finale02.jpg',
        imageAlt: '"O" by Cirque du Soleil Finale Cast Pose'
      },
      {
        description:
          'There is nothing like seeing them in person. The Fountains of Bellagio were destined to romance your senses. Take in a spectacular show of thoughtfully interwoven water, music and light designed to mesmerize its admirers.',
        heading: 'Fountains of Bellagio',
        image:
          'https://static.mgmresorts.com/content/dam/MGM/bellagio/hotel/exterior/bellagio-hotel-exterior-ravi-fountains-night-full-spray.tif',
        imageAlt: 'The Fountains of Bellagio during a night show'
      }
    ]
  },
  lazyRiverImage:
    'https://static.mgmresorts.com/content/dam/MGM/corporate/website-graphics/gen3/lazyrivercarousel-lasvegas-bellagio.jpg',
  locationHeader: 'Location',
  logoAlt: 'Resort Logo',
  logoImage:
    'https://static.mgmresorts.com/content/dam/MGM/corporate/website-graphics/property-logos/logo-color-bellagio.svg',
  overview:
    'Inspired by the villages of Europe, AAA Five Diamond Bellagio overlooks a Mediterranean-blue lake with fountains performing a magnificent ballet. Escape into an otherworldly plane of dance, music and acrobatics with “O” by Cirque du Soleil — aquatic theater in our Parisian-style opera house.',
  phoneText: '702.693.7111'
};
