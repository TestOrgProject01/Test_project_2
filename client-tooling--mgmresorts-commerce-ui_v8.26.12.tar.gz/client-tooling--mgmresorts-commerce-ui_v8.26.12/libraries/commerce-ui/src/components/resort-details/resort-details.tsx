import React from 'react';

import {
  _AmenitiesRow,
  _HighlightedExperiences
} from './resort-details.private';
import { ResortDetailsProps } from './resort-details.types';

import './resort-details.styles.scss';

const componentId = 'ResortDetails';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const ResortDetailsTestIds = {
  amenities: `${componentId}:amenities`,
  component: componentId,
  experiences: `${componentId}:experiences`,
  footer: `${componentId}:footer`,
  hero: `${componentId}:hero`,
  lazyRiver: `${componentId}:lazy-river`,
  location: `${componentId}:location`,
  logo: `${componentId}:logo`,
  overview: `${componentId}:overview`
};

/**
 *
 * @public
 */
export const ResortDetails = ({
  address,
  amenityGroups,
  heroImage,
  heroAlt,
  highlightedExperiences,
  lazyRiverImage,
  locationHeader,
  logoAlt,
  logoImage,
  overview,
  phoneText,
  footerChildren
}: ResortDetailsProps) => {
  return (
    <div
      className="flex flex-col items-center"
      data-testid={ResortDetailsTestIds.component}
    >
      {logoImage && logoAlt ? (
        <div className="flex justify-center mt-3 mb-6 max-h-32 mx-4 m-md:my-16 w-screen max-w-full">
          <img src={logoImage} alt={logoAlt} />
        </div>
      ) : null}

      <div data-testid={ResortDetailsTestIds.logo}>
        <img
          className="aspect-1x1 m-md:aspect-2x1 object-cover w-full"
          src={heroImage}
          alt={heroAlt}
        />
      </div>

      <div
        className="resort-details__row mt-8 m-md:mt-10"
        data-testid={ResortDetailsTestIds.overview}
      >
        <p className="resort-details__overview-text">{overview}</p>
      </div>

      {!!lazyRiverImage && (
        <div
          className="overflow-x-hidden w-screen max-w-full"
          data-testid={ResortDetailsTestIds.lazyRiver}
        >
          <div aria-hidden className="resort-details__lazy-river">
            {/* img to size the div so that the animation loops at the width of the image */}
            <img
              className="inline-block max-w-max max-h-full invisible"
              src={lazyRiverImage}
              alt={heroAlt}
            />
            {/* background to ensure that the background loop covers the screen */}
            <div
              className="resort-details__lazy-river-bg"
              style={{ backgroundImage: `url(${lazyRiverImage})` }}
            />
          </div>
        </div>
      )}

      {highlightedExperiences && (
        <div
          className="resort-details__row mt-6 m-md:mt-0"
          data-testid={ResortDetailsTestIds.experiences}
        >
          <_HighlightedExperiences
            highlightedExperiences={highlightedExperiences}
          />
        </div>
      )}

      {amenityGroups && (
        <div
          className="resort-details__row w-full mt-2 m-md:mt-16"
          data-testid={ResortDetailsTestIds.amenities}
        >
          <_AmenitiesRow amenityGroups={amenityGroups} />
        </div>
      )}

      <div
        className="resort-details__row mt-4"
        data-testid={ResortDetailsTestIds.location}
      >
        <h2 className="text-heading-medium-1 mb-4">{locationHeader}</h2>

        {[...address.split(/,(.+)/), phoneText].map((line, key) => (
          <p
            key={key}
            className="text-body-medium-xs text-gray-700 leading-relaxed"
          >
            {line}
          </p>
        ))}

        <div className="h-0 mt-10 border-b-gray-100 border-b-thin" />
      </div>

      <footer
        className="resort-details__row mt-4 mb-8"
        data-testid={ResortDetailsTestIds.footer}
      >
        {footerChildren}
      </footer>
    </div>
  );
};
