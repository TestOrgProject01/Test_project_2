export * from './resort-details';
export * from './resort-details.types';
