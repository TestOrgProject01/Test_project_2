import React, { useCallback, forwardRef } from 'react';

import clsx from 'clsx';

import { Icon } from '../icon';

import { ChipProps } from './chip.types';

import './chip.scss';

const componentId = 'Chip';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const ChipTestIds = {
  checkmarkIcon: `${componentId}:icon:checkmark`,
  chip: `${componentId}:chip`,
  component: componentId,
  container: `${componentId}:container`,
  label: `${componentId}:label`,
  leftIcon: `${componentId}:icon:left`,
  rightIcon: `${componentId}:icon:right`
};

/**
 * @public
 */
export const Chip = forwardRef(
  (
    {
      label,
      leftIcon,
      rightIcon,
      seatColor,
      selected = false,
      disabled = false,
      size = 'small',
      onClick,
      withCheckmark = false,
      rightIconClassName,
      labelClassName,
      variant,
      customRightIcon,
      buttonProps,
      labelProps,
      buttonClassName
    }: ChipProps,
    ref: React.Ref<HTMLDivElement>
  ) => {
    const isLarge = size === 'large';
    const isSmall = size === 'small';

    const isAvailable = !disabled;

    const iconSize = isSmall ? 20 : 24;

    const handleClick = useCallback(() => {
      if (isAvailable && onClick) {
        onClick();
      }
    }, [isAvailable, onClick]);

    return (
      <div className="w-max" data-testid={ChipTestIds.container} ref={ref}>
        <div
          className={clsx(
            'flex items-center border-default rounded-border-radius-component-circular px-2x justify-end cursor-pointer w-full relative gap-2 whitespace-nowrap',
            {
              'border-digital-900 hover:border-hover hover:px-[15px] bg-transparent-default':
                !selected && isAvailable && variant !== 'outlined-blue',
              'border-gray-500 text-gray-500 cursor-none pointer-events-none':
                !isAvailable,
              'border-interaction-default bg-digital-25 chip__container__animation__selected':
                selected || variant === 'outlined-blue',
              chip__container__animation__deselected: !selected,
              'h-10': isSmall,
              'h-12': isLarge,
              'hover:shadow-[rgb(0,1,43)_0px_0px_0px_1px]':
                variant === 'outlined-blue',
              'w-[calc(100%_+_20px)]': isSmall && selected,
              'w-[calc(100%_+_24px)]': isLarge && selected
            },
            buttonClassName
          )}
          onClick={handleClick}
          data-testid={ChipTestIds.chip}
          aria-disabled={!isAvailable}
          {...buttonProps}
          tabIndex={0}
        >
          {withCheckmark && (
            <div
              className={clsx('absolute origin-center left-3', {
                'opacity-100 scale-100 chip__icon__animation__selected':
                  selected,
                'scale-50 opacity-0 chip__icon__animation__deselected':
                  !selected
              })}
            >
              <Icon
                name="checkmark"
                size={size}
                variant="outlined"
                width={iconSize}
                height={iconSize}
                data-testid={ChipTestIds.checkmarkIcon}
              />
            </div>
          )}
          {leftIcon && (
            <Icon
              name={leftIcon}
              size={size}
              variant="outlined"
              width={iconSize}
              height={iconSize}
              data-testid={ChipTestIds.leftIcon}
            />
          )}
          {seatColor && (
            <span
              className="rounded-border-radius-component-circular w-5 h-5"
              style={{ backgroundColor: seatColor }}
            />
          )}
          <span
            data-testid={ChipTestIds.label}
            className={clsx(
              {
                'text-body-regular-s': typeof label === 'string'
              },
              labelClassName
            )}
            {...labelProps}
          >
            {label}
          </span>
          {rightIcon && (
            <Icon
              name={rightIcon}
              size={size}
              variant="outlined"
              width={iconSize}
              height={iconSize}
              testId={ChipTestIds.rightIcon}
              className={rightIconClassName}
            />
          )}
          {customRightIcon}
        </div>
      </div>
    );
  }
);
