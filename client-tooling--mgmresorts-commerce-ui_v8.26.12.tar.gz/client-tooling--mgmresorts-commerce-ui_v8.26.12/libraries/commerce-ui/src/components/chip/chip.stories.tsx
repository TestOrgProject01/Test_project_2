import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Chip } from './chip';
import { ChipMockData } from './chip.mocks';

export default {
  argTypes: {
    seatColor: { control: 'color' }
  },
  component: Chip,
  parameters: {
    actions: { argTypesRegex: null },
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen'
  },
  title: 'Components/Chip'
} as Meta<typeof Chip>;

const Template: StoryFn<typeof Chip> = (args) => (
  <div>
    <Chip {...args} />
  </div>
);

export const Default = Template.bind({});

Default.args = {
  ...ChipMockData
};

export const WithIcons = Template.bind({});

WithIcons.args = {
  ...ChipMockData,
  label: 'Chip with icons',
  leftIcon: 'pin-location',
  rightIcon: 'chevron-down'
};

export const Selected = Template.bind({});

Selected.args = {
  ...ChipMockData,
  label: 'Selected chip',
  selected: true
};

export const Disabled = Template.bind({});

Disabled.args = {
  ...ChipMockData,
  disabled: true,
  label: 'Disabled chip'
};

export const CustomLabel = Template.bind({});

CustomLabel.args = {
  ...ChipMockData,
  label: (
    <div className="flex gap-1 items-center">
      <span className="text-label-regular-s">Blue Seat:</span>
      <span className="text-label-regular-s text-gray-600">+$0 per seat*</span>
    </div>
  ),
  seatColor: 'blue'
};
