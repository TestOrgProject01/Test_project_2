import { ChipProps } from './chip.types';

export const ChipMockData: ChipProps = {
  disabled: false,
  id: 'chip-id',
  label: 'Chip label',
  onClick: () => {},
  selected: false,
  size: 'small'
};
