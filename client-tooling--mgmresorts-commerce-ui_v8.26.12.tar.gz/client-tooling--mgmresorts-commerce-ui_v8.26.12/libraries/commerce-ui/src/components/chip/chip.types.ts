import { IconName } from '../icon/icon.types';

/**
 * @public
 */
export interface ChipProps {
  id: string;
  /**
   * The label to be shown on the chip.
   */
  label: React.ReactNode | string;
  /**
   * If set a icon it will be placed on the chip aligned to the left.
   */
  leftIcon?: IconName;
  /**
   * If set a icon it will be placed on the chip aligned to the right.
   */
  rightIcon?: IconName;
  /**
   * If set a icon it will be placed on the chip aligned to the right.
   * And the color will change.
   * And it will show the check icon
   */
  selected?: boolean;
  /**
   * It is used to show the chip disabled and prevents the onClick event from being fired.
   */
  disabled?: boolean;
  /**
   * it is used to define the size of the chip
   */
  size?: 'small' | 'large';
  /**
   * Set up onClick event to be fired when the chip is clicked
   */
  onClick?: () => void;
  /**
   * It is used to define the color of the seat chip
   */
  seatColor?: string;
  /**
   * It is used to define the checkmark icon
   */
  withCheckmark?: boolean;

  /**
   * It is used to define the class name for the right icon
   */
  rightIconClassName?: string;

  /**
   * It is used to define the class name for the label
   */
  labelClassName?: string;

  /**
   * It is used to define the class name for the button element
   */
  buttonClassName?: string;

  /**
   * It is used to define the variant of the chip
   */
  variant?: 'outlined-blue';

  /*
   * It is used to define a custom right icon
   */
  customRightIcon?: React.ReactNode;

  buttonProps?: React.HTMLAttributes<HTMLDivElement>;

  labelProps?: React.HTMLAttributes<HTMLSpanElement>;
}
