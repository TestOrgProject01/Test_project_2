import React from 'react';

import {
  create,
  screen,
  renderToHtml,
  axe,
  userEvent
} from '../../util/test-utils';

import { Chip, ChipTestIds } from './chip';
import { ChipProps } from './chip.types';

describe('<Chip/> component', () => {
  const renderChip = (props: ChipProps) => create(<Chip {...props} />);

  const renderChipHtml = (props: ChipProps) =>
    renderToHtml(<Chip {...props} />);

  const baseProps: ChipProps = {
    id: 'chip-test',
    label: 'Chip test'
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderChip(baseProps);
      expect(actual).toMatchSnapshot();
    });

    it('should render with large size', () => {
      const actual = renderChip({
        ...baseProps,
        size: 'large'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with disabled styles', () => {
      const actual = renderChip({
        ...baseProps,
        disabled: true
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with selected styles', () => {
      const actual = renderChip({
        ...baseProps,
        selected: true
      });

      const selectedClass = '.chip__container__animation__selected';
      const chip = screen.getByTestId(ChipTestIds.container);
      expect(chip.querySelector(selectedClass)).not.toBeNull();
      expect(actual).toMatchSnapshot();
    });

    it('should render with deselected styles', () => {
      const actual = renderChip({
        ...baseProps,
        selected: false
      });

      const deselectedClass = '.chip__container__animation__deselected';
      const chip = screen.getByTestId(ChipTestIds.container);
      expect(chip.querySelector(deselectedClass)).not.toBeNull();
      expect(actual).toMatchSnapshot();
    });

    it('should render with left icon', () => {
      const actual = renderChip({
        ...baseProps,
        leftIcon: 'pin-location'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with right icon', () => {
      const actual = renderChip({
        ...baseProps,
        rightIcon: 'chevron-down'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with seat color', () => {
      const actual = renderChip({
        ...baseProps,
        seatColor: 'black'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with custom label', () => {
      const actual = renderChip({
        ...baseProps,
        label: (
          <div className="flex gap-1 items-center">
            <span className="text-label-regular-m">Custom Label:</span>
            <span className="text-label-regular-m text-gray-600">
              +$0 per seat*
            </span>
          </div>
        )
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Interaction tests.
   */
  describe('business logic', () => {
    it('should trigger onClick callback', async () => {
      const onClick = jest.fn();

      renderChip({
        ...baseProps,
        onClick
      });

      const chip = screen.getByTestId(ChipTestIds.chip);
      await userEvent.click(chip);

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should not trigger onClick callback when disabled', async () => {
      const onClick = jest.fn();

      renderChip({
        ...baseProps,
        disabled: true,
        onClick
      });

      const chip = screen.getByTestId(ChipTestIds.container);
      await userEvent.click(chip);

      expect(onClick).toHaveBeenCalledTimes(0);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderChipHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
