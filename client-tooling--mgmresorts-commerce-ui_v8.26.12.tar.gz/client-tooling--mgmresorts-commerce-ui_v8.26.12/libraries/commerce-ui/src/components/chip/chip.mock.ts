import { ChipProps } from './chip.types';

export const defaultProps: ChipProps = {
  disabled: false,
  id: 'id',
  label: 'Lower bowl',
  onClick: () => {},
  selected: false,
  size: 'large'
};
