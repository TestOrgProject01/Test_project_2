export type AlertType = 'error' | 'warning' | 'info' | 'success' | 'highlight';
export interface IAlertProps extends React.HTMLAttributes<HTMLDivElement> {
  message: string;
  messageDataCMS?: string;
  type: AlertType;
  onClickClose?: () => void;
  ariaLabelClose?: string;
  title?: string;
  link?: {
    text: string;
    url: string;
  };
}
