import { IAlertProps } from './alert.types';

export const alertMockData: IAlertProps = {
  link: {
    text: 'Link',
    url: 'https://www.google.com'
  },

  message: 'An error message goes here',

  title: 'Title is optional ',
  type: 'error'
};
