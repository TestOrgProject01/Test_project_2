import React from 'react';

import '@testing-library/jest-dom';

import { axe, create, screen, renderToHtml } from '../../util/test-utils';

import { Alert } from './alert';
import { alertMockData } from './alert.mocks';
import { IAlertProps } from './alert.types';

describe('<Alert/> component', () => {
  const renderAlertComponent = (props: IAlertProps) =>
    create(<Alert {...props} />);

  const renderAlertComponentToHtml = (props: IAlertProps) =>
    renderToHtml(<Alert {...props} />);

  const onClickClose = jest.fn();

  /**
   * style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAlertComponent(alertMockData);
      expect(actual).toMatchSnapshot();
    });

    it('should render with additional className styles', () => {
      const actual = renderAlertComponent({
        ...alertMockData,
        className: 'mb-2'
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('should render with title', () => {
      renderAlertComponent({
        ...alertMockData,
        title: 'This is a title'
      });

      screen.getByText('This is a title');
    });

    it('should render with message', () => {
      renderAlertComponent({
        ...alertMockData,
        message: 'my message'
      });

      screen.getByText('my message');
    });

    it('should render only with message', () => {
      renderAlertComponent({
        message: 'only message',
        type: 'info'
      });

      screen.getByText('only message');
      expect(screen.queryByRole('button')).not.toBeInTheDocument();
      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.queryByRole('heading')).not.toBeInTheDocument();
    });

    it('should render with link', () => {
      renderAlertComponent({
        ...alertMockData,
        link: {
          text: 'Link',
          url: 'https://www.google.com'
        }
      });

      expect(screen.getByRole('link', { name: 'Link' })).toHaveAttribute(
        'href',
        'https://www.google.com'
      );
    });

    it('should render with onClickClose', () => {
      renderAlertComponent({
        ...alertMockData,
        ariaLabelClose: 'ariaClose',
        onClickClose
      });

      screen.getByRole('button', { name: 'ariaClose' });
    });
  });

  /**
   * Actions tests.
   */

  describe('actions', () => {
    it('should call onClickClose', () => {
      renderAlertComponent({
        ...alertMockData,
        onClickClose
      });

      screen.getByRole('button').click();
      expect(onClickClose).toHaveBeenCalled();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderAlertComponentToHtml(alertMockData);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
