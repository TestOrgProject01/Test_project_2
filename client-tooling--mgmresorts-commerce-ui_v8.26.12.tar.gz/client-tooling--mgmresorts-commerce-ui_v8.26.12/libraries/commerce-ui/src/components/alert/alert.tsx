import React from 'react';

import clsx from 'clsx';

import { Icon, IconName } from '../icon';
import { Link } from '../link';

import { AlertType, IAlertProps } from './alert.types';

const iconNames: Record<AlertType, IconName> = {
  error: 'exclamation-point-octagon',
  highlight: 'symbol-i-circle',
  info: 'symbol-i-circle',
  success: 'checkmark-circle',
  warning: 'exclamation-point-triangle'
};

export const Alert = (props: IAlertProps) => {
  const {
    ariaLabelClose = 'Close alert',
    message,
    messageDataCMS,
    type,
    onClickClose,
    title,
    link
  } = props;

  return (
    <div
      className={clsx('p-2x rounded-lg border-[1px]', {
        'border-digital-500 bg-digital-25': type === 'highlight',
        'border-gray-600 bg-gray-25': type === 'info',
        'border-green-700 bg-green-25': type === 'success',
        'border-orange-700 bg-orange-25': type === 'warning',
        'border-red-600 bg-red-25': type === 'error'
      })}
    >
      <div className="flex gap-2 flex-row items-start text-digital-900">
        <Icon name={iconNames[type]} size="small" variant="outlined" />
        <div className="flex-1">
          <h5
            className={clsx('text-body-medium-m', { hidden: !title })}
            aria-hidden={!title}
          >
            {title}
          </h5>
          <div
            className="text-digital-900 text-body-regular-m"
            data-cms={messageDataCMS}
          >
            {message}
          </div>
          {link && <Link label={link?.text} to={link?.url} target="_blank" />}
        </div>
        {onClickClose && (
          <div className="relative">
            <button
              className="absolute right-[-9px] top-[-9px] p-[6px]"
              onClick={onClickClose}
              aria-label={ariaLabelClose}
            >
              <Icon
                name="symbol-x"
                size="small"
                variant="outlined"
                width={20}
                height={20}
              />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
