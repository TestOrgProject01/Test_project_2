import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Alert } from './alert';
import { alertMockData } from './alert.mocks';

export default {
  argTypes: {
    onClickClose: { action: 'onClickClose' }
  },
  component: Alert,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'Gold-25',
      values: [{ name: 'Gold-25', value: '#FAF9F5' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/Alert'
} as Meta<typeof Alert>;

const AllAlertsTemplate: StoryFn<typeof Alert> = (args) => (
  <div className="p-2x space-y-4">
    <Alert {...args} title="Error" type="error" />
    <Alert {...args} title="Warning" type="warning" />
    <Alert {...args} title="Success" type="success" />
    <Alert {...args} title="Highlight" type="highlight" />
    <Alert {...args} title="Info" type="info" />
  </div>
);

export const AllAlerts = AllAlertsTemplate.bind({});

AllAlerts.args = {
  ...alertMockData
};

const Template: StoryFn<typeof Alert> = (args) => (
  <div className="p-2x">
    <Alert {...args} />
  </div>
);

export const Error = Template.bind({});

Error.args = {
  ...alertMockData,
  type: 'error'
};

export const Warning = Template.bind({});

Warning.args = {
  ...alertMockData,
  type: 'warning'
};

export const Success = Template.bind({});

Success.args = {
  ...alertMockData,
  type: 'success'
};

export const Highlight = Template.bind({});

Highlight.args = {
  ...alertMockData,
  type: 'highlight'
};

export const Info = Template.bind({});

Info.args = {
  ...alertMockData,
  type: 'info'
};

export const InfoNoClose = Template.bind({});

InfoNoClose.args = {
  ...alertMockData,
  onClickClose: undefined,
  title: 'Info without close button',
  type: 'info'
};
