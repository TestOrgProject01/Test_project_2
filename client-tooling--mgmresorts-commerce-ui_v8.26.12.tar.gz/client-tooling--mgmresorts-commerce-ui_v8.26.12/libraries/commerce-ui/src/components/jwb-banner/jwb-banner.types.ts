/**
 * @public
 */

export interface JWBBannerProps extends React.HTMLAttributes<HTMLDivElement> {
  emailValue?: string;
  emailInputLabel: string;
  emailInputLabelDataCMS?: string;
  logoAlt: string;
  logoImage: string;
  description: string;
  descriptionDataCMS?: string;
  learnMore: string;
  learnMoreDataCMS?: string;
  invalidEmailLabel: string;
  invalidEmailLabelDataCMS?: string;
  onClickLearnMore?: () => void;
  ctaLabel: string;
  ctaLabelDataCMS?: string;
  onClickCta?: (email: string) => void;
}
