import React, { CSSProperties, useEffect, useState } from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { JWBBanner } from './jwb-banner';
import { JWBBannerMockData } from './jwb-banner.mocks';

export default {
  argTypes: {
    onClickCta: { action: 'clickCTA' },
    onClickLearnMore: { action: 'clickLearnMore' }
  },
  component: JWBBanner,
  parameters: {
    actions: { argTypesRegex: null },
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: 'rgba(250, 249, 245, 1)' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/JWBBanner'
} as Meta<typeof JWBBanner>;

const Template: StoryFn<typeof JWBBanner> = (args) => {
  const [style, setStyle] = useState<CSSProperties>();

  useEffect(() => {
    const handle = () =>
      setStyle({
        maxWidth:
          window.innerWidth < 768
            ? undefined
            : window.innerWidth === 768
            ? '361px'
            : window.innerWidth === 1024
            ? '617px'
            : '1049px'
      });

    window.addEventListener('resize', handle);

    return () => window.removeEventListener('resize', handle);
  }, []);

  return (
    <div style={style}>
      <JWBBanner {...args} />
    </div>
  );
};

export const DefaultMobile = Template.bind({});
DefaultMobile.args = { ...JWBBannerMockData };

export const DefaultDesktop = Template.bind({});
DefaultDesktop.args = { ...JWBBannerMockData };
DefaultDesktop.parameters = { viewport: { defaultViewport: 'xl' } };
