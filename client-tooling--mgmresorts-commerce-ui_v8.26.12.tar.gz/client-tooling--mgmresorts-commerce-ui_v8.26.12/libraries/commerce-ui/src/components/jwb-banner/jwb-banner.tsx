import React, { useCallback, useMemo, useState } from 'react';

import {
  Button,
  Image,
  TextInput,
  TextLink,
  Typography
} from '@mgmresorts/mgm-ui';
import clsx from 'clsx';

import { useMediaQuery } from '../../util';

import { emailRegExp } from '../jwb-modal';

import { JWBBannerProps } from './jwb-banner.types';

const componentId = 'JWBBanner';

/**
 * @public
 */

export const JWBBanner = ({
  emailValue,
  logoAlt,
  logoImage,
  className,
  description,
  learnMore,
  onClickCta,
  onClickLearnMore,
  ctaLabel,
  invalidEmailLabel,
  emailInputLabel,
  emailInputLabelDataCMS,
  ctaLabelDataCMS,
  learnMoreDataCMS,
  descriptionDataCMS,
  ...others
}: JWBBannerProps) => {
  const isDesktopFHD = useMediaQuery('(min-width: 1025px)');
  const min768 = useMediaQuery('(min-width: 768px)');
  const isDesktop = !isDesktopFHD && min768;
  const isMobile = !isDesktopFHD && !isDesktop;

  const [email, setEmail] = useState(emailValue || '');

  const handleOnClickLearnMore = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();

      if (onClickLearnMore) {
        onClickLearnMore();
      }

      // Since we are using a Link we must to return false
      return false;
    },
    [onClickLearnMore]
  );

  const onChange: React.ChangeEventHandler<HTMLInputElement> = useCallback(
    (event) => setEmail(event.target.value),
    []
  );

  const handleOnClickCta = useCallback(() => {
    if (onClickCta) {
      onClickCta(email);
    }
  }, [email, onClickCta]);

  const isEmailInvalid = useMemo(
    () => !emailRegExp.test(email) || email.length > 100,
    [email]
  );

  return (
    <div
      {...others}
      className={clsx(
        'bg-digital-25 rounded-lg flex gap-4 flex-col p-2x m-lg:p-3x d-lg:flex-row',
        className
      )}
      data-testid={componentId}
    >
      {/* HEADER */}
      <div
        className={clsx('flex items-center flex-wrap', {
          'gap-4': isDesktop,
          'gap-4 flex-[38%] self-start mt-[7px]': isDesktopFHD,
          'gap-[10px]': isMobile
        })}
      >
        {/* LOGO */}
        <Image
          className="[&>img]:w-[82px] [&>img]:h-6 !w-[82px] !h-6"
          src={logoImage}
          alt={logoAlt}
          lazyLoading={true}
          fit="contain"
        />

        {/* DESCRIPTION */}
        <div className={clsx('flex-1 text-digital-900')}>
          <Typography
            variant={
              isDesktop || isDesktopFHD ? 'body-regular-m' : 'body-regular-xs'
            }
            data-cms={descriptionDataCMS}
          >
            {description}{' '}
            <TextLink
              onClick={handleOnClickLearnMore}
              variant="large"
              className={clsx(
                '!p-[0] leading-5 m-lg:!leading-[135%] d-sm:!leading-6 !outline-none',
                {
                  '!text-body-regular-m': isDesktop || isDesktopFHD,
                  '!text-body-regular-xs': isMobile
                }
              )}
              data-cms={learnMoreDataCMS}
              aria-label={learnMore}
              button={true}
            >
              {learnMore}
            </TextLink>
          </Typography>
        </div>
      </div>

      {/* INPUT */}
      <div
        className={clsx('flex', {
          'flex-[62%] gap-4': isDesktopFHD,
          'gap-2': isMobile,
          'gap-4': isDesktop
        })}
      >
        <div className="flex-1">
          <TextInput
            aria-label={emailInputLabel}
            data-testid={`${componentId}-input`}
            type="text"
            label={emailInputLabel}
            data-cms={emailInputLabelDataCMS}
            name="email"
            value={email}
            onChange={onChange}
            error={email !== '' && isEmailInvalid}
            hint={
              email !== '' && isEmailInvalid ? invalidEmailLabel : undefined
            }
            variant="default"
          />
        </div>

        <Button
          disabled={isEmailInvalid}
          label={ctaLabel}
          data-cms={ctaLabelDataCMS}
          onClick={handleOnClickCta}
          size={isMobile ? 'small' : 'large'}
          variant="primary"
          className={clsx('!h-14', { '!hidden': !email })}
        />
      </div>
    </div>
  );
};
