import React from 'react';

import {
  axe,
  createWithDesignTokensProvider,
  fireEvent,
  renderToHtmlWithDesignTokensProvider,
  screen
} from '../../util/test-utils';

import { JWBBanner } from './jwb-banner';
import { JWBBannerMockData } from './jwb-banner.mocks';
import { JWBBannerProps } from './jwb-banner.types';

describe('<JWBBannerProps/> component', () => {
  const renderComponent = (props: JWBBannerProps) =>
    createWithDesignTokensProvider(<JWBBanner {...props} />);

  const renderHTML = (props: JWBBannerProps) =>
    renderToHtmlWithDesignTokensProvider(<JWBBanner {...props} />);

  const onClickCta = jest.fn((emailValue) => emailValue);
  const onClickLearnMore = jest.fn();

  /**
   * Style tests.
   */

  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderComponent(JWBBannerMockData);
      expect(actual).toMatchSnapshot();
    });

    it('should render with invalid email', () => {
      const actual = renderComponent({
        ...JWBBannerMockData,
        emailValue: 'invalid@'
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with valid email', () => {
      const actual = renderComponent({
        ...JWBBannerMockData,
        emailValue: 'valid@gmail.com'
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Prop tests.
   */
  describe('props', () => {
    it('custom description', () => {
      renderComponent({
        ...JWBBannerMockData,
        description: 'my-description'
      });

      screen.getByText('my-description');
    });

    it('custom emailInputLabel', () => {
      renderComponent({
        ...JWBBannerMockData,
        emailInputLabel: 'my-emailInputLabel'
      });

      screen.getByText('my-emailInputLabel');
    });

    it('custom invalidEmailLabel', () => {
      renderComponent({
        ...JWBBannerMockData,
        emailValue: 'invalid@',
        invalidEmailLabel: 'my-invalidEmailLabel'
      });

      screen.getByText('my-invalidEmailLabel');
    });

    it('custom learnMore', () => {
      renderComponent({
        ...JWBBannerMockData,
        learnMore: 'my-learnMore'
      });

      screen.getByText('my-learnMore');
    });

    it('custom emailValue, cta button visible/invisible', async () => {
      renderComponent({
        ...JWBBannerMockData,
        emailValue: 'my-valid@email.com'
      });

      const button = screen.getByText('Submit');
      expect(button.className).not.toContain('hidden'); // "hidden" tailwind css class to make it invisible

      const input = screen.getByDisplayValue('my-valid@email.com');
      fireEvent.input(input, { target: { value: '' } });

      const button2 = screen.getByText('Submit');
      expect(button2.className).toContain('hidden'); // "hidden" tailwind css class to make it invisible
    });
  });

  /**
   * Action tests.
   */
  describe('events', () => {
    it('should call onClickLearnMore', () => {
      renderComponent({
        ...JWBBannerMockData,
        onClickLearnMore
      });

      const learnMoreLink = screen.getByText('Learn more');
      fireEvent.click(learnMoreLink);
      expect(onClickLearnMore).toHaveBeenCalled();
    });

    it('should call onClickCta', () => {
      renderComponent({
        ...JWBBannerMockData,
        ctaLabel: 'my-submit',
        emailValue: 'valid@email.com',
        onClickCta
      });

      const ctaButton = screen.getByText('my-submit');
      fireEvent.click(ctaButton);
      expect(onClickCta).toHaveBeenCalledWith('valid@email.com');
    });

    it('should NOT call onClickCta (button disabled)', () => {
      renderComponent({
        ...JWBBannerMockData,
        ctaLabel: 'my-submit',
        emailValue: 'invalid@',
        onClickCta
      });

      const ctaButton = screen.getByText('my-submit');
      fireEvent.click(ctaButton);
      expect(onClickCta).not.toHaveBeenCalled();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderHTML(JWBBannerMockData);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
