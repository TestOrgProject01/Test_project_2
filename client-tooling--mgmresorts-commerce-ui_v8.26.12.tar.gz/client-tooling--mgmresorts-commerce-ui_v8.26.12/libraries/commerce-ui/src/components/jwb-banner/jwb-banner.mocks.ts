import { JWBBannerProps } from './jwb-banner.types';

export const JWBBannerMockData: JWBBannerProps = {
  ctaLabel: 'Submit',
  description: 'Save up to 15%! Enter your email to compare member pricing.',
  emailInputLabel: 'Email address',
  invalidEmailLabel: 'Invalid email',
  learnMore: 'Learn more',
  logoAlt: 'MGM Logo',
  logoImage:
    'https://www.mgmresorts.com/identity/static/media/mgm-resorts.bbd080f916381c304dc48f866f21c774.svg'
};
