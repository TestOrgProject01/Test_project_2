import * as React from 'react';

import { TextLink, Divider } from '@mgmresorts/mgm-ui';
import clsx from 'clsx';

import { RoomsDatePickerBarProps } from './rooms-datepicker-bar.types';

const componentId = 'RoomsDatePickerBar';

/**
 * @public
 */
export const RoomsDatePickerBar = ({
  checkinLabel = 'Check-in',
  checkoutLabel = 'Check-out',
  checkinValue,
  checkoutValue,
  guestCount,
  ctaLabel = 'Change',
  onClickCTA,
  className,
  checkinLabelDataCMS,
  ctaLabelDataCMS,
  guestCountDataCMS,
  checkoutLabelDataCMS,
  ...others
}: RoomsDatePickerBarProps) => {
  const handleOnClickCTA = React.useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();

      if (onClickCTA) {
        onClickCTA(e);
      }

      // Since we are using a Link we must to return false
      return false;
    },
    [onClickCTA]
  );

  return (
    <div
      className={clsx(
        'p-2x flex gap-x-2.5 m-sm:gap-x-4 bg-brand-25 items-center text-digital-900 font-regular text-label-regular-s',
        className
      )}
      {...others}
      data-testid={componentId}
    >
      <div className="flex items-center gap-4">
        <div>
          <div
            className="text-xs text-gray-600 leading-[135%] whitespace-nowrap"
            data-cms={checkinLabelDataCMS}
          >
            {checkinLabel}
          </div>
          <div
            className={clsx('whitespace-nowrap leading-[135%]', {
              hidden: checkinValue === undefined
            })}
          >
            {checkinValue}
          </div>
        </div>
        <div className="text-l font-medium leading-[135%]">{'-'}</div>
        <div>
          <div
            className="text-xs text-gray-600 leading-[135%] whitespace-nowrap"
            data-cms={checkoutLabelDataCMS}
          >
            {checkoutLabel}
          </div>
          <div
            className={clsx('whitespace-nowrap leading-[135%]', {
              hidden: checkinValue === undefined
            })}
          >
            {checkoutValue}
          </div>
        </div>
      </div>
      <div className="h-6">
        <Divider direction="vertical" inverted={false} />
      </div>
      <div
        className="text-s leading-[135%] whitespace-nowrap grow"
        data-cms={guestCountDataCMS}
      >
        {guestCount}
      </div>
      <TextLink
        data-cms={ctaLabelDataCMS}
        variant="small"
        href="#"
        button={true}
        onClick={handleOnClickCTA}
        className="!inline-block !leading-6 before:content-[attr(value)] before:font-semibold before:invisible before:overflow-hidden before:block before:h-0 !outline-none"
        value={ctaLabel}
        aria-label={ctaLabel}
      >
        {ctaLabel}
      </TextLink>
    </div>
  );
};
