import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsDatePickerBar } from './rooms-datepicker-bar';
import { RoomsDatePickerBarMockData } from './rooms-datepicker-bar.mocks';

export default {
  argTypes: {
    onClickCTA: { action: 'onClickCTA' }
  },
  component: RoomsDatePickerBar,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/Rooms/RoomsDatePickerBar'
} as Meta<typeof RoomsDatePickerBar>;

const Template: StoryFn<typeof RoomsDatePickerBar> = (args) => (
  <div>
    <RoomsDatePickerBar {...args} />
  </div>
);

export const Default = Template.bind({});

Default.args = {
  ...RoomsDatePickerBarMockData
};

export const NoDates = Template.bind({});

NoDates.args = {
  ...RoomsDatePickerBarMockData,
  checkinValue: undefined,
  checkoutValue: undefined
};
