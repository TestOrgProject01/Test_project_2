import { RoomsDatePickerBarProps } from './rooms-datepicker-bar.types';

export const RoomsDatePickerBarMockData: RoomsDatePickerBarProps = {
  checkinValue: 'Tue, Apr 01',
  checkoutValue: 'Fri, Apr 04',
  guestCount: '2 guests'
};
