import React from 'react';

import {
  axe,
  createWithDesignTokensProvider,
  fireEvent,
  renderToHtmlWithDesignTokensProvider,
  screen
} from '../../util/test-utils';

import { RoomsDatePickerBar } from './rooms-datepicker-bar';
import { RoomsDatePickerBarProps } from './rooms-datepicker-bar.types';

describe('<RoomsDatePickerBarProps/> component', () => {
  const renderDatePickerBarComponent = (props: RoomsDatePickerBarProps) =>
    createWithDesignTokensProvider(<RoomsDatePickerBar {...props} />);

  const renderDatePickerBarComponentToHtml = (props: RoomsDatePickerBarProps) =>
    renderToHtmlWithDesignTokensProvider(<RoomsDatePickerBar {...props} />);

  const onClickCTA = jest.fn();
  const onClick = jest.fn();

  const ctaLabel = 'Change';

  const baseProps: RoomsDatePickerBarProps = {
    checkinValue: 'Tue, Apr 01',
    checkoutValue: 'Fri, Apr 04',
    ctaLabel,
    guestCount: '2 guests'
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderDatePickerBarComponent(baseProps);
      expect(actual).toMatchSnapshot();
    });

    it('should render with no checkin/checkout values styles', () => {
      const actual = renderDatePickerBarComponent({
        ...baseProps,
        checkinValue: undefined,
        checkoutValue: undefined
      });

      expect(actual).toMatchSnapshot();
    });

    it('should render with additional className styles', () => {
      const actual = renderDatePickerBarComponent({
        ...baseProps,
        checkinValue: undefined,
        checkoutValue: undefined,
        className: 'mb-2'
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('custom check-in/check-out labels', () => {
      renderDatePickerBarComponent({
        ...baseProps,
        checkinLabel: 'Start date',
        checkoutLabel: 'End date'
      });

      screen.getByText('Start date');
      screen.getByText('End date');
    });

    it('custom check-in/check-out values', () => {
      renderDatePickerBarComponent({
        ...baseProps,
        checkinValue: '2024-10-01',
        checkoutValue: '2024-10-02'
      });

      screen.getByText('2024-10-01');
      screen.getByText('2024-10-02');
    });

    it('custom guest value', () => {
      renderDatePickerBarComponent({ ...baseProps, guestCount: '3 guests' });
      screen.getByText('3 guests');
    });

    it('custom cta label', () => {
      renderDatePickerBarComponent({ ...baseProps, ctaLabel: 'choose' });
      screen.getByText('choose');
    });
  });

  /**
   * Actions tests.
   */
  describe('actions', () => {
    it('onClickCTA', () => {
      renderDatePickerBarComponent({ ...baseProps, onClickCTA });
      const ctaLabelHtml = screen.getByText(ctaLabel);
      fireEvent.click(ctaLabelHtml);
      expect(onClickCTA).toHaveBeenCalledTimes(1);
    });

    it('onClick the whole component', () => {
      renderDatePickerBarComponent({ ...baseProps, onClick });
      const component = screen.getByTestId('RoomsDatePickerBar');
      fireEvent.click(component);
      expect(onClick).toHaveBeenCalledTimes(1);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderDatePickerBarComponentToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
