import React from 'react';

import {
  axe,
  create,
  renderToHtml,
  screen,
  userEvent
} from '../../util/test-utils';

import { ButtonTestIds } from '../button';

import { PackageHeader } from './package-header';
import { PackageHeaderTestIds } from './package-header-utils';
import { PackageHeaderProps } from './package-header.types';

describe('<PackageHeader/> component', () => {
  const renderAccessibilityPackageHeader = (props: PackageHeaderProps) =>
    create(<PackageHeader {...props} />);

  const renderPackageHeaderToHtml = (props: PackageHeaderProps) =>
    renderToHtml(<PackageHeader {...props} />);

  const baseProps: PackageHeaderProps = {
    linkLabel: 'Package details',
    onLinkClick: () => {},
    price: '$1,331',
    priceLabel: 'From',
    title: 'Package name'
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityPackageHeader(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <PackageHeader/> component', () => {
      renderAccessibilityPackageHeader({
        ...baseProps
      });

      const element = screen.getByTestId(PackageHeaderTestIds.title);
      const title = screen.getByText('Package details');
      expect(element).toBeTruthy();
      expect(title).toBeTruthy();
    });

    it('should render mobile version as default', () => {
      renderAccessibilityPackageHeader({
        ...baseProps
      });

      const element = screen.getByTestId(PackageHeaderTestIds.component);
      expect(element.classList.contains('PackageHeader-mobile')).toBe(true);
      expect(element.classList.contains('PackageHeader-desktop')).toBe(false);
    });

    it('should render desktop version when "isDesktop" prop is present', () => {
      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: true
      });

      const element = screen.getByTestId(PackageHeaderTestIds.component);
      expect(element.classList.contains('PackageHeader-mobile')).toBe(false);
      expect(element.classList.contains('PackageHeader-desktop')).toBe(true);
    });

    it('should link detail still trigering onLinkClick even using A element', async () => {
      const onLinkClick = jest.fn();

      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: true,
        onLinkClick
      });

      await userEvent.click(screen.getByTestId(ButtonTestIds.component));

      expect(onLinkClick).toHaveBeenCalled();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderPackageHeaderToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });

    it('should use H1 element in the package title on desktop mode', async () => {
      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: true
      });

      expect(screen.getByTestId(PackageHeaderTestIds.title).tagName).toBe('H1');
    });

    it('should use H1 element in the package title on mobile mode', async () => {
      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: false
      });

      expect(screen.getByTestId(PackageHeaderTestIds.title).tagName).toBe('H1');
    });

    it('should use A element as the package detail link on desktop mode', () => {
      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: true
      });

      const linkElement = screen
        .getByTestId(PackageHeaderTestIds.linkContainer)
        .querySelector('*');

      expect(linkElement).not.toBeNull();
      expect(linkElement!.tagName).toBe('A');
    });

    it('should use A element as the package detail link on mobile mode', () => {
      renderAccessibilityPackageHeader({
        ...baseProps,
        isDesktop: false
      });

      const linkElement = screen
        .getByTestId(PackageHeaderTestIds.linkContainer)
        .querySelector('*');

      expect(linkElement).not.toBeNull();
      expect(linkElement!.tagName).toBe('A');
    });
  });
});
