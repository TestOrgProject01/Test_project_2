import { PackageHeaderProps } from './package-header.types';

export const defaultProps: PackageHeaderProps = {
  linkLabel: 'Link',
  onLinkClick: () => {},
  price: '$1,331',
  priceLabel: 'From',
  title: 'Package Name'
};
