import * as React from 'react';

import { PackageHeaderDesktop } from './package-header-desktop';
import { PackageHeaderMobile } from './package-header-mobile';
import { PackageHeaderProps } from './package-header.types';

/**
 * @public
 */
export const PackageHeader = ({ isDesktop, ...props }: PackageHeaderProps) => {
  if (isDesktop) return <PackageHeaderDesktop {...props} />;

  return <PackageHeaderMobile {...props} />;
};
