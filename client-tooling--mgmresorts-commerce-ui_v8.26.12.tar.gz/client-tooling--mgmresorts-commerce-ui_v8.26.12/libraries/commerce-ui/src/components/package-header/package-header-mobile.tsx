import * as React from 'react';

import { Button } from '../button';
import { Divider } from '../divider';
import { SlotText } from '../slot-text/slot-text';

import { PackageHeaderTestIds } from './package-header-utils';
import { PackageHeaderProps } from './package-header.types';

/**
 * @internal
 */
export const PackageHeaderMobile = ({
  title,
  linkLabel,
  onLinkClick,
  priceLabel,
  price,
  isLoading = false,
  enablePriceAnimation
}: PackageHeaderProps) => {
  const isPriceString = typeof price === 'string';

  return (
    <div
      data-testid={PackageHeaderTestIds.component}
      className="flex items-center gap-4 py-2x px-2x w-full text-digital-900 PackageHeader-root PackageHeader-mobile"
    >
      <div
        data-testid={PackageHeaderTestIds.titleContainer}
        className="flex items-start flex-1 flex-col justify-center max-w-[75%]"
      >
        <h1
          data-testid={PackageHeaderTestIds.title}
          className="block truncate text-body-regular-m h-6 items-center w-full"
        >
          {title}
        </h1>
        {onLinkClick && linkLabel && (
          <div data-testid={PackageHeaderTestIds.linkContainer}>
            <Button
              buttonProps={{
                className:
                  '!p-[0] focus:text-digital-600 hover:text-digital-500 underline text-digital-900 cursor-pointer text-link-regular-s hover:text-link-medium-s'
              }}
              label={linkLabel}
              onClick={onLinkClick}
              size="small"
              variant="tertiary"
              custom
              asLink
            />
          </div>
        )}
      </div>
      <Divider direction="vertical" size="small" />
      <div
        data-testid={PackageHeaderTestIds.priceContainer}
        className="flex flex-col justify-center items-end"
      >
        <span className="text-right text-body-regular-s" aria-hidden="true">{priceLabel}</span>
        {isPriceString && (
          <SlotText
            data-testid={PackageHeaderTestIds.price}
            text={price}
            isLoading={isLoading}
            enableAnimation={enablePriceAnimation}
            priceLabel={priceLabel}
          />
        )}
        {!isPriceString && (
          <div
            data-testid={PackageHeaderTestIds.price}
            className="text-body-medium-m"
          >
            {price}
          </div>
        )}
      </div>
    </div>
  );
};
