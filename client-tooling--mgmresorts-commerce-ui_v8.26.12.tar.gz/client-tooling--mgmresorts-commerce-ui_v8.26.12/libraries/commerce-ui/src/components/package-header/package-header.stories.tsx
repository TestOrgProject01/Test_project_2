import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { PackageHeader } from './package-header';
import { defaultProps } from './package-header.mock';

export default {
  argTypes: {
    onLinkClick: { action: 'onLinkClick' }
  },
  component: PackageHeader,
  title: 'Components/PackageHeader'
} as Meta<typeof PackageHeader>;

const Template: StoryFn<typeof PackageHeader> = (args) => (
  <div className="max-w-[375px] border border-default rounded">
    <PackageHeader {...args} />
  </div>
);

const DesktopTemplate: StoryFn<typeof PackageHeader> = (args) => (
  <div className="w-full max-w-[1440px] border border-default rounded">
    <PackageHeader {...args} />
  </div>
);

export const Default = Template.bind({});
Default.args = { ...defaultProps };

export const Desktop = DesktopTemplate.bind({});
Desktop.args = { ...defaultProps, isDesktop: true };
