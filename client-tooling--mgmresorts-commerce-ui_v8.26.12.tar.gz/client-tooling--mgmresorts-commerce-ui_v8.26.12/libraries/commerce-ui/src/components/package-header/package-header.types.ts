/**
 * @public
 */
export interface PackageHeaderProps {
  /**
   * If set a title it will be placed on the link aligned to the left.
   */
  title?: string;
  /**
   * If set a link label it will be placed under the title aligned to the left.
   */
  linkLabel?: string;
  /**
   * If set a onLinkClick it will be called when user clicks on the link button.
   */
  onLinkClick?: () => void;
  /**
   * If set a priceLabel it will be placed on the price children.
   */
  priceLabel?: string;
  /**
   * If set a price (string or Custom component) it will be placed under the price label.
   */
  price?: string | React.ReactNode;
  /**
   * If `true` will display the desktop version. Default is `false`.
   */
  isDesktop?: boolean;
  /**
   * If `true` will display a spinner until the slot text value is passed. Default is `false`.
   */
  isLoading?: boolean;
  /**
   * Whether or not enable the price "slot machine" animation.
   */
  enablePriceAnimation?: boolean;
}
