const componentId = 'PackageHeader';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const PackageHeaderTestIds = {
  component: componentId,
  icon: `${componentId}:icon`,
  linkContainer: `${componentId}:link-container`,
  price: `${componentId}:price`,
  priceContainer: `${componentId}:price-container`,
  title: `${componentId}:title`,
  titleContainer: `${componentId}:title-container`
};
