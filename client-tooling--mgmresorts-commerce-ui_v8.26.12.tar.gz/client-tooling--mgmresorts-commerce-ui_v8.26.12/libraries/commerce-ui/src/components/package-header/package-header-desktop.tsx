import * as React from 'react';

import { Button } from '../button';
import { Divider } from '../divider';
import { SlotText } from '../slot-text/slot-text';

import { PackageHeaderTestIds } from './package-header-utils';
import { PackageHeaderProps } from './package-header.types';

/**
 * @public
 */
export const PackageHeaderDesktop = ({
  title,
  linkLabel,
  onLinkClick,
  priceLabel,
  price,
  isLoading = false,
  enablePriceAnimation
}: PackageHeaderProps) => {
  const isPriceString = typeof price === 'string';

  return (
    <div
      data-testid={PackageHeaderTestIds.component}
      className="relative flex items-center justify-center gap-4 p-2x w-full text-digital-900 PackageHeader-root PackageHeader-desktop"
    >
      <div
        data-testid={PackageHeaderTestIds.titleContainer}
        className="flex items-center flex-row justify-center space-x-6"
      >
        <h1
          data-testid={PackageHeaderTestIds.title}
          className="overflow-hidden text-ellipsis whitespace-nowrap text-label-regular-l h-6 flex items-center"
        >
          {title}
        </h1>
        <Divider direction="vertical" size="small" height={27} />
        <div
          data-testid={PackageHeaderTestIds.priceContainer}
          className="flex flex-row items-center space-x-2"
        >
          <span className="text-right text-body-regular-m" aria-hidden="true">{priceLabel}</span>
          {isPriceString && (
            <SlotText
              data-testid={PackageHeaderTestIds.price}
              text={price}
              className="text-body-regular-xl"
              isDesktop
              isLoading={isLoading}
              enableAnimation={enablePriceAnimation}
              priceLabel={priceLabel}
            />
          )}
          {!isPriceString && (
            <div
              data-testid={PackageHeaderTestIds.price}
              className="text-body-medium-l"
            >
              {price}
            </div>
          )}
        </div>
      </div>
      {onLinkClick && linkLabel && (
        <div
          data-testid={PackageHeaderTestIds.linkContainer}
          className="absolute right-4"
        >
          <Button
            buttonProps={{
              className:
                '!p-[0] focus:text-digital-600 hover:text-digital-500 underline text-digital-900 cursor-pointer text-link-regular-md hover:text-link-medium-md'
            }}
            label={linkLabel}
            onClick={onLinkClick}
            size="small"
            variant="tertiary"
            custom
            asLink
          />
        </div>
      )}
    </div>
  );
};
