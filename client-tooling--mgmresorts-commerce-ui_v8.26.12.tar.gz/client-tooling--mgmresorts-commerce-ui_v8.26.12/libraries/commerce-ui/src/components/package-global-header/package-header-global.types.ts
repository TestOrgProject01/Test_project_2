import { ImgHTMLAttributes, ReactNode } from 'react';

import { TierTagProps } from '../tier-tag';

/**
 * @public
 */
export interface UserInfo {
  /**
   * User name
   */
  name: string;
  /**
   * Rewards points
   */
  rewardsPoints?: string;
  /**
   * Tier label
   */
  tier?: TierTagProps['tier'];
  /**
   * The current tier progress in percentage.
   */
  tierProgress?: number;
  /**
   * The next tier of the user account.
   */
  nextTier?: TierTagProps['tier'];
}

/**
 * @public
 */
export interface PackageHeaderGlobalAccountMenuItem {
  icon?: ReactNode | (() => ReactNode);
  id?: string;
  onClick?: React.MouseEventHandler;
  title: ReactNode;
}

/**
 * @public
 */
export interface PackageHeaderGlobalAccountMenuProps {
  closeOnMenuClick?: boolean;
  onCreditsLabelClick?: () => void;
  onMenuItemClick?: () => void;
  renderProgressLabel?: (userInfo: UserInfo) => ReactNode;
  buttonAriaLabel?: string;
  navAriaLabel?: string;
  tierCreditsAsLabel?: boolean;
}

/**
 * @public
 */
export interface PackageHeaderGlobalProps {
  /**
   * If set a backHandler will show and icon on the left (mobile version).
   */
  onBack?: () => void;
  /**
   * It will be called when the user clicks the sign in button.
   */
  onSignIn: () => void;
  /**
   * If set the userInfo will be displayed instead of the sign in button.
   */
  userInfo?: UserInfo;
  /**
   * the URL for the resort logo
   *
   * typically the `colorVectorLogo`
   */
  logoImage?: string;
  /**
   * the alt text for the logo image
   */
  logoAlt?: string;
  /**
   * Customize the media logo props
   */
  mediaProps?: ImgHTMLAttributes<HTMLElement>;
  /**
   * Link for the logo redirect
   */
  logoLink?: string;
  /**
   * Label for the sign in button
   */
  signInLabel?: string;
  /**
   * Mobile viewport
   */
  mobile?: boolean;
  /**
   * Tier label
   */
  tier?: TierTagProps['tier'];
  /**
   * It will be called when the user clicks the logo.
   */
  onLogoClick?: () => void;
  /**
   * Sign in button should be disabled
   */
  disabled?: boolean;
  /**
   * Account menu links, if not provided or empty, will hide the menu items block.
   */
  accountMenuLinks?: PackageHeaderGlobalAccountMenuItem[];
  /**
   * Account menu props to customize the account menu behavior.
   */
  accountMenuProps?: PackageHeaderGlobalAccountMenuProps;
}
