import React from 'react';

import { faker } from '@faker-js/faker';

import {
  act,
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen
} from '../../util/test-utils';

import { TierTagProps } from '../tier-tag';

import { PackageHeaderGlobal } from './package-header-global';
import { defaultProps } from './package-header-global.mock';
import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import {
  PackageHeaderGlobalProps,
  UserInfo
} from './package-header-global.types';

describe('<PackageHeaderGlobal/> component', () => {
  const renderAccessibilityPackageHeaderGlobal = (
    props: PackageHeaderGlobalProps
  ) => create(<PackageHeaderGlobal {...props} />);

  const renderPackageHeaderGlobalToHtml = (props: PackageHeaderGlobalProps) =>
    renderToHtml(<PackageHeaderGlobal {...props} />);

  const baseProps: PackageHeaderGlobalProps = defaultProps;

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityPackageHeaderGlobal(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.clearAllTimers();
      jest.useRealTimers();
    });

    const checkCommonElements = (params?: { homeContainer?: boolean }) => {
      const { homeContainer = true } = params ?? {};

      if (homeContainer) {
        expect(
          screen.getByTestId(PackageHeaderGlobalTestIds.homeContainer)
        ).toBeTruthy();
      }

      const signInContainer = screen.getByTestId(
        PackageHeaderGlobalTestIds.signInContainer
      );

      expect(signInContainer).toBeTruthy();

      const signInButton = screen.queryByTestId(
        PackageHeaderGlobalTestIds.signIn
      );

      expect(signInButton).not.toBeTruthy();
    };

    it('should render the <PackageHeaderGlobal/> component, desktop version', async () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps
      });

      checkCommonElements();

      const rewardsIcon = screen.getByTestId(
        PackageHeaderGlobalTestIds.rewardsIcon
      );

      expect(rewardsIcon).toBeTruthy();

      const icon = screen.queryByTestId(PackageHeaderGlobalTestIds.icon);
      expect(icon).not.toBeTruthy();
    });

    it('should render the <PackageHeaderGlobal/> component, mobile version', async () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      checkCommonElements({ homeContainer: false });

      const rewardsIcon = screen.queryByTestId(
        PackageHeaderGlobalTestIds.rewardsIcon
      );

      expect(rewardsIcon).toBeNull();

      const icon = screen.queryByTestId(PackageHeaderGlobalTestIds.icon);
      expect(icon).not.toBeNull();
    });

    it('should render the <PackageHeaderGlobal/> component with the signIn button if the userInfo is not passed, desktop version', async () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        userInfo: undefined
      });

      const homeContainer = screen.getByTestId(
        PackageHeaderGlobalTestIds.homeContainer
      );

      expect(homeContainer).toBeTruthy();

      const signInContainer = screen.getByTestId(
        PackageHeaderGlobalTestIds.signInContainer
      );

      expect(signInContainer).toBeTruthy();

      const signInButtonWrapper = screen.getByTestId(
        PackageHeaderGlobalTestIds.signIn
      );

      expect(signInButtonWrapper).toBeTruthy();

      const signInButton = signInButtonWrapper.querySelector('button');

      expect(signInButton).toBeTruthy();

      expect(signInButton).toBeEnabled();

      const rewardsIcon = screen.queryByTestId(
        PackageHeaderGlobalTestIds.rewardsIcon
      );

      expect(rewardsIcon).not.toBeTruthy();

      const icon = screen.queryByTestId(PackageHeaderGlobalTestIds.icon);
      expect(icon).not.toBeTruthy();
    });

    it('should render the <PackageHeaderGlobal/> component with the signIn button disabled if the disabled prop is true', async () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        disabled: true,
        userInfo: undefined
      });

      const homeContainer = screen.getByTestId(
        PackageHeaderGlobalTestIds.homeContainer
      );

      expect(homeContainer).toBeTruthy();

      const signInContainer = screen.getByTestId(
        PackageHeaderGlobalTestIds.signInContainer
      );

      expect(signInContainer).toBeTruthy();

      const signInButtonWrapper = screen.getByTestId(
        PackageHeaderGlobalTestIds.signIn
      );

      expect(signInButtonWrapper).toBeTruthy();

      const signInButton = signInButtonWrapper.querySelector('button');

      expect(signInButton).toBeTruthy();

      expect(signInButton).toBeDisabled();
    });

    it('should render the account menu component when mouse enter on the user info area', async () => {
      renderAccessibilityPackageHeaderGlobal(baseProps);

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      expect(accountMenu).toHaveClass('invisible opacity-0');

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      expect(accountMenu).not.toHaveClass('invisible opacity-0');
    });

    it('should close the account menu component when the user clicks outside the account menu container', async () => {
      renderAccessibilityPackageHeaderGlobal(baseProps);

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      act(() => {
        fireEvent.click(
          screen.getByTestId(PackageHeaderGlobalTestIds.homeContainer)
        );
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');
    });

    it('should render the correct length of menu items based on specified properties', () => {
      const randomMenus = new Array(faker.datatype.number({ max: 10, min: 1 }))
        .fill('')
        .map((_, idx) => ({
          title: `Title ${idx + 1}`
        }));

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: randomMenus
      });

      expect(
        screen.queryAllByTestId(PackageHeaderGlobalTestIds.accountMenuItem, {
          exact: false
        })
      ).toHaveLength(randomMenus.length);
    });

    it('should trigger `onMenuItemClick` when one of the menu items is clicked', () => {
      const onMenuItemClick = jest.fn();

      const randomMenus = new Array(faker.datatype.number({ max: 10, min: 1 }))
        .fill('')
        .map((_, idx) => ({
          title: `Title ${idx + 1}`
        }));

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: randomMenus,
        accountMenuProps: { onMenuItemClick }
      });

      const randomItem = faker.datatype.number({
        max: randomMenus.length - 1,
        min: 0
      });

      const randomMenuItem = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuItem + `-${randomItem}`,
        { exact: false }
      );

      act(() => {
        fireEvent.click(randomMenuItem);
      });

      expect(onMenuItemClick).toHaveBeenCalled();
    });

    it('should trigger onClick passed via accountMenuLinks prop', () => {
      const onClick = jest.fn();

      const randomMenus = new Array(faker.datatype.number({ max: 10, min: 1 }))
        .fill('')
        .map((_, idx) => ({
          onClick,
          title: `Title ${idx + 1}`
        }));

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: randomMenus
      });

      const randomItem = faker.datatype.number({
        max: randomMenus.length - 1,
        min: 0
      });

      const randomMenuItem = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuItem + `-${randomItem}`,
        { exact: false }
      );

      act(() => {
        fireEvent.click(randomMenuItem);
      });

      expect(onClick).toHaveBeenCalled();
    });

    it('should render no menu items if the `accountMenuItems` were not specified', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: []
      });

      expect(
        screen.queryAllByTestId(PackageHeaderGlobalTestIds.accountMenuItem)
      ).toHaveLength(0);
    });

    it('should render custom icons using functions.', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: [
          {
            icon: () => <span data-testid="CustomIcon" />,
            title: 'Title'
          }
        ]
      });

      expect(screen.getByTestId('CustomIcon')).toBeInTheDocument();
    });

    it('should render title as a valid element when using ReactNode element', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: [
          {
            title: <strong data-testid="CustomTitle">Title</strong>
          }
        ]
      });

      expect(screen.getByTestId('CustomTitle')).toBeInTheDocument();
    });

    it('should render no title element if the provided element is invalid', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: [
          {
            title: []
          }
        ]
      });

      expect(
        screen.queryByTestId(PackageHeaderGlobalTestIds.accountMenuItem)
          ?.textContent
      ).toBeFalsy();
    });

    it('should render custom progress label if a custom function was provided', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuProps: {
          renderProgressLabel: (userInfo) => (
            <span data-testid="CustomProgressLabel">
              My custom progress label: ${userInfo.rewardsPoints}
            </span>
          )
        }
      });

      expect(screen.getByTestId('CustomProgressLabel')).toBeInTheDocument();
    });

    it('should render tier progress correctly', () => {
      const progress = faker.datatype.number({ max: 100, min: 0 });

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        userInfo: {
          ...baseProps.userInfo,
          tierProgress: progress
        } as UserInfo
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.tierProgress)
      ).toHaveStyle({
        width: `${progress}%`
      });
    });

    it('should render the default tier progress correctly', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        userInfo: {
          ...baseProps.userInfo,
          tierProgress: undefined
        } as UserInfo
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.tierProgress)
      ).toHaveStyle({
        width: `0%`
      });
    });

    it('should render the default next tier text correctly', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        userInfo: {
          ...baseProps.userInfo,
          nextTier: undefined
        } as UserInfo
      });

      expect(screen.getByText('Progress to Pearl')).toBeInTheDocument();
    });

    it('should render next tier text correctly', () => {
      const availableTier: Array<TierTagProps['tier']> = [
        'Gold',
        'NOIR',
        'Pearl',
        'Platinum',
        'Sapphire'
      ];

      const randomTierIndex = Math.floor(Math.random() * availableTier.length);
      const randomTier = availableTier[randomTierIndex];

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        userInfo: {
          ...baseProps.userInfo,
          nextTier: randomTier
        } as UserInfo
      });

      expect(screen.getByText(`Progress to ${randomTier}`)).toBeInTheDocument();
    });

    it('should close the menu when a menu item is clicked if the prop closeOnMenuClick is true', () => {
      const randomMenus = new Array(faker.datatype.number({ max: 10, min: 1 }))
        .fill('')
        .map((_, idx) => ({
          title: `Title ${idx + 1}`
        }));

      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuLinks: randomMenus,
        accountMenuProps: {
          ...baseProps.accountMenuProps,
          closeOnMenuClick: true
        }
      });

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      expect(accountMenu).not.toHaveClass('opacity-0 invisible');

      const randomItem = faker.datatype.number({
        max: randomMenus.length - 1,
        min: 0
      });

      const randomMenuItem = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuItem + `-${randomItem}`,
        { exact: false }
      );

      act(() => {
        fireEvent.click(randomMenuItem);
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');
    });

    it('should close the menu when the credits label is clicked if the prop closeOnMenuClick is true.', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuProps: {
          ...baseProps.accountMenuProps,
          closeOnMenuClick: true
        }
      });

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      expect(accountMenu).not.toHaveClass('invisible opacity-0');

      act(() => {
        fireEvent.click(
          screen.getByTestId(PackageHeaderGlobalTestIds.tierCreditsLabel)
        );
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');
    });

    it('should open the account menu using `spacebar` keyboard key', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuProps: {
          ...baseProps.accountMenuProps,
          closeOnMenuClick: true
        }
      });

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.focus(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );

        fireEvent.keyDown(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu),
          {
            charCode: 10,
            code: 'Enter',
            key: 'Enter'
          }
        );
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');

      act(() => {
        fireEvent.focus(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );

        fireEvent.keyDown(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu),
          {
            charCode: 32,
            code: ' ',
            key: ' '
          }
        );
      });

      expect(accountMenu).not.toHaveClass('invisible opacity-0');
    });

    it('should close the account menu using `spacebar` keyboard key if it is already opened', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuProps: {
          ...baseProps.accountMenuProps,
          closeOnMenuClick: true
        }
      });

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.focus(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );

        fireEvent.keyDown(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu),
          {
            charCode: 32,
            code: ' ',
            key: ' '
          }
        );
      });

      expect(accountMenu).not.toHaveClass('invisible opacity-0');

      act(() => {
        fireEvent.focus(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );

        fireEvent.keyDown(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu),
          {
            charCode: 32,
            code: ' ',
            key: ' '
          }
        );
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');
    });

    it('should close the account menu using `escape` keyboard key if it is already opened', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        accountMenuProps: {
          ...baseProps.accountMenuProps,
          closeOnMenuClick: true
        }
      });

      const accountMenu = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenu
      );

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      expect(accountMenu).not.toHaveClass('invisible opacity-0');

      act(() => {
        fireEvent.keyDown(document.body, {
          charCode: 27,
          code: 'Escape',
          key: 'Escape'
        });
      });

      expect(accountMenu).toHaveClass('invisible opacity-0');
    });

    it('should render the mobile account menu correctly', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      expect(
        screen.queryByTestId(PackageHeaderGlobalTestIds.accountMenuMobileButton)
      ).not.toBeNull();
    });

    it('should not render mobile menu in desktop mode', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: false
      });

      expect(
        screen.queryByTestId(PackageHeaderGlobalTestIds.accountMenuMobileButton)
      ).toBeNull();
    });

    it('should render the mobile menu when button is pressed on mobile', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      const mobileButton = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuMobileButton
      );

      act(() => {
        fireEvent.click(mobileButton);
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).toHaveClass('PackageHeaderGlobalAccountMenu-mobile-root');
    });

    it('should close the mobile account menu when close button is pressed', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      const mobileButton = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuMobileButton
      );

      act(() => {
        fireEvent.click(mobileButton);
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).not.toHaveClass('invisible');

      act(() => {
        fireEvent.click(
          screen.getByTestId(PackageHeaderGlobalTestIds.closeMobileAccountMenu)
        );
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).toHaveClass('invisible');
    });

    it('should close the mobile account menu when the overlay is pressed', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      const mobileButton = screen.getByTestId(
        PackageHeaderGlobalTestIds.accountMenuMobileButton
      );

      act(() => {
        fireEvent.click(mobileButton);
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).not.toHaveClass('invisible');

      act(() => {
        fireEvent.click(
          screen.getByTestId(
            PackageHeaderGlobalTestIds.mobileAccountMenuOverlay
          )
        );
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).toHaveClass('invisible');
    });

    it('should not open the account menu when mouse enter when in mobile mode', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true
      });

      act(() => {
        fireEvent.mouseEnter(
          screen.getByTestId(PackageHeaderGlobalTestIds.dropdownMenu)
        );
      });

      expect(
        screen.getByTestId(PackageHeaderGlobalTestIds.accountMenu)
      ).toHaveClass('invisible');
    });

    it('should not render the mobile menu button if userInfo is not available', () => {
      renderAccessibilityPackageHeaderGlobal({
        ...baseProps,
        mobile: true,
        userInfo: undefined
      });

      expect(
        screen.queryByTestId(PackageHeaderGlobalTestIds.accountMenuMobileButton)
      ).toBeNull();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderPackageHeaderGlobalToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
