import React, { ReactNode } from 'react';

import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import { PackageHeaderGlobalAccountMenuItem } from './package-header-global.types';

interface PackageHeaderGlobalAccountMenu {
  menuItems: PackageHeaderGlobalAccountMenuItem[];
  onMenuItemClick?: () => void;
}

const renderIconElement = (icon: ReactNode | (() => ReactNode)) => {
  if (typeof icon === 'function') return icon();

  if (!React.isValidElement(icon)) return null;

  return icon;
};

const renderTitleElement = (title: ReactNode) => {
  if (typeof title === 'string') return <span>{title}</span>;

  if (!React.isValidElement(title)) return null;

  return title;
};

export const PackageHeaderGlobalAccountMenuItems = ({
  menuItems,
  onMenuItemClick
}: PackageHeaderGlobalAccountMenu) => {
  if (!menuItems.length) return null;

  return (
    <>
      <div className="w-full h-px bg-gray-100" />
      <div className="w-full flex flex-col gap-4 px-2x pt-2x">
        {menuItems.map(({ id, title, icon, onClick }, idx) => (
          <button
            key={id || `menuitem-${idx}`}
            className="flex flex-row items-center gap-2 text-body-regular-m text-digital-900 hover:underline hover:text-digital-600 hover:font-medium "
            data-testid={[
              PackageHeaderGlobalTestIds.accountMenuItem,
              PackageHeaderGlobalTestIds.accountMenuItem + `-${idx}`
            ].join(' ')}
            onClick={(...args) => {
              if (typeof onClick === 'function') onClick(...args);
              if (typeof onMenuItemClick === 'function') onMenuItemClick();
            }}
          >
            {renderIconElement(icon)}
            {renderTitleElement(title)}
          </button>
        ))}
      </div>
    </>
  );
};
