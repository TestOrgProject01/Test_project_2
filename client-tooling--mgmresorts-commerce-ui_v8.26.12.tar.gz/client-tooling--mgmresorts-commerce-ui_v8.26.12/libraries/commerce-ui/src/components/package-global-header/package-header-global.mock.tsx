import React from 'react';

import { action } from '@storybook/addon-actions';

import { Icon } from '../icon';

import { PackageHeaderGlobalProps } from './package-header-global.types';

export const defaultProps: PackageHeaderGlobalProps = {
  accountMenuLinks: [
    {
      icon: <Icon name="person-circle" size="small" variant="outlined" />,
      title: 'Profile'
    },
    {
      icon: <Icon name="gift-box" size="small" variant="outlined" />,
      title: 'My rewards'
    },
    {
      icon: <Icon name="luggage" size="small" variant="outlined" />,
      title: 'Trips'
    },
    {
      icon: <Icon name="slot-machine" size="small" variant="outlined" />,
      title: 'Win/loss'
    },
    {
      icon: <Icon name="credit-card" size="small" variant="outlined" />,
      title: 'Wallet'
    },
    {
      icon: <Icon name="gear" size="small" variant="outlined" />,
      title: 'Preferences'
    },
    { title: 'Sign out' }
  ],
  accountMenuProps: {
    closeOnMenuClick: true,
    onCreditsLabelClick: action('onCreditsLabelClick'),
    onMenuItemClick: action('onMenuItemClick')
  },
  disabled: false,
  logoAlt: 'Resort Logo',
  logoImage:
    'https://images.contentstack.io/v3/assets/bltc6ce635bc4868eb2/blt778375ced579c397/64ac6f3ea80c2537e7c8ead8/logo-mgm-rewards-inverted.svg',
  logoLink: 'https://www.mgmresorts.com',
  mobile: false,
  onBack: () => {},
  onLogoClick: () => {},
  onSignIn: () => {},
  signInLabel: 'Sign in or join',
  userInfo: {
    name: 'Hi, Casey',
    nextTier: 'NOIR',
    rewardsPoints: '120,000 Tier Credits',
    tier: 'Sapphire',
    tierProgress: 50
  }
};
