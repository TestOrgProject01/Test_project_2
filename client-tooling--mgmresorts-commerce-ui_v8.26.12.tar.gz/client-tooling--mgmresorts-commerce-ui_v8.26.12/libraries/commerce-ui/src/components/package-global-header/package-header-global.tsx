import * as React from 'react';

import { Icon } from '../icon/icon';

import { PackageHeaderGlobalAccountMenu } from './package-header-global-account-menu';
import { PackageHeaderGlobalSigninButton } from './package-header-global-signin-button';
import { PackageHeaderGlobalUserInfo } from './package-header-global-user-info';
import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import { PackageHeaderGlobalProps } from './package-header-global.types';

/**
 * @public
 */
export const PackageHeaderGlobal = ({
  onBack,
  onSignIn,
  logoImage,
  logoLink,
  logoAlt,
  onLogoClick,
  mediaProps,
  userInfo,
  signInLabel,
  mobile = false,
  disabled = false,
  tier,
  accountMenuLinks,
  accountMenuProps
}: PackageHeaderGlobalProps) => {
  const [accountMenuAnchor, setAccountMenuAnchor] =
    React.useState<HTMLElement | null>(null);

  React.useEffect(() => {
    if (mobile || !accountMenuAnchor) return;

    function closeAccountMenuOnClickOutside(ev: MouseEvent) {
      const el = ev.target as HTMLElement | null;

      const userInfo = el?.closest(
        `[data-testid="${PackageHeaderGlobalTestIds.userInfo}"]`
      );

      const dismissMenu =
        el && !el.closest('.PackageHeaderGlobalAccountMenu-root') && !userInfo;

      if (dismissMenu) setAccountMenuAnchor(null);
    }

    window.addEventListener('click', closeAccountMenuOnClickOutside);

    return () => {
      window.removeEventListener('click', closeAccountMenuOnClickOutside);
    };
  }, [mobile, accountMenuAnchor]);

  return (
    <div
      data-testid={PackageHeaderGlobalTestIds.component}
      className="flex items-center justify-between gap-4 max-h-16 d-sm:py-2x py-[0.75rem] px-2x w-full min-h-[64px] bg-digital-900"
    >
      {mobile && (
        <div className="flex items-center gap-4">
          {onBack && (
            <div
              data-testid={PackageHeaderGlobalTestIds.icon}
              onClick={onBack}
              className="flex cursor-pointer text-[#F6EDDD]"
            >
              <Icon name="chevron-left" size="small" variant="outlined" />
            </div>
          )}
          {userInfo && (
            <button
              data-testid={PackageHeaderGlobalTestIds.accountMenuMobileButton}
              className="flex cursor-pointer text-[#F6EDDD]"
              aria-label={accountMenuProps?.buttonAriaLabel}
              onClick={(ev) => setAccountMenuAnchor(ev.currentTarget)}
            >
              <Icon name="stacked-lines–menu" size="small" variant="outlined" />
            </button>
          )}
        </div>
      )}

      {!mobile && (
        <a
          className="flex cursor-pointer"
          role="link"
          href={logoLink}
          onClick={onLogoClick}
          target="_blank"
          rel="noopener noreferrer"
          data-testid={PackageHeaderGlobalTestIds.homeContainer}
        >
          <img
            className="h-10 w-20 max-h-10 object-contain"
            src={logoImage}
            alt={logoAlt}
            {...mediaProps}
            data-testid={PackageHeaderGlobalTestIds.home}
            draggable="false"
          />
        </a>
      )}

      <div
        data-testid={PackageHeaderGlobalTestIds.signInContainer}
        className="flex flex-col justify-center items-end ml-auto cursor-pointer"
      >
        {!userInfo && (
          <PackageHeaderGlobalSigninButton
            label={signInLabel ?? 'Sign in or join'}
            onClick={onSignIn}
            disabled={disabled}
          />
        )}
        {userInfo && (
          <PackageHeaderGlobalUserInfo
            userInfo={{ ...userInfo, tier: tier || userInfo.tier }}
            isMobile={mobile}
            accountMenuProps={accountMenuProps}
            isMenuOpen={!mobile && Boolean(accountMenuAnchor)}
            onMenuChange={(containerRef) => {
              if (!mobile) setAccountMenuAnchor(containerRef);
            }}
          />
        )}
      </div>

      {userInfo && (
        <PackageHeaderGlobalAccountMenu
          userInfo={userInfo}
          isOpen={Boolean(accountMenuAnchor)}
          anchor={accountMenuAnchor}
          onClose={() => setAccountMenuAnchor(null)}
          menuItems={accountMenuLinks}
          isMobile={mobile}
          accountMenuProps={{
            ...accountMenuProps,
            onCreditsLabelClick: () => {
              if (accountMenuProps?.closeOnMenuClick === true)
                setAccountMenuAnchor(null);

              if (typeof accountMenuProps?.onCreditsLabelClick === 'function')
                accountMenuProps?.onCreditsLabelClick();
            },
            onMenuItemClick: () => {
              if (accountMenuProps?.closeOnMenuClick === true)
                setAccountMenuAnchor(null);

              if (typeof accountMenuProps?.onMenuItemClick === 'function')
                accountMenuProps.onMenuItemClick();
            }
          }}
        />
      )}
    </div>
  );
};
