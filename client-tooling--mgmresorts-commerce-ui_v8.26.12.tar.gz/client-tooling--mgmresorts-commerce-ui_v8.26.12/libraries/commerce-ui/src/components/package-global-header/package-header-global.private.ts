export const defaultDebounceTime = 100;

export const hoverSampleTime = 1000;
