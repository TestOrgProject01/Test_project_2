import React, { useEffect, useRef } from 'react';

import { Icon } from '../icon';
import { TierTag } from '../tier-tag';

import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import {
  PackageHeaderGlobalAccountMenuProps,
  UserInfo
} from './package-header-global.types';

interface PackageHeaderGlobalUserInfoProps {
  userInfo: UserInfo;
  isMobile?: boolean;
  isMenuOpen?: boolean;
  onMenuChange?: (anchor: HTMLDivElement | null) => void;
  accountMenuProps?: PackageHeaderGlobalAccountMenuProps;
}

export const PackageHeaderGlobalUserInfo = ({
  userInfo,
  isMobile: mobile,
  onMenuChange,
  isMenuOpen,
  accountMenuProps
}: PackageHeaderGlobalUserInfoProps) => {
  const userInfoContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isMenuOpen) return;

    function onEscapeKeyPressed(ev: KeyboardEvent) {
      const isEscapeKey = ev.key === 'Escape' || ev.keyCode === 27;

      if (isEscapeKey) onMenuChange?.(null);
    }

    window.addEventListener('keydown', onEscapeKeyPressed);

    return () => {
      window.removeEventListener('keydown', onEscapeKeyPressed);
    };
  }, [isMenuOpen, onMenuChange]);

  return (
    <div
      ref={userInfoContainerRef}
      data-testid={PackageHeaderGlobalTestIds.userInfo}
      className="flex flex-row items-center gap-4"
      role={mobile ? undefined : 'button'}
      tabIndex={mobile ? -1 : 0}
      aria-label={mobile ? undefined : accountMenuProps?.buttonAriaLabel}
      onMouseEnter={() => {
        if (isMenuOpen || mobile) return;
        onMenuChange?.(userInfoContainerRef.current);
      }}
      onKeyDown={(e) => {
        const isSpaceBar = e.key === ' ' || e.keyCode === 32;
        const anchorEl = userInfoContainerRef.current;

        if (!isSpaceBar) return;

        onMenuChange?.(!isMenuOpen ? anchorEl : null);
      }}
    >
      {userInfo?.tier && !mobile && <TierTag tier={userInfo.tier} />}
      <div className="flex flex-col gap-0.5 focus-visible:border focus-visible:border-white">
        <div
          data-testid={PackageHeaderGlobalTestIds.dropdownMenu}
          className="flex flex-row items-center justify-start gap-space-component-xs"
        >
          <div className="flex text-label-regular-m text-[#FAF9F5] leading-4 text-left">
            {userInfo.name}
          </div>

          {!mobile && (
            <div
              className="flex text-[#FAF9F5]"
              data-testid={PackageHeaderGlobalTestIds.rewardsIcon}
            >
              <Icon
                name="chevron-down"
                size="small"
                width={16}
                height={16}
                variant="outlined"
              />
            </div>
          )}
        </div>

        {userInfo.rewardsPoints && !mobile && (
          <div
            className="flex text-label-regular-xs leading-[1.013rem] text-white/[.70] text-right"
            data-testid={PackageHeaderGlobalTestIds.rewardsPoints}
          >
            {userInfo.rewardsPoints}
          </div>
        )}
      </div>
    </div>
  );
};
