import React from 'react';

import clsx from 'clsx';

import { Button, ButtonProps } from '../button';

import { PackageHeaderGlobalTestIds } from './package-header-global.public';

interface PackageHeaderGlobalSigninButtonProps extends ButtonProps {}

export const PackageHeaderGlobalSigninButton = ({
  ...buttonProps
}: PackageHeaderGlobalSigninButtonProps) => (
  <div data-testid={PackageHeaderGlobalTestIds.signIn}>
    <Button
      {...buttonProps}
      buttonProps={{
        ...(buttonProps?.buttonProps ?? {}),
        className: clsx(
          'text-label-regular-s leading-[1.181rem] h-10 rounded-md w-full !text-[#F6EDDD] !border-[#F6EDDD] bg-transparent-default hover:border-hover active:bg-digital-900 active:!text-[#F6EDDD] cursor-pointer',
          buttonProps?.buttonProps?.className
        )
      }}
      variant="secondary"
      type="button"
      size="small"
      fullWidth
      custom
    />
  </div>
);
