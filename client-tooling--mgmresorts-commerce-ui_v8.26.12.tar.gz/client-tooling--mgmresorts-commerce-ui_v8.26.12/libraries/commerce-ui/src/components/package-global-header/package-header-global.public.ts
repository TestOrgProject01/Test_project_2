const componentId = 'PackageHeaderGlobal';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const PackageHeaderGlobalTestIds = {
  accountMenu: `${componentId}:account-menu`,
  accountMenuItem: `${componentId}:account-menu-item`,
  accountMenuMobileButton: `${componentId}:mobile:account-menu-btn`,
  closeMobileAccountMenu: `${componentId}:mobile:close-account-menu`,
  component: componentId,
  dropdownMenu: `${componentId}:dropdown-menu`,
  home: `${componentId}:home`,
  homeContainer: `${componentId}:home-container`,
  icon: `${componentId}:icon`,
  mobileAccountMenuOverlay: `${componentId}:mobile:account-menu-overlay`,
  rewardsIcon: `${componentId}:rewards-icon`,
  rewardsPoints: `${componentId}:rewards-points`,
  signIn: `${componentId}:sign-in`,
  signInContainer: `${componentId}:sign-in-container`,
  tierCreditsLabel: `${componentId}:tier-credit-label`,
  tierProgress: `${componentId}:tier-progress`,
  userInfo: `${componentId}:user-info`
};
