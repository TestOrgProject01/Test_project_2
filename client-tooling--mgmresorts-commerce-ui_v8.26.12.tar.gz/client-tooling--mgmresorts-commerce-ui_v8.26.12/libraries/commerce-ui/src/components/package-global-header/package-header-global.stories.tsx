import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { PackageHeaderGlobal } from './package-header-global';
import { defaultProps } from './package-header-global.mock';

export default {
  argTypes: {
    onBack: { action: 'onBack' },
    onLogoClick: { action: 'onLogoClick' },
    onSignIn: { action: 'onSignIn' }
  },
  component: PackageHeaderGlobal,
  title: 'Components/PackageHeaderGlobal'
} as Meta<typeof PackageHeaderGlobal>;

const Template: StoryFn<typeof PackageHeaderGlobal> = (args) => (
  <PackageHeaderGlobal {...args} />
);

export const Default = Template.bind({});
Default.args = { ...defaultProps };
