import React, { ReactNode, useMemo } from 'react';

import clsx from 'clsx';

import { Icon } from '../icon';
import { TierTag } from '../tier-tag';

import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import { UserInfo } from './package-header-global.types';

interface PackageHeaderGlobalAccountMenuTierInfoProps {
  userInfo: UserInfo;
  onCreditsLabelClick?: () => void;
  renderProgressLabel?: (userInfo: UserInfo) => ReactNode;
  tierCreditsAsLabel?: boolean;
}

export const PackageHeaderGlobalAccountMenuTierInfo = ({
  userInfo,
  renderProgressLabel,
  onCreditsLabelClick,
  tierCreditsAsLabel
}: PackageHeaderGlobalAccountMenuTierInfoProps) => {
  const hasCustomProgressLabel = typeof renderProgressLabel === 'function';

  const progressLabel = useMemo(() => {
    if (hasCustomProgressLabel) return renderProgressLabel(userInfo);

    return `Progress to ${userInfo.nextTier ?? 'Pearl'}`;
  }, [userInfo, hasCustomProgressLabel, renderProgressLabel]);

  return (
    <div className="w-full flex flex-col gap-4 px-2x pb-2x">
      <span className="text-digital-900 text-body-medium-l">
        {userInfo.name}
      </span>
      <div className="flex flex-row items-end gap-2">
        <TierTag tier={userInfo.tier} />
        <div className="flex flex-col flex-grow justify-end gap-1">
          {!!progressLabel && (
            <span className="text-digital-900 text-body-regular-s text-right">
              {progressLabel}
            </span>
          )}
          <div className="w-full h-2 rounded-full bg-digital-900/[.16] relative overflow-hidden">
            <div
              className={clsx('h-full  rounded-full', {
                'bg-tier-status-gold': userInfo.tier === 'Gold',
                'bg-tier-status-noir': userInfo.tier === 'NOIR',
                'bg-tier-status-pearl': userInfo.tier === 'Pearl',
                'bg-tier-status-platinum': userInfo.tier === 'Platinum',
                'bg-tier-status-sapphire': userInfo.tier === 'Sapphire'
              })}
              data-testid={PackageHeaderGlobalTestIds.tierProgress}
              style={{
                width: `${userInfo.tierProgress ?? 0}%`
              }}
            />
          </div>
        </div>
      </div>
      {tierCreditsAsLabel ? (
        <span
          className="text-digital-900 text-body-regular-m"
          data-testid={PackageHeaderGlobalTestIds.tierCreditsLabel}
        >
          {userInfo.rewardsPoints}
        </span>
      ) : (
        <button
          onClick={onCreditsLabelClick}
          className="w-full flex flex-row items-center gap-4 text-digital-900 hover:underline hover:text-digital-600 hover:font-medium"
          data-testid={PackageHeaderGlobalTestIds.tierCreditsLabel}
        >
          <span className="text-body-regular-m flex-grow text-left">
            {userInfo.rewardsPoints}
          </span>
          <Icon
            name="chevron-right"
            size="small"
            width={16}
            height={16}
            variant="outlined"
          />
        </button>
      )}
    </div>
  );
};
