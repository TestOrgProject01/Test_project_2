import React, { useEffect, useState } from 'react';

import clsx from 'clsx';
import { createPortal } from 'react-dom';
import { usePopper } from 'react-popper';

import { Icon } from '../icon';

import { PackageHeaderGlobalAccountMenuItems } from './package-header-global-account-menu-items';
import { PackageHeaderGlobalAccountMenuTierInfo } from './package-header-global-account-menu-tier-info';
import { PackageHeaderGlobalTestIds } from './package-header-global.public';
import {
  PackageHeaderGlobalAccountMenuItem,
  PackageHeaderGlobalAccountMenuProps,
  UserInfo
} from './package-header-global.types';

interface PackageHeaderGlobalAccountMenu {
  isOpen?: boolean;
  anchor?: HTMLElement | null;
  onClose?: () => void;
  menuItems?: PackageHeaderGlobalAccountMenuItem[];
  userInfo: UserInfo;
  accountMenuProps?: PackageHeaderGlobalAccountMenuProps;
  isMobile?: boolean;
}

export const PackageHeaderGlobalAccountMenu = ({
  isOpen,
  anchor,
  onClose,
  menuItems,
  userInfo,
  accountMenuProps,
  isMobile
}: PackageHeaderGlobalAccountMenu) => {
  const [wrapperRef, setWrapperRef] = useState<HTMLElement | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  const { attributes, styles } = usePopper(anchor, wrapperRef, {
    modifiers: [{ name: 'offset', options: { offset: [0, 32] } }],
    placement: 'bottom-end',
    strategy: 'fixed'
  });

  useEffect(() => {
    setIsMounted(true);
  }, []);

  // due to react-dom/server in the tests files this was necessary to avoid tests fail
  // because `createPortal` is not supported by server side rendering.
  if (!isMounted) return null;

  if (isMobile)
    return createPortal(
      <div
        className={clsx(
          'fixed left-0 top-0 w-full h-screen transition-opacity z-[9999]',
          { 'opacity-0 invisible': !isOpen }
        )}
      >
        <div
          onClick={() => onClose?.()}
          data-testid={PackageHeaderGlobalTestIds.mobileAccountMenuOverlay}
          className={clsx(
            'absolute left-0 top-0 w-full h-full z-[999] bg-black/60 transition-opacity ease-in-out delay-150 duration-300',
            {
              'opacity-0 invisible': !isOpen
            }
          )}
        />
        <button
          onClick={() => onClose?.()}
          data-testid={PackageHeaderGlobalTestIds.closeMobileAccountMenu}
          className={clsx(
            'absolute left-[335px] top-[16px] z-[9999] transition-opacity ease-in-out delay-150 duration-300',
            {
              'opacity-0 invisible': !isOpen
            }
          )}
        >
          <Icon
            name="symbol-x"
            size="small"
            variant="outlined"
            color="white"
            height={24}
            width={24}
          />
        </button>
        <nav
          aria-expanded={isOpen}
          aria-label={accountMenuProps?.navAriaLabel}
          className={clsx(
            'PackageHeaderGlobalAccountMenu-root PackageHeaderGlobalAccountMenu-mobile-root w-full absolute max-w-[319px] h-full py-2x bg-brand-25 z-[9999] flex flex-col transition-transform ease-in-out delay-150 duration-300 left-0',
            {
              '-translate-x-[319px] invisible': !isOpen
            }
          )}
          data-testid={PackageHeaderGlobalTestIds.accountMenu}
          {...attributes.popper}
        >
          <PackageHeaderGlobalAccountMenuTierInfo
            userInfo={userInfo}
            onCreditsLabelClick={accountMenuProps?.onCreditsLabelClick}
            renderProgressLabel={accountMenuProps?.renderProgressLabel}
            tierCreditsAsLabel={accountMenuProps?.tierCreditsAsLabel}
          />
          <PackageHeaderGlobalAccountMenuItems
            menuItems={menuItems ?? []}
            onMenuItemClick={accountMenuProps?.onMenuItemClick}
          />
        </nav>
      </div>,
      document.body
    );

  return createPortal(
    <nav
      ref={setWrapperRef}
      style={styles.popper}
      aria-expanded={isOpen}
      aria-label={accountMenuProps?.navAriaLabel}
      className={clsx(
        'PackageHeaderGlobalAccountMenu-root w-full max-w-[343px] py-2x rounded-lg fixed bg-brand-25 z-[9999] flex flex-col transition-opacity ease-in-out delay-150 duration-300',
        {
          'opacity-0 invisible': !isOpen
        }
      )}
      data-testid={PackageHeaderGlobalTestIds.accountMenu}
      onMouseLeave={onClose}
      {...attributes.popper}
    >
      <PackageHeaderGlobalAccountMenuTierInfo
        userInfo={userInfo}
        onCreditsLabelClick={accountMenuProps?.onCreditsLabelClick}
        renderProgressLabel={accountMenuProps?.renderProgressLabel}
        tierCreditsAsLabel={accountMenuProps?.tierCreditsAsLabel}
      />
      <PackageHeaderGlobalAccountMenuItems
        menuItems={menuItems ?? []}
        onMenuItemClick={accountMenuProps?.onMenuItemClick}
      />
    </nav>,
    document.body
  );
};
