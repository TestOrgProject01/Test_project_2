export type TCarouselElement = HTMLDivElement | null;
export type TSwipingEvent = MouseEvent | TouchEvent;

export type TNavigationAction = (
  event: TSwipingEvent,
  direction: 'next' | 'prev',
  withThrottle?: boolean
) => void;

export type TEnsureCarouselPosition = (scrollBehavior?: ScrollBehavior) => void;

export interface ISwipeObj {
  isSwiping: boolean;
  touchStartX: number;
  touchStartY: number;
  touchEndX: number;
  sliderScrollLeft: number;
  hasUpdatedSlide?: boolean;
  shouldVerticallyScrollEntirePage?: boolean;
  isHorizontallySwiping?: boolean;
}
