import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomCard } from './room-card';
import {
  storyBiggerImage,
  storyCustomDetailsComponent,
  storyCustomDetailsSeparator,
  storyCustomImageComponent,
  storyDefaultMockProps,
  storyInfiniteCarousel,
  storySingleImage,
  storyTaggedRoom,
  storyTransparentRoomMock,
  storyTransparentVariantProps,
  storyUnavailableMockProps
} from './room-card.mock';

export default {
  argTypes: {
    onActionClick: { action: 'onActionClick' },
    onTitleClick: { action: 'onTitleClick' }
  },
  component: RoomCard,
  parameters: {
    background: { default: 'dark' }
  },
  title: 'Components/RoomCard'
} as Meta<typeof RoomCard>;

const Template: StoryFn<typeof RoomCard> = (args) => (
  <div className="w-full d-sm:w-[420px]">
    <RoomCard {...args} />
  </div>
);

const TemplateMultipleResorts: StoryFn<typeof RoomCard> = () => {
  return (
    <div className="grid gap-4 grid-cols-2">
      <RoomCard {...storyBiggerImage} />

      <RoomCard {...storyTaggedRoom} />

      <RoomCard {...storyDefaultMockProps} />

      <RoomCard {...storyCustomDetailsComponent} />

      <RoomCard {...storyCustomDetailsSeparator} />

      <RoomCard {...storySingleImage} />

      <RoomCard {...storyInfiniteCarousel} />

      <RoomCard {...storyCustomImageComponent} />
    </div>
  );
};

export const Basic = Template.bind({});
Basic.args = { ...storyDefaultMockProps };

/**
 * Just use the `price` prop as a custom `ReactNode`.
 */
export const TransparentVariant = Template.bind({});
TransparentVariant.args = { ...storyTransparentVariantProps };

export const TaggedRoom = Template.bind({});
TaggedRoom.args = { ...storyTaggedRoom };

export const InfiniteCarousel = Template.bind({});
InfiniteCarousel.args = { ...storyInfiniteCarousel };

export const CustomDetailsComponent = Template.bind({});
CustomDetailsComponent.args = { ...storyCustomDetailsComponent };

export const CustomDetailsSeparator = Template.bind({});
CustomDetailsSeparator.args = { ...storyCustomDetailsSeparator };

export const SingleImage = Template.bind({});
SingleImage.args = { ...storySingleImage };

export const Unavailable = Template.bind({});
Unavailable.args = { ...storyUnavailableMockProps };

export const MultipleRoomsDesktop = TemplateMultipleResorts.bind({});
MultipleRoomsDesktop.args = {};

export const MultipleTransparentRoomsDesktop = Template.bind({});

MultipleTransparentRoomsDesktop.args = {
  ...storyTransparentRoomMock
};

/**
 * You can use a custom image component, for example. You might want to use a image
 * component from `next/image` module. Since we use an flex container to render images, we
 * recommend using `flex: 0 0 auto` on the main image component.
 *
 * ```tsx
 * <RoomCard
 *  // others props
 *  renderImage={({ imageProps, isVisible, index }) => (
 *    <Image
 *      className="flex-[0_0_auto]"
 *      src={imageProps.src}
 *      alt={imageProps.alt}
 *      width={420}
 *      height={236}
 *    />
 *  )}
 * />
 * ```
 */
export const CustomImageComponent = Template.bind({});
CustomImageComponent.args = { ...storyCustomImageComponent };
