import React, {
  MouseEvent as MouseEventReact,
  useCallback,
  useEffect,
  useRef,
  useState
} from 'react';

import clsx from 'clsx';
import { debounce, throttle } from 'rambdax';

import { useSwiping } from '../../util/use-carousel-swiping';
import { useOnClickWithTolerance } from '../../util/use-onclick-with-tolerance';

import { Icon } from '../icon';

import {
  ensureCarouselInfiniteLoop,
  renderCarouselImage,
  scrollCarousel
} from './room-card.private';
import { _RoomCardImagesCarouselProps } from './room-card.types';

const componentId = 'RoomCardImagesCarousel';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const RoomCardImagesCarouselTestIds = {
  activeImageIndicator: `${componentId}:activeImageIndicator`,
  carouselImage: `${componentId}:carouselImage`,
  component: componentId,
  componentContainer: `${componentId}:componentContainer`,
  nextButton: `${componentId}:nextButton`,
  prevButton: `${componentId}:prevButton`
};

type CarouselDirection = 'next' | 'prev';

/**
 * @internal
 */
export const RoomCardImagesCarousel = ({
  images: imagesProp,
  renderImage = renderCarouselImage,
  infiniteCarousel,
  prevButtonProps,
  nextButtonProps,
  hideCarouselButtons = false,
  enableNavigation = true,
  enableSwipe = true,
  className,
  prevButtonClassName,
  nextButtonClassName,
  onImageChange,
  enableShadow = false,
  onClickImage,
  onClickImageTolerance = 5,
  paginationClassName,
  navigationButtonsClassName,
  contrastClassName,
  ...props
}: _RoomCardImagesCarouselProps) => {
  const images = Array.isArray(imagesProp) ? imagesProp : [imagesProp];
  const lastCarouselImageIndex = images.length - 1;
  const [activeImage, setActiveImage] = useState(0);
  const carouselImagesRef = useRef<HTMLElement>(null);

  const onImageChangeHandler = useCallback(
    (index: number, numberOfImages: number) => {
      if (onImageChange) {
        onImageChange(index, numberOfImages).catch(() => {});
      }
    },
    [onImageChange]
  );

  const changeImageHandler = useCallback(
    (
      event: MouseEvent | TouchEvent | MouseEventReact<HTMLElement, MouseEvent>,
      direction: CarouselDirection
    ) => {
      event.stopPropagation();
      event.preventDefault();

      const nextIndex =
        direction === 'next' ? activeImage + 1 : activeImage - 1;

      const calculatedIndex = infiniteCarousel
        ? ensureCarouselInfiniteLoop(nextIndex, lastCarouselImageIndex)
        : Math.min(Math.max(nextIndex, 0), lastCarouselImageIndex);

      if (calculatedIndex !== activeImage) {
        setActiveImage(calculatedIndex);

        onImageChangeHandler(calculatedIndex, lastCarouselImageIndex + 1);
      }
    },
    [
      activeImage,
      infiniteCarousel,
      lastCarouselImageIndex,
      onImageChangeHandler
    ]
  );

  const throttledChangeImage = throttle(
    debounce(changeImageHandler, 100),
    1000
  );

  const getCarouselOffset = useCallback(() => {
    /* istanbul ignore if */
    if (!carouselImagesRef.current)
      // it's really difficult to enter a unit test and it's heavy work to mock the "useRef" function.
      return 0;

    const offsetX =
      (carouselImagesRef.current.scrollWidth / images.length) * activeImage;

    return offsetX;
  }, [activeImage, images.length]);

  const ensureCarouselPosition = useCallback(
    (scrollBehavior?: ScrollBehavior) => {
      /**
       * Force casting the third param to ScrollBehavior, it seems to be a bug from typescript.
       *
       * @see https://github.com/microsoft/TypeScript/issues/47441
       */
      scrollCarousel(
        getCarouselOffset(),
        carouselImagesRef.current,
        scrollBehavior ? scrollBehavior : ('instant' as ScrollBehavior)
      );
    },
    [getCarouselOffset]
  );

  const ensureCarouselPositionHandler = useCallback(() => {
    ensureCarouselPosition();
  }, [ensureCarouselPosition]);

  useEffect(() => {
    // recalculate scroll when window resizes.
    window.addEventListener('resize', ensureCarouselPositionHandler);

    // triggered when `activeImage` changes.
    scrollCarousel(getCarouselOffset(), carouselImagesRef.current);

    // cleanup event listeners
    return () =>
      window.removeEventListener('resize', ensureCarouselPositionHandler);
  }, [
    activeImage,
    ensureCarouselPositionHandler,
    getCarouselOffset,
    images.length
  ]);

  const navigationAction = useCallback(
    (
      event: MouseEvent | TouchEvent | MouseEventReact<HTMLElement, MouseEvent>,
      direction: CarouselDirection,
      withThrottle = true
    ) => {
      if (enableNavigation && withThrottle) {
        throttledChangeImage(event, direction);
      } else if (enableNavigation && !withThrottle) {
        changeImageHandler(event, direction);
      }
    },
    [changeImageHandler, enableNavigation, throttledChangeImage]
  );

  const swipeRef = useSwiping(
    navigationAction,
    ensureCarouselPosition,
    carouselImagesRef,
    enableSwipe
  );

  const onClickImageAndCheckButton = useCallback(
    (e: MouseEvent) => {
      const target = e.target as Element;

      const isButton = target.closest('button');

      if (isButton) {
        return;
      }

      if (onClickImage && typeof onClickImage === 'function') {
        onClickImage();
      }
    },
    [onClickImage]
  );

  useOnClickWithTolerance(
    swipeRef,
    onClickImageAndCheckButton,
    onClickImageTolerance
  );

  return (
    <div
      ref={swipeRef}
      data-testid={RoomCardImagesCarouselTestIds.componentContainer}
      className={clsx(
        'h-full w-full',
        enableShadow &&
          "z-[1] relative before:content-[''] before:h-[216px] before:max-h-full before:w-full before:absolute before:bottom-0 before:left-0 before:right-0 before:z-[1]",
        enableShadow &&
          'before:bg-[linear-gradient(0deg,_rgba(0,_0,_0,_0.70)_0.34%,_rgba(0,_0,_0,_0.55)_17.65%,_rgba(93,_93,_93,_0.15)_61.92%,_rgba(93,_93,_93,_0.00)_87.63%)]',
        contrastClassName
      )}
      {...props}
    >
      <figure
        ref={carouselImagesRef}
        data-testid={RoomCardImagesCarouselTestIds.component}
        className={clsx(
          !className?.includes('rounded')
          ? 'rounded-t-border-radius-component-m'
          : undefined,
          'w-full overflow-x-scroll [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] flex items-center relative',
          className
        )}
      >
        {images.map((imageProps, idx) => (
          <React.Fragment key={`carousel-image-${idx}`}>
            {renderImage({
              imageProps: {
                'data-testid': RoomCardImagesCarouselTestIds.carouselImage,
                ...imageProps
              },
              index: idx,
              isVisible: idx === activeImage
            })}
          </React.Fragment>
        ))}
      </figure>
      {images.length > 1 && (
        <React.Fragment>
          <div
            className={clsx(
              'w-full flex flex-row items-center justify-center absolute bottom-4 space-x-2 z-50 pr-2x pl-2x',
              paginationClassName
            )}
          >
            {images.map((_, i) => (
              <button
                type="button"
                aria-label={`Go to slide ${i + 1}`}
                key={`indicator-${i}`}
                onClick={() => {
                  setActiveImage(i);
                  onImageChangeHandler(i, lastCarouselImageIndex + 1);
                }}
                data-testid={RoomCardImagesCarouselTestIds.activeImageIndicator}
                className={clsx('bg-bg-default w-full h-1 rounded-full', {
                  'opacity-50': activeImage !== i
                })}
              />
            ))}
          </div>
          {!hideCarouselButtons && (
            <div
              className={clsx(
                'w-full absolute top-0 bottom-0 flex flex-row items-center justify-between text-white z-[40]  pr-2x pl-2x',
                navigationButtonsClassName
              )}
            >
              <button
                onClick={(event) => navigationAction(event, 'prev')}
                className={clsx(
                  'p-1x border border-l-0 rounded-full bg-brand-25/60 disabled:bg-bg-subtle/60 text-fg-default disabled:text-gray-400',
                  prevButtonClassName
                )}
                disabled={!infiniteCarousel && activeImage === 0}
                aria-label="Previous image"
                data-testid={RoomCardImagesCarouselTestIds.prevButton}
                {...prevButtonProps}
              >
                <Icon name="chevron-left" size="small" variant="outlined" />
              </button>
              <button
                onClick={(event) => navigationAction(event, 'next')}
                className={clsx(
                  'p-1x border border-r-0 rounded-full bg-brand-25/60 disabled:bg-bg-subtle/60 text-fg-default disabled:text-gray-400',
                  nextButtonClassName
                )}
                disabled={
                  !infiniteCarousel && activeImage === lastCarouselImageIndex
                }
                aria-label="Next image"
                data-testid={RoomCardImagesCarouselTestIds.nextButton}
                {...nextButtonProps}
              >
                <Icon name="chevron-right" size="small" variant="outlined" />
              </button>
            </div>
          )}
        </React.Fragment>
      )}
    </div>
  );
};
