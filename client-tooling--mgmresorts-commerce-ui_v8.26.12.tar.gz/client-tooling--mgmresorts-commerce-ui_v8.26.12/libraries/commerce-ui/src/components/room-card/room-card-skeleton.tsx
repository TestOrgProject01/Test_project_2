import React from 'react';

import { Skeleton } from '../skeleton';

export const SkeletonRoomCard = () => (
  <div className="m-2 gap-2 bg-white rounded-md">
    <div className="w-full">
      <Skeleton height="193px" />
    </div>
    <div className="flex-1 flex flex-col gap-4 mt-4 p-2x">
      <div className="flex-1">
        <Skeleton height="32px" width="9.25rem" />
      </div>
      <div className="flex flex-col gap-2">
        <Skeleton height="8px" width="60%" />
        <Skeleton height="8px" maxWidth="100%" />
      </div>
      <Skeleton height="38px" />
    </div>
  </div>
);
