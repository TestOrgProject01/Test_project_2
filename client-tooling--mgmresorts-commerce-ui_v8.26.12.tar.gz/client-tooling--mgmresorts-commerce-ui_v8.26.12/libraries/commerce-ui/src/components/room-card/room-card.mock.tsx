import React from 'react';

import { formatCurrency } from '../../util';

import { RoomCardProps } from './room-card.types';

// aspect ratio 16:9
const singleImage = {
  alt: 'King suite',
  src: 'https://static.mgmresorts.com/transform/I3633ZiLoUK5/AM2A8673-02_10',
};

const biggerImage = {
  alt: 'King suite',
  src: 'https://static.mgmresorts.com/transform/I3633ZiLoUK5/AM2A8673-02_10',
};

const smallImage = {
  alt: 'King suite',
  src: 'https://static.mgmresorts.com/transform/I3633ZiLoUK5/AM2A8673-02_10',
};

// aspect ratio 16:9
const multipleImages = [
  singleImage,
  {
    alt: 'King suite',
    src: 'https://static.mgmresorts.com/transform/suhz8AEJmC43/Park-King-Detail-Window-Seat-Unlayered.tif',
  },
];

const defaultProps: RoomCardProps = {
  details: ['520 sq ft', '1 King bed', '3 guests max'],
  enableSwipe: true,
  images: [
    ...multipleImages,
    biggerImage,
    smallImage,
    ...multipleImages,
    ...multipleImages
  ],
  price: (
    <div className="flex flex-col items-start justify-stretch">
      <div className="text-label-medium-xl">
        {`${formatCurrency(1249, {
          fraction: false,
          signDisplay: 'always'
        })} `}
      </div>
      <div className="block m-md:text-body-regular-m">To Package Total</div>
    </div>
  ),
  selected: false,
  title: 'King suite'
};

export const storyDefaultMockProps = {
  ...defaultProps
};

export const storyUnavailableMockProps = {
  ...defaultProps,
  isUnavailable: true
};

export const storyTransparentVariantProps = {
  ...defaultProps,
  price: (
    <div className="flex flex-col">
      <span>Included in package</span>
      <span>({formatCurrency(1249)} total per night)</span>
    </div>
  )
};

export const storyTaggedRoom = {
  ...defaultProps,
  isTagged: true,
  tagText: 'Featured'
};

export const storyInfiniteCarousel = {
  ...defaultProps,
  infiniteCarousel: true
};

export const storyCustomDetailsComponent = {
  ...defaultProps,
  details: (
    <p className="text-body-regular-m">
      Breakfast, <strong className="text-body-medium-m">Free Wi-Fi</strong>
    </p>
  )
};

export const storyCustomDetailsSeparator = {
  ...defaultProps,
  detailsSeparator: <span className="flex justify-center w-8">😃</span>
};

export const storySingleImage = {
  ...defaultProps,
  images: singleImage
};

export const storyBiggerImage = {
  ...defaultProps,
  images: biggerImage,
  title: 'Sky Suites Two Bedroom Penthouse King Bed and Queen Beds - Strip View'
};

export const storySmallImage = {
  ...defaultProps,
  images: smallImage,
  title: 'Sky Suites Two Bedroom Penthouse King Bed and Queen Beds - Strip View'
};

export const storyTransparentRoomMock = {
  ...defaultProps,
  images: smallImage,
  price: (
    <div className="text-body-regular-s text-informative-default">
      <div className="inline-flex items-center gap-1 text-gray-900 w-full">
        <h1 className="text-body-medium-xl leading-tight">$91</h1>
        per night
      </div>
      Incl. daily resort fee
      <br />
      $6,604 package total
    </div>
  ),
  title: 'Premier King'
};

export const storyCustomImageComponent: RoomCardProps = {
  ...defaultProps,
  renderImage: ({ index }) => (
    <div className="w-full flex-[0_0_auto] h-[240px] bg-bg-high-contrast text-white flex justify-center items-center">
      Image {index + 1}
    </div>
  )
};
