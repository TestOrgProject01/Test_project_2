import React from 'react';

import { P, match } from 'ts-pattern';

import { _RoomCardDetailsProps } from './room-card.types';

const componentId = 'RoomCardDetails';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const RoomCardDetailsTestIds = {
  component: componentId
};

/**
 * @internal
 */
export const RoomCardDetails = ({
  details,
  detailsSeparator = '・'
}: _RoomCardDetailsProps) => {
  if (!details) return null;

  const detailsText = match(details)
    .with(P.array(P.any), (arr) => (
      <div className="flex items-center">
        {arr.map((detail, idx) => (
          <React.Fragment key={`details-${idx}`}>
            <span>{detail}</span>
            {idx < arr.length - 1 && <span>{detailsSeparator}</span>}
          </React.Fragment>
        ))}
      </div>
    ))
    .otherwise(() => details);

  return (
    <div
      data-testid={RoomCardDetailsTestIds.component}
      className="text-body-regular-s text-fg-contrast"
    >
      {detailsText}
    </div>
  );
};
