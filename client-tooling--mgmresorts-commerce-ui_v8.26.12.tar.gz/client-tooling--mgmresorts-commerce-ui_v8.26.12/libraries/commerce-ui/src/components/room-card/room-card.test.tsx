jest.mock('react', () => ({
  ...jest.requireActual<Record<string, unknown>>('react'),
  useId: jest.fn().mockReturnValue('')
}));

import React, { useId } from 'react';

import {
  render,
  screen,
  act,
  fireEvent,
  waitFor
} from '@testing-library/react';

import { formatCurrency } from '../../util';
import { axe, renderToHtml, userEvent } from '../../util/test-utils';

import { RoomCard, RoomCardTestIds } from './room-card';
import { RoomCardDetailsTestIds } from './room-card-details';
import { RoomCardImagesCarouselTestIds } from './room-card-images-carousel';
import { RoomCardProps } from './room-card.types';

describe('<RoomCard /> component', () => {
  const defaultProps: RoomCardProps = {
    details: ['520 sq ft', '1 King bed', '3 guests max'],
    images: {
      alt: 'king suite',
      src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
    },
    price: (
      <React.Fragment>
        <span className="text-body-medium-m">{formatCurrency(1249.99)}</span>{' '}
        Package total
      </React.Fragment>
    ),
    title: 'King suite'
  };

  const RoomCardWrapper = (props: Partial<RoomCardProps>) => (
    <RoomCard {...defaultProps} {...props} />
  );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      expect(render(<RoomCardWrapper />)).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    const checkActiveImage = async (target: string) => {
      const imageItem = screen.getByTestId(target);

      await waitFor(() => {
        expect(imageItem).toHaveAttribute('data-isactive', 'true');
      });
    };

    it('should render component with title and details', () => {
      render(<RoomCardWrapper />);
      expect(screen.getByTestId(RoomCardTestIds.component)).toBeInTheDocument();
      expect(screen.getByText('King suite')).toBeInTheDocument();
      expect(screen.getByText('520 sq ft')).toBeInTheDocument();
      expect(screen.getByText('1 King bed')).toBeInTheDocument();
      expect(screen.getByText('3 guests max')).toBeInTheDocument();
    });

    it('should render tag text when isTagged is true', () => {
      render(<RoomCardWrapper isTagged={true} />);
      expect(screen.getByTestId(RoomCardTestIds.tagText)).toBeInTheDocument();
      expect(screen.getByText('Included')).toBeInTheDocument();
    });

    it('should render custom tag text when isTagged is true', () => {
      render(<RoomCardWrapper isTagged={true} tagText="Custom Tag" />);
      expect(screen.getByTestId(RoomCardTestIds.tagText)).toBeInTheDocument();
      expect(screen.getByText('Custom Tag')).toBeInTheDocument();
    });

    it('should render price line text', () => {
      render(<RoomCardWrapper />);
      expect(screen.getByText('$1,249.99')).toBeInTheDocument();
      expect(screen.getByText('Package total')).toBeInTheDocument();
    });

    it('should render carousel images with prev and next buttons', () => {
      render(
        <RoomCardWrapper
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
        />
      );

      expect(screen.getAllByTestId('carousel-image')).toHaveLength(2);

      expect(
        screen.getAllByTestId(
          RoomCardImagesCarouselTestIds.activeImageIndicator
        )
      ).toHaveLength(2);

      expect(screen.getByLabelText('Previous image')).toBeInTheDocument();
      expect(screen.getByLabelText('Next image')).toBeInTheDocument();
    });

    it('should recalculate the scroll position when the window resizes', () => {
      render(
        <RoomCardWrapper
          images={{
            alt: 'king suite',
            'data-testid': 'myimage',
            src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
          }}
        />
      );

      const carouselEl = screen.getByTestId('myimage').closest('figure');
      const scrollToSpy = jest.fn();
      carouselEl!.scrollTo = scrollToSpy;

      window.dispatchEvent(new Event('resize'));
      expect(scrollToSpy).toHaveBeenCalled();
    });

    it('should scroll to correct image when navigation button was clicked', async () => {
      const onImageChangeHandler = jest
        .fn()
        .mockImplementation((index: number, numberOfImages: number) => {
          return Promise.resolve({ index, numberOfImages });
        });

      render(
        <RoomCardWrapper
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image3',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
          onImageChange={onImageChangeHandler}
        />
      );

      const nextButton = screen.getByTestId(
        RoomCardImagesCarouselTestIds.nextButton
      );

      const prevButton = screen.getByTestId(
        RoomCardImagesCarouselTestIds.prevButton
      );

      // to apply delay between click events
      const delay = () => new Promise((resolve) => setTimeout(resolve, 250));

      await userEvent.click(nextButton);
      await delay();
      await userEvent.click(nextButton);
      await delay();
      await checkActiveImage('carousel-image3');
      expect(onImageChangeHandler).toHaveBeenCalledTimes(2);
      expect(onImageChangeHandler).toHaveBeenCalledWith(2, 3);
      await delay();
      await userEvent.click(prevButton);
      await checkActiveImage('carousel-image2');
      expect(onImageChangeHandler).toHaveBeenCalledTimes(3);
      expect(onImageChangeHandler).toHaveBeenCalledWith(1, 3);
    });

    it('should change slides with swipe and touch events', async () => {
      const onImageChangeHandler = jest
        .fn()
        .mockImplementation((index: number, numberOfImages: number) => {
          return Promise.resolve({ index, numberOfImages });
        });

      render(
        <RoomCardWrapper
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image3',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
          onImageChange={onImageChangeHandler}
        />
      );

      fireEvent.mouseDown(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 250 }
      );

      fireEvent.mouseMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 100 }
      );

      fireEvent.mouseUp(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 50 }
      );

      await checkActiveImage('carousel-image2');

      fireEvent.mouseDown(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 250 }
      );

      fireEvent.mouseMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 100 }
      );

      fireEvent.mouseUp(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 50 }
      );

      await checkActiveImage('carousel-image3');

      //Try to change to the next img when the last img is active (should not change)
      fireEvent.mouseDown(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 250 }
      );

      fireEvent.mouseMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 100 }
      );

      fireEvent.mouseUp(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 50 }
      );

      await checkActiveImage('carousel-image3');

      fireEvent.touchStart(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 50 }], clientX: 50 }
      );

      fireEvent.touchMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 100 }], clientX: 100 }
      );

      fireEvent.touchEnd(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 250 }], clientX: 250 }
      );

      await checkActiveImage('carousel-image2');

      fireEvent.touchStart(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 50 }], clientX: 50 }
      );

      fireEvent.touchMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 100 }], clientX: 100 }
      );

      fireEvent.touchEnd(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 250 }], clientX: 250 }
      );

      await checkActiveImage('carousel-image1');

      //Try to change to the previous img when the first img is active (should not change)
      fireEvent.touchStart(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 50 }], clientX: 50 }
      );

      fireEvent.touchMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 100 }], clientX: 100 }
      );

      fireEvent.touchEnd(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 250 }], clientX: 250 }
      );

      await checkActiveImage('carousel-image1');

      /**  Should not change slides because the swiping did not reached the min swipe distance */

      const my_element = screen.getByTestId(
        RoomCardImagesCarouselTestIds.componentContainer
      );

      jest.spyOn(my_element, 'getBoundingClientRect').mockImplementation(() => {
        return {
          bottom: 0,
          height: 500,
          left: 0,
          right: 0,
          toJSON: () => '',
          top: 0,
          width: 500,
          x: 0,
          y: 0
        };
      });

      fireEvent.touchStart(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 50 }], clientX: 50 }
      );

      fireEvent.touchMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 55 }], clientX: 55 }
      );

      fireEvent.touchEnd(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { changedTouches: [{ clientX: 60 }], clientX: 60 }
      );

      await checkActiveImage('carousel-image1');
    });

    it('should scroll with an infinite loop when using infiniteCarousel property', async () => {
      render(
        <RoomCardWrapper
          infiniteCarousel
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
        />
      );

      const nextButton = screen.getByLabelText('Next image');
      const prevButton = screen.getByLabelText('Previous image');

      // to apply delay between click events
      const delay = () => new Promise((resolve) => setTimeout(resolve, 250));

      act(() => {
        fireEvent.click(nextButton);
      });

      await checkActiveImage('carousel-image2');

      await delay();

      act(() => {
        fireEvent.click(nextButton);
      });

      await checkActiveImage('carousel-image1');

      await delay();

      act(() => {
        fireEvent.click(prevButton);
      });

      await checkActiveImage('carousel-image2');
    });

    it('should be able navigating using the indicators buttons below the images', () => {
      render(
        <RoomCardWrapper
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
        />
      );

      const indicatorsButtons = screen.queryAllByTestId(
        RoomCardImagesCarouselTestIds.activeImageIndicator
      );

      act(() => {
        fireEvent.click(indicatorsButtons[1]);
      });

      expect(screen.getByTestId('carousel-image2')).toHaveAttribute(
        'data-isactive',
        'true'
      );
    });

    it('should not render the details when is not present on properties', () => {
      render(<RoomCardWrapper details={null} />);

      expect(
        screen.queryByTestId(RoomCardDetailsTestIds.component)
      ).not.toBeInTheDocument();
    });

    it('should render details correcly when use as custom component', () => {
      render(
        <RoomCardWrapper
          details={<p data-testid="mycustom-details">my details</p>}
        />
      );

      expect(screen.getByTestId('mycustom-details')).toBeInTheDocument();
    });

    it('should use a custom details separator when it is present on properties', () => {
      render(<RoomCardWrapper detailsSeparator={<span>|separator|</span>} />);
      expect(screen.getAllByText('|separator|')).toHaveLength(2);
    });

    it('should call onActionClick when action was clicked', () => {
      const onActionClickFn = jest.fn();
      render(<RoomCardWrapper onActionClick={onActionClickFn} />);
      const actionButton = screen.getByTestId(RoomCardTestIds.actionButton);
      fireEvent.click(actionButton);
      expect(onActionClickFn).toHaveBeenCalled();
    });

    it('should call onTitleClick when title was clicked', () => {
      const onTitleClickFn = jest.fn();
      render(<RoomCardWrapper onTitleClick={onTitleClickFn} />);
      const actionButton = screen.getByTestId(RoomCardTestIds.titleButton);
      fireEvent.click(actionButton);
      expect(onTitleClickFn).toHaveBeenCalled();
    });

    it('should render title button with custom button props', () => {
      render(
        <RoomCardWrapper
          titleButtonProps={{ 'aria-label': 'my custom label' }}
        />
      );

      const actionButton = screen.getByTestId(RoomCardTestIds.titleButton);
      expect(actionButton).toHaveAttribute('aria-label', 'my custom label');
    });

    it('should render the unavailable text when isUnavailable is true', () => {
      render(<RoomCardWrapper isUnavailable={true} />);

      expect(
        screen.getByTestId(RoomCardTestIds.unavailableContainer)
      ).toBeInTheDocument();

      expect(
        screen.getByTestId(RoomCardTestIds.unavailableText)
      ).toBeInTheDocument();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      expect(await axe(renderToHtml(<RoomCardWrapper />))).toHaveNoViolations();
    });

    it('should have id with random value on the title element', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValue(randomId);
      render(<RoomCardWrapper />);

      expect(screen.getByTestId(RoomCardTestIds.title)).toHaveAttribute(
        'id',
        randomId
      );

      (useId as jest.Mock).mockReset();
    });

    it('should have aria-describedby on action button', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValue(randomId);
      render(<RoomCardWrapper />);

      expect(screen.getByTestId(RoomCardTestIds.actionButton)).toHaveAttribute(
        'aria-describedby',
        randomId
      );

      (useId as jest.Mock).mockReset();
    });

    it('should have aria-describedby on the previous and next buttons', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValue(randomId);

      render(
        <RoomCardWrapper images={[{ src: 'image1' }, { src: 'image2' }]} />
      );

      expect(
        screen.getByTestId(RoomCardImagesCarouselTestIds.prevButton)
      ).toHaveAttribute('aria-describedby', randomId);

      expect(
        screen.getByTestId(RoomCardImagesCarouselTestIds.nextButton)
      ).toHaveAttribute('aria-describedby', randomId);

      (useId as jest.Mock).mockReset();
    });
  });
});
