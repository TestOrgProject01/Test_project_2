import React, {
  DetailedHTMLProps,
  HTMLAttributes,
  ImgHTMLAttributes
} from 'react';

/**
 * @public
 */
export type CustomPriceTextHandler = (
  formattedPrice: string
) => React.ReactNode;

/**
 * @public
 */
export type ImageProps = DetailedHTMLProps<
  ImgHTMLAttributes<HTMLImageElement>,
  HTMLImageElement
> & {
  'data-testid'?: string;
};

/**
 * @public
 */
export interface RenderImageParams {
  imageProps: ImageProps;
  isVisible: boolean;
  index: number;
}

/**
 * @public
 */
export type RenderImageHandler = (params: RenderImageParams) => React.ReactNode;

/**
 * @public
 */
export type TOnImageChange = (
  index: number,
  numberOfImages: number
) => Promise<void>;

/**
 * @public
 */
export interface RoomCardProps {
  /**
   * The title of the room card.
   */
  title: string;
  /**
   * An array of images to display for the room card.
   */
  images: ImageProps | Array<ImageProps>;
  /**
   * Whether the image carousel should be infinite.
   */
  infiniteCarousel?: boolean;
  /**
   * Details about the room. Can be React nodes or an array of nodes.
   */
  details?: React.ReactNode | React.ReactNode[];
  /**
   * The separator between details.
   */
  detailsSeparator?: React.ReactNode;
  /**
   * The price of the room.
   */
  price: React.ReactNode;
  /**
   * Text for the action button.
   */
  actionButtonText?: string;
  /**
   * A function to handle the action button click event.
   */
  onActionClick?: () => Promise<void> | void;
  /**
   * A function to handle the title click event.
   */
  onTitleClick?: () => Promise<void> | void;
  /**
   * Whether the room is tagged.
   */
  isTagged?: boolean;
  /**
   * Text for the tag displayed on the room card.
   */
  tagText?: string;
  /**
   * A function to render the image in the carousel.
   */
  renderImage?: RenderImageHandler;
  /**
   * Props for the previous button in the image carousel.
   */
  prevButtonProps?: HTMLAttributes<HTMLButtonElement>;
  /**
   * Props for the next button in the image carousel.
   */
  nextButtonProps?: HTMLAttributes<HTMLButtonElement>;
  /**
   * Props for the title button
   */
  titleButtonProps?: HTMLAttributes<HTMLButtonElement>;
  /**
   * Props for unavailable room state
   */
  isUnavailable?: boolean;
  /**
   * Unavailable room text
   */
  unavailableText?: string;
  /**
   * Custom function that it's called when we change the current carrousel's image.
   */
  onImageChange?: TOnImageChange;
  /**
   * Enable swipe navigation for the carousel.
   *
   * @defaultValue `true`
   */
  enableSwipe?: boolean;
  /**
   * Set the selected state for the button
   */
  selected?: boolean;
  /**
   * Set the loading state for the button
   */
  loading?: boolean;
  /**
   * Set the disabled state for the button
   */
  disabled?: boolean;
}

/**
 * @internal
 */
export type _RoomCardImagesCarouselProps = React.HTMLAttributes<HTMLElement> &
  Pick<
    RoomCardProps,
    | 'images'
    | 'renderImage'
    | 'infiniteCarousel'
    | 'prevButtonProps'
    | 'nextButtonProps'
  > & {
    /**
     * Hide carousel buttons.
     */
    hideCarouselButtons?: boolean;

    /**
     * Enable navigation for the carousel using the left and right arrows.
     *
     * @defaultValue `true`
     */
    enableNavigation?: boolean;

    /**
     * Enable swipe navigation for the carousel.
     *
     * @defaultValue `false`
     */
    enableSwipe?: boolean;

    /**
     * Custom class name to override styles.
     */
    className?: string;

    /**
     * Custom class name to override the pagination styles.
     */
    paginationClassName?: string;

    /**
     * Custom class name to override the navigation buttons styles.
     */
    navigationButtonsClassName?: string;

    /**
     * Custom class name for the previous button.
     */
    prevButtonClassName?: string;

    /**
     * Custom class name for the next button.
     */
    nextButtonClassName?: string;

    /**
     * Custom function that it's called when we change the current carrousel's image.
     */
    onImageChange?: TOnImageChange;

    /**
     * Enable shadow for the carousel images for better visibility.
     */
    enableShadow?: boolean;

    /**
     * Fired when the user clicks on the carousel image. This does not fire when clicking on buttons inside the carousel such as next, prev, bottom navigation buttons.
     * This is not fired when swiping or moving mouse/touch on the carousel.
     */
    onClickImage?: () => void;

    /**
     * Number of pixels that the user can move the mouse or touch before the click is not fired.
     */
    onClickImageTolerance?: number;

    /**
     * Custom class names to override constrast element styles.
     */
    contrastClassName?: string;
  };

/**
 * @internal
 */
export type _RoomCardDetailsProps = Pick<
  RoomCardProps,
  'details' | 'detailsSeparator'
>;
