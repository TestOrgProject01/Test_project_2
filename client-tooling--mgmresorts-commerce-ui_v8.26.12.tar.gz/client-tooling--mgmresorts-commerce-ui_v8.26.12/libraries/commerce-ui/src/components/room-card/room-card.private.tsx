import React from 'react';

import clsx from 'clsx';

import { RenderImageHandler } from './room-card.types';

/**
 * Scroll element with default behavior.
 *
 * @internal
 */
export const scrollCarousel = (
  left: number,
  scrollableEl: HTMLElement | null,
  behavior: ScrollBehavior = 'smooth'
) => {
  if (!scrollableEl?.scrollTo) return;

  scrollableEl.scrollTo({
    behavior: behavior,
    left
  });
};

/**
 * Ensure that the carousel has an infinite loop.
 *
 * @internal
 */
export const ensureCarouselInfiniteLoop = (
  current: number,
  lastIndex: number
) => {
  if (current > lastIndex) return 0;

  if (current < 0) return lastIndex;

  return current;
};

/**
 * Default function to render carousel image.
 *
 * @internal
 */
export const renderCarouselImage: RenderImageHandler = ({ imageProps }) => (
  <img
    {...imageProps}
    className={clsx(
      'max-w-full',
      'flex-[0_0_auto]',
      'select-none',
      'pointer-events-none',
      imageProps.className
    )}
  />
);
