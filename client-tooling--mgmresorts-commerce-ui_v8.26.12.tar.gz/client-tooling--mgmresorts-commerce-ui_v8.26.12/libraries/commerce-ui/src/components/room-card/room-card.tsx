import React, { useId } from 'react';

import clsx from 'clsx';
import { nop } from 'rambdax';

import { Button } from '../button';
import { Icon } from '../icon';

import { RoomCardDetails } from './room-card-details';
import { RoomCardImagesCarousel } from './room-card-images-carousel';
import { SkeletonRoomCard } from './room-card-skeleton';
import { RoomCardProps } from './room-card.types';

const componentId = 'RoomCard';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const RoomCardTestIds = {
  actionButton: `${componentId}:actionButton`,
  component: componentId,
  priceText: `${componentId}:priceText`,
  tagText: `${componentId}:tagText`,
  title: `${componentId}:title`,
  titleButton: `${componentId}:titleButton`,
  unavailableContainer: `${componentId}:unavailableContainer`,
  unavailableText: `${componentId}:unavailableText`
};

/**
 * @public
 */
export const RoomCard = ({
  title,
  details,
  price,
  detailsSeparator,
  images,
  onActionClick = nop,
  actionButtonText = 'Select room',
  renderImage,
  isTagged,
  tagText = 'Included',
  infiniteCarousel,
  prevButtonProps,
  nextButtonProps,
  onTitleClick,
  titleButtonProps,
  isUnavailable = false,
  unavailableText = 'This room is no longer available.',
  onImageChange,
  enableSwipe = true,
  selected = false,
  loading = false,
  disabled = false
}: RoomCardProps) => {
  const titleAriaDescribedby = useId();

  const imageStyling = {
    roomCard:
      '[&_>img]:h-full [&_>img]:object-cover [&_>img]:object-center rounded-t-lg h-full [&_>img]:aspect-[1.78_/_1] d-sm:aspect-[1.78_/_1]',
  };

  return (
    <div
      className="flex flex-col w-full h-full relative bg-bg-surface rounded-border-radius-component-m"
      data-testid={RoomCardTestIds.component}
    >
      <div
        className={clsx('relative flex-shrink-0"', {
          grayscale: isUnavailable
        })}
      >
        <RoomCardImagesCarousel
          {...{ images, infiniteCarousel, renderImage }}
          nextButtonProps={{
            ...nextButtonProps,
            'aria-describedby': titleAriaDescribedby
          }}
          prevButtonProps={{
            ...prevButtonProps,
            'aria-describedby': titleAriaDescribedby
          }}
          onImageChange={onImageChange}
          enableSwipe={enableSwipe}
          className={imageStyling.roomCard}
        />
        {isTagged && (
          <span
            data-testid={RoomCardTestIds.tagText}
            className="absolute top-2 px-space-component-s py-[2.5px] bg-interaction-default text-white rounded-r-border-radius-component-xs text-body-regular-s z-50"
          >
            {tagText}
          </span>
        )}
      </div>
      <div className="flex flex-col space-y-space-component-m p-space-component-m">
        <div className="flex flex-col space-y-space-component-xs max-h-[2.563rem]">
          <button
            className="underline text-slate-950 text-left text-body-medium-l cursor-pointer w-fit"
            data-testid={RoomCardTestIds.titleButton}
            type="button"
            onClick={onTitleClick}
            {...titleButtonProps}
          >
            <h3
              data-testid={RoomCardTestIds.title}
              className="text-label-regular-l text-fg-default hover:text-digital-500 focus:text-digital-600 focus:border-digital-600"
              id={titleAriaDescribedby}
            >
              {title}
            </h3>
          </button>
          <RoomCardDetails {...{ details, detailsSeparator }} />
        </div>
        {isUnavailable ? (
          <div
            data-testid={RoomCardTestIds.unavailableContainer}
            className="flex self-stretch m-md:h-[100px] m-md:items-end gap-1"
          >
            <div className="min-w-6">
              <Icon
                name="exclamation-point-octagon"
                size="small"
                variant="outlined"
                color="red"
              />
            </div>
            <div
              className="text-body-regular-s text-red-600"
              data-testid={RoomCardTestIds.unavailableText}
            >
              {unavailableText}
            </div>
          </div>
        ) : (
          <>
            <div
              className="m-md:flex m-md:items-end m-md:min-h-[2.869rem] m-md:whitespace-pre-wrap text-body-regular-m text-fg-default"
              data-testid={RoomCardTestIds.priceText}
            >
              {price}
            </div>
            <Button
              label={actionButtonText}
              variant="secondary"
              size="small"
              onClick={onActionClick}
              buttonProps={{
                'aria-describedby': titleAriaDescribedby,
                'data-testid': RoomCardTestIds.actionButton
              }}
              selected={selected}
              loading={loading}
              disabled={disabled}
              {...(selected
                ? {
                    icon: 'checkmark'
                  }
                : undefined)}
            />
          </>
        )}
      </div>
    </div>
  );
};

RoomCard.Skeleton = SkeletonRoomCard;
