import * as React from 'react';

import clsx from 'clsx';

import { Button } from '../button';
import { Icon } from '../icon';

import { PriceAndSeatsBottomSheetProps } from './price-seats-bottom-sheet.types';

const componentId = 'PriceAndSeatsBottomSheet';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const PriceAndSeatsBottomSheetIds = {
  action: `${componentId}:action`,
  collapse: `${componentId}:collapse`,
  component: componentId,
  detail: `${componentId}:detail`,
  label: `${componentId}:label`,
  secondary: `${componentId}:secondary`
};

/**
 * @public
 */
export const PriceAndSeatsBottomSheet = ({
  label,
  buttonActionHandler,
  details,
  closeActionHandler,
  buttonLabel,
  children,
  isDisabled = false,
  variant = 'transparent',
  totalSeatsSelectedLabel,
  collapseButtonState = false,
  collapseActionHandler,
  loading = false
}: PriceAndSeatsBottomSheetProps) => {
  const isBAYG = variant === 'build-as-you-go';

  return (
    <div
      className={clsx('w-full flex flex-col rounded-t-2xl bg-brand-25', {
        'gap-space-component-l p-2x': !isBAYG,
        'py-2x pl-2x': isBAYG
      })}
      data-testid={PriceAndSeatsBottomSheetIds.component}
    >
      <div
        className={clsx('flex gap-space-component-m justify-between', {
          'pr-2x': isBAYG
        })}
      >
        <div className="flex flex-1 flex-col items-start max-w-[287px] m-md:max-w-full">
          {(!collapseButtonState || !collapseActionHandler) && (
            <>
              <h3
                data-testid={PriceAndSeatsBottomSheetIds.label}
                className="text-body-regular-m leading-[1.35rem] font-normal text-fg-default"
              >
                {label}
              </h3>

              <div
                data-testid={PriceAndSeatsBottomSheetIds.detail}
                className="text-body-regular-s leading-[1.181rem] text-fg-contrast"
              >
                {details}
              </div>
            </>
          )}
          {collapseButtonState && collapseActionHandler && (
            <div className="text-body-medium-xl">
              {totalSeatsSelectedLabel ?? ''}
            </div>
          )}
        </div>

        {closeActionHandler && !collapseActionHandler && (
          <div data-testid={PriceAndSeatsBottomSheetIds.secondary}>
            <button
              type="button"
              title="close-icon"
              onClick={closeActionHandler}
            >
              <Icon name={'symbol-x'} size={'small'} variant="outlined" />
            </button>
          </div>
        )}

        {collapseActionHandler && (
          <div data-testid={PriceAndSeatsBottomSheetIds.collapse}>
            <button
              type="button"
              onClick={collapseActionHandler}
              title="collapse button"
            >
              <Icon
                name={!collapseButtonState ? 'chevron-down' : 'chevron-up'}
                size="small"
                variant="outlined"
                testId={'ChevronIcon'}
              />
            </button>
          </div>
        )}
      </div>

      {(!collapseButtonState || !collapseActionHandler) && (
        <div
          className={clsx('w-full', {
            'flex flex-col gap-space-component-m pt-2x': isBAYG
          })}
        >
          {children}
        </div>
      )}

      {buttonActionHandler && (
        <div
          data-testid={PriceAndSeatsBottomSheetIds.action}
          className={clsx('', {
            'pt-1x pr-2x': isBAYG
          })}
        >
          <Button
            onClick={buttonActionHandler}
            label={buttonLabel ?? ''}
            fullWidth
            size={'large'}
            disabled={isDisabled}
            loading={loading}
          />
        </div>
      )}
    </div>
  );
};
