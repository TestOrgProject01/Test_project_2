import { ReactNode } from 'react';

/**
 * @public
 */
export interface PriceAndSeatsBottomSheetProps {
  label: string;
  details?: string;
  buttonLabel?: string;
  buttonActionHandler?: () => void;
  closeActionHandler?: () => void;
  children?: ReactNode;
  isDisabled?: boolean;
  totalSeatsSelectedLabel?: string;
  collapseActionHandler?: () => void;
  collapseButtonState?: boolean;
  variant?: 'transparent' | 'build-as-you-go';
  loading?: boolean;
}
