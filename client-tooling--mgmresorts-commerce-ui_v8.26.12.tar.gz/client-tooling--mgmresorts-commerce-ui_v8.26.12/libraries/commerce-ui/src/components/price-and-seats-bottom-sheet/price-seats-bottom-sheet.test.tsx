import React from 'react';

import {
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen
} from '../../util/test-utils';

import {
  PriceAndSeatsBottomSheet,
  PriceAndSeatsBottomSheetIds
} from './price-seats-bottom-sheet';
import { PriceAndSeatsBottomSheetMockData } from './price-seats-bottom-sheet.mocks';
import { PriceAndSeatsBottomSheetProps } from './price-seats-bottom-sheet.types';

describe('<PriceAndSeatsBottomSheet/> component', () => {
  const renderAccessibilityPriceAndSeatsBottomSheet = (
    props: PriceAndSeatsBottomSheetProps
  ) => create(<PriceAndSeatsBottomSheet {...props} />);

  const renderPriceAndSeatsBottomSheetToHtml = (
    props: PriceAndSeatsBottomSheetProps
  ) => renderToHtml(<PriceAndSeatsBottomSheet {...props} />);

  const onClick = jest.fn();

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityPriceAndSeatsBottomSheet({
        ...PriceAndSeatsBottomSheetMockData
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <PriceAndSeatsBottomSheet/> component', () => {
      renderAccessibilityPriceAndSeatsBottomSheet({
        ...PriceAndSeatsBottomSheetMockData
      });

      const element = screen.getByTestId(PriceAndSeatsBottomSheetIds.label);

      const PriceAndSeatsBottomSheetLabel = screen.getByText('Button Label');

      expect(element).toBeTruthy();
      expect(PriceAndSeatsBottomSheetLabel).toBeTruthy();
    });

    it('should trigger buttonActionHandler callback', () => {
      renderAccessibilityPriceAndSeatsBottomSheet({
        ...PriceAndSeatsBottomSheetMockData,
        buttonActionHandler: onClick,
        closeActionHandler: onClick
      });

      const button = screen.getByTestId(
        PriceAndSeatsBottomSheetIds.action
      ).firstElementChild;

      const secondaryButton = screen.getByTestId(
        PriceAndSeatsBottomSheetIds.secondary
      ).firstElementChild;

      expect(button).toBeTruthy();
      expect(secondaryButton).toBeTruthy();

      if (button) fireEvent.click(button);
      if (secondaryButton) fireEvent.click(secondaryButton);

      expect(onClick).toHaveBeenCalledTimes(2);
    });

    it('should trigger collapseActionHandler callback', () => {
      renderAccessibilityPriceAndSeatsBottomSheet({
        ...PriceAndSeatsBottomSheetMockData,
        buttonActionHandler: onClick,
        collapseActionHandler: onClick
      });

      const button = screen.getByTestId(
        PriceAndSeatsBottomSheetIds.action
      ).firstElementChild;

      const collapseButton = screen.getByTestId(
        PriceAndSeatsBottomSheetIds.collapse
      ).firstElementChild;

      expect(button).toBeTruthy();
      expect(collapseButton).toBeTruthy();

      if (collapseButton) fireEvent.click(collapseButton);

      expect(onClick).toHaveBeenCalledTimes(1);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderPriceAndSeatsBottomSheetToHtml(
        PriceAndSeatsBottomSheetMockData
      );

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
