import React, { useState } from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { EventInfoCarousel } from '../event-info-carousel';
import { SelectedSeatsCard } from '../selected-seats-card/selected-seats-card';
import { storyDefaultMockProps } from '../selected-seats-card/selected-seats-card.mock';

import { PriceAndSeatsBottomSheet } from './price-seats-bottom-sheet';
import { PriceAndSeatsBottomSheetMockData } from './price-seats-bottom-sheet.mocks';

export default {
  component: PriceAndSeatsBottomSheet,
  parameters: {
    actions: { argTypesRegex: null },
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen'
  },
  title: 'Components/PriceAndSeatsBottomSheet'
} as Meta<typeof PriceAndSeatsBottomSheet>;

const Template: StoryFn<typeof PriceAndSeatsBottomSheet> = (args) => (
  <div style={{ margin: '24px auto', maxWidth: 375 }}>
    <PriceAndSeatsBottomSheet {...args} />
  </div>
);

export const Main = Template.bind({});

Main.args = {
  ...PriceAndSeatsBottomSheetMockData,
  children: <SelectedSeatsCard {...storyDefaultMockProps} />
};

export const Carrousel = Template.bind({});

const Section = () => <div>Section...</div>;

Carrousel.args = {
  ...PriceAndSeatsBottomSheetMockData,
  children: (
    <EventInfoCarousel
      cardVariant="transparent"
      data={[
        {
          id: '1',
          price: 5,
          section: <Section />,
          surcharge: 5
        },
        {
          id: '2',
          price: 10,
          section: <Section />,
          surcharge: 5
        }
      ]}
    />
  )
};

const CollapseTemplate: StoryFn<typeof PriceAndSeatsBottomSheet> = (args) => {
  const [modalExpanded, setModalExpanded] = useState(true);

  return (
    <div style={{ margin: '24px auto', maxWidth: 375 }}>
      <PriceAndSeatsBottomSheet
        {...args}
        collapseButtonState={modalExpanded}
        collapseActionHandler={() => {
          setModalExpanded(!modalExpanded);
        }}
      />
    </div>
  );
};

export const CollapseButton = CollapseTemplate.bind({});

CollapseButton.args = {
  ...PriceAndSeatsBottomSheetMockData,
  children: (
    <EventInfoCarousel
      cardVariant="transparent"
      data={[
        {
          id: '1',
          price: 5,
          section: <Section />,
          surcharge: 5
        },
        {
          id: '2',
          price: 10,
          section: <Section />,
          surcharge: 5
        }
      ]}
    />
  ),
  totalSeatsSelectedLabel: 'Selected seats (2)'
};
