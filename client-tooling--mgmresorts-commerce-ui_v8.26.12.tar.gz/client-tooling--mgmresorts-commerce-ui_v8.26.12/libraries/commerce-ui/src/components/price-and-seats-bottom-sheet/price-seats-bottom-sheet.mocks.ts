import { PriceAndSeatsBottomSheetProps } from './price-seats-bottom-sheet.types';

export const PriceAndSeatsBottomSheetMockData: PriceAndSeatsBottomSheetProps = {
  buttonActionHandler: () => {},
  buttonLabel: 'Button Label',
  closeActionHandler: () => {},
  details: 'Additional details goes here',
  isDisabled: false,
  label: 'Bottom Sheet Label',
  variant: 'build-as-you-go'
};
