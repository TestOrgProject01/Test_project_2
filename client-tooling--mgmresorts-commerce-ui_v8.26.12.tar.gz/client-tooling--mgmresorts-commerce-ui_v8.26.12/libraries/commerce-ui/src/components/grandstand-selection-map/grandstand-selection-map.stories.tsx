import React, { useEffect, useState } from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { GrandStandSelectionMap } from './grandstand-selection-map';
import { GrandStandSelectionMapProps } from './grandstand-selection-map.types';
import GrandStandSelectionMapSvgBackground from './mocks/f1-circuit-map.svg';

export default {
  argTypes: {
    onMarkerClick: { action: 'onMarkerClick' },
    onToggleAccessibility: { action: 'onToggleAccessibility' }
  },
  component: GrandStandSelectionMap,
  title: 'Components/GrandStandSelectionMap'
} as Meta<typeof GrandStandSelectionMap>;

const TemplateWrapper = (props: Partial<GrandStandSelectionMapProps>) => {
  const [svgBg, setSvgBg] = useState<string | null>(null);

  useEffect(() => {
    // This was created to gets work in both environment: Jest and Storybook.
    async function fetchSvgBackground() {
      const svgString = await fetch(GrandStandSelectionMapSvgBackground).then(
        (res) => res.text()
      );

      setSvgBg(svgString);
    }

    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    fetchSvgBackground();
  }, []);

  return (
    <div className="h-[27rem] w-full">
      <GrandStandSelectionMap {...props} svgBg={svgBg} />
    </div>
  );
};

const Template: StoryFn<typeof GrandStandSelectionMap> = (args) => (
  <TemplateWrapper {...args} />
);

export const Main = Template.bind({});

Main.args = {};
