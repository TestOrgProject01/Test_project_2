import fs from 'node:fs';
import path from 'node:path';

import React from 'react';

import {
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen,
  waitFor
} from '../../util/test-utils';

import {
  GrandStandSelectionMap,
  GrandStandSelectionMapTestIds
} from './grandstand-selection-map';
import { GrandStandSelectionMapProps } from './grandstand-selection-map.types';

const createWrapper = (props?: Partial<GrandStandSelectionMapProps>) => {
  const svgBg = fs
    .readFileSync(path.resolve(__dirname, 'mocks/f1-circuit-map.svg'))
    .toString();

  const Wrapper = () => <GrandStandSelectionMap {...props} {...{ svgBg }} />;

  return { Wrapper };
};

describe('<GrandStandSelectionMap/> component', () => {
  const renderAccessibilityGrandStandSelectionMap = (
    props: GrandStandSelectionMapProps
  ) => {
    const { Wrapper } = createWrapper(props);

    return create(<Wrapper />);
  };

  const renderGrandStandSelectionMapToHtml = (
    props: GrandStandSelectionMapProps
  ) => {
    const { Wrapper } = createWrapper(props);

    return renderToHtml(<Wrapper />);
  };

  const onClick = jest.fn();

  const baseProps: GrandStandSelectionMapProps = {
    disabled: false,
    onMarkerClick: onClick
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityGrandStandSelectionMap(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <GrandStandSelectionMap /> component', async () => {
      renderAccessibilityGrandStandSelectionMap({
        ...baseProps
      });

      const element = screen.getByTestId(
        GrandStandSelectionMapTestIds.component
      );

      expect(element).toBeTruthy();

      const marker = await waitFor(() => {
        const element = screen
          .getByTestId(GrandStandSelectionMapTestIds.component)
          .querySelector('svg .marker > path');

        expect(element).not.toBeNull();

        return element!;
      });

      expect(marker).toBeTruthy();
      fireEvent.click(marker);
      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should render with custom width and height', () => {
      renderAccessibilityGrandStandSelectionMap({
        ...baseProps,
        height: 150,
        width: 150
      });

      expect(
        screen.getByTestId(GrandStandSelectionMapTestIds.component)
      ).toHaveStyle({
        height: '150px',
        width: '150px'
      });
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderGrandStandSelectionMapToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
