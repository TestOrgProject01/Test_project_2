import { MouseEvent } from 'react';

import { SizedSVGContainerProps } from '../sized-svg-container';

/**
 * @public
 */
export interface GrandStandSelectionMapProps {
  /**
   * mapUrl it will used to fecth the svg grandstand map
   */
  svgBg?: string | null;
  /**
   * If set as disabled it will be disable all the markers and accessibility toggle.
   */
  disabled?: boolean;
  /**
   * If set as onMarkerClick this will be fired only for elements containing id
   */
  onMarkerClick?: (event: MouseEvent<HTMLDivElement>) => void;
  /**
   * Container width
   */
  width?: number;
  /**
   * Container height
   */
  height?: number;
  /**
   * Customize the container of main SVG element
   */
  svgContainerProps?: SizedSVGContainerProps['containerProps'];
}
