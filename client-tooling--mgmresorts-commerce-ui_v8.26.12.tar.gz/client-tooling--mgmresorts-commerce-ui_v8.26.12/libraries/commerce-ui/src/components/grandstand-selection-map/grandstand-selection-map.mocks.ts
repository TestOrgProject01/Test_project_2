import { GrandStandSelectionMapProps } from './grandstand-selection-map.types';

const defaultProps = {
  disabled: false,
  onMarkerClick: () => {},
  onToggleAccessibility: () => {}
};

export const storyDefaultMockProps: GrandStandSelectionMapProps = {
  ...defaultProps
};
