import React, { useEffect, useRef, useState } from 'react';

import clsx from 'clsx';

import { SizedSVGContainer } from '../sized-svg-container';

import { GrandStandSelectionMapProps } from './grandstand-selection-map.types';

import './grandstand-selection-map.styles.scss';

const componentId = 'GrandStandSelectionMap';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const GrandStandSelectionMapTestIds = {
  component: componentId
};

/**
 * @public
 */
export const GrandStandSelectionMap = ({
  svgBg,
  disabled,
  onMarkerClick: onClick,
  width,
  height,
  svgContainerProps
}: GrandStandSelectionMapProps) => {
  const rootElement = useRef<HTMLDivElement | null>(null);

  const [svgSize, setSvgSize] = useState({
    height: width || '100%',
    width: height || '100%'
  });

  useEffect(() => {
    function calculateSize() {
      /* istanbul ignore if */
      if (!rootElement.current)
        // it's really difficult to enter a unit test and it's heavy work to mock the "useRef" function.
        return;

      setSvgSize({
        height: rootElement.current.clientHeight,
        width: rootElement.current.clientWidth
      });
    }

    window.addEventListener('resize', calculateSize);
    calculateSize();

    return () => {
      window.removeEventListener('resize', calculateSize);
    };
  }, []);

  return (
    <div
      ref={rootElement}
      data-testid={GrandStandSelectionMapTestIds.component}
      className={clsx('grandstand-selection-map-container', {
        disabled
      })}
      onClick={(e) => {
        // `e.target` was used instead of `e.currentTarget` just because we were looking
        // at the clicked element inside the wrapper. `currentTarget` refers to the "div"
        // (wrapper), and `target` (child of wrapper) the clicked element which propagates
        // the `click` event to the parents.
        //
        // This was the reason to use cast here!
        const element = e.target as SVGPathElement;
        if (!!element.id && typeof onClick === 'function') onClick(e);
      }}
      // keep these width and height properties on the styles attribute due to having
      // priority on the CSS style
      style={{ height, width }}
    >
      {!!svgBg && (
        <SizedSVGContainer
          className="bg-seatmap"
          svgSrc={svgBg}
          containerProps={svgContainerProps}
          {...svgSize}
        />
      )}
    </div>
  );
};
