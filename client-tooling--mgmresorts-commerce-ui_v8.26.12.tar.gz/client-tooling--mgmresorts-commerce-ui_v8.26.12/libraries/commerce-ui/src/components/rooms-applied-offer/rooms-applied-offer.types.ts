/**
 * @public
 */
export interface RoomsAppliedOfferProps {
  title: string;
  titleDataCMS?: string;
  viewMoreOffersTitle: string;
  viewMoreOffersTitleDataCMS?: string;
  onViewMoreOffersClick?: () => void;
  subtitle: string;
  shortDescription?: string;
  averageRoomRate?: string;
  averageRoomRateDataCMS?: string;
  dailyResortFee?: string;
  dailyResortFeeDataCMS?: string;
  averagePerNight?: string;
  averagePerNightDataCMS?: string;
  learnMoreTitle: string;
  learnMoreTitleDataCMS?: string;
  onLearnMoreClick?: () => void;
  imgSrc?: string;
  altImg?: string;
}
