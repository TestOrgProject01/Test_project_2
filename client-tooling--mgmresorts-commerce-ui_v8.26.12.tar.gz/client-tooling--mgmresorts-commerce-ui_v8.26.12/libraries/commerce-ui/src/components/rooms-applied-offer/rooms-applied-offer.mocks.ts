import { RoomsAppliedOfferProps } from './rooms-applied-offer.types';

export const RoomsAppliedOfferMockData: RoomsAppliedOfferProps = {
  averagePerNight: '$245 average per night',
  averageRoomRate: '$200 average room rate (<s>was $275</s>)',
  dailyResortFee: '+ $45 daily resort fee',
  learnMoreTitle: 'Learn more',
  onLearnMoreClick: () => {},
  onViewMoreOffersClick: () => {},
  shortDescription: 'Up to 3 Comp Nights, $65 FREEPLAY®, $50 Resort Credit',
  subtitle: 'Your MGM Rewards Offer!',
  title: 'Applied offer',
  viewMoreOffersTitle: 'View more offers'
};
