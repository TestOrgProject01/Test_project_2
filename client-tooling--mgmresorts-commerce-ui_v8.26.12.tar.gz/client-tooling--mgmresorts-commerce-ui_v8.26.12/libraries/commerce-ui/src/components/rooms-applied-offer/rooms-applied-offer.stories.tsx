import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsAppliedOffer } from './rooms-applied-offer';

export default {
  argTypes: {
    onLearnMoreClick: { action: 'onLearnMoreClick' },
    onViewMoreOffersClick: { action: 'onViewMoreOffersClick' }
  },
  component: RoomsAppliedOffer,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/RoomsAppliedOffer'
} as Meta<typeof RoomsAppliedOffer>;

const Template: StoryFn<typeof RoomsAppliedOffer> = (args) => {
  return (
    <div>
      <RoomsAppliedOffer {...args} />
    </div>
  );
};

export const Regular = Template.bind({});

Regular.args = {
  averagePerNight: '$245 average per night',
  averageRoomRate: '$200 average room rate (<s>was $275</s>)',
  dailyResortFee: '+ $45 daily resort fee',
  learnMoreTitle: 'Learn more',
  onLearnMoreClick: () => {},
  onViewMoreOffersClick: () => {},
  shortDescription: 'Up to 3 Comp Nights, $65 FREEPLAY®, $50 Resort Credit',
  subtitle: 'Your MGM Rewards Offer!',
  title: 'Applied offer',
  viewMoreOffersTitle: 'View more offers'
};

export const PO = Template.bind({});

PO.args = {
  averagePerNight: undefined,
  averageRoomRate: undefined,
  dailyResortFee: undefined,
  imgSrc:
    'https://static.mgmresorts.com/transform/gDVfq1q8t61/18-BEL-03963-0048---Bellagio-Hero-Shot---Resize-v00PP',
  learnMoreTitle: 'Learn more',
  onLearnMoreClick: () => {},
  onViewMoreOffersClick: () => {},
  shortDescription: 'Up to 3 Comp Nights, $65 FREEPLAY®, $50 Resort Credit',
  subtitle: 'Your MGM Rewards Offer!',
  title: 'Applied offer',
  viewMoreOffersTitle: 'View more offers'
};
