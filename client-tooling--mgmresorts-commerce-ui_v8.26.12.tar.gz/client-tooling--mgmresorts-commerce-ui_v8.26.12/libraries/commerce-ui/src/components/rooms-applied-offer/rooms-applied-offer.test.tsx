import React from 'react';

import {
  axe,
  fireEvent,
  screen,
  createWithDesignTokensProvider,
  renderToHtmlWithDesignTokensProvider
} from '../../util/test-utils';

import {
  RoomsAppliedOffer,
  RoomsAppliedOfferTestIds
} from './rooms-applied-offer';
import { RoomsAppliedOfferMockData } from './rooms-applied-offer.mocks';
import { RoomsAppliedOfferProps } from './rooms-applied-offer.types';

const defaultProps: RoomsAppliedOfferProps = {
  averagePerNight: 'averagePerNight',
  averageRoomRate: 'averageRoomRate',
  dailyResortFee: 'dailyResortFee',
  learnMoreTitle: 'learnMoreTitle',
  shortDescription: 'shortDescription',
  subtitle: 'subtitle',
  title: 'title',
  viewMoreOffersTitle: 'viewMoreOffersTitle'
};

describe('<RoomsAppliedOffer/> component', () => {
  const renderComponent = (props: RoomsAppliedOfferProps) =>
    createWithDesignTokensProvider(<RoomsAppliedOffer {...props} />);

  const renderHTML = (props: RoomsAppliedOfferProps) =>
    renderToHtmlWithDesignTokensProvider(<RoomsAppliedOffer {...props} />);

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', async () => {
      const actual = renderComponent(RoomsAppliedOfferMockData);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('custom labels', async () => {
      renderComponent(defaultProps);

      screen.getByText('averagePerNight');
      screen.getByText('averageRoomRate');
      screen.getByText('dailyResortFee');
      screen.getByText('learnMoreTitle');
      screen.getByText('shortDescription');
      screen.getByText('subtitle');
      screen.getByText('title');
      screen.getByText('viewMoreOffersTitle');

      expect(
        screen.queryByTestId(RoomsAppliedOfferTestIds.offerImg)
      ).toBeNull();
    });
  });

  /**
   * Actions tests.
   */
  describe('actions', () => {
    it('onViewMoreOffersClick', () => {
      const onViewMoreOffersClick = jest.fn();
      const viewMoreOffersTitle = 'viewMoreOffersTitle';

      renderComponent({
        ...RoomsAppliedOfferMockData,
        onViewMoreOffersClick,
        viewMoreOffersTitle
      });

      fireEvent.click(screen.getByText(viewMoreOffersTitle));
      expect(onViewMoreOffersClick).toHaveBeenCalledTimes(1);
    });

    it('onViewMoreOffersClick', () => {
      const learnMoreTitle = 'viewMoreOffersTitle';
      const onLearnMoreClick = jest.fn();

      renderComponent({
        ...RoomsAppliedOfferMockData,
        learnMoreTitle,
        onLearnMoreClick
      });

      fireEvent.click(screen.getByText(learnMoreTitle));
      expect(onLearnMoreClick).toHaveBeenCalledTimes(1);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderHTML(RoomsAppliedOfferMockData);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
