import React from 'react';

import { Image, TextLink, Typography } from '@mgmresorts/mgm-ui';
import clsx from 'clsx';

import { useMediaQuery } from '../../util';

import { RoomsMarkdown } from '../rooms-markdown';

import { RoomsAppliedOfferProps } from './rooms-applied-offer.types';

const componentId = 'RoomsAppliedOffer';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const RoomsAppliedOfferTestIds = {
  component: componentId,
  offerImg: `${componentId}:offerImg`
};

/**
 * @public
 */
export const RoomsAppliedOffer = (props: RoomsAppliedOfferProps) => {
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  const { imgSrc, altImg } = props;

  const hideBannerImg = !imgSrc || !isDesktop;

  return (
    <div
      data-testid={RoomsAppliedOfferTestIds.component}
      className="flex flex-col items-start gap-2"
    >
      <div className="flex items-start gap-4 self-stretch">
        <Typography
          variant="body-medium-m"
          className="text-digital-900 flex-1"
          data-cms={props.titleDataCMS}
          as="h2"
        >
          {props.title}
        </Typography>

        <Typography
          variant="body-regular-s"
          className="flex justify-end items-center gap-1 flex-1"
          data-cms={props.viewMoreOffersTitleDataCMS}
        >
          <TextLink
            onClick={props.onViewMoreOffersClick}
            variant="large"
            className="!leading-5 !p-[0] !text-body-regular-s !outline-none"
            aria-label={props.viewMoreOffersTitle}
            button={true}
          >
            {props.viewMoreOffersTitle}
          </TextLink>
        </Typography>
      </div>

      <div className="flex p-2x items-start gap-2 self-stretch rounded-border-radius-component-m bg-white">
        <div
          className={clsx(
            'flex items-start flex-1',
            isDesktop ? 'flex-row gap-4' : 'flex-col gap-1'
          )}
        >
          {!hideBannerImg && (
            <Image
              className="[&>img]:rounded-lg [&>img]:w-16 [&>img]:h-16 !w-16 !h-16"
              src={imgSrc}
              alt={altImg || ''}
              lazyLoading={true}
              fit="cover"
              data-testid={RoomsAppliedOfferTestIds.offerImg}
            />
          )}

          <div className="flex flex-1 flex-col justify-center items-start self-stretch">
            <div className="flex flex-col justify-center items-start self-stretch">
              <Typography
                variant={isDesktop ? 'body-medium-m' : 'body-medium-s'}
                className="self-stretch text-digital-900 line-clamp-2"
                as="h3"
              >
                {props.subtitle}
              </Typography>

              {props.shortDescription && (
                <Typography
                  variant="body-regular-s"
                  className="self-stretch text-digital-900 line-clamp-2"
                >
                  <RoomsMarkdown strictMode={true}>
                    {props.shortDescription}
                  </RoomsMarkdown>
                </Typography>
              )}
            </div>
          </div>

          {(props.averageRoomRate ||
            props.dailyResortFee ||
            props.averagePerNight) && (
            <div className="flex flex-1 py-1x flex-col items-start self-stretch">
              <div className="flex flex-col items-start">
                {props.averageRoomRate && (
                  <Typography
                    variant="body-regular-s"
                    className="text-gray-900"
                    data-cms={props.averageRoomRateDataCMS}
                  >
                    <RoomsMarkdown strictMode={true}>
                      {props.averageRoomRate}
                    </RoomsMarkdown>
                  </Typography>
                )}

                {props.dailyResortFee && (
                  <Typography
                    variant="body-regular-s"
                    className="text-gray-900"
                    data-cms={props.dailyResortFeeDataCMS}
                  >
                    <RoomsMarkdown strictMode={true}>
                      {props.dailyResortFee}
                    </RoomsMarkdown>
                  </Typography>
                )}
              </div>

              {props.averagePerNight && (
                <Typography
                  variant="body-medium-s"
                  className="text-digital-900"
                  data-cms={props.averagePerNightDataCMS}
                >
                  <RoomsMarkdown strictMode={true}>
                    {props.averagePerNight}
                  </RoomsMarkdown>
                </Typography>
              )}
            </div>
          )}

          <Typography
            variant="body-regular-s"
            className={clsx(
              'text-digital-900',
              'flex items-end gap-1',
              isDesktop && 'self-center'
            )}
            data-cms={props.learnMoreTitleDataCMS}
          >
            <TextLink
              variant="large"
              className="!leading-5 !p-[0] !text-body-regular-s !outline-none"
              onClick={props.onLearnMoreClick}
              button={true}
              aria-label={props.learnMoreTitle}
            >
              {props.learnMoreTitle}
            </TextLink>
          </Typography>
        </div>
      </div>
    </div>
  );
};
