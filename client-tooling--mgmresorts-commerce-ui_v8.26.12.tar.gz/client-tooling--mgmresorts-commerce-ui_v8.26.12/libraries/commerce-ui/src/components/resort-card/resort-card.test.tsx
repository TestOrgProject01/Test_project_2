jest.mock('react', () => ({
  ...jest.requireActual<Record<string, unknown>>('react'),
  useId: jest.fn().mockReturnValue('')
}));

import React, { useId } from 'react';

import { fireEvent, render, screen } from '@testing-library/react';

import { axe, renderToHtml } from '../../util/test-utils';

import { ButtonProps } from '../button';

import { ResortCard, ResortCardTestIds } from './resort-card';
import { ResortCardProps } from './resort-card.types';

describe('<ResortCard /> component', () => {
  const defaultProps: ResortCardProps = {
    mediaSrc: 'test-image.jpg',
    onActionClick: jest.fn(),
    price: 452,
    title: 'Test Resort'
  };

  const ResortCardWrapper = (props: Partial<ResortCardProps>) => (
    <ResortCard {...defaultProps} {...props} />
  );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      expect(
        render(<ResortCardWrapper variant={'transparent'} />)
      ).toMatchSnapshot();
    });

    it('should use H1 element on priceText element with the correct classes using the build-as-you-go variant', () => {
      render(<ResortCardWrapper variant={'build-as-you-go'} />);

      const h1PriceText = screen
        .getByTestId(ResortCardTestIds.priceText)
        .querySelector('h1#price');

      expect(h1PriceText).toBeTruthy();

      expect(h1PriceText).toHaveClass('text-body-medium-xl text-gray-900');
    });

    it('should use the correct rounded corners', () => {
      render(<ResortCardWrapper variant={'build-as-you-go'} />);

      expect(screen.getByTestId(ResortCardTestIds.component)).toHaveClass(
        'm-md:overflow-hidden m-md:rounded-t-lg m-md:rounded-b-2xl'
      );
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the ResortCard component correctly with default props', () => {
      render(<ResortCardWrapper {...defaultProps} variant={'transparent'} />);

      expect(
        screen.getByTestId(ResortCardTestIds.component)
      ).toBeInTheDocument();

      expect(screen.getByTestId(ResortCardTestIds.title)).toHaveTextContent(
        'Test Resort'
      );

      expect(screen.getByTestId(ResortCardTestIds.priceText)).toHaveTextContent(
        'Included in package($452 total per night)'
      );
    });

    it('should render the ResortCard component correctly with "build-as-you-go" variant', () => {
      const props: ResortCardProps = {
        ...defaultProps,
        price: 150,
        variant: 'build-as-you-go'
      };

      render(<ResortCardWrapper {...props} />);

      expect(
        screen.getByTestId(ResortCardTestIds.component)
      ).toBeInTheDocument();

      expect(screen.getByTestId(ResortCardTestIds.title)).toHaveTextContent(
        'Test Resort'
      );

      expect(screen.getByTestId(ResortCardTestIds.priceText)).toHaveTextContent(
        '+$150'
      );
    });

    it('should render the price correctly when price is a number', () => {
      const props = { ...defaultProps, price: 150 };
      render(<ResortCardWrapper {...props} variant={'transparent'} />);

      expect(screen.getByTestId(ResortCardTestIds.priceText)).toHaveTextContent(
        'Included in package($150 total per night)'
      );
    });

    it('should render the price correctly when price is a function', () => {
      const priceFunction = () => <span>my custom price: $200</span>;
      const props = { ...defaultProps, price: priceFunction };
      render(<ResortCardWrapper {...props} />);

      expect(screen.getByTestId(ResortCardTestIds.priceText)).toHaveTextContent(
        'my custom price: $200'
      );
    });

    it('should render the default tagText when isTagged is true', () => {
      const props = { ...defaultProps, isTagged: true };
      render(<ResortCardWrapper {...props} />);

      expect(screen.getByTestId(ResortCardTestIds.tagText)).toHaveTextContent(
        'Included'
      );
    });

    it('should render the correct tagText when isTagged is true', () => {
      const props = { ...defaultProps, isTagged: true, tagText: 'Discounted' };
      render(<ResortCardWrapper {...props} />);

      expect(screen.getByTestId(ResortCardTestIds.tagText)).toHaveTextContent(
        'Discounted'
      );
    });

    it('should not render the tagText when isTagged is false', () => {
      const props = { ...defaultProps, isTagged: false, tagText: 'Discounted' };
      render(<ResortCardWrapper {...props} />);

      expect(screen.queryByText('Discounted')).not.toBeInTheDocument();
    });

    it('should call the onActionClick function when the button is clicked', () => {
      const onActionClick = jest.fn();
      const props = { ...defaultProps, onActionClick };
      render(<ResortCardWrapper {...props} />);

      fireEvent.click(screen.getByText('Select'));
      expect(onActionClick).toHaveBeenCalledTimes(1);
    });

    it('should call the onTitleClick function when the title is clicked', () => {
      const onTitleClick = jest.fn();
      const props = { ...defaultProps, onTitleClick };
      render(<ResortCardWrapper {...props} />);

      fireEvent.click(screen.getByTestId(ResortCardTestIds.title));
      expect(onTitleClick).toHaveBeenCalledTimes(1);
    });

    it('should call the onThumbnailClick function when the figure is clicked', () => {
      const onThumbnailClick = jest.fn();
      const props = { ...defaultProps, onThumbnailClick };
      render(<ResortCardWrapper {...props} />);

      fireEvent.click(screen.getByTestId(ResortCardTestIds.mediaImageWrapper));
      expect(onThumbnailClick).toHaveBeenCalledTimes(1);
    });

    it('should render image with custom media props correctly', () => {
      const props: ResortCardProps = {
        ...defaultProps,
        mediaProps: {
          'aria-label': 'custom title aria label',
          title: 'custom title'
        }
      };

      render(<ResortCardWrapper {...props} />);

      expect(screen.getByTestId(ResortCardTestIds.mediaImage)).toHaveAttribute(
        'title',
        'custom title'
      );

      expect(screen.getByTestId(ResortCardTestIds.mediaImage)).toHaveAttribute(
        'aria-label',
        'custom title aria label'
      );
    });

    it('should render title and action button with custom button props correctly', () => {
      const defaultButtonProps: ButtonProps['buttonProps'] = {
        type: 'button'
      };

      const props: ResortCardProps = {
        ...defaultProps,
        actionButtonProps: {
          ...defaultButtonProps
        },
        titleButtonProps: {
          ...defaultButtonProps
        }
      };

      render(<ResortCardWrapper {...props} />);

      expect(screen.getByTestId(ResortCardTestIds.titleButton)).toHaveAttribute(
        'type',
        'button'
      );

      expect(screen.getByText('Select')).toHaveAttribute('type', 'button');
    });

    it('should render the disabled properties if they are provided correctly', () => {
      const defaultButtonProps = {
        disabledText: 'Unavailable',
        isDisabled: true
      };

      const props: ResortCardProps = {
        ...defaultProps,
        ...defaultButtonProps
      };

      render(<ResortCardWrapper {...props} />);

      expect(screen.getByText(defaultButtonProps.disabledText)).toBeDisabled();
    });

    it('should render the unavailable properties if they are provided correctly', () => {
      const defaultUnavailableProps = {
        isUnavailable: true,
        unavailableText: 'random test'
      };

      const props: ResortCardProps = {
        ...defaultProps,
        ...defaultUnavailableProps
      };

      render(<ResortCardWrapper {...props} />);

      expect(
        screen.getByTestId(ResortCardTestIds.unavailableText)
      ).toHaveTextContent(defaultUnavailableProps.unavailableText);

      expect(
        screen.getByTestId(ResortCardTestIds.unavailableContainer)
      ).toBeInTheDocument();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      expect(
        await axe(renderToHtml(<ResortCardWrapper />))
      ).toHaveNoViolations();
    });

    it('should have id with random value on the title element', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValueOnce(randomId);
      render(<ResortCardWrapper />);

      expect(screen.getByTestId(ResortCardTestIds.title)).toHaveAttribute(
        'id',
        randomId
      );

      (useId as jest.Mock).mockReset();
    });

    it('should have aria-describedby on action button', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValueOnce(randomId);
      render(<ResortCardWrapper />);

      expect(
        screen.getByTestId(ResortCardTestIds.actionButton)
      ).toHaveAttribute('aria-describedby', randomId);

      (useId as jest.Mock).mockReset();
    });
  });
});
