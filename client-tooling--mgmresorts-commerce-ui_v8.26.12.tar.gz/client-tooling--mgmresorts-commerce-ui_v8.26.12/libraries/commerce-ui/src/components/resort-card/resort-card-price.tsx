import React, { ReactNode } from 'react';

import { ResortCardTestIds } from './resort-card';

export interface ResortCardPriceProps {
  /**
   * The price of the resort.
   */
  price: string;
  priceLabel?: string;
  infoLines?: (string | ReactNode)[];
}

export const ResortCardPrice = ({
  price,
  priceLabel,
  infoLines = []
}: ResortCardPriceProps) => {
  return (
    <div data-testid={ResortCardTestIds.transparentPrice}>
      <div
        id="price-details"
        aria-label="Price per night"
        className="inline-flex items-end h-7 gap-1 text-black w-full leading-none"
      >
        <h1
          id="price"
          aria-describedby="price-details"
          className="text-body-medium-xl leading-none"
        >
          {price}
        </h1>
        {priceLabel && <p className="text-body-regular-s">{priceLabel}</p>}
      </div>
      <div
        className="text-body-regular-s text-informative-default"
        aria-describedby="price-details"
      >
        {infoLines.map((infoLine, index) => (
          <React.Fragment key={index}>
            {infoLine}
            <br />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};
