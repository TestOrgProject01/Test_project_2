import React, { useId, useMemo } from 'react';

import { Icon } from '@mgmresorts/mgm-ui';
import clsx from 'clsx';
import { match } from 'ts-pattern';

import { formatCurrency, isFunctionGuard } from '../../util';

import { Button } from '../button';

import { ResortCardPrice } from './resort-card-price';
import { SkeletonResortCard } from './resort-card-skeleton';
import { ResortCardProps, _PriceTextMatchInput } from './resort-card.types';

const componentId = 'ResortCard';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const ResortCardTestIds = {
  actionButton: `${componentId}:actionButton`,
  component: componentId,
  mediaImage: `${componentId}:mediaImage`,
  mediaImageWrapper: `${componentId}:mediaImageWrapper`,
  priceText: `${componentId}:priceText`,
  tagText: `${componentId}:tagText`,
  title: `${componentId}:title`,
  titleButton: `${componentId}:titleButton`,
  transparentPrice: `${componentId}:transparentPrice`,
  unavailableContainer: `${componentId}:unavailableContainer`,
  unavailableText: `${componentId}:unavailableText`
};

/**
 * @public
 */
export const ResortCard = ({
  title,
  mediaSrc,
  actionText = 'Select',
  onActionClick,
  onTitleClick,
  onThumbnailClick,
  price,
  variant,
  mediaProps,
  isTagged,
  tagText = 'Included',
  actionButtonProps,
  titleButtonProps,
  selected = false,
  isDisabled = false,
  disabledText,
  isUnavailable = false,
  unavailableText = 'This resort is no longer available, please select another resort.',
  priceDescription,
  currencyOptions
}: ResortCardProps) => {
  const isTransparent = variant === 'transparent';
  const titleId = useId();

  const formattedPrice =
    typeof price !== 'function'
      ? formatCurrency(price, {
          fraction: false,
          signDisplay: !isTransparent ? 'always' : 'never',
          ...currencyOptions
        })
      : '';

  const priceText = match<_PriceTextMatchInput, React.ReactNode>({
    price,
    variant
  })
    .with({ price: isFunctionGuard() }, ({ price: fn }) => fn())
    .with({ variant: 'build-as-you-go' }, () => (
      <>
        <div className="flex flex-col m-md:block">
          <h1
            id="price"
            aria-describedby="price-details"
            className="text-body-medium-xl text-gray-900"
          >
            {formattedPrice}
          </h1>
          <p className="text-gray-600 font-regular">
            {isTagged
              ? priceDescription?.included ?? 'Included in package total'
              : priceDescription?.default ?? 'To package total'}
          </p>
        </div>
      </>
    ))
    .otherwise(() => (
      <>
        <div className="hidden m-md:block text-gray-600">
          {!isTagged ? (
            <p>{formattedPrice} per night</p>
          ) : (
            <>
              <p>{formattedPrice} per night</p>
              <p>(Included in package)</p>
            </>
          )}
        </div>

        <div className="m-md:hidden">
          Included in package
          <br />({formattedPrice} total per night)
        </div>
      </>
    ));

  const UnavailableWrapper: React.FC<{
    text: ResortCardProps['unavailableText'];
  }> = ({ text }) => {
    return (
      <div
        data-testid={ResortCardTestIds.unavailableContainer}
        className="flex flex-row gap-1 min-h-[57px] m-md:min-h-[38px]"
      >
        <div className="min-w-6">
          <Icon
            name="exclamation-point-octagon"
            size="small"
            variant="outlined"
            color="red"
          />
        </div>

        <div
          className="text-body-regular-s leading-[1.181rem] text-red-600"
          data-testid={ResortCardTestIds.unavailableText}
        >
          {text}
        </div>
      </div>
    );
  };

  const CardContent = useMemo(() => {
    if (isUnavailable) {
      return <UnavailableWrapper text={unavailableText} />;
    }

    return (
      <>
        <div
          className="text-body-regular-s leading-[1.181rem] m-md:text-body-regular-m m-md:leading-[1.35rem]"
          data-testid={ResortCardTestIds.priceText}
        >
          {priceText}
        </div>

        <Button
          buttonProps={{
            ...actionButtonProps,
            'aria-describedby': titleId,
            className:
              'text-body-regular-m leading-[1.181rem] h-10 rounded-lg m-md:rounded-md',
            'data-testid': ResortCardTestIds.actionButton
          }}
          className="text-body-regular-m"
          disabled={isDisabled}
          label={disabledText ?? actionText}
          onClick={async () => {
            await onActionClick?.();
          }}
          variant="secondary"
          type="button"
          size="small"
          fullWidth
          selected={selected}
          custom
          {...(selected
            ? {
                icon: 'checkmark'
              }
            : undefined)}
        />
      </>
    );
  }, [
    isUnavailable,
    unavailableText,
    priceText,
    actionButtonProps,
    isDisabled,
    disabledText,
    actionText,
    onActionClick,
    selected,
    titleId
  ]);

  return (
    <div
      className="flex flex-row w-full gap-space-component-m m-md:bg-bg-surface m-md:flex-col m-md:max-w-[23.125rem] h-full m-md:overflow-hidden m-md:rounded-t-lg m-md:rounded-b-2xl"
      data-testid={ResortCardTestIds.component}
    >
      {/** Using an aspect ratio box to work with the safari browser: https://css-tricks.com/aspect-ratio-boxes/ */}
      <figure
        className={clsx(
          'relative cursor-pointer min-h-[9.25rem] h-auto w-[9.25rem] m-md:w-full m-md:pb-[calc(100%_/_(16_/_9_))] m-md:aspect-16x9',
          {
            'aspect-1x1': !isTransparent,
            'aspect-3x4': isTransparent,
            grayscale: isUnavailable
          }
        )}
        data-testid={ResortCardTestIds.mediaImageWrapper}
        onClick={onThumbnailClick}
      >
        {isTagged && !!tagText && (
          <span
            data-testid={ResortCardTestIds.tagText}
            className="absolute top-2 px-space-component-s py-[2.5px] bg-interaction-default text-white rounded-r-border-radius-component-xs text-body-regular-s leading-[1.181rem] z-10"
          >
            {tagText}
          </span>
        )}

        <img
          src={mediaSrc}
          alt={title}
          {...mediaProps}
          data-testid={ResortCardTestIds.mediaImage}
          draggable="false"
          loading="lazy"
          className={clsx(
            'm-md:aspect-16x9 rounded-border-radius-component-s m-md:rounded-border-radius-component-none w-full h-full !absolute top-0 left-0 object-center object-cover opacity-100 bg-center transition-[opacity] ease-in duration-150 delay-0',
            {
              'aspect-1x1': !isTransparent,
              'aspect-3x4': isTransparent
            }
          )}
        />
      </figure>

      <div className="flex flex-col flex-1 w-full justify-between m-md:px-2x m-md:pb-2x gap-[6px] m-md:gap-space-component-s">
        <button
          className="underline text-slate-950 text-left align-top text-body-medium-l max-h-12 cursor-pointer w-fit"
          data-testid={ResortCardTestIds.titleButton}
          type="button"
          onClick={onTitleClick}
          {...(titleButtonProps as React.ButtonHTMLAttributes<HTMLButtonElement>)}
        >
          <h3
            data-testid={ResortCardTestIds.title}
            className="text-body-medium-l font-regular text-fg-default leading-[1.519rem] hover:text-digital-500 focus:text-digital-600 focus:border-digital-600"
            id={titleId}
          >
            {title}
          </h3>
        </button>

        <div
          className={clsx('flex flex-col self-stretch justify-end max-w-full', {
            'gap-space-component-m': isTransparent,
            'm-md:gap-space-component-m gap-space-component-s': !isTransparent
          })}
        >
          {CardContent}
        </div>
      </div>
    </div>
  );
};

ResortCard.Skeleton = SkeletonResortCard;

ResortCard.TransparentPrice = ResortCardPrice;
