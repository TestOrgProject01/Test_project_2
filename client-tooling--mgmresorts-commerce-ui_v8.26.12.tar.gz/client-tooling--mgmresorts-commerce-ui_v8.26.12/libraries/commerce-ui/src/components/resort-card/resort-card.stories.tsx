import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { ResortCard } from './resort-card';
import {
  storyBuildAsYouGoVariantMockProps,
  storyCustomPriceTextMockProps,
  storyDefaultMockProps,
  storyTransparentTextMockProps,
  storyWithDisabledProps,
  storyWithTagMockProps,
  storyWithTagTextMockProps,
  storyWithUnavailableProps
} from './resort-card.mock';

export default {
  argTypes: {
    onActionClick: { action: 'onActionClick' }
  },
  component: ResortCard,
  title: 'Components/ResortCard'
} as Meta<typeof ResortCard>;

const Template: StoryFn<typeof ResortCard> = (args) => <ResortCard {...args} />;

const MultipleElementsTemplate: StoryFn<typeof ResortCard> = (args) => (
  <div className="grid grid-cols-2 gap-2">
    <ResortCard {...args} title={'Test Resort'} />{' '}
    <ResortCard {...args} price={-100} />
    <ResortCard {...args} price={0} />
  </div>
);

export const Default = Template.bind({});
Default.args = { ...storyDefaultMockProps };

export const BuildAsYouGo = Template.bind({});
BuildAsYouGo.args = { ...storyBuildAsYouGoVariantMockProps };

/**
 * You can define a custom text for the price line informing the `price` property as
 * a function that should return a `ReactNode`.
 *
 * ```jsx
 * <ResortCard
 *  {...props}
 *  price={() => (
 *    <React.Fragment>
 *      My custom price: <strong>$100</strong>
 *    </React.Fragment>
 *  )}
 * />
 * ```
 */
export const CustomPriceText = Template.bind({});
CustomPriceText.args = { ...storyCustomPriceTextMockProps };

export const Transparent = Template.bind({});
Transparent.args = { ...storyTransparentTextMockProps, variant: 'transparent' };

export const WithTag = Template.bind({});
WithTag.args = { ...storyWithTagMockProps };

export const CustomTagText = Template.bind({});
CustomTagText.args = { ...storyWithTagTextMockProps };

export const DisabledText = Template.bind({});
DisabledText.args = { ...storyWithDisabledProps };

export const UnavailableText = Template.bind({});
UnavailableText.args = { ...storyWithUnavailableProps };

export const MultipleResorts = MultipleElementsTemplate.bind({});
MultipleResorts.args = { ...storyDefaultMockProps, variant: 'build-as-you-go' };
