import React from 'react';

import { Skeleton } from '../skeleton';

export const SkeletonResortCard = () => (
  <div className="flex m-md:flex-col gap-4 ">
    <div className="w-[148px] m-md:w-full">
      <Skeleton height="148px" />
    </div>
    <div className="flex-1 flex flex-col m-md:p-2x">
      <div className="flex-1 mb-4">
        <Skeleton height="32px" maxWidth="146px" />
      </div>
      <div className="mb-[11px] flex flex-col gap-[7px]">
        <Skeleton height="8px" maxWidth="71px" />
        <Skeleton height="8px" maxWidth="146px" />
      </div>
      <Skeleton height="40px" />
    </div>
  </div>
);
