import React from 'react';

import { ResortCardPrice } from './resort-card-price';
import { ResortCardProps } from './resort-card.types';

const defaultProps: ResortCardProps = {
  isDisabled: false,
  mediaSrc:
    'https://uat-static-mgmresorts.devtest.vegas//transform/kCgfWZ9nxbp1/VDR00036.tif',
  price: 100,
  title: 'Vdara Hotel & Spa at ARIA Las Vegas'
};

export const storyDefaultMockProps = {
  ...defaultProps
};

export const storyBuildAsYouGoVariantMockProps = {
  ...defaultProps,
  variant: 'build-as-you-go'
};

export const storyCustomPriceTextMockProps = {
  ...defaultProps,
  price: () => (
    <React.Fragment>
      My custom price: <strong>$452</strong>
    </React.Fragment>
  )
};

export const storyTransparentTextMockProps = {
  ...defaultProps,
  isTagged: true,
  isTransparent: true,
  price: () => (
    <ResortCardPrice
      price="$91"
      priceLabel="per night"
      infoLines={[
        '(Included in package)',
        'Incl. daily resort fee',
        '$6,604 packate total'
      ]}
    />
  ),
  tagText: 'Included'
};

export const storyWithTagMockProps = {
  ...defaultProps,
  isTagged: true,
  price: 452
};

export const storyWithTagTextMockProps = {
  ...defaultProps,
  isTagged: true,
  price: 452,
  tagText: 'Included'
};

export const storyWithDisabledProps = {
  ...defaultProps,
  disabledText: 'Unavailable',
  isDisabled: true,
  isTagged: true,
  price: 452,
  tagText: 'Included'
};

export const storyWithUnavailableProps = {
  ...defaultProps,
  isTagged: true,
  isUnavailable: true,
  price: 452,
  tagText: 'Included'
};
