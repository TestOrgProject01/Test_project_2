import { ImgHTMLAttributes } from 'react';

import { FormatCurrencyOptions } from '../../util';

import { ButtonProps } from '../button';

/**
 * @public
 */
export type RenderPriceTextHandler = () => React.ReactNode;

/**
 * @public
 */
export type ResortCardVariant = 'transparent' | 'build-as-you-go';

/**
 * @internal
 */
export interface _PriceTextMatchInput {
  price: number | RenderPriceTextHandler;
  variant?: ResortCardVariant;
}

/**
 * @public
 */
export interface ResortCardProps {
  /**
   * Customize action button props
   */
  actionButtonProps?: ButtonProps['buttonProps'];
  /**
   * Customize tittle button props
   */
  titleButtonProps?: ButtonProps['buttonProps'];
  /**
   * Title for the action button
   */
  actionText?: string;
  /**
   * Display the tag label
   */
  isTagged?: boolean;
  /**
   * Image source url
   */
  mediaSrc: string;
  /**
   * Customize the media image props
   */
  mediaProps?: ImgHTMLAttributes<HTMLElement>;
  /**
   * Callback when the action button was clicked.
   *
   * @returns void
   */
  onActionClick?: () => Promise<void> | void;
  /**
   * Callback when the title button was clicked.
   *
   * @returns void
   */
  onTitleClick?: () => Promise<void> | void;
  /**
   * Callback when the Thumbnail image was clicked.
   *
   * @returns void
   */
  onThumbnailClick?: () => Promise<void> | void;
  /**
   * Price to display. It can be a function that returns ReactNode or a number
   */
  price: number | RenderPriceTextHandler;
  /**
   * Custom text for the tag label
   */
  tagText?: string;
  /**
   * Card title
   */
  title: string;
  /**
   * Card variant
   */
  variant?: ResortCardVariant;
  /**
   * Set the selected state for the button
   */
  selected?: boolean;
  /**
   * Props for unavailable resort state
   */
  isUnavailable?: boolean;
  /**
   * Unavailable resort text
   */
  unavailableText?: string;
  /**
   * Props for disabled resort state
   */
  isDisabled?: boolean;
  /**
   * Disabled resort text
   */
  disabledText?: string;
  /**
   * Custom labels for price description
   */
  priceDescription?: {
    included?: string;
    default?: string;
  };
  /**
   * Custom options that will be passed to `formatCurrency` function.
   */
  currencyOptions?: Partial<FormatCurrencyOptions>;
}
