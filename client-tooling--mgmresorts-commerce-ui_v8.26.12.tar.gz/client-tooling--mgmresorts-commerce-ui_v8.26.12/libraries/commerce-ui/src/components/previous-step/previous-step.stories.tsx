import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { PreviousStep } from './previous-step';
import { previousStepMockData } from './previous-step.mock';

export default {
  component: PreviousStep,
  title: 'Components/PreviousStep'
} as Meta<typeof PreviousStep>;

const Template: StoryFn<typeof PreviousStep> = (args) => (
  <PreviousStep {...args} />
);

export const Main = Template.bind({});

Main.args = {
  ...previousStepMockData
};
