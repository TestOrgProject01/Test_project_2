import React, { useId } from 'react';

import { PreviousStepProps } from './previous-step.types';

const componentId = 'PreviousStep';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const PreviousStepTestIds = {
  actionButton: `${componentId}:actionButton`,
  component: componentId,
  subtitle: `${componentId}:subtitle`,
  title: `${componentId}:title`
};

/**
 * @public
 */
export const PreviousStep = ({
  title,
  subtitle,
  onActionClick,
  actionText = 'Change',
  buttonProps
}: PreviousStepProps) => {
  const titleId = useId();

  return (
    <div
      className="flex flex-col w-full gap-space-component-s border border-b-thin border-gray-100 pb-2x"
      data-testid={PreviousStepTestIds.component}
    >
      <div className="flex">
        <h2
          id={titleId}
          className="text-label-regular-s leading-[1.181rem] text-fg-contrast"
          data-testid={PreviousStepTestIds.title}
        >
          {title}
        </h2>
      </div>

      <div className="flex justify-between">
        <p
          className="text-label-regular-m leading-[1.35rem] text-black"
          data-testid={PreviousStepTestIds.subtitle}
        >
          {subtitle}
        </p>

        <button
          type="button"
          className="text-label-regular-m leading-6 text-black underline hover:text-digital-500 focus:text-digital-600 focus:border-digital-600 cursor-pointer"
          onClick={onActionClick}
          data-testid={PreviousStepTestIds.actionButton}
          aria-describedby={titleId}
          {...buttonProps}
        >
          {actionText}
        </button>
      </div>
    </div>
  );
};
