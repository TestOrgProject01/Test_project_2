import { ButtonHTMLAttributes } from 'react';

/**
 * @public
 */
export interface PreviousStepProps {
  /**
   * Callback for the action button was clicked.
   *
   * @returns void
   */
  onActionClick: () => Promise<void> | void;
  /**
   * Card subtitle
   */
  subtitle: string;
  /**
   * Card title
   */
  title: string;
  /**
   * Title for the action button
   */
  actionText?: string;
  /**
   * button html attributes will be spread into the button element
   */
  buttonProps?: ButtonHTMLAttributes<HTMLButtonElement>;
}
