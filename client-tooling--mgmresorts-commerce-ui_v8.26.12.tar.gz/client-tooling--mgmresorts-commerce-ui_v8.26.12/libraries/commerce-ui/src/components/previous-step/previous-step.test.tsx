jest.mock('react', () => ({
  ...jest.requireActual<Record<string, unknown>>('react'),
  useId: jest.fn().mockReturnValue('')
}));

import React, { useId } from 'react';

import { fireEvent, render, screen } from '@testing-library/react';

import { axe, renderToHtml } from '../../util/test-utils';

import { PreviousStep, PreviousStepTestIds } from './previous-step';
import { PreviousStepProps } from './previous-step.types';

describe('<PreviousStep /> component', () => {
  const defaultTitle = 'Stay dates';

  const defaultProps: PreviousStepProps = {
    buttonProps: {
      'aria-label': `Click this button to go to the ${defaultTitle} step`
    },
    onActionClick: jest.fn(),
    subtitle: 'Thu, Oct 16 to Sat, Oct 21 (5 nights)',
    title: defaultTitle
  };

  const PreviousStepWrapper = (props: Partial<PreviousStepProps>) => (
    <PreviousStep {...defaultProps} {...props} />
  );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      expect(render(<PreviousStepWrapper />)).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the PreviousStep component correctly with default props', () => {
      render(<PreviousStepWrapper {...defaultProps} />);

      expect(
        screen.getByTestId(PreviousStepTestIds.component)
      ).toBeInTheDocument();

      expect(screen.getByTestId(PreviousStepTestIds.title)).toHaveTextContent(
        defaultProps.title
      );

      expect(
        screen.getByTestId(PreviousStepTestIds.subtitle)
      ).toHaveTextContent(defaultProps.subtitle);

      expect(
        screen.getByTestId(PreviousStepTestIds.actionButton)
      ).toHaveAttribute(
        'aria-label',
        `Click this button to go to the ${defaultProps.title} step`
      );
    });

    it('should call onActionClick when the button is clicked', () => {
      const onActionClick = jest.fn();
      const props = { ...defaultProps, onActionClick };
      render(<PreviousStepWrapper {...props} />);

      fireEvent.click(screen.getByTestId(PreviousStepTestIds.actionButton));
      expect(onActionClick).toHaveBeenCalledTimes(1);
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      expect(
        await axe(renderToHtml(<PreviousStepWrapper />))
      ).toHaveNoViolations();
    });

    it('should use BUTTON element on the link', () => {
      render(<PreviousStepWrapper {...defaultProps} />);

      expect(
        screen.getByTestId(PreviousStepTestIds.actionButton).tagName
      ).toEqual('BUTTON');
    });

    it('should use P element on the subtitle', () => {
      render(<PreviousStepWrapper {...defaultProps} />);

      expect(screen.getByTestId(PreviousStepTestIds.subtitle).tagName).toEqual(
        'P'
      );
    });

    it('should have id with random value on the title element', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValueOnce(randomId);
      render(<PreviousStepWrapper />);

      expect(screen.getByTestId(PreviousStepTestIds.title)).toHaveAttribute(
        'id',
        randomId
      );

      (useId as jest.Mock).mockReset();
    });

    it('should have aria-describedby on action button', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (useId as jest.Mock).mockReturnValueOnce(randomId);
      render(<PreviousStepWrapper />);

      expect(
        screen.getByTestId(PreviousStepTestIds.actionButton)
      ).toHaveAttribute('aria-describedby', randomId);

      (useId as jest.Mock).mockReset();
    });
  });
});
