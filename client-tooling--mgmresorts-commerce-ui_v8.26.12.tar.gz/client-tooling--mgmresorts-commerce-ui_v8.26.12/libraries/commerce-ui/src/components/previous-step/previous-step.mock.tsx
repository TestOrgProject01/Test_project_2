import { PreviousStepProps } from './previous-step.types';

export const previousStepMockData: PreviousStepProps = {
  onActionClick: () => {},
  subtitle: 'Thu, Oct 16 to Sat, Oct 21 (5 nights)',
  title: 'Stay dates'
};
