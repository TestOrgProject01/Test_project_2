import React from 'react';

import clsx from 'clsx';

import type { TRenderImageHandler } from './rooms-carousel.types';

/**
 * Default function to render rooms carousel image.
 *
 * @internal
 */
export const renderImageHandler: TRenderImageHandler = ({ imageProps }) => (
  <img
    {...imageProps}
    className={clsx(
      'max-w-full flex-[0_0_auto] select-none pointer-events-none',
      imageProps.className
    )}
  />
);
