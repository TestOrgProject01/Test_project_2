import { DetailedHTMLProps, ImgHTMLAttributes } from 'react';

import type { RoomCardProps, TOnImageChange } from '../room-card';

/**
 * @public
 */
export type TImageProps = DetailedHTMLProps<
  ImgHTMLAttributes<HTMLImageElement>,
  HTMLImageElement
> & {
  'data-testid'?: string;
};

/**
 * @public
 */
export interface IRenderImageParams {
  imageProps: TImageProps;
  isVisible: boolean;
  index: number;
}

/**
 * @public
 */
export type TRenderImageHandler = (
  params: IRenderImageParams
) => React.ReactNode;

/**
 * @public
 */
type RoomCardImagesCarouselProps = Pick<
  RoomCardProps,
  | 'images'
  | 'renderImage'
  | 'infiniteCarousel'
  | 'prevButtonProps'
  | 'nextButtonProps'
> & {
  /**
   * Hide carousel buttons.
   */
  hideCarouselButtons?: boolean;

  /**
   * Enable navigation for the carousel using the left and right arrows.
   *
   * @defaultValue `true`
   */
  enableNavigation?: boolean;

  /**
   * Enable swipe navigation for the carousel.
   *
   * @defaultValue `false`
   */
  enableSwipe?: boolean;

  /**
   * Custom class name to override styles.
   */
  className?: string;

  /**
   * Custom class name for the previous button.
   */
  prevButtonClassName?: string;

  /**
   * Custom class name for the next button.
   */
  nextButtonClassName?: string;

  /**
   * Custom function that it's called when we change the current carrousel's image.
   */
  onImageChange?: TOnImageChange;

  /**
   * Custom function that is called when click on carousel image. This does not fired when click on buttons inside carousel such next, prev, bottom navigation buttons.
   */

  onClickImage?: () => void;
};

/**
 * @public
 */
export type TRoomsCarousel = React.HTMLAttributes<HTMLElement> &
  RoomCardImagesCarouselProps & {
    variant:
      | 'resortCard'
      | 'roomCard'
      | 'roomDetails'
      | 'resortDetails'
      | 'mapRoomCard';
    titleAriaDescribedby?: string;
    paginationClassName?: string;
    navigationButtonsClassName?: string;
  };
