jest.mock('nanoid', () => ({
  nanoid: jest.fn().mockReturnValue('')
}));

import React from 'react';

import {
  render,
  screen,
  act,
  fireEvent,
  waitFor
} from '@testing-library/react';
import { nanoid } from 'nanoid';

import { axe, renderToHtml, userEvent } from '../../util/test-utils';

import { RoomCardImagesCarouselTestIds } from '../room-card/room-card-images-carousel';
import type { ImageProps } from '../room-card/room-card.types.ts';

import { RoomsCarousel } from './rooms-carousel';
import type { TRoomsCarousel } from './rooms-carousel.types';

describe('<RoomsCarousel /> component', () => {
  const defaultProps: TRoomsCarousel = {
    enableNavigation: true,
    enableSwipe: true,
    images: [
      {
        alt: 'king suite',
        'data-testid': 'carousel-image1',
        src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
      },
      {
        alt: 'king suite',
        'data-testid': 'carousel-image2',
        src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
      },
      {
        alt: 'king suite',
        'data-testid': 'carousel-image3',
        src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
      }
    ],
    variant: 'resortCard'
  };

  const RoomsCarouselWrapper = (props: Partial<TRoomsCarousel>) => (
    <RoomsCarousel {...defaultProps} {...props} />
  );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      expect(
        render(<RoomsCarouselWrapper variant={'resortCard'} />)
      ).toMatchSnapshot();

      expect(
        render(<RoomsCarouselWrapper variant={'resortDetails'} />)
      ).toMatchSnapshot();

      expect(
        render(<RoomsCarouselWrapper variant={'roomCard'} />)
      ).toMatchSnapshot();

      expect(
        render(<RoomsCarouselWrapper variant={'roomDetails'} />)
      ).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    const checkActiveImage = async (target: string, nonExistence?: boolean) => {
      const imageItem = screen.getByTestId(target);

      if (nonExistence) {
        await waitFor(() => {
          expect(imageItem).toHaveAttribute('data-isactive', 'false');
        });

        return;
      }

      await waitFor(() => {
        expect(imageItem).toHaveAttribute('data-isactive', 'true');
      });
    };

    it('should render carousel with swipe events', async () => {
      const onImageChangeHandler = jest
        .fn()
        .mockImplementation((index: number, numberOfImages: number) => {
          return Promise.resolve({ index, numberOfImages });
        });

      render(
        <RoomsCarouselWrapper
          images={defaultProps.images}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
          onImageChange={onImageChangeHandler}
        />
      );

      const indicatorsButtons = screen.queryAllByTestId(
        RoomCardImagesCarouselTestIds.activeImageIndicator
      );

      await act(async () => {
        await userEvent.click(indicatorsButtons[1]);
      });

      expect(screen.getByTestId('carousel-image2')).toHaveAttribute(
        'data-isactive',
        'true'
      );

      const imagesSize = (defaultProps.images as ImageProps[]).length;

      expect(onImageChangeHandler).toHaveBeenCalledTimes(1);
      expect(onImageChangeHandler).toHaveBeenCalledWith(1, imagesSize);

      const prevButton = screen.getByTestId(
        RoomCardImagesCarouselTestIds.prevButton
      );

      //apply delay between click events
      const delay = () => new Promise((resolve) => setTimeout(resolve, 250));

      await act(async () => {
        await userEvent.click(prevButton);
        await delay();
      });

      expect(screen.getByTestId('carousel-image1')).toHaveAttribute(
        'data-isactive',
        'true'
      );

      expect(onImageChangeHandler).toHaveBeenCalledTimes(2);
      expect(onImageChangeHandler).toHaveBeenCalledWith(0, imagesSize);

      const nextButton = screen.getByTestId(
        RoomCardImagesCarouselTestIds.nextButton
      );

      await act(async () => {
        await userEvent.click(nextButton);
        await delay();
      });

      expect(screen.getByTestId('carousel-image2')).toHaveAttribute(
        'data-isactive',
        'true'
      );

      expect(onImageChangeHandler).toHaveBeenCalledTimes(3);
      expect(onImageChangeHandler).toHaveBeenCalledWith(1, imagesSize);
    });

    it('should render carousel without navigation buttons and without swiping functionality', async () => {
      render(
        <RoomsCarouselWrapper
          enableSwipe={false}
          images={defaultProps.images}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
          hideCarouselButtons={true}
        />
      );

      expect(
        screen.queryByTestId(RoomCardImagesCarouselTestIds.prevButton)
      ).toBeNull();

      expect(
        screen.queryByTestId(RoomCardImagesCarouselTestIds.nextButton)
      ).toBeNull();

      fireEvent.mouseDown(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 250 }
      );

      fireEvent.mouseMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 100 }
      );

      fireEvent.mouseUp(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 50 }
      );

      await checkActiveImage('carousel-image2', true);

      fireEvent.mouseDown(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 250 }
      );

      fireEvent.mouseMove(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 100 }
      );

      fireEvent.mouseUp(
        screen.getByTestId(RoomCardImagesCarouselTestIds.componentContainer),
        { clientX: 50 }
      );

      await checkActiveImage('carousel-image3', true);
    });

    it('should scroll with an infinite loop when using infiniteCarousel property', async () => {
      render(
        <RoomsCarouselWrapper
          infiniteCarousel
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
        />
      );

      const nextButton = screen.getByLabelText('Next image');
      const prevButton = screen.getByLabelText('Previous image');

      // to apply delay between click events
      const delay = () => new Promise((resolve) => setTimeout(resolve, 250));

      act(() => {
        fireEvent.click(nextButton);
      });

      await checkActiveImage('carousel-image2');

      await delay();

      act(() => {
        fireEvent.click(nextButton);
      });

      await checkActiveImage('carousel-image1');

      await delay();

      act(() => {
        fireEvent.click(prevButton);
      });

      await checkActiveImage('carousel-image2');
    });

    it('should be able navigating using the carousel pagination', () => {
      render(
        <RoomsCarouselWrapper
          images={[
            {
              alt: 'king suite',
              'data-testid': 'carousel-image1',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            },
            {
              alt: 'king suite',
              'data-testid': 'carousel-image2',
              src: 'https://fastly.picsum.photos/id/426/1200/675.jpg?hmac=GrN1_pi302Z8qHF_uQj9612vebuu8CgaTlzgndnSBE8'
            }
          ]}
          renderImage={({ imageProps, isVisible }) => (
            <img {...imageProps} data-isactive={isVisible} />
          )}
        />
      );

      const indicatorsButtons = screen.queryAllByTestId(
        RoomCardImagesCarouselTestIds.activeImageIndicator
      );

      act(() => {
        fireEvent.click(indicatorsButtons[1]);
      });

      expect(screen.getByTestId('carousel-image2')).toHaveAttribute(
        'data-isactive',
        'true'
      );
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      expect(
        await axe(renderToHtml(<RoomsCarouselWrapper />))
      ).toHaveNoViolations();
    });

    it('should have aria-describedby on the previous and next buttons', () => {
      const randomId = `randomId-${
        Math.floor(Math.random() * (1000 - 100 + 1)) + 100
      }`;

      (nanoid as jest.Mock).mockReturnValueOnce(randomId);

      render(
        <RoomsCarouselWrapper
          images={[{ src: 'image1' }, { src: 'image2' }]}
          titleAriaDescribedby={randomId}
        />
      );

      expect(
        screen.getByTestId(RoomCardImagesCarouselTestIds.prevButton)
      ).toHaveAttribute('aria-describedby', randomId);

      expect(
        screen.getByTestId(RoomCardImagesCarouselTestIds.nextButton)
      ).toHaveAttribute('aria-describedby', randomId);

      (nanoid as jest.Mock).mockReset();
    });
  });
});
