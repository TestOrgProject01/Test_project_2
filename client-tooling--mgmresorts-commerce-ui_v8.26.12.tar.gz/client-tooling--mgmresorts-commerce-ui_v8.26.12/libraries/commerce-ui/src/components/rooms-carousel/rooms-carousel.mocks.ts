import { imgSrc } from '../rooms-room-card/rooms-room-card.mock';

import type { TRoomsCarousel } from './rooms-carousel.types';

const defaultProps: TRoomsCarousel = {
  enableNavigation: true,
  enableSwipe: true,
  images: [
    { alt: 'Image 1', src: imgSrc },
    { alt: 'Image 2', src: imgSrc },
    { alt: 'Image 3', src: imgSrc },
    { alt: 'Image 4', src: imgSrc }
  ],
  variant: 'resortCard'
};

export const storyDefaultMockProps = {
  ...defaultProps
};

export const storyResortCardMockProps = {
  ...defaultProps,
  variant: 'resortCard'
};

export const storyResortDetailsMockProps = {
  ...defaultProps,
  variant: 'resortDetails'
};

export const storyRoomsCardMockProps = {
  ...defaultProps,
  variant: 'roomCard'
};

export const storyRoomDetailsMockProps = {
  ...defaultProps,
  variant: 'roomDetails'
};
