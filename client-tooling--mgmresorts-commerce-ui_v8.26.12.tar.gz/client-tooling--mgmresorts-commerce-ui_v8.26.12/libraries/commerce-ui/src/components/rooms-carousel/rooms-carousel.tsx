import React from 'react';

import { twMerge } from 'tailwind-merge';

import { RoomCardImagesCarousel } from '../room-card/room-card-images-carousel';

import { renderImageHandler } from './rooms-carousel.private';
import type { TRoomsCarousel } from './rooms-carousel.types';

/**
 * @public
 */
export const RoomsCarousel = ({
  enableSwipe = true,
  onImageChange,
  hideCarouselButtons,
  variant,
  images,
  infiniteCarousel,
  renderImage = renderImageHandler,
  nextButtonProps,
  prevButtonProps,
  titleAriaDescribedby,
  onClickImage,
  paginationClassName,
  navigationButtonsClassName,
  ...props
}: TRoomsCarousel) => {
  const imageStyling = {
    mapRoomCard:
      'rounded-l-lg rounded-tr-none rounded-br-none h-full [&_>img]:aspect-[4/3] d-sm:aspect-[4/3]',
    resortCard:
      'rounded-lg m-lg:rounded-b-none h-full [&_>img]:aspect-[4/3] d-sm:aspect-[4/3]',
    resortDetails:
      'rounded-none rounded-tr-none rounded-tl-none [&_>img]:h-[320px] [&_>img]:w-full [&_>img]:object-cover [&_>img]:object-center d-sm:[&_>img]:h-[409px]',
    roomCard:
      'rounded-t-lg h-full [&_>img]:aspect-[1.78_/_1] d-sm:aspect-[1.78_/_1]',
    roomDetails:
      'rounded-lg h-full [&_>img]:aspect-4x3 d-sm:[&_>img]:aspect-16x9'
  };

  // Using before because the contrast elemennt is a before tag. This is useful for border radius
  const constratStyling = {
    mapRoomCard: 'before:rounded-l-lg',
    resortCard: 'before:rounded-lg',
    resortDetails: 'before:rounded-none',
    roomCard: 'before:rounded-t-lg',
    roomDetails: 'before:rounded-lg'
  };

  return (
    <RoomCardImagesCarousel
      images={images}
      infiniteCarousel={infiniteCarousel}
      renderImage={renderImage}
      nextButtonProps={{
        ...nextButtonProps,
        'aria-describedby': titleAriaDescribedby
      }}
      prevButtonProps={{
        ...prevButtonProps,
        'aria-describedby': titleAriaDescribedby
      }}
      hideCarouselButtons={hideCarouselButtons}
      className={twMerge(
        variant !== 'resortDetails'
          ? '[&_>img]:h-full [&_>img]:object-cover [&_>img]:object-center rounded-tr-none'
          : '',
        imageStyling[variant]
      )}
      contrastClassName={constratStyling[variant]}
      prevButtonClassName={twMerge(
        'backdrop-blur-[5px] p-[7px] border-[length:1px] border-solid border-[#D1D1D1]'
      )}
      nextButtonClassName={twMerge(
        'backdrop-blur-[5px] p-[7px] border-[length:1px] border-solid border-[#D1D1D1]'
      )}
      enableSwipe={enableSwipe}
      onImageChange={onImageChange}
      enableShadow
      onClickImage={onClickImage}
      paginationClassName={twMerge('!z-[3]', paginationClassName)}
      navigationButtonsClassName={twMerge('!z-[2]', navigationButtonsClassName)}
      {...props}
    />
  );
};
