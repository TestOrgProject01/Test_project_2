import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsCarousel } from './rooms-carousel';
import {
  storyDefaultMockProps,
  storyRoomsCardMockProps,
  storyResortCardMockProps,
  storyResortDetailsMockProps,
  storyRoomDetailsMockProps
} from './rooms-carousel.mocks';

const Template: StoryFn<typeof RoomsCarousel> = (args) => {
  return (
    <div className={'relative flex-shrink-0'}>
      <RoomsCarousel {...args} />
    </div>
  );
};

export default {
  argTypes: {},
  component: RoomsCarousel,
  parameters: {
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/RoomsCarousel'
} as Meta<typeof RoomsCarousel>;

export const Default = Template.bind({});
Default.args = { ...storyDefaultMockProps };

Default.parameters = {
  viewport: { defaultViewport: 'xs' }
};

export const ResortCardCarousel = Template.bind({});
ResortCardCarousel.args = { ...storyResortCardMockProps };

ResortCardCarousel.parameters = {
  viewport: { defaultViewport: 'lg' }
};

export const ResortDetailsCarousel = Template.bind({});
ResortDetailsCarousel.args = { ...storyResortDetailsMockProps };

ResortDetailsCarousel.parameters = {
  viewport: { defaultViewport: 'lg' }
};

export const RoomsCardCarousel = Template.bind({});
RoomsCardCarousel.args = { ...storyRoomsCardMockProps };

RoomsCardCarousel.parameters = {
  viewport: { defaultViewport: 'lg' }
};

export const RoomDetailsCarousel = Template.bind({});
RoomDetailsCarousel.args = { ...storyRoomDetailsMockProps };

RoomDetailsCarousel.parameters = {
  viewport: { defaultViewport: 'lg' }
};
