import React from 'react';

import { fireEvent, render, screen } from '@testing-library/react';

import { EventInfoCard, EventInfoCardTestIds } from './event-info-card';

describe('<EventInfoCard /> component', () => {
  it('should render the section title correctly for the `transparent` variant', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.sectionTitle).textContent
    ).toBe('foo bar title');
  });

  it('should render the section title correctly for the `build-as-you-go` variant', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date('2023-06-23T00:00:00.000Z')}
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.sectionTitle).textContent
    ).toBe('Fri, Jun 23');
  });

  it('should render the section title as h2 element', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.sectionTitle).tagName).toBe(
      'H2'
    );
  });

  it('should render the hours instead surcharge when variant is `build-as-you-go`', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date('2023-06-23T07:30:00.000Z')}
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.surchargeText).textContent
    ).toBe('7:30 AM');
  });

  it('should render the default text for price when variant is `transparent`', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.priceText).textContent).toBe(
      'Tickets from $1,000.00'
    );
  });

  it('should render the default surcharge text when variant is `transparent`', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.surchargeText).textContent
    ).toBe('+$100.00 per ticket');
  });

  it('should render the custom text price when the `priceText` prop was passed', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        priceText="my custom price $100.00"
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.priceText).textContent).toBe(
      'my custom price $100.00'
    );
  });

  it('should render the custom text price when the `priceText` was a function which returns a string', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        priceText={() => 'my custom price $100.00'}
        section="foo bar title"
        surcharge={100}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.priceText).textContent).toBe(
      'my custom price $100.00'
    );
  });

  it('should render the custom surcharge text when the `surchargeText` prop was passed', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
        surchargeText="custom surcharge price"
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.surchargeText).textContent
    ).toBe('custom surcharge price');
  });

  it('should render the custom text price when the `surchargeText` was a function which returns a string', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="transparent"
        price={1000}
        section="foo bar title"
        surcharge={100}
        surchargeText={() => 'my custom price $100.00'}
      />
    );

    expect(
      screen.getByTestId(EventInfoCardTestIds.surchargeText).textContent
    ).toBe('my custom price $100.00');
  });

  it('should call `onClick` prop when the card was clicked', () => {
    const onClickSpy = jest.fn();

    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={onClickSpy}
      />
    );

    fireEvent.click(screen.getByTestId(EventInfoCardTestIds.component));
    expect(onClickSpy).toHaveBeenCalled();
  });

  it('should render the default text for price when variant is `build-as-you-go`', () => {
    const onClickSpy = jest.fn();

    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={onClickSpy}
      />
    );

    expect(screen.getByTestId(EventInfoCardTestIds.priceText).textContent).toBe(
      'From +$1,000.00'
    );
  });

  it('should not render the default text for price when variant is `build-as-you-go` if the showPrice prop is false', () => {
    const onClickSpy = jest.fn();

    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={onClickSpy}
        showPrice={false}
      />
    );

    expect(screen.queryByTestId(EventInfoCardTestIds.priceText)).toBeFalsy();
  });

  it('should have accessibility attribute `role=radio`', () => {
    render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={jest.fn()}
        showPrice={false}
      />
    );

    expect(
      screen.queryByTestId(EventInfoCardTestIds.component)
    ).toHaveAttribute('role', 'radio');
  });

  it('should set aria-checked correctly based on isSelected property', () => {
    const { rerender } = render(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={jest.fn()}
        showPrice={false}
      />
    );

    expect(
      screen.queryByTestId(EventInfoCardTestIds.component)
    ).toHaveAttribute('aria-checked', 'false');

    rerender(
      <EventInfoCard
        id="event-info-card"
        variant="build-as-you-go"
        price={1000}
        date={new Date()}
        onClick={jest.fn()}
        showPrice={false}
        isSelected
      />
    );

    expect(
      screen.queryByTestId(EventInfoCardTestIds.component)
    ).toHaveAttribute('aria-checked', 'true');
  });
});
