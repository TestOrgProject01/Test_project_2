/**
 * List of available variants
 *
 * @public
 */
export type EventInfoCardVariants = 'transparent' | 'build-as-you-go';

/**
 * @internal
 */
export type _CustomTextHandler = (priceFormatted: string) => React.ReactNode;

interface EventInfoCommonProps {
  isSelected?: boolean;
  onClick?: () => Promise<void> | void;
  priceText?: string | _CustomTextHandler;
  cssWrapperClass?: string;
  disabled?: boolean;
}

interface EventInfoCardTransparentProps<T extends EventInfoCardVariants>
  extends EventInfoCommonProps {
  variant: T;
  section?: React.ReactNode;
  surcharge?: number;
  price: number;
  date?: Date;
  surchargeText?: string | _CustomTextHandler;
  id: string | number;
  showPrice?: boolean;
}

interface EventInfoCardBuildAsYouGoProps<T extends EventInfoCardVariants>
  extends EventInfoCommonProps {
  variant: T;
  date: Date;
  price: number;
  section?: never;
  surcharge?: never;
  surchargeText?: never;
  id: string | number;
  showPrice?: boolean;
}

/**
 * @public
 */
export type EventInfoCardProps<T extends EventInfoCardVariants> =
  T extends 'build-as-you-go'
    ? EventInfoCardBuildAsYouGoProps<T>
    : EventInfoCardTransparentProps<T>;
