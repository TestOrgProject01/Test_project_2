import React, { useId, useMemo } from 'react';

import clsx from 'clsx';
import { format, isValid } from 'date-fns';

import { formatCurrency } from '../../util';

import {
  EventInfoCardProps,
  EventInfoCardVariants
} from './event-info-card.types';

const componentId = 'EventInfoCard';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const EventInfoCardTestIds = {
  component: componentId,
  priceText: `${componentId}:priceText`,
  sectionTitle: `${componentId}:sectionTitle`,
  surchargeText: `${componentId}:surchargeText`
};

/**
 * @public
 */
export const EventInfoCard = <T extends EventInfoCardVariants>({
  price,
  variant,
  date,
  surcharge,
  section,
  isSelected,
  onClick,
  priceText: priceTextProp,
  surchargeText: surchargeTextProp,
  id,
  cssWrapperClass,
  showPrice = true,
  disabled = false
}: EventInfoCardProps<T>) => {
  const isBuildAsYouGoVariant = variant === 'build-as-you-go';
  const isTransparentVariant = variant === 'transparent';
  const ariaLabelId = useId();

  const priceFormatted = formatCurrency(price);
  const surchargeFormatted = formatCurrency(surcharge);

  const label = isValid(date) ? format(date as Date, 'EEE, MMM dd') : section;

  const priceText = useMemo(() => {
    if (!showPrice) {
      return undefined;
    }

    if (!priceTextProp) {
      if (isBuildAsYouGoVariant) return `From +${priceFormatted}`;

      if (isTransparentVariant) return `Tickets from ${priceFormatted}`;

      return `(${priceFormatted} per ticket)`;
    }

    if (typeof priceTextProp === 'function') {
      return priceTextProp(priceFormatted);
    }

    if (typeof priceTextProp === 'string') {
      return priceTextProp;
    }

    return null;
  }, [
    showPrice,
    priceTextProp,
    priceFormatted,
    isTransparentVariant,
    isBuildAsYouGoVariant
  ]);

  const surchargeText = useMemo(() => {
    if (!surcharge && !surchargeTextProp) {
      return '';
    }

    if (typeof surchargeTextProp === 'string') {
      return surchargeTextProp;
    }

    if (typeof surchargeTextProp === 'function' && surchargeTextProp) {
      return surchargeTextProp(surchargeFormatted);
    }

    return `+${surchargeFormatted} per ticket`;
  }, [surcharge, surchargeTextProp, surchargeFormatted]);

  const surchargeOrTimeLine = isValid(date)
    ? format(date as Date, 'h:mm aa')
    : surchargeText;

  return (
    <div
      id={`wrapper-${id}`}
      data-testid={EventInfoCardTestIds.component}
      role="radio"
      aria-checked={!!isSelected}
      aria-labelledby={ariaLabelId}
      aria-disabled={disabled}
      onClick={!disabled ? onClick : undefined}
      className={clsx(
        `select-none w-fit max-h-[100px] rounded-lg focus-visible:outline focus-visible:outline-[2px] focus-visible:outline-offset-[2px] focus-visible:outline-interaction-default bg-white ${cssWrapperClass}`,
        {
          'bg-bg-surface border-default border-fg-subtle': !isSelected,
          'border-default border-interaction-default': isSelected,
          '!cursor-not-allowed': disabled,
          'cursor-pointer': !disabled,
          'min-w-fit': isBuildAsYouGoVariant || isTransparentVariant
        }
      )}
    >
      <div
        className={clsx(
          'flex flex-col gap-space-component-xs items-start p-space-component-m text-body-regular-s',
          {
            'text-fg-contrast': !isSelected,
            'text-fg-default': isSelected,
            'w-max': !isBuildAsYouGoVariant && !isTransparentVariant
          }
        )}
      >
        <h2
          data-testid={EventInfoCardTestIds.sectionTitle}
          id={ariaLabelId}
          className={clsx('', {
            'text-body-medium-m': isSelected,
            'text-body-regular-m ': !isSelected,
            'text-fg-default': !disabled
          })}
        >
          {label}
        </h2>
        <span data-testid={EventInfoCardTestIds.surchargeText}>
          {surchargeOrTimeLine}
        </span>
        {priceText && (
          <span data-testid={EventInfoCardTestIds.priceText}>{priceText}</span>
        )}
      </div>
    </div>
  );
};
