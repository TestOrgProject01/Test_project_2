import React from 'react';

import { Meta } from '@storybook/react';

import { EventInfoCard } from './event-info-card';
import {
  storyTransparentMockProps,
  storyBuildAsYouGoMockProps
} from './event-info-card.mock';
import { EventInfoCardProps } from './event-info-card.types';

export default {
  argTypes: {
    date: { control: 'date', if: { arg: 'variant', eq: 'build-as-you-go' } },
    onClick: { action: 'clicked' },
    section: { if: { arg: 'variant', eq: 'transparent' } },
    surcharge: { if: { arg: 'variant', eq: 'transparent' } },
    surchargeText: { if: { arg: 'variant', eq: 'transparent' } }
  },
  component: EventInfoCard,
  title: 'Components/EventInfoCard'
} as Meta<typeof EventInfoCard>;

export const Transparent = (args: EventInfoCardProps<'transparent'>) => (
  <EventInfoCard {...args} />
);

Transparent.args = { ...storyTransparentMockProps };

export const BuildAsYouGo = (args: EventInfoCardProps<'transparent'>) => (
  <EventInfoCard {...args} />
);

BuildAsYouGo.args = { ...storyBuildAsYouGoMockProps };

export const BuildAsYouGoPriceTextHidden = (
  args: EventInfoCardProps<'transparent'>
) => <EventInfoCard {...args} />;

BuildAsYouGoPriceTextHidden.args = {
  ...storyBuildAsYouGoMockProps,
  showPrice: false
};

/**
 * **This section is specific to the `transparent` variant**
 *
 * You can customize the price text passing the `priceText` to the properties, it have two ways to do that.
 *
 * ### Using String
 *
 * ```jsx
 * <EventInfoCard {...args} priceText="custom price text" />
 * ```
 *
 * ### Using a function
 *
 * You can use a function to pick up the formatted price from the first param and write your custom string.
 *
 * ```jsx
 * <EventInfoCard {...args} priceText={formattedPrice => `custom price text - ${formattedPrice}`} />
 * ```
 */
export const CustomPriceText = (args: EventInfoCardProps<'transparent'>) => (
  <div className="flex flex-col gap-2 items-start">
    <EventInfoCard {...args} priceText="custom price text" />
    <EventInfoCard
      {...args}
      priceText={(formattedPrice) => `custom price text - ${formattedPrice}`}
    />
  </div>
);

CustomPriceText.args = { ...storyTransparentMockProps };

/**
 * **This section is specific to the `transparent` variant**
 *
 * You can customize the surcharge text passing the `surchargeText` to the properties, it have two ways to do that.
 *
 * ### Using String
 *
 * ```jsx
 * <EventInfoCard {...args} surchargeText="custom price text" />
 * ```
 *
 * ### Using a function
 *
 * You can use a function to pick up the formatted price from the first param and write your custom string.
 *
 * ```jsx
 * <EventInfoCard {...args} surchargeText={formattedPrice => `custom price text - ${formattedPrice}`} />
 * ```
 */
export const CustomSurchargeText = (
  args: EventInfoCardProps<'transparent'>
) => (
  <div className="flex flex-col gap-2 items-start">
    <EventInfoCard {...args} surchargeText="custom surcharge text" />
    <EventInfoCard
      {...args}
      surchargeText={(formattedPrice) =>
        `custom surcharge text - ${formattedPrice}`
      }
    />
  </div>
);

CustomSurchargeText.args = { ...storyTransparentMockProps };
