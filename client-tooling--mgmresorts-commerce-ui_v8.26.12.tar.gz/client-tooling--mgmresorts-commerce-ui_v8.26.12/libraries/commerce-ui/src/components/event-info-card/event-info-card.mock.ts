import { EventInfoCardProps } from './event-info-card.types';

const transparentProps: EventInfoCardProps<'transparent'> = {
  cssWrapperClass: '',
  disabled: false,
  id: 1,
  price: 2927,
  section: 'Section Label',
  surcharge: 100,
  variant: 'transparent'
};

const buildAsYouGoProps: EventInfoCardProps<'build-as-you-go'> = {
  cssWrapperClass: '',
  date: new Date(),
  disabled: false,
  id: 1,
  price: 2927,
  variant: 'build-as-you-go'
};

export const storyTransparentMockProps: EventInfoCardProps<'transparent'> = {
  ...transparentProps
};

export const storyBuildAsYouGoMockProps: EventInfoCardProps<'build-as-you-go'> = {
  ...buildAsYouGoProps
};
