import { ICalendarBottomPanel } from './rooms-calendar-bottom-panel.types';

export const RoomsCalendarBottomPanelMockData: ICalendarBottomPanel = {
  averagePerNightPrice: undefined,
  averageRoomRate: undefined,
  ctaDisabled: true,
  ctaLabel: 'Continue',
  panelBodyText: undefined,
  pricingDisclaimer: undefined,
  resortFee: undefined
};

export const DatesSelectedNoResortSelectedMockData: ICalendarBottomPanel = {
  ...RoomsCalendarBottomPanelMockData,
  ctaDisabled: false,
  panelBodyText: 'Proceed to resort selection'
};

export const RoomsCalendarBottomPanelRegularPricingMockData: ICalendarBottomPanel =
  {
    ...RoomsCalendarBottomPanelMockData,
    averagePerNightPrice: '$345 average per night',
    averageRoomRate: '$300 average room rate',
    ctaDisabled: false,
    pricingDisclaimer: 'Excludes taxes',
    resortFee: '+ $45 daily resort fee'
  };

export const RoomsCalendarBottomPanelDiscountedPricingMockData: ICalendarBottomPanel =
  {
    ...RoomsCalendarBottomPanelRegularPricingMockData,
    averagePerNightPrice: '$245 average per night',
    averageRoomRate: '$200 average room rate <s>(was $275)<s/>'
  };

export const FullyCompedMockData: ICalendarBottomPanel = {
  ...RoomsCalendarBottomPanelRegularPricingMockData,
  averagePerNightPrice: 'Comp',
  averageRoomRate: 'Was <s>$200</s> average room rate',
  compNightsLabel: '(5 comp nights)',
  pricingDisclaimer: null,
  resortFee: undefined
};

export const FullyCompedWithDailyResortFeeMockData: ICalendarBottomPanel = {
  ...RoomsCalendarBottomPanelRegularPricingMockData,
  averagePerNightPrice: '$45 average per night',
  averageRoomRate: 'Comp <s>($200 average room rate)</s>',
  compNightsLabel: '(5 comp nights)',
  pricingDisclaimer: 'Excludes taxes',
  resortFee: '+ $45 daily resort fee'
};

export const PartialCompedWithDailyResortFeeMockData: ICalendarBottomPanel = {
  ...RoomsCalendarBottomPanelRegularPricingMockData,
  averagePerNightPrice: '$125 average per night',
  averageRoomRate: '$80 average room rate <s>(was $100)</s>',
  compNightsLabel: '(4 comp nights)',
  pricingDisclaimer: 'Excludes taxes',
  resortFee: '+ $45 daily resort fee'
};

export const PartialCompedWithNoDailyResortFeeOnCompNightsMockData: ICalendarBottomPanel =
  {
    ...RoomsCalendarBottomPanelRegularPricingMockData,
    averagePerNightPrice: '$89 average per night',
    averageRoomRate: '$80 average room rate <s>(was $200)</s>',
    compNightsLabel: '(4 comp nights)',
    pricingDisclaimer: 'Excludes taxes',
    resortFee: '+ $9 daily resort fee'
  };
