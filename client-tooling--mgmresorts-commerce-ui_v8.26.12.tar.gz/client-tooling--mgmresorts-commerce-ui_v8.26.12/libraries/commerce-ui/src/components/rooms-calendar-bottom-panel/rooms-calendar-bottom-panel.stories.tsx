import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsCalendarBottomPanel } from './rooms-calendar-bottom-panel';
import {
  PartialCompedWithDailyResortFeeMockData,
  RoomsCalendarBottomPanelDiscountedPricingMockData,
  FullyCompedMockData,
  FullyCompedWithDailyResortFeeMockData,
  RoomsCalendarBottomPanelMockData,
  RoomsCalendarBottomPanelRegularPricingMockData,
  PartialCompedWithNoDailyResortFeeOnCompNightsMockData,
  DatesSelectedNoResortSelectedMockData
} from './rooms-calendar-bottom-panel.mocks';

export default {
  argTypes: {
    onClickCTA: { action: 'onClickCTA' }
  },
  component: RoomsCalendarBottomPanel,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'white',
      values: [{ name: 'white', value: '#FFFFFF' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/RoomsCalendarBottomPanel'
} as Meta<typeof RoomsCalendarBottomPanel>;

const Template: StoryFn<typeof RoomsCalendarBottomPanel> = (args) => (
  <div>
    <RoomsCalendarBottomPanel {...args} />
  </div>
);

export const NoDatesSelected = Template.bind({});

NoDatesSelected.args = {
  ...RoomsCalendarBottomPanelMockData,
  panelBodyText: 'Please select dates to continue'
};

export const DatesSelectedNoResortSelected = Template.bind({});

DatesSelectedNoResortSelected.args = {
  ...DatesSelectedNoResortSelectedMockData
};

export const RegularPricing = Template.bind({});

RegularPricing.args = {
  ...RoomsCalendarBottomPanelRegularPricingMockData
};

export const DiscountedPricing = Template.bind({});

DiscountedPricing.args = {
  ...RoomsCalendarBottomPanelDiscountedPricingMockData
};

export const FullyComped = Template.bind({});

FullyComped.args = {
  ...FullyCompedMockData
};

export const FullyCompedWithDailyResortFee = Template.bind({});

FullyCompedWithDailyResortFee.args = {
  ...FullyCompedWithDailyResortFeeMockData
};

export const PartialCompedWithDailyResortFee = Template.bind({});

PartialCompedWithDailyResortFee.args = {
  ...PartialCompedWithDailyResortFeeMockData
};

export const PartialCompedWithNoDailyResortFeeOnCompNights = Template.bind({});

PartialCompedWithNoDailyResortFeeOnCompNights.args = {
  ...PartialCompedWithNoDailyResortFeeOnCompNightsMockData
};
