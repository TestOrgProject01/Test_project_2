import React from 'react';

import { Button } from '@mgmresorts/mgm-ui';
import clsx from 'clsx';
import { nop } from 'rambdax';
import { twMerge } from 'tailwind-merge';

import { ICalendarBottomPanel } from './rooms-calendar-bottom-panel.types';

const componentId = 'RoomsCalendarBottomPanel';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const RoomsCalendarBottomPanelTestIds = {
  component: componentId,
  pricingDisclaimer: `${componentId}:pricingDisclaimer`,
  resortFee: `${componentId}:resortFee`
};

/**
 * @public
 */
export const RoomsCalendarBottomPanel = ({
  panelBodyText,
  panelBodyTextDataCMS,
  ctaLabel = 'Continue',
  ctaLabelDataCMS,
  averageRoomRate,
  averageRoomRateDataCMS,
  resortFee,
  resortFeeDataCMS,
  averagePerNightPrice,
  averagePerNightPriceDataCMS,
  ctaDisabled,
  compNightsLabel,
  compNightsLabelDataCMS,
  onClickCTA = nop,
  pricingDisclaimer = 'Excludes taxes',
  pricingDisclaimerDataCMS,
  className,
  ...rest
}: ICalendarBottomPanel) => {
  return (
    <div
      className={twMerge(
        'flex justify-between items-center p-2x bg-brand-25 shadow-[0px_-3px_8px_0px_rgba(0,0,0,0.10)]',
        className
      )}
      data-testid={RoomsCalendarBottomPanelTestIds.component}
      {...rest}
    >
      <div className={twMerge(!panelBodyText && 'self-start w-[197px]')}>
        {panelBodyText && (
          <div
            className={clsx(
              'text-[14px] not-italic font-medium leading-[135%] text-digital-900'
            )}
            data-cms={panelBodyTextDataCMS}
          >
            {panelBodyText}
          </div>
        )}

        {!panelBodyText && (
          <>
            {averageRoomRate && (
              <div
                className={clsx(
                  'text-gray-600 text-[12px] not-italic font-regular leading-[135%] whitespace-nowrap overflow-hidden text-ellipsis'
                )}
                dangerouslySetInnerHTML={{
                  __html: averageRoomRate
                }}
                data-cms={averageRoomRateDataCMS}
              />
            )}

            {resortFee && (
              <div
                className={
                  'text-gray-600 text-[12px] not-italic font-regular leading-[135%]'
                }
                data-testid={RoomsCalendarBottomPanelTestIds.resortFee}
                data-cms={resortFeeDataCMS}
              >
                {resortFee}
              </div>
            )}

            {averagePerNightPrice && (
              <div
                className={
                  'text-digital-900 text-[14px] not-italic font-medium leading-[135%]'
                }
                data-cms={averagePerNightPriceDataCMS}
              >
                {averagePerNightPrice}
              </div>
            )}

            {compNightsLabel && (
              <div
                className={
                  'text-digital-900 text-[14px] not-italic font-regular leading-[135%]'
                }
                data-cms={compNightsLabelDataCMS}
              >
                {compNightsLabel}
              </div>
            )}

            {pricingDisclaimer && (
              <div
                className={
                  'text-gray-600 text-[12px] not-italic font-regular leading-[135%]'
                }
                data-testid={RoomsCalendarBottomPanelTestIds.pricingDisclaimer}
                data-cms={pricingDisclaimerDataCMS}
              >
                {pricingDisclaimer}
              </div>
            )}
          </>
        )}
      </div>

      <Button
        label={ctaLabel || ''}
        data-cms={ctaLabelDataCMS}
        disabled={ctaDisabled}
        onClick={onClickCTA}
        size="large"
        variant="primary"
        className="whitespace-nowrap w-full"
      />
    </div>
  );
};
