import React from 'react';

import {
  act,
  axe,
  createWithDesignTokensProvider,
  renderToHtmlWithDesignTokensProvider,
  screen,
  userEvent
} from '../../util/test-utils';
import '@testing-library/jest-dom';

import {
  RoomsCalendarBottomPanel,
  RoomsCalendarBottomPanelTestIds
} from './rooms-calendar-bottom-panel';
import {
  DatesSelectedNoResortSelectedMockData,
  FullyCompedMockData,
  FullyCompedWithDailyResortFeeMockData,
  PartialCompedWithDailyResortFeeMockData,
  PartialCompedWithNoDailyResortFeeOnCompNightsMockData,
  RoomsCalendarBottomPanelDiscountedPricingMockData,
  RoomsCalendarBottomPanelMockData,
  RoomsCalendarBottomPanelRegularPricingMockData
} from './rooms-calendar-bottom-panel.mocks';
import { ICalendarBottomPanel } from './rooms-calendar-bottom-panel.types';

describe('<RoomsCalendarBottomPanel/> component', () => {
  const renderRoomsResortSelectionSummary = (props: ICalendarBottomPanel) =>
    createWithDesignTokensProvider(<RoomsCalendarBottomPanel {...props} />);

  const renderRoomsResortSelectionSummaryToHtml = (
    props: ICalendarBottomPanel
  ) =>
    renderToHtmlWithDesignTokensProvider(
      <RoomsCalendarBottomPanel {...props} />
    );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles for no dates selected scenario', () => {
      const actual = renderRoomsResortSelectionSummary(
        RoomsCalendarBottomPanelMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for dates selected and no resort selected scenario', () => {
      const actual = renderRoomsResortSelectionSummary(
        DatesSelectedNoResortSelectedMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for regular pricing', () => {
      const actual = renderRoomsResortSelectionSummary(
        RoomsCalendarBottomPanelRegularPricingMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for discounted pricing', () => {
      const actual = renderRoomsResortSelectionSummary(
        RoomsCalendarBottomPanelDiscountedPricingMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for fully comp pricing', () => {
      const actual = renderRoomsResortSelectionSummary(FullyCompedMockData);

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for fully comp pricing with daily resort fee', () => {
      const actual = renderRoomsResortSelectionSummary(
        FullyCompedWithDailyResortFeeMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for partial comp pricing with daily resort fee', () => {
      const actual = renderRoomsResortSelectionSummary(
        PartialCompedWithDailyResortFeeMockData
      );

      expect(actual).toMatchSnapshot();
    });

    it('should render with default styles for partial comp pricing with no daily resort fee on comp nights', () => {
      const actual = renderRoomsResortSelectionSummary(
        PartialCompedWithNoDailyResortFeeOnCompNightsMockData
      );

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('Should render component with disabled button and select dates label', async () => {
      const onClickContinueHandler = jest.fn();
      const panelBodyText = 'Please select dates to continue';

      renderRoomsResortSelectionSummary({
        ...RoomsCalendarBottomPanelMockData,
        onClickCTA: onClickContinueHandler,
        panelBodyText: panelBodyText
      });

      const label = screen.getByText(panelBodyText);

      expect(label).toBeInTheDocument();

      const button = screen.getByText(
        RoomsCalendarBottomPanelMockData.ctaLabel as string
      );

      expect(button).toHaveProperty('disabled', true);

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).not.toHaveBeenCalled();
    });

    it('Should render component for the selected dates and no resort selected scenario', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...DatesSelectedNoResortSelectedMockData,
        onClickCTA: onClickContinueHandler
      });

      const label = screen.getByText(
        DatesSelectedNoResortSelectedMockData.panelBodyText as string
      );

      expect(label).toBeInTheDocument();

      const button = screen.getByText(
        DatesSelectedNoResortSelectedMockData.ctaLabel as string
      );

      expect(button).toHaveProperty('disabled', false);

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with regular pricing', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...RoomsCalendarBottomPanelRegularPricingMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelRegularPricingMockData.averageRoomRate as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelRegularPricingMockData.resortFee as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelRegularPricingMockData.averagePerNightPrice as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelRegularPricingMockData.pricingDisclaimer as string
        )
      ).toBeInTheDocument();

      const button = screen.getByText(
        RoomsCalendarBottomPanelMockData.ctaLabel as string
      );

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with discounted pricing', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...RoomsCalendarBottomPanelDiscountedPricingMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(screen.getByText('$200 average room rate')).toBeInTheDocument();
      expect(screen.getByText('(was $275)')).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelDiscountedPricingMockData.resortFee as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelDiscountedPricingMockData.averagePerNightPrice as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          RoomsCalendarBottomPanelDiscountedPricingMockData.pricingDisclaimer as string
        )
      ).toBeInTheDocument();

      const button = screen.getByText(
        RoomsCalendarBottomPanelDiscountedPricingMockData.ctaLabel as string
      );

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with fully comped pricing', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...FullyCompedMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(screen.getByText(/Was/)).toBeInTheDocument();
      expect(screen.getByText(/\$200/)).toBeInTheDocument();
      expect(screen.getByText(/average room rate/)).toBeInTheDocument();
      expect(screen.getByText(/Comp/)).toBeInTheDocument();
      expect(screen.getByText('(5 comp nights)')).toBeInTheDocument();

      expect(
        screen.queryByTestId(RoomsCalendarBottomPanelTestIds.resortFee)
      ).toBeNull();

      expect(
        screen.queryByTestId(RoomsCalendarBottomPanelTestIds.pricingDisclaimer)
      ).toBeNull();

      const button = screen.getByText(FullyCompedMockData.ctaLabel as string);

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with fully comped pricing with daily resort fee', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...FullyCompedWithDailyResortFeeMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(screen.getByText(/Comp/)).toBeInTheDocument();
      expect(screen.getByText(/\$200 average room rate/)).toBeInTheDocument();

      expect(
        screen.getByText(
          FullyCompedWithDailyResortFeeMockData.resortFee as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          FullyCompedWithDailyResortFeeMockData.averagePerNightPrice as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          FullyCompedWithDailyResortFeeMockData.compNightsLabel as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          FullyCompedWithDailyResortFeeMockData.pricingDisclaimer as string
        )
      ).toBeInTheDocument();

      const button = screen.getByText(
        FullyCompedWithDailyResortFeeMockData.ctaLabel as string
      );

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with partial comped pricing with daily resort fee', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...PartialCompedWithDailyResortFeeMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(screen.getByText(/\$80 average room rate/)).toBeInTheDocument();
      expect(screen.getByText(/was \$100/)).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithDailyResortFeeMockData.resortFee as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithDailyResortFeeMockData.averagePerNightPrice as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithDailyResortFeeMockData.compNightsLabel as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithDailyResortFeeMockData.pricingDisclaimer as string
        )
      ).toBeInTheDocument();

      const button = screen.getByText(
        PartialCompedWithDailyResortFeeMockData.ctaLabel as string
      );

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });

    it('Should render component with partial comped pricing with no daily resort fee on comp nights', async () => {
      const onClickContinueHandler = jest.fn();

      renderRoomsResortSelectionSummary({
        ...PartialCompedWithNoDailyResortFeeOnCompNightsMockData,
        onClickCTA: onClickContinueHandler
      });

      expect(screen.getByText(/\$80 average room rate/)).toBeInTheDocument();

      expect(screen.getByText(/was \$200/)).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithNoDailyResortFeeOnCompNightsMockData.resortFee as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithNoDailyResortFeeOnCompNightsMockData.averagePerNightPrice as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithNoDailyResortFeeOnCompNightsMockData.compNightsLabel as string
        )
      ).toBeInTheDocument();

      expect(
        screen.getByText(
          PartialCompedWithNoDailyResortFeeOnCompNightsMockData.pricingDisclaimer as string
        )
      ).toBeInTheDocument();

      const button = screen.getByText(
        PartialCompedWithNoDailyResortFeeOnCompNightsMockData.ctaLabel as string
      );

      await act(async () => await userEvent.click(button));

      expect(onClickContinueHandler).toHaveBeenCalled();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderRoomsResortSelectionSummaryToHtml(
        RoomsCalendarBottomPanelRegularPricingMockData
      );

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
