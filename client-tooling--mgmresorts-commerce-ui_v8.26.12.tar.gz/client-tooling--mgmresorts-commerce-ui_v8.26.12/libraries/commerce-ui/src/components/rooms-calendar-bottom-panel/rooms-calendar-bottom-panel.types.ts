/**
 * @public
 */
export interface ICalendarBottomPanel
  extends React.HTMLAttributes<HTMLDivElement> {
  panelBodyText?: string | null;
  panelBodyTextDataCMS?: string;
  ctaLabel?: string | null;
  ctaLabelDataCMS?: string;
  averageRoomRate?: string | null;
  averageRoomRateDataCMS?: string;
  resortFee?: string | null;
  resortFeeDataCMS?: string;
  averagePerNightPrice?: string | null;
  averagePerNightPriceDataCMS?: string;
  compNightsLabel?: string | null;
  compNightsLabelDataCMS?: string;
  ctaDisabled?: boolean;
  onClickCTA?: () => void;
  pricingDisclaimer?: string | null;
  pricingDisclaimerDataCMS?: string;
}
