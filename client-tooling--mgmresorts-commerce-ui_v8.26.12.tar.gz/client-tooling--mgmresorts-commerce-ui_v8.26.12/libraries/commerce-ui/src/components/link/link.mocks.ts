import { LinkProps } from './link.types';

export const linkMockData: LinkProps = {
  label: 'Link test',
  leadingIcon: 'pin-location',
  size: 'small',
  to: '/',
  trailingIcon: 'arrow-right'
};
