import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Link } from './link';
import { linkMockData } from './link.mocks';

export default {
  component: Link,
  title: 'Components/Link'
} as Meta<typeof Link>;

const Template: StoryFn<typeof Link> = (args) => <Link {...args} />;

export const Main = Template.bind({});

Main.args = {
  ...linkMockData
};
