import * as React from 'react';

import clsx from 'clsx';

import { Icon } from '../icon/icon';

import { LinkProps } from './link.types';

const componentId = 'Link';

/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const LinkTestIds = {
  component: componentId,
  label: `${componentId}:label`,
  leadingIcon: `${componentId}:leading-icon`,
  trailingIcon: `${componentId}:trailing-icon`
};

/**
 * @public
 */
export const Link = ({
  className,
  href,
  label,
  to,
  leadingIcon,
  trailingIcon,
  size = 'small',
  disabled = false,
  extraIconProps,
  ...props
}: LinkProps & React.AnchorHTMLAttributes<HTMLAnchorElement>) => {
  const isLarge = size === 'large';

  return (
    <a
      data-testid={LinkTestIds.component}
      href={!disabled ? to || href : undefined}
      className={clsx(
        'flex w-fit underline gap-2 rounded-s-md border-focused text-digital-900 border border-transparent-default rounded-md',
        {
          'cursor-pointer hover:text-digital-500 focus:text-digital-600 focus:border-digital-600':
            !disabled,
          'hover:text-link-medium-m focus:font-medium': isLarge && !disabled,
          'hover:text-link-medium-s': !isLarge && !disabled,
          'text-fg-muted cursor-not-allowed': disabled,
          'text-link-regular-m h-6 items-center ': isLarge,
          'text-link-regular-s h-5 items-end': !isLarge
        },
        className
      )}
      {...props}
    >
      {leadingIcon && (
        <div
          className={clsx('flex items-center', {
            'w-5 h-5': isLarge,
            'w-[18px] h-[18px]': !isLarge
          })}
        >
          <Icon
            name={leadingIcon}
            size={size}
            variant="outlined"
            {...extraIconProps}
          />
        </div>
      )}
      <span
        data-testid={LinkTestIds.label}
        className={clsx('flex', {
          'items-center': isLarge
        })}
      >
        {label}
      </span>
      {trailingIcon && (
        <div
          className={clsx('flex items-center', {
            'w-5 h-5': isLarge,
            'w-[18px] h-[18px]': !isLarge
          })}
        >
          <Icon name={trailingIcon} size={size} variant="outlined" />
        </div>
      )}
    </a>
  );
};
