import React from 'react';

import { axe, create, renderToHtml, screen } from '../../util/test-utils';

import { Link, LinkTestIds } from './link';
import { LinkProps } from './link.types';

describe('<Link/> component', () => {
  const renderAccessibilityLink = (props: LinkProps) =>
    create(<Link {...props} />);

  const renderLinkToHtml = (props: LinkProps) =>
    renderToHtml(<Link {...props} />);

  const baseProps: LinkProps = {
    label: 'Link test',
    leadingIcon: 'pin-location',
    to: '/',
    trailingIcon: 'arrow-right'
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityLink(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <Link/> component', () => {
      renderAccessibilityLink({
        ...baseProps
      });

      const element = screen.getByTestId(LinkTestIds.label);
      const title = screen.getByText('Link test');
      expect(element).toBeTruthy();
      expect(title).toBeTruthy();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderLinkToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
