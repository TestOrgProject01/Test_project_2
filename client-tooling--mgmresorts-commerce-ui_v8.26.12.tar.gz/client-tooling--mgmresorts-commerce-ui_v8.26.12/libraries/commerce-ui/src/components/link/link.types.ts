import { IconName, IconProps } from '../icon/icon.types';

/**
 * @public
 */
export interface LinkProps {
  label: React.ReactNode;
  to: string;
  size?: 'small' | 'large';
  leadingIcon?: IconName;
  trailingIcon?: IconName;
  disabled?: boolean;
  extraIconProps?: Omit<IconProps, 'name' | 'size' | 'variant'>;
}
