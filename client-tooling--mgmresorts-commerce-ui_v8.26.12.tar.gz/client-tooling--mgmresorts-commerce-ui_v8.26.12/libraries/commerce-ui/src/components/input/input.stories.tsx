import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Input } from './input';

export default {
  argTypes: {},
  component: Input,
  parameters: {
    actions: { argTypesRegex: null },

    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/Input'
} as Meta<typeof Input>;

const Template: StoryFn<typeof Input> = (args) => (
  <div style={{ margin: '1rem' }}>
    <Input {...args} />
  </div>
);

export const Empty = Template.bind({});

Empty.args = {
  placeholder: 'Email address',
  type: 'email'
};

export const WithError = Template.bind({});

WithError.args = {
  defaultValue: 'asm',
  error: 'Invalid email',
  placeholder: 'Email address',
  type: 'email'
};

export const Correct = Template.bind({});

Correct.args = {
  defaultValue: 'asmith@gmail.com',
  placeholder: 'Email address',
  type: 'email'
};
