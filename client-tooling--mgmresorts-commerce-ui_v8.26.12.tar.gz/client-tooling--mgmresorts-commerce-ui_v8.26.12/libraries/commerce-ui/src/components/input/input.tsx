import React, { useCallback, useRef, useState } from 'react';

import clsx from 'clsx';

import { Icon } from '../icon';

import { InputProps } from './input.types';

export const Input = ({
  className,
  error,
  placeholder,
  ...props
}: InputProps) => {
  const [focus, setFocus] = useState(false);
  const onFocus = useCallback(() => setFocus(true), []);
  const onBlur = useCallback(() => setFocus(false), []);

  const inputRef = useRef<HTMLInputElement>(null);

  const value =
    inputRef.current !== null
      ? inputRef.current.value
      : props.value ?? props.defaultValue;

  return (
    <label
      className="flex flex-col items-center gap-2 self-stretch"
      onFocus={onFocus}
      onBlur={onBlur}
    >
      <div
        className={clsx(
          'flex border-b-[0.5px] border-solid border-transparent-default h-14 self-stretch bg-white flex-grow relative',
          {
            'rounded-[8px] border-red-600': error,
            'rounded-t-[8px] border-b-gray-600': !error
          }
        )}
      >
        <span
          className={clsx(
            'absolute left-4 transition-[transform,_font-size] will-change-[transform,_font-size] cursor-text select-none',
            'font-sans font-regular leading-[135%]',
            {
              'top-[50%] -translate-y-2/4 text-m': !focus && !value,
              'top-[50%] -translate-y-[100%] text-xs': focus || !!value
            },
            {
              'text-gray-600': !error,
              'text-red-600': error
            }
          )}
        >
          {placeholder}
        </span>

        <input
          {...props}
          ref={inputRef}
          className={clsx(
            className,
            'w-full h-full pt-2x px-2x bg-brand-0',
            'text-digital-900 font-sans text-m font-regular leading-[135%]',
            'focus-visible:outline-none focus-visible:outline-offset-0',
            {
              'rounded-[8px] focus-visible:outline-red-600': error,
              'rounded-t-[8px] focus-visible:outline-digital-600': !error
            }
          )}
        />
      </div>

      {!!error && (
        <div className="flex items-center gap-2 self-stretch text-error-default">
          <Icon
            name="exclamation-point-octagon"
            variant="outlined"
            size="small"
            width={24}
            height={24}
          />
          <span className="flex-grow font-sans text-s font-regular leading-[135%]">
            {error}
          </span>
        </div>
      )}
    </label>
  );
};
