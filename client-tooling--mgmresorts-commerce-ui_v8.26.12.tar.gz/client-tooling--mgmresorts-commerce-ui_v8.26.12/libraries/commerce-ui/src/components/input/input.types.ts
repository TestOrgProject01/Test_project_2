/**
 * @public
 */
export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: string;
}
