import { DividerProps } from './divider.types';

export const defaultProps: DividerProps = {
  direction: 'vertical',
  size: 'small'
};
