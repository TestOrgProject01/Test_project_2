import React from 'react';

import { axe, create, renderToHtml } from '../../util/test-utils';

import { Divider } from './divider';
import { defaultProps } from './divider.mock';
import { DividerProps } from './divider.types';

describe('<Divider/> component', () => {
  const renderAccessibilityPackageHeader = (props: DividerProps) =>
    create(<Divider {...props} />);

  const renderDividerToHtml = (props: DividerProps) =>
    renderToHtml(<Divider {...props} />);

  const baseProps: DividerProps = {
    ...defaultProps
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityPackageHeader(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderDividerToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
