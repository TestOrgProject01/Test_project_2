import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Divider } from './divider';
import { defaultProps } from './divider.mock';

export default {
  component: Divider,
  title: 'Components/Divider'
} as Meta<typeof Divider>;

const Template: StoryFn<typeof Divider> = (args) => (
  <div className="max-w-[375px] p-3x">
    <Divider {...args} />
  </div>
);

export const Default = Template.bind({});
Default.args = { ...defaultProps };
