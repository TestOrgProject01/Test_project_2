/**
 * @public
 */
export interface DividerProps {
  direction?: 'vertical' | 'horizontal';
  size?: 'small' | 'medium' | 'large';
  height?: number;
  testId?: string;
  className?: string;
}
