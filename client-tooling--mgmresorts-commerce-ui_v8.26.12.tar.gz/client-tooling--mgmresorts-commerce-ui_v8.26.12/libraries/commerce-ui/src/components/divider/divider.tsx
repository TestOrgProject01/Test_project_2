import React from 'react';

import clsx from 'clsx';

import { DividerProps } from './divider.types';

/**
 * @public
 */
export const Divider = ({
  direction = 'horizontal',
  size = 'small',
  height,
  testId,
  className
}: DividerProps) => {
  return (
    <div
      className={clsx(
        'border-gray-100 bg-gray-100',
        {
          ' w-full h-[1px]': direction === 'horizontal',
          'border-l-medium': size === 'medium',
          'border-l-thick': size === 'large',
          'border-l-thin ': size === 'small',
          'w-[1px] h-11': direction === 'vertical'
        },
        className
      )}
      style={{ height }}
      data-testid={testId}
    />
  );
};
