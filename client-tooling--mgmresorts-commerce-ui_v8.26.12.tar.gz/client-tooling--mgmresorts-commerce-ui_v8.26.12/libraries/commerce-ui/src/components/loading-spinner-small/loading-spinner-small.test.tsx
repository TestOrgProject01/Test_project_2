import React from 'react';

import { axe, renderToHtml } from '../../util/test-utils';

import { LoadingSpinnerSmall } from './loading-spinner-small';
import { LoadingSpinnerSmallProps } from './loading-spinner-small.types';

describe('<LoadingSpinnerSmall/> component', () => {
  const renderSpinnerComponentToHtml = (props: LoadingSpinnerSmallProps) =>
    renderToHtml(<LoadingSpinnerSmall {...props} />);

  const baseProps: LoadingSpinnerSmallProps = {
    size: 'small'
  };

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderSpinnerComponentToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
