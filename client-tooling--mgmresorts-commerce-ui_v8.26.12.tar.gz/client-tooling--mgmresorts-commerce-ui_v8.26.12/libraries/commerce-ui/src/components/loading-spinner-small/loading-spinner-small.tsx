import React from 'react';

import clsx from 'clsx';

import './loading-spinner-small.css';
import { LoadingSpinnerSmallProps } from './loading-spinner-small.types';

/**
 *
 * @public
 */
export const LoadingSpinnerSmall = ({
  size = 'small'
}: LoadingSpinnerSmallProps) => {
  const isLarge = size === 'large';
  const isSmall = size === 'small';

  return (
    <div className="relative">
      <div
        className={clsx(
          'absolute top-0 border-medium border-gray-300 rounded-full',
          {
            'h-5 w-5': isSmall,
            'h-6 w-6': isLarge
          }
        )}
      />
      <div
        className={clsx(
          'loading-spinner-small aspect-1x1 rounded-full border-medium border-white',
          {
            'h-5 w-5': isSmall,
            'h-6 w-6': isLarge
          }
        )}
      />
    </div>
  );
};
