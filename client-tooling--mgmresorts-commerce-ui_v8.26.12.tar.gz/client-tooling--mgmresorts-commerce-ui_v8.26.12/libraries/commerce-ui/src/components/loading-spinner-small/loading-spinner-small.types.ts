/**
 * @public
 */
export interface LoadingSpinnerSmallProps {
  size: 'small' | 'large';
}
