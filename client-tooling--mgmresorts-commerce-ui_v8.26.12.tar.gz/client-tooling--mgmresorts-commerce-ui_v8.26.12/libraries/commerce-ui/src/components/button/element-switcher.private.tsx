import React from 'react';

import { omit } from 'rambdax';

type ButtonElementSwitcherProps =
  | (React.JSX.IntrinsicElements['button'] & { asLink: false })
  | (React.JSX.IntrinsicElements['a'] & { asLink: true });

/**
 * The goal of the component is to render either `<a />` or `<button />` element based on
 * `asLink` property, focusing in better performance than declare inside the component life cycle.
 *
 * @internal
 */
export const ButtonElementSwitcher = (props: ButtonElementSwitcherProps) => {
  if (props.asLink) return <a href="#" {...omit(['type'], props)} />;

  return <button {...omit(['asLink'], props)} />;
};
