import React from 'react';

import clsx from 'clsx';
import { omit } from 'rambdax';

import { Icon } from '../icon';
import { LoadingSpinnerSmall } from '../loading-spinner-small';

import { ButtonProps } from './button.types';
import { ButtonElementSwitcher } from './element-switcher.private';

const componentId = 'Button';
/**
 * Keys used for data-testid for testing this component.
 *
 * @public
 */
export const ButtonTestIds = {
  component: componentId,
  icon: `${componentId}:icon`
};

/**
 *
 * @public
 */
export const Button = ({
  label,
  size = 'small',
  disabled = false,
  variant = 'primary',
  icon,
  loading = false,
  onClick,
  type = 'button',
  buttonProps,
  fullWidth = false,
  selected = false,
  custom = false,
  className,
  iconProps,
  classNameIconContainer,
  asLink
}: ButtonProps) => {
  /// SIZE BUTTON
  const isLarge = size === 'large';
  const isSmall = size === 'small';

  /// VARIANT BUTTON
  const isPrimary = variant === 'primary';
  const isSecondary = variant === 'secondary';
  const isTertiary = variant === 'tertiary';

  const isAvailable = !disabled;

  // get the className from the buttonProps obj
  // if there is a className, then add it to the button
  // if there is no className, then add an empty string
  const customClassName = buttonProps?.className ?? '';

  // remove className from buttonProps obj
  if (custom && buttonProps?.className) {
    delete buttonProps.className;
  }

  return (
    <ButtonElementSwitcher
      {...(asLink ? { asLink: true } : { asLink: false, disabled, type })}
      type={type}
      data-testid={ButtonTestIds.component}
      onClick={onClick}
      className={clsx(
        'px-2x flex items-center gap-2 focus:border-double justify-center',
        {
          'active:bg-digital-50 text-digital-500 border-transparent-default hover:bg-digital-25':
            isAvailable && isTertiary && !asLink,
          'bg-gradient-to-bl from-digital-500 from-[14.64%] to-digital-600 to-50% active:to-digital-700 active:from-digital-700 hover:to-digital-500 text-white':
            isAvailable && isPrimary,
          'bg-gray-500 hover:bg-gray-500 text-white': disabled && isPrimary,
          'bg-transparent-default border-digital-900 hover:border-hover text-digital-900 active:bg-digital-900 active:text-white':
            isAvailable && isSecondary,
          'border-gray-500  text-gray-500': disabled && isSecondary,
          'border-thin': isSecondary,
          'cursor-not-allowed': disabled,
          [customClassName]: customClassName,
          'm-md:bg-digital-900 m-md:text-white': selected,
          'text-body-regular-m h-14 p-2x rounded-lg': isLarge && !custom,
          'text-body-regular-s h-10 rounded-md': isSmall && !custom,
          'text-gray-500 border-transparent-default': disabled && isTertiary,
          'w-full': fullWidth
        },
        className
      )}
      {...omit(['type'], buttonProps)}
    >
      {loading && <LoadingSpinnerSmall size={size} />}
      {!loading && icon && (
        <div
          data-testid={ButtonTestIds.icon}
          className={clsx(
            'flex items-center aspect-1x1 rounded-full',
            {
              'w-5 h-5': isSmall,
              'w-6 h-6': isLarge
            },
            classNameIconContainer
          )}
        >
          <Icon name={icon} size={size} variant="outlined" {...iconProps} />
        </div>
      )}
      {label}
    </ButtonElementSwitcher>
  );
};
