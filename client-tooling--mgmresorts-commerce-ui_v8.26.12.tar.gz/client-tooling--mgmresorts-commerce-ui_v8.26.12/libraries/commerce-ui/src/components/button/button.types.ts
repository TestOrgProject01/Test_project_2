import { IconName, IconProps } from '../icon/icon.types';

/**
 * @public
 */
export interface ButtonProps {
  /**
   * If set a label it will be placed on the button aligned to the center.
   */
  label: React.ReactNode;
  /**
   * it is used to define the size of the icon aligned to the left of the label
   */
  size?: 'small' | 'large';
  /**
   * It is used to show the button disabled and prevents the onClick event from being fired.
   */
  disabled?: boolean;
  /**
   * It is used to show the button with 100% of width
   */
  fullWidth?: boolean;
  /**
   * defines what type of style to use
   */
  variant?: 'primary' | 'secondary' | 'tertiary';
  /**
   * Set up onClick event to be fired when the button is clicked
   */
  onClick: () => void;
  /**
   * If set a icon it will be placed on the button aligned to the left.
   */
  icon?: IconName | undefined;
  /**
   * Icon props will be used to pass additional props to the icon component
   */
  iconProps?: Partial<IconProps>;
  /**
   * if set it will show a spinner to the left of the label instead of the icon
   */
  loading?: boolean;
  /**
   * If you set a type, it will be placed as the type of the button
   */
  type?: 'submit' | 'reset' | 'button' | undefined;
  /**
   * button html attributes will be spread into the button element
   */
  buttonProps?: (
    | React.AnchorHTMLAttributes<HTMLAnchorElement>
    | React.ButtonHTMLAttributes<HTMLButtonElement>
  ) & {
    'data-testid'?: string;
    'data-cms'?: string;
  };
  /**
   * If set a icon it will be placed on the button aligned to the right.
   * And the color will change.
   */
  selected?: boolean;
  /**
   * If true, the custom class name passed should be preserved
   */
  custom?: boolean;
  /**
   * Custom class name
   */
  className?: string;
  /**
   * Custom class name for the icon container
   */
  classNameIconContainer?: string;
  /**
   * Render buttons as link element
   */
  asLink?: boolean;
}
