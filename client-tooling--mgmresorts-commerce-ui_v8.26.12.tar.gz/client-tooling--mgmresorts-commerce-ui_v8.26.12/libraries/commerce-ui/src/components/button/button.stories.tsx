import React from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { Button } from './button';
import { ButtonMockData } from './button.mocks';

export default {
  component: Button,
  parameters: {
    actions: { argTypesRegex: null },
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen'
  },
  title: 'Components/Button'
} as Meta<typeof Button>;

const Template: StoryFn<typeof Button> = (args) => (
  <div>
    <Button {...args} />
  </div>
);

export const Default = Template.bind({});

Default.args = {
  ...ButtonMockData
};
