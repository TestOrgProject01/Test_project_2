import { ButtonProps } from './button.types';

export const ButtonMockData: ButtonProps = {
  disabled: false,
  fullWidth: false,
  label: 'Button label',
  loading: false,
  onClick: () => {},
  size: 'small',
  variant: 'primary'
};
