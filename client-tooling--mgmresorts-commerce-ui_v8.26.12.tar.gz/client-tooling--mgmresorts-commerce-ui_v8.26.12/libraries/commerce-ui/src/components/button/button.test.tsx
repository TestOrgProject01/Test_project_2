import React from 'react';

import {
  axe,
  create,
  fireEvent,
  renderToHtml,
  screen
} from '../../util/test-utils';

import { Button, ButtonTestIds } from './button';
import { ButtonProps } from './button.types';

describe('<Button/> component', () => {
  const renderAccessibilityButton = (props: ButtonProps) =>
    create(<Button {...props} />);

  const renderButtonToHtml = (props: ButtonProps) =>
    renderToHtml(<Button {...props} />);

  const onClick = jest.fn();

  const baseProps: ButtonProps = {
    icon: 'magnifying-glass',
    label: 'Button test',
    onClick
  };

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderAccessibilityButton(baseProps);
      expect(actual).toMatchSnapshot();
    });
  });

  it('should render secondary variant', () => {
    const actual = renderAccessibilityButton({
      ...baseProps,
      variant: 'secondary'
    });

    expect(actual).toMatchSnapshot();
  });

  it('should render tertiary variant', () => {
    const actual = renderAccessibilityButton({
      ...baseProps,
      variant: 'tertiary'
    });

    expect(actual).toMatchSnapshot();
  });

  /**
   * Logic tests.
   */
  describe('business logic', () => {
    it('should render the <Button/> component', () => {
      renderAccessibilityButton({
        ...baseProps
      });

      const element = screen.getByTestId(ButtonTestIds.component);
      const buttonLabel = screen.getByText('Button test');
      expect(element).toBeTruthy();
      expect(buttonLabel).toBeTruthy();
    });

    it('should trigger onClick callback', () => {
      renderAccessibilityButton({
        ...baseProps
      });

      const button = screen.getByTestId(ButtonTestIds.component);
      fireEvent.click(button);
      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should render as link (tag A) if the link property is `true`', () => {
      renderAccessibilityButton({
        ...baseProps,
        asLink: true
      });

      const button = screen.getByTestId(ButtonTestIds.component);

      expect(button.tagName).toEqual('A');
    });
  });

  /**
   * Accessibility tests.
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderButtonToHtml(baseProps);
      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
