import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState
} from 'react';

import {
  TextLink,
  Typography,
  LegacyCarousel,
  Radio
} from '@mgmresorts/mgm-ui';
import clsx from 'clsx';

import { useMediaQuery } from '../../util';
import { userPressedEnterOrSpace } from '../../util/rooms-dropdown';

import { RoomsMarkdown } from '../rooms-markdown';

import { RoomsAvailableRoomRatesSkeletonItem } from './rooms-available-room-rates-skeleton';
import { RoomsAvailableRoomRatesProps } from './rooms-available-room-rates.types';

/**
 * @public
 */
export const RoomsAvailableRoomRates = (
  props: RoomsAvailableRoomRatesProps
) => {
  const isFullDesktop = useMediaQuery('(min-width: 1440px)');
  const isDesktop = useMediaQuery('(min-width: 1024px)');

  const ref = useRef<any>(null);
  const [firstCalculation, setFirstCalculation] = useState(true);
  const [visible, setVisible] = useState(false);
  const [style, setStyle] = useState<React.CSSProperties>({ width: '250px' });

  useEffect(() => {
    let handler: any;

    const handleResize = () => {
      clearTimeout(handler);
      setVisible(false);

      handler = setTimeout(() => {
        const carousel = ref.current?.getDOMNode() ?? undefined;
        if (carousel === undefined) return;

        const containerWidth = (carousel as HTMLDivElement).getBoundingClientRect()
          .width;

        const width = isFullDesktop
          ? props.offers.length >= 3
            ? (containerWidth - 32) / 3
            : (containerWidth - 16) / 2
          : isDesktop
          ? (containerWidth - 16) / 2
          : containerWidth;

        setStyle({ width: `${Math.trunc(width)}px` });

        if (!props.isLoading) {
          setVisible(true);
        }

        if (firstCalculation) {
          setFirstCalculation(false);
        }
      }, props.delayRezieTimeout || 501); // This is the time that the LegacyCarousel takes to calculate the parent size.
    };

    document.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      clearTimeout(handler);
      document.removeEventListener('resize', handleResize);
    };
  }, [
    isDesktop,
    isFullDesktop,
    props.offers.length,
    props.isLoading,
    props.delayRezieTimeout,
    firstCalculation
  ]);

  const carouselSelected = useMemo(() => {
    if (props.defaultSelectedOfferId === undefined) return undefined;

    return props.offers.findIndex((o) => o.id === props.defaultSelectedOfferId);
  }, [props.offers, props.defaultSelectedOfferId]);

  const onMoreDetailsClick: React.MouseEventHandler<HTMLAnchorElement> = useCallback(
    (event) => {
      event.stopPropagation();

      const offerId = event.currentTarget.dataset.offerId;
      if (offerId === undefined) return;

      const onClick = props.moreDetails.onClick;
      if (onClick === undefined) return;

      onClick(offerId);
    },
    [props.moreDetails.onClick]
  );

  const onChange = useCallback(
    (offerIdParam: string) => {
      const onChangeCallback = props.onSelectedOfferId;
      if (onChangeCallback === undefined) return;

      onChangeCallback(offerIdParam);

      return;
    },
    [props.onSelectedOfferId]
  );

  return (
    <LegacyCarousel
      ref={ref}
      key={style?.width?.toString()}
      className={clsx(
        firstCalculation ? 'invisible' : 'visible',
        props.className
      )}
      selected={carouselSelected}
      actions={
        !props.viewMoreRates.isLoading ? (
          <Typography
            className="flex justify-end items-center gap-2 flex-1"
            variant="body-regular-s"
            data-cms={props.viewMoreRates['data-cms']}
          >
            <TextLink
              onClick={props.viewMoreRates.onClick}
              variant="large"
              className="!leading-5 !p-[0] !text-body-regular-m !outline-none"
              data-testid="viewMoreRates"
              button={true}
            >
              {props.viewMoreRates.label}
            </TextLink>
          </Typography>
        ) : null
      }
      header={
        <Typography
          as="h2"
          variant="body-medium-m"
          className="flex-1 text-digital-900"
          data-cms={props.titleDataCMS}
        >
          {props.title}
        </Typography>
      }
      step="item"
      spacing={16}
      swipeEnabled={false}
    >
      {props.offers.map((o, index) => (
        <div
          key={o.id}
          className={clsx(
            'rounded-lg bg-white h-full cursor-default relative min-h-[164px]'
          )}
          style={style}
          onClick={() => {
            onChange(o.id);
          }}
        >
          <RoomsAvailableRoomRatesSkeletonItem
            className={clsx(
              props.isLoading || !visible ? 'visible' : 'invisible',
              firstCalculation ? 'invisible' : '',
              'absolute left-4 right-4 top-4 bottom-4'
            )}
            shortContent={!o.averagePrice || !o.resortFee || !o.subtotal}
          />
          <div
            className={clsx(
              'w-full h-full flex p-2x flex-col items-start gap-2',
              props.isLoading ? 'invisible' : visible ? 'visible' : 'invisible'
            )}
          >
            <div className="group flex flex-col items-start w-full justify-between gap-1 text-digital-900 font-sans text-m font-regular leading-[135%] cursor-pointer [&_div[variant=large]:nth-child(2)]:self-start">
              <Radio
                id={`radio-${index}`}
                label={
                  <Typography
                    variant="body-medium-l"
                    className="text-digital-900 line-clamp-2"
                  >
                    {o.name}
                  </Typography>
                }
                labelPosition={'left'}
                fullWidth={true}
                variant={'large'}
                checked={props.defaultSelectedOfferId === o.id}
                onChange={() => {
                  onChange(o.id);
                }}
                value={o.id}
                disabled={false}
                onKeyDown={(e) => {
                  if (
                    props.defaultSelectedOfferId !== o.id &&
                    userPressedEnterOrSpace(e)
                  ) {
                    onChange(o.id);
                  }
                }}
                className="focus-visible:!outline-offset-[0px] focus-visible:!outline-[0px]"
              />

              <div className="flex items-start gap-1 pr-6x">
                <Typography
                  variant="body-regular-s"
                  className="text-digital-900 line-clamp-2"
                >
                  <RoomsMarkdown strictMode={true}>
                    {o.description}
                  </RoomsMarkdown>
                </Typography>
              </div>
            </div>

            {o.averagePrice || o.resortFee || o.subtotal ? (
              <div className="flex flex-col items-start self-stretch flex-1">
                {o.averagePrice !== undefined && (
                  <Typography
                    variant="body-regular-s"
                    className="text-gray-600"
                    data-cms={o.averageRoomRateDataCMS}
                  >
                    <RoomsMarkdown strictMode={true}>
                      {o.averagePrice}
                    </RoomsMarkdown>
                  </Typography>
                )}

                {o.resortFee !== undefined && (
                  <Typography
                    variant="body-regular-s"
                    className="text-gray-600"
                    data-cms={o.resortFeeDataCMS}
                  >
                    <RoomsMarkdown strictMode={true}>
                      {o.resortFee}
                    </RoomsMarkdown>
                  </Typography>
                )}

                <Typography
                  variant="body-regular-m"
                  className="text-digital-900"
                  data-cms={o.subtotalDataCMS}
                >
                  <RoomsMarkdown strictMode={true}>{o.subtotal}</RoomsMarkdown>
                </Typography>
              </div>
            ) : null}

            <div className="flex justify-center items-start gap-2 self-stretch mt-auto">
              <Typography
                variant="body-regular-s"
                className="flex-1 text-digital-900"
                data-cms={props.taxDisclaimerDataCMS}
              >
                {props.taxDisclaimer}
              </Typography>

              <Typography
                variant="body-regular-s"
                className="flex items-center gap-1 text-digital-900"
                data-cms={props.moreDetails['data-cms']}
              >
                <TextLink
                  onClick={onMoreDetailsClick}
                  variant="large"
                  className="!leading-5 !p-[0] !text-body-regular-s !outline-none"
                  data-offer-id={o.id}
                  data-testid={`link.offer.${o.id}`}
                  aria-label={props.moreDetails.label}
                  button={true}
                >
                  {props.moreDetails.label}
                </TextLink>
              </Typography>
            </div>
          </div>
        </div>
      ))}
    </LegacyCarousel>
  );
};
