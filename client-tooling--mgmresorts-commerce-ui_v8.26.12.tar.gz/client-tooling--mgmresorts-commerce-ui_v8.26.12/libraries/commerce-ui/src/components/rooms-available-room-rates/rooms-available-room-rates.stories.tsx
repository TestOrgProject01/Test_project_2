import React, { useState } from 'react';

import { Meta, StoryFn } from '@storybook/react';

import { RoomsAvailableRoomRates } from './rooms-available-room-rates';

export default {
  argTypes: {},
  component: RoomsAvailableRoomRates,
  parameters: {
    backgrounds: {
      default: 'grey',
      values: [{ name: 'grey', value: '#ededed' }]
    },
    layout: 'fullscreen',
    viewport: { defaultViewport: 'xs' }
  },
  title: 'Components/RoomsAvailableRoomRates'
} as Meta<typeof RoomsAvailableRoomRates>;

const Template: StoryFn<typeof RoomsAvailableRoomRates> = (args) => {
  const [selectedOfferId, setSelectedOfferId] = useState('1');

  return (
    <div className="d-lg:max-w-[1440px] mx-auto ">
      <div className="flex">
        <div className="w-[375px] bg-green-300 flex-none">
          <p>Select dates</p>
        </div>

        <div className="flex-1 px-2x">
          <RoomsAvailableRoomRates
            {...args}
            defaultSelectedOfferId={selectedOfferId}
            onSelectedOfferId={setSelectedOfferId}
            className="-mr-4 d-lg:mr-[calc(((100vw-1440px)/-2)-16px)]"
          />
        </div>
      </div>
    </div>
  );
};

export const Tablet = Template.bind({});

Tablet.args = {
  isLoading: false,
  moreDetails: { label: 'More details' },
  offers: [
    {
      averagePrice: undefined,
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '1',
      name: 'MGM Rewards Flexible Rate',
      resortFee: undefined,
      subtotal: '**Comp**'
    },
    {
      averagePrice: 'Comp',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '2',
      name: 'MGM Rewards Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$45 average per night**'
    },
    {
      averagePrice: '$200 average room rate',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '3',
      name: 'Save up to 10% off Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$245 average per night**'
    },
    {
      averagePrice: '$300 average room rate',
      description: 'Guaranteed best rates',
      id: '5',
      name: 'Flexible rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$345 average per night**'
    }
  ],
  taxDisclaimer: 'Excludes taxes',
  title: 'Available room rates',
  viewMoreRates: { isLoading: false, label: 'View other rates' }
};

Tablet.parameters = {
  viewport: { defaultViewport: 'md' }
};

export const Desktop = Template.bind({});

Desktop.args = {
  isLoading: false,
  moreDetails: { label: 'More details' },
  offers: [
    {
      averagePrice: undefined,
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '1',
      name: 'MGM Rewards Flexible Rate',
      resortFee: undefined,
      subtotal: '**Comp**'
    },
    {
      averagePrice: 'Comp',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '2',
      name: 'MGM Rewards Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$45 average per night**'
    },
    {
      averagePrice: '$200 average room rate',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '3',
      name: 'Save up to 10% off Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$245 average per night**'
    },
    {
      averagePrice: '$300 average room rate',
      description: 'Guaranteed best rates',
      id: '5',
      name: 'Flexible rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$345 average per night**'
    }
  ],
  taxDisclaimer: 'Excludes taxes',
  title: 'Available room rates',
  viewMoreRates: { isLoading: false, label: 'View other rates' }
};

Desktop.parameters = {
  viewport: { defaultViewport: 'lg' }
};

export const LargeDesktop = Template.bind({});

LargeDesktop.args = {
  isLoading: false,
  moreDetails: { label: 'More details' },
  offers: [
    {
      averagePrice: undefined,
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '1',
      name: 'MGM Rewards Flexible Rate',
      resortFee: undefined,
      subtotal: '**Comp**'
    },
    {
      averagePrice: 'Comp',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '2',
      name: 'MGM Rewards Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$45 average per night**'
    },
    {
      averagePrice: '$200 average room rate',
      description: 'Upto 15 % off our Flexible Rate, exclusively to members.',
      id: '3',
      name: 'Save up to 10% off Flexible Rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$245 average per night**'
    },
    {
      averagePrice: '$300 average room rate',
      description: 'Guaranteed best rates',
      id: '5',
      name: 'Flexible rate',
      resortFee: '+$45 daily resort fee',
      subtotal: '**$345 average per night**'
    }
  ],
  taxDisclaimer: 'Excludes taxes',
  title: 'Available room rates',
  viewMoreRates: { isLoading: false, label: 'View other rates' }
};

LargeDesktop.parameters = {
  viewport: { defaultViewport: 'xl' }
};
