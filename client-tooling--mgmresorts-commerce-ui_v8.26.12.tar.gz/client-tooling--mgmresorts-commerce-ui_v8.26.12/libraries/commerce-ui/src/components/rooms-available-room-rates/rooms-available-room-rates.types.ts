/**
 * @public
 */
export interface RoomsAvailableRoomRatesProps {
  className?: string;
  title: string;
  titleDataCMS?: string;
  defaultSelectedOfferId?: string;
  offers: {
    id: string;
    name: string;
    description: string;
    averagePrice: string | undefined;
    averageRoomRateDataCMS?: string;
    radioInputName?: string;
    resortFee: string | undefined;
    resortFeeDataCMS?: string;
    subtotal: string;
    subtotalDataCMS?: string;
  }[];
  moreDetails: {
    'data-cms'?: string;
    label: string;
    onClick?: (id: string) => void;
  };
  viewMoreRates: {
    'data-cms'?: string;
    label: string;
    onClick?: () => void;
    isLoading: boolean;
  };
  taxDisclaimer: string;
  taxDisclaimerDataCMS?: string;
  onSelectedOfferId?: (offerId: string) => void;
  isLoading?: boolean;
  delayRezieTimeout?: number;
}
/**
 * @internal
 */
export interface _RoomsAvailableRoomRatesSkeletonItemProps
  extends React.HTMLAttributes<HTMLDivElement> {
  shortContent?: boolean;
}
