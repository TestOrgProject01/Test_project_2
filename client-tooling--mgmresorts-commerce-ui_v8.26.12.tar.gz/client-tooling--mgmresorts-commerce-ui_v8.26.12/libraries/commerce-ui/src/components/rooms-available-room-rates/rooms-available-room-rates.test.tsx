import React from 'react';

import { screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import {
  axe,
  createWithDesignTokensProvider,
  renderToHtmlWithDesignTokensProvider
} from '../../util/test-utils';

import { RoomsAvailableRoomRates } from './rooms-available-room-rates';
import { RoomsAvailableRoomRatesProps } from './rooms-available-room-rates.types';

describe('<RoomsAvailableRoomRates/> component', () => {
  const renderComponent = (props: RoomsAvailableRoomRatesProps) =>
    createWithDesignTokensProvider(<RoomsAvailableRoomRates {...props} />);

  const renderHTML = (props: RoomsAvailableRoomRatesProps) =>
    renderToHtmlWithDesignTokensProvider(
      <RoomsAvailableRoomRates {...props} />
    );

  /**
   * Style tests.
   */
  describe('styles', () => {
    it('should render with default styles', () => {
      const actual = renderComponent({
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: { isLoading: false, label: 'viewMoreRates.label' }
      });

      expect(actual).toMatchSnapshot();
    });
  });

  /**
   * Props tests.
   */
  describe('props', () => {
    it('custom labels', () => {
      renderComponent({
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: { isLoading: false, label: 'viewMoreRates.label' }
      });

      screen.getByText('moreDetails.label');
      screen.getByText('offer.1.averagePrice');
      screen.getByText('offer.1.description');
      screen.getByText('offer.1.name');
      screen.getByText('offer.1.resortFee');
      screen.getByText('offer.1.subtotalt');
      screen.getByText('taxDisclaimer');
      screen.getByText('title');
      screen.getByText('viewMoreRates.label');
    });
  });

  /**
   * Actions tests.
   */
  describe('actions', () => {
    it('onMoreDetailsClick', () => {
      const onMoreDetailsClick = jest.fn();

      renderComponent({
        moreDetails: {
          label: 'moreDetails.label',
          onClick: onMoreDetailsClick
        },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: { isLoading: false, label: 'viewMoreRates.label' }
      });

      const input = screen.getByTestId('link.offer.1');
      fireEvent.click(input);

      expect(onMoreDetailsClick).toHaveBeenCalledWith('1');
    });

    it('onViewMoreRatesClick', () => {
      const onViewMoreRatesClick = jest.fn();

      renderComponent({
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: {
          isLoading: false,
          label: 'viewMoreRates.label',
          onClick: onViewMoreRatesClick
        }
      });

      const input = screen.getByTestId('viewMoreRates');
      fireEvent.click(input);

      expect(onViewMoreRatesClick).toHaveBeenCalled();
    });

    it('should not render view other offers label when rates are still loading', () => {
      const onViewMoreRatesClick = jest.fn();

      renderComponent({
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: {
          isLoading: true,
          label: 'view other offers',
          onClick: onViewMoreRatesClick
        }
      });

      expect(screen.queryByText('view other offers')).not.toBeInTheDocument();
    });
  });

  /**
   * Accessibility tests
   */
  describe('accessibility', () => {
    it('should meet accessibility guidelines', async () => {
      const wrapper = renderHTML({
        moreDetails: { label: 'moreDetails.label' },
        offers: [
          {
            averagePrice: 'offer.1.averagePrice',
            description: 'offer.1.description',
            id: '1',
            name: 'offer.1.name',
            resortFee: 'offer.1.resortFee',
            subtotal: 'offer.1.subtotalt'
          }
        ],
        taxDisclaimer: 'taxDisclaimer',
        title: 'title',
        viewMoreRates: { isLoading: false, label: 'viewMoreRates.label' }
      });

      const actual = await axe(wrapper);
      expect(actual).toHaveNoViolations();
    });
  });
});
