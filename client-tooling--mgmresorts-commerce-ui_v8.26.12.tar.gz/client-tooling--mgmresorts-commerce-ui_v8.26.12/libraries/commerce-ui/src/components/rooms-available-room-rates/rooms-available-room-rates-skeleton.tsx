import React from 'react';

import clsx from 'clsx';

import { Skeleton } from '../skeleton';

import { _RoomsAvailableRoomRatesSkeletonItemProps } from './rooms-available-room-rates.types';

export const RoomsAvailableRoomRatesSkeletonItem = (
  props: _RoomsAvailableRoomRatesSkeletonItemProps
) => (
  <div className={clsx(props.className)}>
    <Skeleton width="80%" height="20px" className="!rounded-[22.5px] mb-2" />
    <Skeleton width="65%" height="12px" className="!rounded-[17.5px] mb-6" />
    <Skeleton
      width="40%"
      height="12px"
      className={clsx({ hidden: props.shortContent }, '!rounded-[17.5px] mb-2')}
    />
    <Skeleton width="80%" height="20px" className="!rounded-[22.5px] mb-11" />
    <div className="flex justify-between absolute bottom-0 left-0 right-0">
      <Skeleton width="40%" height="12px" className="!rounded-[17.5px]" />
      <Skeleton width="30%" height="12px" className="!rounded-[17.5px]" />
    </div>
  </div>
);
