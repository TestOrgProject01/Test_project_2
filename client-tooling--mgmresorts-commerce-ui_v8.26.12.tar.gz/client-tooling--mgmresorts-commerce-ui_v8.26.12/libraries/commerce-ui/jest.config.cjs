const esmModules = ['react-markdown'].join('|');

module.exports = {
  collectCoverage: true,
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.stories.tsx',
    '!src/**/*.(mock|mocks).{js,jsx,ts,tsx}',
    '!**/node_modules/**',
    '!**/coverage/**',
    '!**/lib-commonjs/**',
    '!**/lib-es6/**'
  ],
  coverageDirectory: '<rootDir>/.coverage',
  coveragePathIgnorePatterns: [
    '/node_modules/',
    'package.json',
    'package-lock.json',
    '.*__snapshots__/.*',
    '/lib-commonjs/',
    '/lib-es6/',
    '/dist/'
  ],
  coverageReporters: [
    'html',
    'text-summary',
    [
      'lcovonly',
      {
        file: 'lcov.info'
      }
    ]
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 70,
      lines: 70,
      statements: 70
    }
  },
  globalSetup: '<rootDir>/jest.global-setup.cjs',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx'],
  moduleNameMapper: {
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
    // Mocks out all these file formats when tests are run
    '\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      'identity-obj-proxy',
    '^#testing/(.*)': '<rootDir>/testing/$1'
  },
  modulePathIgnorePatterns: [
    '<rootDir>/.+.story.tsx',
    '<rootDir>/lib-commonjs/',
    '<rootDir>/lib-es6/',
    '<rootDir>/dist/'
  ],
  setupFiles: ['jest-canvas-mock'],
  setupFilesAfterEnv: ['./jest.setup.ts'],
  testEnvironment: 'jsdom',
  testMatch: ['**/*.(test|spec).(js|jsx|ts|tsx)'],
  testPathIgnorePatterns: [
    '/node_modules/',
    '/lib-commonjs/',
    '/lib-es6/',
    '/dist/'
  ],
  testTimeout: 30000,

  transform: {
    '^.+\\.(t|j)sx?$': [
      '@swc/jest',
      {
        jsc: {
          transform: {
            react: {
              runtime: 'automatic'
            }
          }
        }
      }
    ]
  },
  transformIgnorePatterns: [
    `/node_modules/(?!${esmModules})/`,
    `node_modules\\\\(?!${esmModules}).+\\.js$`
  ],
  // This is a workaround for:
  // https://github.com/facebook/jest/issues/11956
  workerIdleMemoryLimit: '1GB'
};
