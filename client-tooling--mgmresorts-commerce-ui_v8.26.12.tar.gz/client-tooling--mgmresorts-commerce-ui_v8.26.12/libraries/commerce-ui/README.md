# Commerce UI Web Components

[:book:](https://mgmresorts.github.io/commerce-ui)

## Running the Storybook

First of all, make sure that you are in the "commerce-ui" folder. Assuming that you are in the commerce-ui folder you can just run the below command:

```sh
$ pnpm storybook
```

This will initialize the Storybook server.
