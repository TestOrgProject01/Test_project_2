import '@testing-library/react';
import '@testing-library/jest-dom';
import '@testing-library/jest-dom/extend-expect';

import { configure } from '@testing-library/react';
import { TextDecoder, TextEncoder } from 'util';
import { toHaveNoViolations } from 'jest-axe';

expect.extend(toHaveNoViolations);

/**
 * This magically makes the warning below go away.
 * `Warning: [JSS] Cannot set property 'parentStyleSheet' of undefined`
 * https://stackoverflow.com/questions/66760985/jest-mocking-a-javascript-created-injected-stylesheet
 */
window.CSSStyleSheet.prototype.insertRule = (rule) => {
  const styleElement = document.createElement('style');
  const textNode = document.createTextNode(rule);

  styleElement.appendChild(textNode);
  document.head.appendChild(styleElement);

  return 0;
};

(window.SVGElement.prototype as SVGGraphicsElement).getBBox = () => {
  return {
    bottom: 0,
    height: 0,
    left: 0,
    right: 0,
    top: 0,
    width: 0,
    x: 0,
    y: 0
  } as DOMRect;
};

Object.defineProperty(window.SVGElement.prototype, 'viewBox', {
  configurable: true,
  value: { baseVal: { width: 0, height: 0, x: 0, y: 0 } } // default value, you can change it on each test case if needed
});

configure({ asyncUtilTimeout: 30000 });

global.beforeAll(() => {
  const intersectionObserverMock = () => ({
    disconnect: () => null,
    observe: () => null
  });

  window.IntersectionObserver = jest
    .fn()
    .mockImplementation(intersectionObserverMock);

  window.ResizeObserver = jest.fn().mockImplementation(() => ({
    disconnect: jest.fn(),
    observe: jest.fn()
  }));
});

global.beforeEach(() => {
  Object.defineProperty(window, 'matchMedia', {
    value: jest.fn().mockImplementation((query) => ({
      addEventListener: jest.fn(),
      addListener: jest.fn(),
      dispatchEvent: jest.fn(),
      matches: false,
      media: query,
      onchange: null,
      removeEventListener: jest.fn(),
      removeListener: jest.fn()
    })),
    writable: true
  });
});

global.afterEach(() => {
  jest.clearAllMocks();
});

global.TextDecoder = TextDecoder as unknown as typeof global.TextDecoder;
global.TextEncoder = TextEncoder as unknown as typeof global.TextEncoder;
