// This is a workaround for https://github.com/eslint/eslint/issues/3458
require('@mgmresorts/eslint-config-cet/patch/modern-module-resolution');

/**
 * @type {import("eslint").Linter.Config}
 */
module.exports = {
  env: {
    es6: true
  },
  extends: ['@mgmresorts/eslint-config-cet/profiles/web-app/recommended'],
  ignorePatterns: ['jest.setup.ts'],
  overrides: [
    {
      excludedFiles: '*.test.js',
      files: ['src/sdk.ts'],
      rules: {
        'no-underscore-dangle': 0
      }
    },
    {
      files: [
        '**/*{.,_}{test,spec,stories}.{js,jsx,ts,tsx}',
        './src/util/test-utils.tsx'
      ],
      rules: {
        'import/no-default-export': 'off',
        'import/no-extraneous-dependencies': 'off',
        'no-console': 'off'
      }
    }
  ],
  parserOptions: {
    project: './tsconfig.lint.json',
    tsconfigRootDir: __dirname
  },
  rules: {
    'no-restricted-imports': [
      'error',
      {
        message: 'Use `src/modules/logrocket` instead.',
        name: 'logrocket'
      }
    ]
  },
  settings: {
    'import/resolver': {
      node: {
        extensions: ['.js', '.jsx', '.ts', '.tsx']
      }
    }
  }
};
