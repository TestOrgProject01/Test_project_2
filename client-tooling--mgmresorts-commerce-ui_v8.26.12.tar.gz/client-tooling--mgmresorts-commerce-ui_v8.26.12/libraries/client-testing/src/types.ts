import { Config as JestTypes } from '@jest/types';
import { PartialStrykerOptions } from '@stryker-mutator/api/core';

/**
 * Cypress configuration.
 *
 * @public
 */
// XXX - Requires update to correct typing for config file
export type CypressConfig = {
  [k: string]: unknown;
};

/**
libraries/client-testing/src/configs/jest/config.test.ts * Jest configuration.
 *
 * @public
 */
export type JestConfig = JestTypes.InitialOptions;

/**
 * Stryker configuration.
 *
 * @public
 */
export type StrykerConfig = PartialStrykerOptions;
