export { default as createCypressConfig } from './cypress/config';

export { default as createJestConfig } from './jest/config';

export { default as createStrykerConfig } from './stryker/config';
