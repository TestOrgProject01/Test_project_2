export const baseConfig = () => ({
  defaultCommandTimeout: 30000,
  reporter: 'cypress-multi-reporters',
  reporterOptions: {
    configFile: './reporter-config.json'
  },
  env: {},
  numTestsKeptInMemory: 1,
  chromeWebSecurity: false,
  projectId: 'AczpTQ',
  viewportHeight: 800,
  viewportWidth: 1280,
  video: false,
  e2e: {
    pageLoadTimeout: 100_000,
    baseUrl: 'http://localhost:3000/',
    specPattern: 'cypress/integration/**/*.feature',
    excludeSpecPattern: []
  }
});
