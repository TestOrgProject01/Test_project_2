import { baseConfig } from './base-config';
import { merge } from 'rambdax';
import { CypressConfig } from '../../types';

/**
 * Provides safe defaults for LogRocket initialization that can be overridden
 * with partial configuartion.
 *
 * @public
 */
const createCypressConfig = (overrides: CypressConfig = {}) =>
  merge(baseConfig)(overrides);

export default createCypressConfig;
