import { StrykerConfig } from '../../types';

export const baseConfig = (): StrykerConfig => ({
  packageManager: 'pnpm',
  reporters: ['clear-text', 'progress', 'dashboard'],
  testRunner: 'jest',
  testRunner_comment:
    'More information about the jest plugin can be found here: https://stryker-mutator.io/docs/stryker-js/jest-runner',
  coverageAnalysis: 'perTest',
  plugins: ['@stryker-mutator/jest-runner']
});
