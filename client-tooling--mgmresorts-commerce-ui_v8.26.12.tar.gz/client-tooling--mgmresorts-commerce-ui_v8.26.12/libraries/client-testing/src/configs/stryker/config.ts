import { StrykerConfig } from '../../types';
import { baseConfig } from './base-config';
import { mergeDeepRight } from 'rambdax';

/**
 * Provides safe defaults for Stryker initialization that can be overridden
 * with partial configuartion.
 *
 * @public
 */
const createStrykerConfig = (overrides = {}): StrykerConfig =>
  mergeDeepRight<StrykerConfig>(baseConfig)(overrides);

export default createStrykerConfig;
