import { JestConfig } from '../../types';

export const baseConfig = (): JestConfig => ({
  clearMocks: true,
  collectCoverageFrom: [
    '{src,pages,server}/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.story.tsx',
    '!**/node_modules/**',
    '!**/coverage/**'
  ],
  collectCoverage: true,
  coveragePathIgnorePatterns: [
    '/node_modules/',
    'package.json',
    'package-lock.json'
  ],
  coverageDirectory: '<rootDir>/.coverage',
  coverageReporters: [
    'html',
    'text-summary',
    [
      'lcovonly',
      {
        file: 'lcov.info'
      }
    ]
  ],
  coverageThreshold: {
    global: {
      statements: 65,
      branches: 45,
      functions: 55,
      lines: 65
    }
  },
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx'],
  moduleNameMapper: {
    '\\.(css|less)$': 'identity-obj-proxy',
    '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      '<rootDir>/__mocks__/fileMock.js',
    '^#next/(.*)': '<rootDir>/next-utils/$1',
    '^#pages/(.*)': '<rootDir>/pages/$1',
    '^#public/(.*)': '<rootDir>/public/$1',
    '^#testing/(.*)': '<rootDir>/testing/$1',
    '^src/(.*)': '<rootDir>/src/$1',
    '^react($|/.+)': '<rootDir>/node_modules/react$1' // makes sure all React imports are running off of the one in this package.
  },
  modulePathIgnorePatterns: ['<rootDir>/.+.story.tsx', 'cypress'],
  setupFiles: ['./jest.setup-all.js', 'jest-canvas-mock'],
  setupFilesAfterEnv: [
    '@testing-library/jest-dom',
    '<rootDir>/testing/setup.jest.ts',
    '<rootDir>/testing/mocks/setupMockClient.jest.js'
  ],
  testEnvironment: 'jsdom',
  testEnvironmentOptions: {
    url: 'https://www.mgmresorts.com'
  },
  testMatch: ['**/*.(test|spec).(js|jsx|ts|tsx)'],
  testPathIgnorePatterns: ['/cypress/specs', '/cypress/perf'],
  testTimeout: 30_000,
  transform: {
    '(jest.setup-all|setupMockClient.jest).js$': '@swc/jest',
    '.*\\.(tsx?)$': [
      '@swc/jest',
      {
        jsc: {
          transform: {
            react: {
              runtime: 'automatic'
            }
          }
        }
      }
    ]
  },

  transformIgnorePatterns: [],

  // This is a workaround for:
  // https://github.com/facebook/jest/issues/11956
  workerIdleMemoryLimit: '1GB'
});
