import { JestConfig } from '../../types';
import { baseConfig } from './base-config';
import { mergeDeepRight } from 'rambdax';

/**
 * Provides safe defaults for Jest initialization that can be overridden
 * with partial configuartion.
 *
 * @public
 */
const createJestConfig = (overrides = {}): JestConfig =>
  mergeDeepRight<JestConfig>(baseConfig())(overrides);

export default createJestConfig;
