import { baseConfig } from './base-config';
import createJestConfig from './config';

describe('jest', () => {
  describe('createJestConfig', () => {
    it('should merge the presets of the base config with the custom config', () => {
      const newConfig = {
        fakeProp: ['other-fake-prop']
      };
      const actual = createJestConfig(newConfig);

      expect(actual).not.toEqual(baseConfig());
    });

    it('array override for same key should replace', () => {
      const newConfig = {
        collectCoverageFrom: ['other-fake-prop']
      };
      const actual = createJestConfig(newConfig);

      expect(actual).not.toEqual(baseConfig());
    });

    it('object override for same key should append value', () => {
      const newConfig = {
        moduleNameMapper: {
          'other-fake-prop': 'fake-value'
        }
      };
      const actual = createJestConfig(newConfig);

      expect(actual).not.toEqual(baseConfig());
    });
  });
});
