export {
  createCypressConfig,
  createJestConfig,
  createStrykerConfig
} from './configs';

export type { JestConfig, CypressConfig, StrykerConfig } from './types';
