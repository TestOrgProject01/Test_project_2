export {};

declare global {
  export interface Window {}
}
