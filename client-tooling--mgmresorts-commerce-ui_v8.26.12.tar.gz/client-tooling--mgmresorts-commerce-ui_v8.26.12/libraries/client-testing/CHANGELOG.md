## 2.5.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### 🧱 Updated Dependencies

- Updated client-typescript-config to 2.6.1

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 2.5.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- Add checks to commerce ui - CSBP-2287 ([#48](https://github.com/MGMResorts/client-tooling/pull/48))
- corrected name of testing library type file ([2dcdb22d](https://github.com/MGMResorts/client-tooling/commit/2dcdb22d))
- removed un-needed cypress packages ([c3f7c6b0](https://github.com/MGMResorts/client-tooling/commit/c3f7c6b0))
- added missing api-extractor package ([dc2dd5cf](https://github.com/MGMResorts/client-tooling/commit/dc2dd5cf))
- added new testing package ([10ca1f5d](https://github.com/MGMResorts/client-tooling/commit/10ca1f5d))

### 🩹 Fixes

- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))

### 🧱 Updated Dependencies

- Updated client-typescript-config to 2.6.0

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Gustavo Arellano @GustavoFSLCo
- Rob Fyffe

# Change Log - @mgmresorts/client-testing

This log was last generated on Wed, 07 Aug 2024 20:50:00 GMT and should not be manually modified.

## 2.4.11
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 2.4.10
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 2.4.9
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 2.4.8
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 2.4.7
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 2.4.6
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 2.4.5
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 2.4.4
Thu, 20 Apr 2023 18:51:09 GMT

_Version update only_

## 2.4.3
Fri, 14 Apr 2023 04:59:47 GMT

_Version update only_

## 2.4.2
Fri, 14 Apr 2023 04:45:04 GMT

_Version update only_

## 2.4.1
Fri, 14 Apr 2023 03:46:03 GMT

_Version update only_

## 2.4.0
Thu, 13 Apr 2023 23:58:00 GMT

### Minor changes

- changed name of type file to correct name

## 2.3.0
Thu, 13 Apr 2023 23:38:11 GMT

### Minor changes

- removed un-needed cypress packages

## 2.2.0
Wed, 12 Apr 2023 20:03:37 GMT

### Minor changes

- added new package for managing testing configurations
- added api-extractor dependency from microsoft

