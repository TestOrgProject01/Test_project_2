import { mergeAll, Dictionary } from 'rambdax';

import { maskEmail, maskStr, maskPhoneNumber } from '../utils/maskers/index.js';
import maskFirstChar from '../utils/maskers/maskFirstChar.js';

type Variations = Dictionary<(value: unknown) => unknown>;

const nameFieldVariations = {
  cardHolderName: maskStr,
  family_name: maskStr,
  firstName: maskStr,
  first_name: maskStr,
  fullName: maskStr,
  full_name: maskStr,
  given_name: maskStr,
  lastName: maskStr,
  last_name: maskStr,
  middleName: maskStr,
  middle_name: maskStr,
  nameOnCard: maskStr
} as Variations;

// TODO: Make these operate on the `Authorization` header.
const mgmIdVariations = {
  'com.mgm.gse.id': maskStr,
  'com.mgm.mlife_number': maskStr,
  mgmId: maskStr,
  mlife: maskStr,
  mlifeAccountNumber: maskStr,
  mlifeNumber: maskStr
} as Variations;

const birthdayFieldVariations = {
  age: maskStr,
  birthdate: maskStr,
  birthday: maskStr
} as Variations;

const addressFieldVariations = {
  postalCode: maskStr,
  profilePostalCode: maskStr,
  profileStreet1: maskStr,
  profileStreet2: maskStr,
  street1: maskStr,
  street2: maskStr
} as Variations;

const paymentAddressVariations = {
  address: maskStr,
  address1: maskStr,
  address2: maskStr,
  city: maskStr,
  country: maskStr,
  postalCode: maskStr,
  state: maskStr,
  zip: maskStr,
  zipCode: maskStr
} as Variations;

const paymentVariations = {
  cardHolderFirstName: maskStr,
  cardHolderLastName: maskStr,
  cardHolderName: maskStr,
  nameOnTender: maskStr,
  securityCode: maskStr
} as Variations;

const emailFieldVariations = {
  email: maskEmail,
  emailAddress: maskEmail,
  emailAddress1: maskEmail,
  emailAddress2: maskEmail,
  email_address: maskEmail,
  login: maskEmail,
  sub: maskEmail
} as Variations;

const phoneFieldVariations = {
  mobile_phone: maskPhoneNumber,
  number: maskPhoneNumber,
  phone: maskPhoneNumber,
  phoneNumber: maskPhoneNumber,
  phone_number: maskPhoneNumber,
  telephone: maskPhoneNumber
} as Variations;

const authFieldVariations = {
  accessToken: maskFirstChar,
  access_token: maskFirstChar,
  cardCVV: maskStr,
  id_token: maskFirstChar,
  password: maskStr,
  value: maskFirstChar
} as Variations;

export const defaultTransformers = mergeAll<Variations>([
  mgmIdVariations,
  nameFieldVariations,
  birthdayFieldVariations,
  addressFieldVariations,
  paymentAddressVariations,
  paymentVariations,
  emailFieldVariations,
  phoneFieldVariations,
  authFieldVariations
]);
