import { Dictionary } from 'rambdax';

import { defaultNetworkInclusions } from './network.js';
import { defaultTransformers } from './variations.js';

/**
 * @public
 */
export type Sanitizer = Dictionary<(value: unknown) => unknown>;

/**
 * Sanitizers configuration.
 *
 * @remarks
 * `exclusions` is not yet implemented.
 *
 * @public
 */
export interface SanitizersConfig {
  /**
   * Sanitizers to be run on request header and response body fields.
   */
  sanitizers: Sanitizer;
  /**
   * Field(s) which should be excluded from sanitization.
   */
  exclusions?: string[] | symbol[];
  /**
   * Network requests which should be included for sanitization.
   * By default `graphql`, `identity`, and `payment` calls are sanitized.
   */
  networkInclusions?: string[];
}

export const defaultSanitizers: SanitizersConfig = {
  networkInclusions: defaultNetworkInclusions,
  sanitizers: defaultTransformers
};
