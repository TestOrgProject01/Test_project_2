type NetworkInclusions = string[];

/**
 * When determining which network requests to sanitize, Logrocket configuration
 * searches for substrings contained in the request URL. This is the default set of
 * substrings to match.
 */
export const defaultNetworkInclusions: NetworkInclusions = [
  'graphql',
  'identity',
  'payment'
];
