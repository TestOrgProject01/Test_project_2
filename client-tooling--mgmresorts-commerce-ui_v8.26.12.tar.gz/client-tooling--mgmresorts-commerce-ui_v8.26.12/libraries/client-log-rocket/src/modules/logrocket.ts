// eslint-disable-next-line no-restricted-imports
export { default as LogRocket } from 'logrocket';
