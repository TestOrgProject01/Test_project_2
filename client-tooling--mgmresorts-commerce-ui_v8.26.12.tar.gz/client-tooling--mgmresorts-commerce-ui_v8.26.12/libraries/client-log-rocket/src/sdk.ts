import * as Privacy from '@mgmresorts/client-utils/Privacy';
import Cookies from 'js-cookie';

import { LogRocket as L } from './modules/logrocket.js';
import { SanitizersConfig } from './sanitizers/index.js';
import { LrAppId, LrConfig, LrReduxMiddleware } from './types.js';
import makeLrConfig from './utils/makeLrConfig.js';
import makeLrMiddlewareOptions from './utils/makeLrMiddlewareOptions.js';
import { skipWhenTrackingDisabled } from './utils/skipWhenTrackingDisabled.js';

/**
 * {@link LogRocketSdkSingleton} initial configuration.
 *
 * @public
 */
export interface LogRocketSdkConfig {
  /**
   * Find your App ID on https://app.logrocket.com.
   */
  appId: LrAppId;
  /**
   * The path to get the Adobe Analytics journey-id from the session storage.
   * Default to 'journey-id'.
   */
  journeyIdPath?: string;
  /**
   * The path to get the Launch Darkly user-key from the cookies.
   * Default to '__mgm-ld-id2'
   */
  userKeyPath?: string;
  /**
   * Optional configuration.
   */
  options?: {
    /**
     * Turn on debugging options
     *
     * @remarks
     * Defaults to `false`.
     */
    debug?: boolean;
    /**
     * Provides default sanitizers if enabled.
     *
     * @remarks
     * Configuration can be provided which allows for field exclusions.
     *
     * @privateRemarks
     * TODO: Document default sanitiers.
     * TODO: Allow this to receive `boolean` to trigger default configuration or skip.
     */
    sanitizers?: SanitizersConfig;
    /**
     * If enabled, sessions will be stitched using the host name.
     *
     * @remarks
     * Defaults to `false`.
     */
    stitchSessions?: boolean;
    /**
     * LogRocket configuration overrides will be merged with the defaults.
     */
    overrides?: Partial<LrConfig>;
  };
}

/**
 * {@link LogRocketSdk} singleton builder.
 *
 * @remarks
 * Do not use this directly. Use {@link LogRocketSdk}, instead.
 *
 * @public
 */
export class LogRocketSdkSingleton {
  private static _instance: LogRocketSdkSingleton;
  private static canInit: boolean = true;

  logRocketConfig: LrConfig = {};
  middlewareOptions: LrReduxMiddleware = {};

  private readonly unsubscriptions: (() => void)[];

  constructor() {
    this.unsubscriptions = [];

    if (LogRocketSdkSingleton._instance) {
      // eslint-disable-next-line no-constructor-return
      return LogRocketSdkSingleton._instance;
    }

    LogRocketSdkSingleton._instance = this;
  }

  /**
   * Initialize the SDK with sane defaults.
   *
   * @param config - configuration object defined by {@link LogRocketSdkConfig}
   */
  @skipWhenTrackingDisabled
  init(config: LogRocketSdkConfig) {
    const {
      appId,
      journeyIdPath,
      userKeyPath,
      options = {
        stitchSessions: false
      }
    } = config;

    this.logRocketConfig = makeLrConfig(options);
    this.middlewareOptions = makeLrMiddlewareOptions(options);

    if (LogRocketSdkSingleton.canInit) {
      // eslint-disable-next-line no-console
      console.log('[LogRocket]: initializing...');

      this.eventWatcher();

      L.init(appId, this.logRocketConfig);
      LogRocketSdkSingleton.canInit = false;

      this.unsubscriptions.push(
        LogRocketSdkSingleton.handleJourneyIdChanges(
          journeyIdPath ?? 'journey-id'
        ),
        LogRocketSdkSingleton.handleUserKeyChanges(
          userKeyPath ?? '__mgm-ld-id2'
        )
      );
    }

    return this;
  }

  /**
   * De-initialize the SDK if required
   */
  private uninstall() {
    // eslint-disable-next-line no-console
    console.log('[LogRocket]: uninstalling...');

    /**
     * Needs to be typed to any since LR interface does not provide typing
     * This request to LR has been provided to them.
     */
    (L as any).uninstall();
    LogRocketSdkSingleton.canInit = false;
    this.unsubscriptions.forEach((unsubscription) => unsubscription());
  }

  private static handleUserKeyChanges(userKeyPath: string): () => void {
    if (typeof window === 'undefined') return () => {};

    const trackUserKey = (userKey: string) => {
      // eslint-disable-next-line no-console
      console.log('[LogRocket]: new Launch Darkly user-key detected!', userKey);
      L.track('userKey', { userKey });
    };

    // eslint-disable-next-line no-console
    console.log('[LogRocket]: tracking Launch Darkly user-key changes...');

    let userKey = Cookies.get(userKeyPath);
    if (userKey) trackUserKey(userKey);

    const handler = setInterval(() => {
      const currentUserKey = Cookies.get(userKeyPath);
      if (!currentUserKey || currentUserKey === userKey) return;

      userKey = currentUserKey;
      trackUserKey(userKey);
    }, 5000);

    return () => clearInterval(handler);
  }

  private static handleJourneyIdChanges(journeyIdPath: string): () => void {
    if (typeof window === 'undefined') return () => {};

    const trackJourneyId = (journeyId: string) => {
      // eslint-disable-next-line no-console
      console.log(
        '[LogRocket]: new Adobe Analytics journey-id detected!',
        journeyId
      );

      L.track('journeyId', { journeyId });
    };

    // eslint-disable-next-line no-console
    console.log('[LogRocket]: tracking Adobe Analytics journey-id changes...');

    const journeyId = sessionStorage.getItem(journeyIdPath);
    if (journeyId) trackJourneyId(journeyId);

    const handleJourneyIdChange = (event: StorageEvent) => {
      if (event.storageArea !== sessionStorage) return;
      if (event.key !== journeyIdPath) return;
      if (!event.newValue) return;
      trackJourneyId(event.newValue);
    };

    window.addEventListener('storage', handleJourneyIdChange);

    return () => window.removeEventListener('storage', handleJourneyIdChange);
  }

  /**
   * Identify a user with the current session, optionally accepting additional user traits.
   */
  @skipWhenTrackingDisabled
  identify(...args: [uid: string, traits?: Parameters<typeof L.identify>[0]]) {
    const [uid, traits] = args;
    L.identify(uid, traits);
  }

  /**
   * Manually report string errors to LogRocket.
   */
  @skipWhenTrackingDisabled
  captureMessage(...args: Parameters<typeof L.captureMessage>) {
    const [message, options] = args;
    L.captureMessage(message, options);
  }

  /**
   * Manually report exceptions to LogRocket.
   */
  @skipWhenTrackingDisabled
  captureException(...args: Parameters<typeof L.captureException>) {
    const [exception, options] = args;
    L.captureException(exception, options);
  }

  /**
   * Manually report events to LogRocket.
   */
  @skipWhenTrackingDisabled
  captureEvent(...args: Parameters<typeof L.track>) {
    const [message, options] = args;
    L.track(message, options);
  }

  /**
   * Get the current session URL in a callback function.
   */
  @skipWhenTrackingDisabled
  getSessionURL(...args: Parameters<typeof L.getSessionURL>) {
    const [callback] = args;

    return L.getSessionURL(callback);
  }

  /**
   * Returns a Redux middleware which adds Redux logs to LogRocket sessions.
   *
   * @see {@link https://docs.logrocket.com/reference/redux-logging}
   */
  reduxMiddleware() {
    return L.reduxMiddleware(this.middlewareOptions);
  }

  /**
   * When a user changes their cookie preferences
   * we need to update tracking to reflect that
   */
  private eventWatcher() {
    Privacy.privacyPreferencesUpdated(() => {
      if (Privacy.isPerformanceCookieDisabled()) {
        this.uninstall();
      }
    });
  }

  /**
   * Returns configuration object defining SDK behavior.
   */
  get debug() {
    return {
      // `any` is required due to LR namespace
      config: this.logRocketConfig as any,

      hasInitialized: !LogRocketSdkSingleton.canInit
    };
  }
}

/**
 * LogRocketSdk singleton instance.
 *
 * @see {@link https://mgmresorts.github.io/client-log-rocket}
 *
 * @public
 */
export const LogRocketSdk = new LogRocketSdkSingleton();
