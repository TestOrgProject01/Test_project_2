export {};

declare global {
  export interface Window {
    OneTrust?: {
      OnConsentChanged?: (cb: () => void) => void;
    };
  }
}
