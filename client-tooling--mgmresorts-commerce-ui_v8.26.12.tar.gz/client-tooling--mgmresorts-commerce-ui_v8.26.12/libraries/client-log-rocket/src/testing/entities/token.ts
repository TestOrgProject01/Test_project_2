import { faker } from '@faker-js/faker';

import createRandomUser from './user.js';

const createRandomToken = (): object => ({
  ...createRandomUser,
  'com.mgm.id': faker.random.word(),
  'com.mgm.mlife_number': faker.random.word()
});

export default createRandomToken;
