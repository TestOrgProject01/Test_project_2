import { faker } from '@faker-js/faker';

const createRandomUser = (): object => ({
  birthday: faker.date.birthdate(),
  email: faker.internet.email(),
  firstName: faker.name.firstName(),
  id: faker.datatype.uuid(),
  lastName: faker.name.lastName(),
  name: {
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName()
  }
});

export default createRandomUser;
