import createRandomUser from './entities/user.js';

const mockNestedObject = {
  topLevel: {
    secondLevel: {
      ...createRandomUser(),
      thirdLevel: createRandomUser()
    }
  },
  ...createRandomUser()
};

export default mockNestedObject;
