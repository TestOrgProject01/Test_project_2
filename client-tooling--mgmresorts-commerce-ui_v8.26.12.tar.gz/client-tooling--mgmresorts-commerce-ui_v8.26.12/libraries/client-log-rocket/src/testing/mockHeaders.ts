import jwt_encode from 'jwt-encode';
import { v4 as uuidv4 } from 'uuid';

import createRandomToken from './entities/token.js';

const mockHeaders = {
  authorization: `Bearer ${jwt_encode(createRandomToken(), uuidv4())}`,
  password: 'hello'
};

export default mockHeaders;
