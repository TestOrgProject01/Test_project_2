import { isType, maybe } from 'rambdax';

const checkType = isType('Object');

const safeParseObject = (x: string) =>
  maybe(checkType(x), JSON.stringify(x), x);

export default safeParseObject;
