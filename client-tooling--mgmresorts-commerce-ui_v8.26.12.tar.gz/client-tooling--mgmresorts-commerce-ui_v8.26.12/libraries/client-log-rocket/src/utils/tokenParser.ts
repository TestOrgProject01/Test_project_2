import jwt_decode from 'jwt-decode';
import jwt_encode from 'jwt-encode';
import { modifyPath, pipe } from 'rambdax';
import { v4 as uuidv4 } from 'uuid';

export const TOKEN_PATH = 'authorization';

export const decodeToken = jwt_decode as unknown as <T>(_: T) => T;

export const encodeToken = (token: unknown) =>
  `MaskedBearer ${jwt_encode(token, uuidv4())}`;

/**
 * Decodes a JWT token, applies the provided function, and re-encodes the token.
 *
 * @public
 */
export const maskTokenWith = <T>(f: (v: T) => T) =>
  modifyPath(TOKEN_PATH, pipe(decodeToken, f, encodeToken));
