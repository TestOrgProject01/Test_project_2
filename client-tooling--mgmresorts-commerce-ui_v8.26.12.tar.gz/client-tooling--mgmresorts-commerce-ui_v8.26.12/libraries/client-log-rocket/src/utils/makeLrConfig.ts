import {
  maybe,
  defaultTo,
  pipe,
  merge,
  evolve,
  hasPath,
  when,
  isEmpty
} from 'rambdax';

import { defaultSanitizers, SanitizersConfig } from '../sanitizers/index.js';
import { LogRocketSdkConfig } from '../sdk.js';
import { LrConfig } from '../types.js';
import getHost from '../utils/getHost.js';

import maskObject from './maskers/maskObject.js';
import { canSanitizeNetworkCall } from './networkParser.js';
import safeParseJson from './safeParseJson.js';
import safeParseObject from './safeParseObject.js';
import { maskTokenWith, TOKEN_PATH } from './tokenParser.js';
import { joinUrl, maskEmailInUrl, splitUrl } from './urlParser.js';

export const createNetworkSanitizers = (
  config: SanitizersConfig
): {
  requestSanitizer: NonNullable<
    NonNullable<LrConfig['network']>['requestSanitizer']
  >;
  responseSanitizer: NonNullable<
    NonNullable<LrConfig['network']>['responseSanitizer']
  >;
} => {
  const networkConfig = maybe(
    isEmpty(config?.networkInclusions),
    defaultSanitizers.networkInclusions,
    config?.networkInclusions
  );

  const checkNetworkCall = canSanitizeNetworkCall(networkConfig);

  const hasAuthHeader = hasPath(TOKEN_PATH);

  const maskWithSanitizers = maskObject(config.sanitizers);

  const sanitizeUrl = pipe(splitUrl, maskEmailInUrl, joinUrl);

  const sanitizeBody = pipe(
    safeParseObject,
    safeParseJson,
    maskWithSanitizers,
    (x) => JSON.stringify(x)
  );

  const sanitizeHeaders = pipe(
    when(hasAuthHeader, maskTokenWith(maskWithSanitizers)),
    maskWithSanitizers,
    // satisfy typings
    (x) => x as { [key: string]: string | undefined }
  );

  const evolveSanitize = evolve({
    body: sanitizeBody,
    headers: sanitizeHeaders,
    url: sanitizeUrl
  });

  return {
    requestSanitizer: (request) => {
      const shouldSanitize =
        request.method !== 'GET' && checkNetworkCall(request);

      return maybe(shouldSanitize, evolveSanitize(request), request);
    },
    responseSanitizer: (response) => {
      const shouldSanitize = checkNetworkCall(response);

      return maybe(shouldSanitize, evolveSanitize(response), response);
    }
  };
};

/**
 * Provides safe defaults for LogRocket initialization that can be overridden
 * with partial configuartion.
 *
 * @public
 */
// Typings must be defined here. We should be able to use currying, but LogRocket does
// not export their namespace. See https://github.com/microsoft/TypeScript/issues/5711.
const makeLrConfig = (config: LogRocketSdkConfig['options']): LrConfig => {
  const sanitizersConfig = merge(
    config?.sanitizers,
    defaultTo(defaultSanitizers, config?.sanitizers)
  );

  const sanitizers = createNetworkSanitizers(sanitizersConfig);

  const rootHostname = maybe(!!config?.stitchSessions, getHost, '');

  return merge<LrConfig>({
    browser: {
      //urlSanitizer?(url: string): null | string,
    },
    // release: null,
    console: {
      isEnabled: {
        debug: true,
        error: true,
        info: true,
        log: true,
        warn: true
      },
      shouldAggregateConsoleErrors: true
    },
    dom: {
      //baseHref?: string,
      //inputSanitizer?: boolean | string,
      //privateAttributeBlocklist?: string[],
      //textSanitizer?: boolean | string,
      isEnabled: true
    },
    network: {
      isEnabled: true,
      requestSanitizer: sanitizers.requestSanitizer,
      responseSanitizer: sanitizers.responseSanitizer
    },
    /**
     * Enable sharing sessions across subdomains by setting this to the top-level hostname.
     */
    rootHostname,

    /**
     * Controls collection of IP addresses and related features, such as GeoIP
     */
    shouldCaptureIP: false,

    /**
     * Convenience option for configuring the SDK for an on-prem install.
     * Include the protocol (eg. https://ingest.example.com)
     */
    //ingestServer?: string,

    /**
     * Convenience option for configuring
     * where the full SDK should be loaded from for on-prem installs
     */
    //sdkServer?: string,

    //uploadTimeInterval?: number,

    /**
     * a callback which determines whether to send data at a particular moment of time.
     */
    //shouldSendData?(): boolean,

    //shouldDebugLog?: boolean,

    //mergeIframes?: boolean,

    /**
     * Controls domains to which a parent window can post messages
     * in order to merge recording with cross-domain iframes
     */
    // TODO: investigate this in relation to auth
    //childDomains?: string[] | null,

    /**
     * Controls domain to which an iframe window can post messages
     * in order to merge recording with a cross-domain parent window
     * */
    // TODO: investigate this in relation to auth
    //parentDomain?: string | null,

    /**
     * When a user responds to a Delighted or Wootric survey in your
     * application, LogRocket will append the URL for the user's
     * current session to the survey response (feedback) text.
     */
    //shouldAugmentNPS?: boolean,

    /**
     * Decodes response bodies from `[Object object]`.
     */
    shouldParseXHRBlob: true
  })(config?.overrides ?? {});
};

export default makeLrConfig;
