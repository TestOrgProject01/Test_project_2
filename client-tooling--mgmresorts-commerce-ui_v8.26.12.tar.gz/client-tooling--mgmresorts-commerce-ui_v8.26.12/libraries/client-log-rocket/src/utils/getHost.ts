const isSSR = () => !window || !document || !document.body;

const getHost = () => {
  const host = window?.location?.host;

  return isSSR() || !host ? '' : host;
};

export default getHost;
