import { join, map, maybe, split } from 'rambdax';

import maskEmail, { isValidEmail } from './maskers/maskEmail.js';

export const splitUrl = split('/');

export const joinUrl = join('/');

const maskEmailWith = maybe(!!isValidEmail, maskEmail, (x) => x);

/**
 * Takes a URL that includes an email and sanitizes
 *
 * @public
 */
export const maskEmailInUrl = map(maskEmailWith);
