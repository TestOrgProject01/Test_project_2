import { describe, it, expect } from 'vitest';

import { defaultSanitizers } from '../sanitizers/index.js';
import mockNestedObject from '../testing/mockNestedObject.js';

import makeLrMiddlewareOptions, {
  createMiddlwareSanitizers
} from './makeLrMiddlewareOptions.js';

const mockReduxActions = {
  meta: mockNestedObject,
  payload: mockNestedObject,
  type: 'action/name'
};

const mockSanitizerConfig = {
  sanitizers: defaultSanitizers
};

describe('LogRocket middleware configuration', () => {
  describe('makeLrMiddlewareOptions', () => {
    it('sanitizes redux state and action data with defaults', () => {
      const sanitizers = makeLrMiddlewareOptions(mockSanitizerConfig);
      const actionResponse = sanitizers.actionSanitizer?.(mockReduxActions);
      const stateResponse = sanitizers.stateSanitizer?.(mockNestedObject);

      expect(actionResponse).not.toEqual(mockReduxActions);
      expect(stateResponse).not.toEqual(mockNestedObject);
    });
  });

  describe('createMiddlwareSanitizers', () => {
    it('sanitizes redux state and action data with defaults', () => {
      const { actionSanitizer, stateSanitizer } =
        createMiddlwareSanitizers(defaultSanitizers);

      const actionResponse = actionSanitizer(mockReduxActions);
      const stateResponse = stateSanitizer(mockNestedObject);

      expect(actionResponse).not.toEqual(mockReduxActions);
      expect(stateResponse).not.toEqual(mockNestedObject);
    });
  });
});
