import { defaultTo, merge } from 'rambdax';

import { defaultSanitizers, SanitizersConfig } from '../sanitizers/index.js';
import { LogRocketSdkConfig } from '../sdk.js';
import { LrReduxMiddleware } from '../types.js';

import { maskObject } from './maskers/index.js';

export const createMiddlwareSanitizers = (
  config: SanitizersConfig
): {
  actionSanitizer: NonNullable<
    NonNullable<LrReduxMiddleware>['actionSanitizer']
  >;
  stateSanitizer: NonNullable<NonNullable<LrReduxMiddleware>['stateSanitizer']>;
} => {
  const maskWithSanitizers = maskObject(config.sanitizers);

  return {
    actionSanitizer: maskWithSanitizers,
    stateSanitizer: maskWithSanitizers
  };
};

/**
 * Used to sanitize the Redux state and/or Redux actions before they are logged.
 *
 * @public
 */
const makeLrMiddlewareOptions = (
  config: LogRocketSdkConfig['options']
): LrReduxMiddleware => {
  const sanitizersConfig = merge(
    config?.sanitizers,
    defaultTo(defaultSanitizers, config?.sanitizers)
  );

  const sanitizers = createMiddlwareSanitizers(sanitizersConfig);

  return sanitizers;
};

export default makeLrMiddlewareOptions;
