import * as Control from '@mgmresorts/client-utils/Control';
import * as Privacy from '@mgmresorts/client-utils/Privacy';

/**
 * Decorator function for to check if a method should run
 *
 * Used to wrap SDK methods.
 */
export const skipWhenTrackingDisabled = (
  target: any,
  propertyKey: string,
  descriptor: PropertyDescriptor
) => {
  const originalMethod = descriptor.value;

  descriptor.value = async function (...args: any[]) {
    /**
     * Wait for consent manager to be ready before checking tracking status
     */
    const pathsToCheck = [
      [Privacy.PRIVACY_WINDOW_GROUPS],
      [Privacy.PRIVACY_WINDOW_OBJECT, Privacy.PRIVACY_WINDOW_UPDATED_EVENT]
    ];

    if (!Control || typeof Control.waitFor !== 'function') {
      throw new Error('Control.waitFor is not defined or is not a function.');
    }

    await Control.waitFor(pathsToCheck, undefined, 100);

    if (!Privacy || typeof Privacy.isPerformanceCookieDisabled !== 'function') {
      throw new Error(
        'Privacy.isPerformanceCookieDisabled is not defined or is not a function.'
      );
    }

    if (Privacy.isPerformanceCookieDisabled()) {
      return this;
    }

    if (!this || typeof originalMethod !== 'function') {
      throw new Error(
        "Original method is not defined or 'this' context is invalid."
      );
    }

    return originalMethod.apply(this, args);
  };

  return descriptor;
};
