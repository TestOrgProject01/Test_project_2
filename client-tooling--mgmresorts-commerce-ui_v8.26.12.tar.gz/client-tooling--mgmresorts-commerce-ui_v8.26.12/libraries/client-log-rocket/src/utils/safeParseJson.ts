import { tryCatch } from 'rambdax';

const safeParseJson = tryCatch(JSON.parse, Object());

export default safeParseJson;
