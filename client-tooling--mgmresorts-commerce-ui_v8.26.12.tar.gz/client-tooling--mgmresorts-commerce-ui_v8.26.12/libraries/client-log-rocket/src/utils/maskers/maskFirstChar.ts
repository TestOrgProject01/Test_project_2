import { is, join, repeat, identity } from 'rambdax';

export const MASK_STR_CHAR = '*';

/**
 * Mask the first character of a `string` and return.
 *
 * @example
 * ```ts
 * maskFirstChar('hello')
 * // => '*'
 * ```
 *
 * @public
 */
const maskFirstChar = <T extends string>(s: T) =>
  is(String, s) ? join('', repeat(MASK_STR_CHAR, 1)) : identity(s);

export default maskFirstChar;
