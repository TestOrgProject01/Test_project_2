import { is, join, repeat, identity } from 'rambdax';

export const MASK_STR_CHAR = '*';

/**
 * Mask the characters of a `string`.
 *
 * @example
 * ```ts
 * maskStr('hello')
 * // => '****'
 * ```
 *
 * @public
 */
const maskStr = <T extends string>(s: T) =>
  is(String, s) ? join('', repeat(MASK_STR_CHAR, s.length)) : identity(s);

export default maskStr;
