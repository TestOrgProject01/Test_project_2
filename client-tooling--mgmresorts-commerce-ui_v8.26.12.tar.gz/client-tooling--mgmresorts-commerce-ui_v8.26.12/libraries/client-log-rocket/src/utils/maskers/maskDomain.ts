import { join, pipe, split, map } from 'rambdax';

import maskLast from '../maskers/maskLast.js';

const DELIMITER = '.';

/**
 * Mask a domain `string`.
 *
 * @example
 * ```ts
 * maskDomain('mgmresorts.com')
 * // => 'm*********.c**'
 * ```
 *
 * @public
 */
const maskDomain = pipe(split(DELIMITER), map(maskLast), join(DELIMITER));

export default maskDomain;
