/* eslint-disable import/no-default-export */
import { pipe } from 'effect/Function';
import * as O from 'effect/Option';
import * as R from 'effect/Record';

type Dictionary<T> = Record<string, T>;

const isTransformApplicable = (value: unknown, transform: unknown): boolean =>
  typeof transform === 'function' && !(value instanceof Object);

const applyTransformOrRecurse = (
  transforms: Dictionary<(value: any) => any>,
  key: string,
  value: any
): any => {
  // Do not pollute intrinsic properties
  if (['__proto__', 'constructor', 'prototype'].includes(key)) return value;

  return pipe(
    O.fromNullable(transforms[key]),
    O.match({
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      onNone: () =>
        value instanceof Object ? maskObject(transforms)(value) : value,
      onSome: (transform) =>
        isTransformApplicable(value, transform) ? transform(value) : value
    })
  );
};

/**
 * Deeply mask values of an object given an object of transforms.
 *
 * @param transforms - The transforms to apply on a per-key basis. These operate on primitve non-object values.
 * @param obj - The object to mask.
 *
 * @remarks
 * If a field key is not included in `transforms`, there will be no change to its value.
 *
 * @example
 * ```ts
 * import { maskers } from '@mgmresorts/client-tooling'
 *
 * const { maskStr, maskObject, maskEmail } = maskers;
 *
 * maskObject(
 *   {
 *     email: maskEmail,
 *     firstName: maskStr,
 *     lastName: maskStr,
 *   },
 *   {
 *     email: 'ehegnes@mgmresorts.com',
 *     firstName: 'Eric',
 *     nested: {
 *       noop: 'wow',
 *       lastName: 'holy cow',
 *     },
 *     somekey: 'hello',
 *   }
 * )
 * // => {
 * //   email: 'e******@m*********.c**',
 * //   firstName: '****',
 * //   nested: {
 * //     noop: 'wow',
 * //     lastName: '********'
 * //   },
 * //   somekey: 'hello'
 * // }
 * ```
 *
 * @public
 */
const maskObject =
  <T extends Record<string, unknown>>(
    transforms: Dictionary<(value: any) => any> = {}
  ) =>
  (obj: T = {} as T): T =>
    pipe(
      O.fromNullable(obj),
      O.match({
        onNone: () => ({} as T),
        onSome: (nonNullObj) =>
          R.map(nonNullObj, (value, key) =>
            applyTransformOrRecurse(transforms, key, value)
          ) as T
      })
    );

export default maskObject;
/* eslint-enable import/no-default-export */
