import { pipe, split, join, when } from 'rambdax';

import { maskDomain, maskLast } from '../maskers/index.js';

export const DELIMITER = '@';
const splitEmail = split(DELIMITER);

const maskParts = (parts: string[]) =>
  join('', [maskLast(parts[0]), DELIMITER, maskDomain(parts[1])]);

export const EMAIL_ADDRESS_REGEX =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
export const isValidEmail = (str: string) => EMAIL_ADDRESS_REGEX.test(str);

/**
 * Mask an email address.
 *
 * @example
 * ```ts
 * maskEmail('ehegnes@mgmresorts.com')
 * // => 'e******@m*********.c**'
 * ```
 *
 * @public
 */
const maskEmail = when(isValidEmail, pipe(splitEmail, maskParts));

export default maskEmail;
