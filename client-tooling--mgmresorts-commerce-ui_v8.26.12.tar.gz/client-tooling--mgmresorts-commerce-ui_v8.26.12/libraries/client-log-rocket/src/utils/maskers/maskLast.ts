import { concat, head, join, repeat, dec } from 'rambdax';

/**
 * Mask the last `(n - 1)` characters of a `string`.
 *
 * @example
 * ```ts
 * maskLast('hello')
 * // => 'h****'
 * ```
 *
 * @public
 */
const maskLast = (s: string) =>
  concat(head(s), join('', repeat('*', dec(s.length))));

export default maskLast;
