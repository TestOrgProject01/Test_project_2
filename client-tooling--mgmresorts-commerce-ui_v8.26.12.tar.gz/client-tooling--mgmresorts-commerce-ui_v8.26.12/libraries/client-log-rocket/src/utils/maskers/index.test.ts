/* eslint-disable @typescript-eslint/no-use-before-define */
import * as E from 'effect/Either';
import { pipe } from 'effect/Function';
import fc from 'fast-check';
import * as RX from 'rambdax';
import { describe, expect, it } from 'vitest';

import {
  maskObject,
  maskEmail,
  maskStr,
  maskDomain,
  maskPhoneNumber
} from './index.js';
import { MASK_PHONE_NUMBER_CHAR } from './maskPhoneNumber.js';
import { MASK_STR_CHAR } from './maskStr.js';

describe('maskers', () => {
  describe('maskEmail', () => {
    it('changes the initial value', () => {
      fc.assert(
        fc.property(fc.emailAddress(), (email) => {
          const result = maskEmail(email);
          expect(result).not.toEqual(email);
          expect(result).toEqual(expect.stringContaining(MASK_STR_CHAR));
        })
      );
    });
  });

  describe('maskStr', () => {
    it('changes the initial value', () => {
      const stringsWithoutOnlyAsterisks = fc
        .string({ minLength: 1 })
        .filter(
          RX.pipe(RX.split(''), RX.uniq, RX.equals([MASK_STR_CHAR]), RX.not)
        );

      fc.assert(
        fc.property(stringsWithoutOnlyAsterisks, (str) => {
          const result = maskStr(str);
          expect(result).not.toEqual(str);
          expect(result).toEqual(expect.stringContaining(MASK_STR_CHAR));
        })
      );
    });

    it('does not manipulate non-string inputs', () => {
      fc.assert(
        fc.property(
          fc.oneof(
            fc.integer(),
            fc.boolean(),
            fc.date(),
            fc.tuple(fc.anything())
          ),
          (v) => {
            // Required for testing incorrect input types
            // @ts-expect-error
            const result = maskStr(v);
            expect(result).toEqual(v);
            expect(result).toEqual(expect.not.stringContaining(MASK_STR_CHAR));
          }
        )
      );
    });
  });

  describe('maskDomain', () => {
    it('changes the initial value', () => {
      fc.assert(
        fc.property(fc.domain(), (domain) => {
          const result = maskDomain(domain);
          expect(result).not.toEqual(domain);
          expect(result).toEqual(expect.stringContaining(MASK_STR_CHAR));
        })
      );
    });
  });

  describe('maskPhoneNumber', () => {
    it.each([
      '907-200-9294',
      '+1 (907) 200-9294',
      '(44) 2738-8315',
      '+380(0512)24-21-84'
    ])('masks all string numbers in %p', (v) => {
      const result = maskPhoneNumber(v);
      expect(result).toEqual(expect.stringContaining(MASK_PHONE_NUMBER_CHAR));
    });
  });

  describe('maskObject', () => {
    it('handles undefined gracefully', () => {
      const maskUndefinedObject = () => {
        return maskObject(undefined)(undefined);
      };

      expect(maskUndefinedObject).not.toThrowError('Incorrect iterable input');
      expect(maskUndefinedObject()).toEqual({});
    });

    const simpleObjectArbitrary = fc.dictionary(
      fc.string(),
      fc.oneof(fc.string(), fc.integer())
    );

    const transformArbitrary = fc.dictionary(
      fc.string(),
      fc.func(fc.oneof(fc.string(), fc.integer()))
    );

    // eslint-disable-next-line @typescript-eslint/consistent-type-definitions
    type CheckResult = {
      passed: boolean;
      failedCheck: string; // Name or description of the check that failed
    };

    /**
     * Prop 1: All keys in `obj` should be present in `transformedObj`
     * Prop 2: All transformed keys in `transformedObj` should be equal to
     *         applying the transform function on keys in `obj`
     * Prop 3: All non-transformed keys should remain the same
     */
    const checkSingleProperty =
      (original: any, transformed: any, transforms: any) =>
      (key: string): E.Either<CheckResult, Error> => {
        const originalValue = original[key];
        const transformedValue = transformed[key];
        const transform = transforms[key];

        const originalValueEqualsTransformedValue = () => ({
          failedCheck: `Value not equal: ${originalValue} -> ${JSON.stringify(
            transformedValue,
            null,
            0
          )}`,
          passed: originalValue === transformedValue
        });

        const recurse = () => {
          return pipe(
            checkProperties(originalValue, transformedValue, transform),
            E.map((arr) =>
              arr.every((result) => result.passed)
                ? { failedCheck: 'Recursion succeeded', passed: true }
                : { failedCheck: 'Recursion failed', passed: false }
            ),
            E.getOrElse(() => ({
              failedCheck: 'Recursion failed',
              passed: false
            }))
          );
        };

        const transformIsFn = () => RX.is(Function, transform);

        const transformedValueEqTransformOriginalValue = () => ({
          failedCheck: 'Transform failed',
          passed: transformedValue === transform(originalValue)
        });

        return E.right(
          RX.cond([
            [RX.isNil, originalValueEqualsTransformedValue], // Prop 1
            [RX.is(Object), recurse], // recursion case
            [transformIsFn, transformedValueEqTransformOriginalValue], // Prop 2
            [RX.T, originalValueEqualsTransformedValue] // Prop 3
          ])(originalValue)
        );
      };

    // Check properties for an object
    const checkProperties = (
      original: any,
      transformed: any,
      transforms: any = {}
    ): E.Either<CheckResult[], Error> => {
      const keys = RX.keys(original) as string[];

      const singleCheckResults = keys.map(
        checkSingleProperty(original, transformed, transforms)
      );

      return pipe(
        E.all(singleCheckResults),
        E.map((results) => [...results]) // copy read-only
      );
    };

    it.skip('should apply the transforms to the matching keys at any depth in the object', () => {
      fc.assert(
        fc.property(
          simpleObjectArbitrary,
          transformArbitrary,
          (obj, transforms) => {
            const transformedObj = maskObject(transforms)(obj);

            const result = checkProperties(obj, transformedObj, transforms);

            return pipe(
              result,
              E.match({
                onLeft: (left) => {
                  // eslint-disable-next-line no-console
                  console.error('Left', left);

                  return false;
                },
                onRight: (checkResults) => {
                  const allPassed = checkResults.every(({ passed }) => passed);

                  if (!allPassed) {
                    const failedChecks = checkResults
                      .filter(({ passed }) => !passed)
                      .map(({ failedCheck }) => failedCheck);

                    // eslint-disable-next-line no-console
                    console.log('Failed Checks:', failedChecks);
                  }

                  return allPassed;
                }
              })
            );
          }
        ),
        {
          //endOnFailure: true,
          //path: "30:87:86:85",
          //seed: 1371206807,
          verbose: 2
        }
      );
    });
  });
});
/* eslint-enable @typescript-eslint/no-use-before-define */
