import { replace, pipe, repeat, join } from 'rambdax';

export const MASK_PHONE_NUMBER_CHAR = '*';

const replaceStr = replace(/[0-9]/, MASK_PHONE_NUMBER_CHAR);

const replaceNum = pipe(
  (n) => n.toString(),
  pipe((n) => repeat('0', n.length), join('')),
  Number
);

/**
 * Mask a phone number.
 *
 * @example
 * ```ts
 * maskPhoneNumber('123 456 7890')
 * // => '*** *** ****'
 * maskPhoneNumber(1234567890);
 * // => 0000000000
 * ```
 *
 * @public
 */
const maskPhoneNumber = <T>(v: T) => {
  if (typeof v === 'string') return replaceStr(v);
  if (typeof v === 'number') return replaceNum(v);

  return v;
};

export default maskPhoneNumber;
