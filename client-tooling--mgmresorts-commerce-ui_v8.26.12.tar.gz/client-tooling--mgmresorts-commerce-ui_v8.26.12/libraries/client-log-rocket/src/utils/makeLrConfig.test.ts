import { describe, it, expect } from 'vitest';

import { defaultSanitizers } from '../sanitizers/index.js';
import mockHeaders from '../testing/mockHeaders.js';
import mockNestedObject from '../testing/mockNestedObject.js';

import { createNetworkSanitizers } from './makeLrConfig.js';

describe('LogRocket configuration', () => {
  describe('createNetworkSanitizers', () => {
    it('sanitizes body with defaults', () => {
      const { responseSanitizer, requestSanitizer } =
        createNetworkSanitizers(defaultSanitizers);

      const url = 'https://mgmresorts.com/graphql/email@email.com';
      const body = mockNestedObject;
      const bodyStr = JSON.stringify(body);

      const mockResponse = {
        body: bodyStr,
        headers: mockHeaders,
        method: 'POST',
        reqId: '',
        url
      };

      const mockRequest = mockResponse;

      const responseResult = responseSanitizer(mockResponse);
      const requestResult = requestSanitizer(mockRequest);

      expect(responseResult?.body).not.toEqual(bodyStr);
      expect(responseResult?.headers).not.toEqual(mockResponse.headers);

      expect(requestResult?.url).not.toEqual(url);
      expect(requestResult?.body).not.toEqual(bodyStr);
      expect(requestResult?.headers).not.toEqual(mockRequest.headers);
    });

    it('should skip sanitization if networkInclusions not found', () => {
      const { responseSanitizer, requestSanitizer } = createNetworkSanitizers({
        ...defaultSanitizers,
        networkInclusions: ['fake']
      });

      const body = mockNestedObject;
      const bodyStr = JSON.stringify(body);

      const mockResponse = {
        body: bodyStr,
        headers: mockHeaders,
        method: 'POST',
        reqId: '',
        url: 'https://mgmresorts.com/graphql'
      };

      const mockRequest = mockResponse;

      const responseResult = responseSanitizer(mockResponse);
      const requestResult = requestSanitizer(mockRequest);

      expect(responseResult?.body).toEqual(bodyStr);
      expect(responseResult?.headers).toEqual(mockResponse.headers);
      expect(requestResult?.body).toEqual(bodyStr);
      expect(requestResult?.headers).toEqual(mockRequest.headers);
    });
  });
});
