import * as Privacy from '@mgmresorts/client-utils/Privacy';
import { constVoid } from 'effect/Function';
import { vi, describe, test, expect, afterEach } from 'vitest';

import { skipWhenTrackingDisabled } from './skipWhenTrackingDisabled.js';

vi.mock('@mgmresorts/client-utils/Control', () => ({
  waitFor: vi.fn().mockResolvedValue(constVoid())
}));

describe('skipWhenTrackingDisabled', () => {
  afterEach(() => {
    vi.resetAllMocks();
    vi.clearAllMocks();
  });

  test.sequential.each([
    { enabled: true, fCalls: 1, spyCalls: 1 },
    { enabled: false, fCalls: 0, spyCalls: 1 }
  ])('tracking enabled: $enabled', async ({ enabled, spyCalls, fCalls }) => {
    const spy = vi
      .spyOn(Privacy, 'isPerformanceCookieDisabled')
      .mockImplementation(() => !enabled);

    const f = vi.fn();

    class A {
      @skipWhenTrackingDisabled
      f() {
        return f();
      }
    }

    const a = new A();

    await a.f();

    expect(spy).toHaveBeenCalledTimes(spyCalls);
    expect(f).toHaveBeenCalledTimes(fCalls);
  });
});
