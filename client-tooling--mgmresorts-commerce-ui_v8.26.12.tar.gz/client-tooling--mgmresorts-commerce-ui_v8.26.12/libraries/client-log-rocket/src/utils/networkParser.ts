import { any, includes } from 'rambdax';

import { SanitizersConfig } from '../sanitizers/index.js';

/**
 * Determines if a network call should be sanitized based on provided config.
 *
 * @public
 */
export const canSanitizeNetworkCall =
  <T extends Record<string, any>>(
    inclusions: SanitizersConfig['networkInclusions']
  ) =>
  (obj: T) =>
    any((element) => includes(element, obj?.url))(inclusions!);
