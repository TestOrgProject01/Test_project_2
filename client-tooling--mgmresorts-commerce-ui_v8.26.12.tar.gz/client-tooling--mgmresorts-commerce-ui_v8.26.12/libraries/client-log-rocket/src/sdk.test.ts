import { describe, it } from 'vitest';

describe('LogRocketSdk', () => {
  it.skip('initializes with safe defaults', () => {});
  it.skip('only allows initialization once', () => {});
  it.skip('allows configuration overrides', () => {});
});
