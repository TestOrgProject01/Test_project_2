import { LogRocket as L } from './modules/logrocket.js';

/**
 * `LogRocket.init()` parameters.
 *
 * @public
 */
export type LrInitParams = Parameters<(typeof L)['init']>;

/**
 * `LogRocket.init()` parameters.
 *
 * @public
 */
export type LrReduxMiddlewareParams = Parameters<(typeof L)['reduxMiddleware']>;

/**
 * LogRocket App ID.
 *
 * @public
 */
export type LrAppId = LrInitParams[0];

/**
 * LogRocket configuration.
 *
 * @public
 */
export type LrConfig = NonNullable<LrInitParams[1]>;

/**
 * LogRocket redux middleware configuration.
 *
 * @public
 */
export type LrReduxMiddleware = NonNullable<LrReduxMiddlewareParams[0]>;

/**
 * Copied from LogRocket package as not exported
 *
 * @public
 */
export type IRequest = Parameters<
  NonNullable<NonNullable<LrConfig['network']>['requestSanitizer']>
>[0];
export type IResponse = Parameters<
  NonNullable<NonNullable<LrConfig['network']>['responseSanitizer']>
>[0];
