/**
 * MGM's web SDK for managing Log Rocket
 *
 * @remarks
 * The `@mgmresorts/client-log-rocket` defines the {@link LogRocketSdk}
 * singleton instance which is used to configure and manage LogRocket
 *
 * {@link LogRocketSdkSingleton} is exported for the sake of documentation and
 * should not be used directly.
 *
 * @packageDocumentation
 */

import { SanitizersConfig, Sanitizer } from './sanitizers/index.js';
import {
  LogRocketSdk,
  LogRocketSdkSingleton,
  LogRocketSdkConfig
} from './sdk.js';
import { LrInitParams, LrConfig, LrAppId } from './types.js';
import { default as makeLrConfig } from './utils/makeLrConfig.js';
import * as maskers from './utils/maskers/index.js';

export type {
  LogRocketSdkConfig,
  LrInitParams,
  LrAppId,
  LrConfig,
  Sanitizer,
  SanitizersConfig
};
export { LogRocketSdk, LogRocketSdkSingleton, maskers, makeLrConfig };
export { LogRocket } from './modules/logrocket.js';
