# Client Log Rocket SDK

[:book:](https://mgmresorts.github.io/client-log-rocket)
