## 2.11.1 (2025-04-03)

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1
- Updated client-utils to 0.2.1

### ❤️ Thank You

- Daniel Roma @danielromafsl

## 2.11.0 (2025-03-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### ❤️ Thank You

- Agus Garcia @agustin-mgm

## 2.10.1 (2025-02-17)

### 🩹 Fixes

- **logrocket:** add journey-id (PATCH) (CET-442) ([#584](https://github.com/MGMResorts/client-tooling/pull/584))

### ❤️ Thank You

- Agus Garcia @agustin-mgm

## 2.10.0 (2025-02-14)

### 🚀 Features

- **logrocket:** add journey id into lr (CET-442) (MINOR) ([#581](https://github.com/MGMResorts/client-tooling/pull/581))

### 🩹 Fixes

- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Guido Quispe @guido-mgm

## 2.9.1 (2025-01-22)

### 🩹 Fixes

- added undefined checks to LR decorator (PATCH) (CET-492) ([d2f826fe](https://github.com/MGMResorts/client-tooling/commit/d2f826fe))

### ❤️ Thank You

- Rob Fyffe

## 2.9.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- improved documentation (MINOR) (CET-487) ([d827bc57](https://github.com/MGMResorts/client-tooling/commit/d827bc57))
- moved privacy logic to client-utils (CET-430) (MINOR) ([#314](https://github.com/MGMResorts/client-tooling/pull/314))
- added logic for conditonal tracking (CET-405) (MINOR) ([#278](https://github.com/MGMResorts/client-tooling/pull/278))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- disabled IP tracking for PII requirements (CET-209) ([#150](https://github.com/MGMResorts/client-tooling/pull/150))
- added additional properties for masking (NONE) (MINOR) ([#119](https://github.com/MGMResorts/client-tooling/pull/119))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- **client-log-rocket:** added new captureEvent func ([#30](https://github.com/MGMResorts/client-tooling/pull/30))
- **vega-tailwind:** initial package release ([#19](https://github.com/MGMResorts/client-tooling/pull/19))
- added new testing package ([10ca1f5d](https://github.com/MGMResorts/client-tooling/commit/10ca1f5d))
- rename and publish eslint package ([#14](https://github.com/MGMResorts/client-tooling/pull/14))
- added handling for object variations ([2d78dd0f](https://github.com/MGMResorts/client-tooling/commit/2d78dd0f))
- **client-log-rocket:** Use module export for LogRocket ([c6e0c0b6](https://github.com/MGMResorts/client-tooling/commit/c6e0c0b6))
- updated LR package comment formatting ([30d2a957](https://github.com/MGMResorts/client-tooling/commit/30d2a957))
- trigger release for log rocket package ([4ff05b59](https://github.com/MGMResorts/client-tooling/commit/4ff05b59))
- fixed spelling mistake for object parser ([3f4ed9b4](https://github.com/MGMResorts/client-tooling/commit/3f4ed9b4))
- added sanitizer to mask url PII data ([a7e03b15](https://github.com/MGMResorts/client-tooling/commit/a7e03b15))
- added object parser for log rocket ([12bd56b5](https://github.com/MGMResorts/client-tooling/commit/12bd56b5))
- config for network call sanitization ([e25394e1](https://github.com/MGMResorts/client-tooling/commit/e25394e1))
- removed debugging conditions from network sanitizers ([fa276efb](https://github.com/MGMResorts/client-tooling/commit/fa276efb))
- added string check to JSON.parse for body masking ([dc130215](https://github.com/MGMResorts/client-tooling/commit/dc130215))
- added when condition to authorization token masking ([a379d52f](https://github.com/MGMResorts/client-tooling/commit/a379d52f))
- adding temporary logging for network sanitizers ([4f651f3c](https://github.com/MGMResorts/client-tooling/commit/4f651f3c))
- updated requestBody to stringify object ([350586c8](https://github.com/MGMResorts/client-tooling/commit/350586c8))
- added return statement to Redux middleware handler ([39dd08f3](https://github.com/MGMResorts/client-tooling/commit/39dd08f3))
- updates to multiple package configurations ([34a88f2e](https://github.com/MGMResorts/client-tooling/commit/34a88f2e))
- removed some test rambdas code ([85c4f6b1](https://github.com/MGMResorts/client-tooling/commit/85c4f6b1))
- added middleware masking handler ([efe856c0](https://github.com/MGMResorts/client-tooling/commit/efe856c0))
- removed typing for repsonse handler ([9716fc22](https://github.com/MGMResorts/client-tooling/commit/9716fc22))
- added JWT token masking feature ([441d58c4](https://github.com/MGMResorts/client-tooling/commit/441d58c4))
- **client-log-rocket:** add sanitizers ([f7071afd](https://github.com/MGMResorts/client-tooling/commit/f7071afd))
- adding initial boilerplate for LogRocket pacakge ([c80dfb08](https://github.com/MGMResorts/client-tooling/commit/c80dfb08))

### 🩹 Fixes

- added missing address1 to LR masking (PATCH) (CET-487) ([#522](https://github.com/MGMResorts/client-tooling/pull/522))
- **client-log-rocket, urql:** client utils workaround (MINOR) (NONE) ([#492](https://github.com/MGMResorts/client-tooling/pull/492))
- **client-log-rocket:** add sanitizer configuration for payment calls (MINOR) (CAPL-7299) ([#475](https://github.com/MGMResorts/client-tooling/pull/475))
- **client-log-rocket:** make happy (PATCH) (NONE) ([#337](https://github.com/MGMResorts/client-tooling/pull/337))
- removed decorator from redux middleware (PATCH) (CET-409) ([adc2fefe](https://github.com/MGMResorts/client-tooling/commit/adc2fefe))
- updated LR comments (CET-414) (MINOR) ([3afa9881](https://github.com/MGMResorts/client-tooling/commit/3afa9881))
- added undefined checks for window object (CET-405) (MINOR) ([#287](https://github.com/MGMResorts/client-tooling/pull/287))
- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **client-log-rocket:** handle masking undefined (CAPL-5693) ([#65](https://github.com/MGMResorts/client-tooling/pull/65))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))
- `SanitizersConfig` type export ([6e3c7262](https://github.com/MGMResorts/client-tooling/commit/6e3c7262))
- **ci:** `concurrently` doesnt play nicely in CI ([3722882b](https://github.com/MGMResorts/client-tooling/commit/3722882b))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0
- Updated client-utils to 0.2.0

### ❤️ Thank You

- Bruce @breif-mgm
- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Rob Fyffe @rfyffe-mgmresorts
- Robert Fyffe
- Thomas Kelly
- voliveira-mgm @voliveira-mgm

# Change Log - @mgmresorts/client-log-rocket

This log was last generated on Thu, 05 Dec 2024 07:18:53 GMT and should not be manually modified.

## 2.8.0
Thu, 05 Dec 2024 07:18:53 GMT

### Minor changes

- updated comments for decorator function

## 2.7.2
Thu, 05 Dec 2024 02:51:43 GMT

### Patches

- added address1 to list of payment fields to mask

## 2.7.1
Tue, 03 Dec 2024 01:14:06 GMT

### Patches

- arbitrary documentation text update

## 2.7.0
Thu, 07 Nov 2024 19:34:59 GMT

### Minor changes

- add sanitization for payment network calls and fields

## 2.6.5
Mon, 28 Oct 2024 18:15:56 GMT

_Version update only_

## 2.6.4
Mon, 09 Sep 2024 21:24:25 GMT

### Patches

- Fix compatibility; migrate from `fp-ts` to `effect`

## 2.6.3
Fri, 06 Sep 2024 15:02:12 GMT

_Version update only_

## 2.6.2
Tue, 03 Sep 2024 18:45:27 GMT

_Version update only_

## 2.6.1
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 2.6.0
Wed, 28 Aug 2024 21:37:10 GMT

### Minor changes

- moved privacy logic to client-utils

## 2.5.4
Tue, 27 Aug 2024 03:31:58 GMT

### Patches

- removed decorator from redux middleware

## 2.5.3
Thu, 22 Aug 2024 20:33:14 GMT

### Patches

- added maxRetries to waitFor function

## 2.5.2
Thu, 15 Aug 2024 07:21:15 GMT

### Patches

- removed throw error code from waitFor (CET-414)

## 2.5.1
Thu, 15 Aug 2024 07:00:29 GMT

### Patches

- updated LR comments (CET-414)

## 2.5.0
Thu, 15 Aug 2024 06:23:02 GMT

### Minor changes

- added undefined checks for window object

### Patches

- added windwow check in waitFor (CET-414)

## 2.4.0
Sat, 10 Aug 2024 04:53:02 GMT

### Minor changes

- added logic to determine if tracking should be disabled

## 2.3.1
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 2.3.0
Wed, 31 Jul 2024 19:23:27 GMT

### Minor changes

- Bump `logrocket` dependency from `3.0.1` to `8.1.2`.

## 2.2.6
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 2.2.5
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 2.2.4
Mon, 15 Apr 2024 22:43:19 GMT

### Patches

- disabled IP tracking for PII requirements

## 2.2.3
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 2.2.2
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 2.2.1
Thu, 08 Feb 2024 16:13:06 GMT

_Version update only_

## 2.2.0
Thu, 01 Feb 2024 17:06:53 GMT

### Minor changes

- added additional properties for masking

## 2.1.7
Thu, 09 Nov 2023 23:02:38 GMT

_Version update only_

## 2.1.6
Thu, 09 Nov 2023 22:21:40 GMT

_Version update only_

## 2.1.5
Wed, 01 Nov 2023 13:00:43 GMT

_Version update only_

## 2.1.4
Tue, 31 Oct 2023 18:44:27 GMT

_Version update only_

## 2.1.3
Thu, 31 Aug 2023 15:25:56 GMT

### Patches

- Handle masking of undefined objects - CAPL-5693

## 2.1.2
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 2.1.1
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 2.1.0
Tue, 27 Jun 2023 19:52:50 GMT

### Minor changes

- added new logrocket func
- removed wrong label
- changed the LR function
- changed event to track func

### Patches

- reverting version changed

## 2.0.4
Wed, 07 Jun 2023 06:34:34 GMT

_Version update only_

## 2.0.3
Wed, 07 Jun 2023 02:29:28 GMT

_Version update only_

## 2.0.2
Wed, 24 May 2023 12:41:01 GMT

_Version update only_

## 2.0.1
Mon, 10 Apr 2023 21:28:25 GMT

_Version update only_

## 2.0.0
Mon, 10 Apr 2023 21:17:31 GMT

### Breaking changes

- updated eslint package to reflect name change

### Minor changes

- added handling for object variations

### Patches

- Add export of `LogRocket`; fix `SanitizersConfig` type export

## 1.11.0
Fri, 27 Jan 2023 20:41:48 GMT

### Minor changes

- updated comment formatting for typings
- added sanitizer to mask any PII data in network URL
- trigger release for log rocket package

## 1.10.0
Fri, 27 Jan 2023 00:28:51 GMT

### Minor changes

- added object parser for network call body data

## 1.9.0
Thu, 26 Jan 2023 20:22:13 GMT

### Minor changes

- added new functionality to specify the network calls that should be sanitized

## 1.8.0
Mon, 23 Jan 2023 01:04:16 GMT

### Minor changes

- removed debugging conditions from network sanitizers

## 1.7.0
Sun, 22 Jan 2023 09:31:50 GMT

### Minor changes

- added string check to JSON.parse for body masking

## 1.6.0
Sun, 22 Jan 2023 07:43:42 GMT

### Minor changes

- added when condition to authorization token masking

## 1.5.0
Sun, 22 Jan 2023 05:05:16 GMT

### Minor changes

- adding temporary logging for network sanitizers

## 1.4.0
Sat, 21 Jan 2023 20:51:04 GMT

### Minor changes

- updated requestBody to stringify object

## 1.3.0
Sat, 21 Jan 2023 09:19:52 GMT

### Minor changes

- added return statement to Redux middleware handler
- removed test file for index file

## 1.2.0
Sat, 21 Jan 2023 01:06:40 GMT

### Minor changes

- updated repo property within package.json

## 1.1.0
Sat, 21 Jan 2023 00:39:07 GMT

### Minor changes

- updating client-log-rocket settings so that it can be published to GitHub packages

