export { default as basePrettierConfig } from './config';

export type { PrettierConfig } from './types';
