import { Options as PrettierTypes } from 'prettier';

/**
 * Prettier configuration.
 *
 * @public
 */
export type PrettierConfig = PrettierTypes;
