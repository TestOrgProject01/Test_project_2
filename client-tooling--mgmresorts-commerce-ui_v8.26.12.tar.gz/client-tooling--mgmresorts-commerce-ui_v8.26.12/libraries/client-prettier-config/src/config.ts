import { Options as PrettierConfig } from 'prettier';
import { merge } from 'rambdax';

const base: PrettierConfig = {
  printWidth: 80,
  tabWidth: 2,
  useTabs: false,
  semi: true,
  singleQuote: true,
  trailingComma: 'all',
  bracketSpacing: true,
  jsxSingleQuote: true,
  arrowParens: 'avoid',
  proseWrap: 'always'
};

/**
 * Provides safe defaults for Prettier that can be overridden
 * with partial configuartion.
 *
 * @public
 */
const config = (overrides: PrettierConfig = {}) =>
  merge<PrettierConfig>(base)(overrides);

export default config;
