## 2.5.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 2.5.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- added prettier package export paths ([7f1140e7](https://github.com/MGMResorts/client-tooling/commit/7f1140e7))
- added support for commonjs and es6 ([2899e462](https://github.com/MGMResorts/client-tooling/commit/2899e462))
- added new testing package ([10ca1f5d](https://github.com/MGMResorts/client-tooling/commit/10ca1f5d))
- added new prettier package ([0d025d29](https://github.com/MGMResorts/client-tooling/commit/0d025d29))

### 🩹 Fixes

- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Rob Fyffe

# Change Log - @mgmresorts/client-prettier-config

This log was last generated on Wed, 07 Aug 2024 20:50:00 GMT and should not be manually modified.

## 2.4.7
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Update dependencies

## 2.4.6
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 2.4.5
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 2.4.4
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 2.4.3
Thu, 07 Mar 2024 21:59:10 GMT

### Patches

- Update dependencies

## 2.4.2
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 2.4.1
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 2.4.0
Thu, 20 Apr 2023 19:01:36 GMT

### Minor changes

- updated package.json with export paths

## 2.3.0
Thu, 20 Apr 2023 18:51:09 GMT

### Minor changes

- added support for commonjs and es6

## 2.2.0
Wed, 12 Apr 2023 20:03:37 GMT

### Minor changes

- changed to typescript

## 2.1.0
Mon, 10 Apr 2023 21:58:35 GMT

### Minor changes

- added new pacakage for managing prettier config

