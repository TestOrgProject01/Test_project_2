export default {
  collectCoverage: true,
  coverageDirectory: 'temp/coverage',
  coverageReporters: ['html'],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  moduleNameMapper: {
    '^#root/(.*)$': '<rootDir>/$1'
  },
  modulePathIgnorePatterns: ['./constants.ts'],
  rootDir: 'src',
  setupFiles: ['<rootDir>/../jest.setup.js'],
  testEnvironment: 'jsdom',
  transform: {
    '^.+\\.(t|j)sx?$': ['@swc/jest']
  },
  transformIgnorePatterns: []
};
