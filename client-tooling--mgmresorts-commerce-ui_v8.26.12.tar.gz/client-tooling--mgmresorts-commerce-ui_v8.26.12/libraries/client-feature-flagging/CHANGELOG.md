## 3.6.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1
- Updated urql to 0.2.1

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl

## 3.6.0 (2025-01-31)

### 🚀 Features

- update getClient.ts (CET-531) ([#573](https://github.com/MGMResorts/client-tooling/pull/573))

### 🩹 Fixes

- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### ❤️ Thank You

- Francisco Rubial @franjorub
- Guido Quispe @guido-mgm

## 3.5.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))
- added support for custom contextKind value (CAPL-6180) ([#196](https://github.com/MGMResorts/client-tooling/pull/196))
- updated replaceFlagValue logic CET-201) ([#195](https://github.com/MGMResorts/client-tooling/pull/195))
- added decoding to url flags (CET-201) ([#194](https://github.com/MGMResorts/client-tooling/pull/194))
- flag overrides from URL parameters (CET-201) ([#182](https://github.com/MGMResorts/client-tooling/pull/182))
- **commerce-ui:** RoomsOfferDetails component (MINOR) (DBXB-3968) ([#163](https://github.com/MGMResorts/client-tooling/pull/163))
- **client-feature-flagging:** add QA3 env (CAPL-6320) ([#151](https://github.com/MGMResorts/client-tooling/pull/151))
- **ld:** added typings for channelId attribute ([#139](https://github.com/MGMResorts/client-tooling/pull/139))
- **ld:** updated documentation for fetch function ([999b69e2](https://github.com/MGMResorts/client-tooling/commit/999b69e2))
- **LD:** updated gql query to pass through attributes (NONE) (MINOR) ([#131](https://github.com/MGMResorts/client-tooling/pull/131))
- **LD:** changed cientApp to clientId (CET-205) ([#128](https://github.com/MGMResorts/client-tooling/pull/128))
- **LD:** added custom attribute support (CET-205) ([#127](https://github.com/MGMResorts/client-tooling/pull/127))
- **eslint-config-cet:** Add recommended config and WP mixins ([#81](https://github.com/MGMResorts/client-tooling/pull/81))
- **vega-tailwind:** initial package release ([#19](https://github.com/MGMResorts/client-tooling/pull/19))
- **client-tooling:** update user key handling ([#17](https://github.com/MGMResorts/client-tooling/pull/17))
- added new testing package ([10ca1f5d](https://github.com/MGMResorts/client-tooling/commit/10ca1f5d))
- updated GraphQL schema for feature flagging ([32dabdba](https://github.com/MGMResorts/client-tooling/commit/32dabdba))
- rename and publish eslint package ([#14](https://github.com/MGMResorts/client-tooling/pull/14))
- updated package description for library ([490911c3](https://github.com/MGMResorts/client-tooling/commit/490911c3))
- updates to multiple package configurations ([34a88f2e](https://github.com/MGMResorts/client-tooling/commit/34a88f2e))

### 🩹 Fixes

- **urql,client-utils:** provision source header correctly for URQL (PATCH (NONE) ([#284](https://github.com/MGMResorts/client-tooling/pull/284))
- **client-feature-flagging:** update GQL synchronization (PATCH) (NONE) ([#198](https://github.com/MGMResorts/client-tooling/pull/198))
- **client-feature-flagging:** drop `parse-domain` version for extended Node compatibility (CAPL-5668) ([#141](https://github.com/MGMResorts/client-tooling/pull/141))
- **client-feature-flagging:** make user key subdomain agnostic (CAPL-5668) ([#96](https://github.com/MGMResorts/client-tooling/pull/96))
- **client-feature-flagging:** fix module export pathing ([#91](https://github.com/MGMResorts/client-tooling/pull/91))
- fix ESM and CJS export (CET-196) ([#62](https://github.com/MGMResorts/client-tooling/pull/62))
- **deps:** enforce strict peer dependencies ([#37](https://github.com/MGMResorts/client-tooling/pull/37))
- **ci:** `concurrently` doesnt play nicely in CI ([3722882b](https://github.com/MGMResorts/client-tooling/commit/3722882b))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0
- Updated urql to 0.2.0

### ❤️ Thank You

- Eric Hegnes @ehegnes-mgm
- Guido Quispe @guido-mgm
- Rob Fyffe @rfyffe-mgmresorts
- Thomas Kelly

# Change Log - @mgmresorts/client-feature-flagging

This log was last generated on Mon, 28 Oct 2024 18:15:56 GMT and should not be manually modified.

## 3.4.7
Mon, 28 Oct 2024 18:15:56 GMT

_Version update only_

## 3.4.6
Fri, 06 Sep 2024 15:02:12 GMT

_Version update only_

## 3.4.5
Tue, 03 Sep 2024 18:45:27 GMT

_Version update only_

## 3.4.4
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 3.4.3
Wed, 28 Aug 2024 21:37:10 GMT

_Version update only_

## 3.4.2
Sat, 10 Aug 2024 03:47:47 GMT

### Patches

- Upgrade `vitest`; fix test execution

## 3.4.1
Fri, 09 Aug 2024 14:45:42 GMT

_Version update only_

## 3.4.0
Wed, 07 Aug 2024 20:50:00 GMT

### Minor changes

- Migrate from jest to vitest; add `@mgmresorts/urql`

## 3.3.1
Mon, 29 Jul 2024 16:28:21 GMT

### Patches

- Revert `@mgmresorts/build-tools-ng', `@mgmresort/urql`, and `@mgmresorts/client-utils` changes failing publish

## 3.3.0
Tue, 18 Jun 2024 18:14:52 GMT

### Minor changes

- added support for custom contextKind value

### Patches

- Use QA4 for GQL introspection

## 3.2.2
Fri, 14 Jun 2024 07:16:16 GMT

### Patches

- updated replaceFlagValue logic

## 3.2.1
Fri, 14 Jun 2024 05:55:31 GMT

### Patches

- added decoding to url flags

## 3.2.0
Fri, 14 Jun 2024 01:34:12 GMT

### Minor changes

- added the ability to override flag values from URL parameters

## 3.1.1
Wed, 12 Jun 2024 16:05:07 GMT

### Patches

- Bump build dependencies

## 3.1.0
Mon, 29 Apr 2024 18:40:17 GMT

### Minor changes

- Add QA3 env

## 3.0.3
Thu, 14 Mar 2024 20:06:05 GMT

### Patches

- Bump build dependencies

## 3.0.2
Thu, 14 Mar 2024 17:02:16 GMT

### Patches

- Drop `parse-domain` version for extended Node compatibility (CAPL-5668)

## 3.0.1
Mon, 11 Mar 2024 18:46:15 GMT

### Patches

- added typings for channelId attribute 

## 3.0.0
Thu, 07 Mar 2024 21:59:10 GMT

### Breaking changes

- Make `fetchUserKey` subdomain agnostic (CAPL-5668)

### Patches

- Update dependencies

## 2.3.1
Thu, 29 Feb 2024 23:17:11 GMT

### Patches

- updated documentation for fetch function

## 2.3.0
Wed, 28 Feb 2024 19:54:01 GMT

### Minor changes

- updated gql query to pass through attributes

## 2.2.0
Mon, 26 Feb 2024 18:07:42 GMT

### Minor changes

- changed default clientApp to clientId

## 2.1.0
Mon, 26 Feb 2024 17:36:21 GMT

### Minor changes

- added support for passing custom attributes as well as assigning defaults

## 2.0.14
Thu, 08 Feb 2024 16:13:06 GMT

_Version update only_

## 2.0.13
Wed, 15 Nov 2023 18:18:20 GMT

### Patches

- fix export pathing

## 2.0.12
Thu, 09 Nov 2023 23:02:38 GMT

_Version update only_

## 2.0.11
Thu, 09 Nov 2023 22:21:40 GMT

_Version update only_

## 2.0.10
Wed, 01 Nov 2023 13:00:43 GMT

_Version update only_

## 2.0.9
Tue, 31 Oct 2023 18:44:27 GMT

_Version update only_

## 2.0.8
Sat, 26 Aug 2023 00:38:42 GMT

### Patches

- fix CJS and ESM build and export

## 2.0.7
Wed, 05 Jul 2023 20:43:21 GMT

### Patches

- Fix executable file permissions

## 2.0.6
Wed, 05 Jul 2023 17:29:11 GMT

### Patches

- Enforce strict peer dependencies

## 2.0.5
Wed, 07 Jun 2023 06:34:34 GMT

_Version update only_

## 2.0.4
Wed, 07 Jun 2023 02:29:28 GMT

_Version update only_

## 2.0.3
Wed, 24 May 2023 12:41:01 GMT

_Version update only_

## 2.0.2
Mon, 15 May 2023 21:50:33 GMT

### Patches

- Use new flag user key handling

## 2.0.1
Mon, 10 Apr 2023 21:28:25 GMT

_Version update only_

## 2.0.0
Mon, 10 Apr 2023 21:17:31 GMT

### Breaking changes

- updated eslint package to reflect name change

### Minor changes

- updated GraphQL schema

## 1.1.0
Thu, 26 Jan 2023 20:22:13 GMT

### Minor changes

- updated rush config so package can be published
- updated package description for library

