import { describe, expect, it } from 'vitest';

import { makeFlagSchema } from './makeFlagSchema';
import { replaceFlagValue } from './replaceFlagValue';

describe('replaceFlagValue', () => {
  it('should return a correctly formatted object', async () => {
    const target = [
      {
        __typename: 'TypeName',
        flagKey: 'v1',
        flagValue: false
      },
      {
        __typename: 'TypeName',
        flagKey: 'v2',
        flagValue: true
      }
    ];

    const source = makeFlagSchema({
      v1: true,
      v2: true
    });

    const result = replaceFlagValue(target, source);

    expect(Object.keys(result).length).toEqual(2);
  });
});
