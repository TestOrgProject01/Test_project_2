import * as RX from 'rambdax';

/**
 * Takes the GQL repsonse for flags and overrides values
 * taken from the browser URL
 *
 * @public
 */
export const replaceFlagValue = RX.curry((target, source) =>
  RX.pipe(
    RX.map((d: RX.Dictionary<string>) => {
      const update = RX.find((u: any) => u.flagKey === d.flagKey)(source);

      return update ? RX.merge(d, update) : d;
    })
  )(target ?? [])
);
