import { describe, expect, it } from 'vitest';

import { Environment } from '../types/Environment';

import selectValueByApiEnv from './selectValueByApiEnv';

describe('selectValueByApiEnv', () => {
  const config = {
    DEV: 'DEV',
    PREPROD: 'PREPROD',
    PROD: 'PROD',
    QA3: 'QA3',
    QA4: 'QA4',
    UAT: 'UAT',
    fallback: 'fallback'
  };

  it.each([
    'DEV',
    'UAT',
    'PREPROD',
    'QA3',
    'QA4',
    'PROD',
    'fallback'
  ] as Environment[])('case %p', (e) => {
    expect(selectValueByApiEnv(e, config)).toBe(e);
  });
});
