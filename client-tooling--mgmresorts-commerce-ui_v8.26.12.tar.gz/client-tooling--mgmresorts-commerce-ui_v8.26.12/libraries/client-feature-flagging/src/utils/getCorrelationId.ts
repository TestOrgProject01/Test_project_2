import { v4 as uuidv4 } from 'uuid';

import { hasWindow } from '../utils';

/**
 * Gets a correlation ID for use in request tracing.
 *
 * @returns A `string` in the shape of 'A|B' such that `A` is a session
 * identifier and `B` is a transaction identifier.
 *
 * @remarks
 * Identifers are UUIDv4 standardized. Note that `|` is a pipe character, not
 * logical OR. If `window` is not defined in context, a standard UUIDv4 string
 * is returned.
 */
const getCorrelationId = () => {
  const JOURNEY_KEY = 'journey-id';

  if (!hasWindow()) {
    return uuidv4();
  }

  let journeyId = window?.sessionStorage.getItem(JOURNEY_KEY);
  const transactionId = uuidv4();

  if (!journeyId) {
    journeyId = uuidv4();
    window?.sessionStorage.setItem(JOURNEY_KEY, journeyId);
  }

  return `${journeyId}|${transactionId}`;
};

export default getCorrelationId;
