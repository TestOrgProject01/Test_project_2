import { describe, expect, it, vi } from 'vitest';

import poll from './poll';

describe('poll', () => {
  it('polls until timeout', async () => {
    const fn = vi.fn();
    const delay = 10;
    const timeout = 50;

    const result = await poll({
      condition: () => false,
      delay,
      fn,
      timeout
    });

    expect(result).toBe(null);
    expect(fn).toHaveBeenCalledTimes(timeout / delay);
  });

  it('polls until successful condition', async () => {
    const delay = 1;
    const timeout = 50;
    const data = [1, 2, 3];

    const fnWrapper = {
      fn:
        <T>(xs: T[]) =>
        (): boolean => {
          if (xs.length === 0) {
            return true;
          }

          const [, ...tail] = xs;

          return fnWrapper.fn(tail)();
        }
    };

    const mock = vi.spyOn(fnWrapper, 'fn');

    const result = await poll({
      condition: (v) => v === true,
      delay,
      fn: fnWrapper.fn(data),
      timeout
    });

    expect(result).toBe(true);
    expect(mock).toHaveBeenCalledTimes(data.length + 1);
  });
});
