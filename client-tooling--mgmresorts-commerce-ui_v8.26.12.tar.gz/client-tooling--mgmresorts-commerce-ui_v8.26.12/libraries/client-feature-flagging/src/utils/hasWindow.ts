const hasWindow = (): boolean => window !== undefined;

export default hasWindow;
