import delayP from './delay';

/**
 * Polls a value produced by `fn` until it satisfies a condition or encounters timeout.
 *
 * @param props - `fn`: The function to call
 * @param props - `delay`: The delay between polling attempts (milliseconds)
 * @param props - `condition`: The condition to satisfy to end polling.
 * @param props - `timeout`: The maximum duration to poll during (milliseconds)
 *
 * @returns The value if successful, otherwise `null`.
 *
 * @public
 */
export default async function poll<T, F extends () => T>(props: {
  fn?: F;
  delay: number | (() => number);
  condition: (v?: T) => boolean | Promise<boolean>;
  timeout: number;
}): Promise<T | null> {
  const { fn, delay, condition, timeout } = props;
  const interval = typeof delay === 'function' ? delay() : delay;

  if (timeout - interval <= 0) {
    return fn?.() ?? null;
  }

  const result = fn?.();

  if (!condition(result)) {
    await delayP(interval);

    return poll({
      ...props,
      timeout: timeout - interval
    });
  }

  return result ?? null;
}
