import { mergeDeepRight } from 'rambdax';

import { FlagsSdkConfig } from '../sdk';
import { LdAttributes } from '../types/Attributes';

/**
 * Provides safe defaults for Launch Darkly attributes that can be overridden
 * with passed attributes.
 *
 * @public
 */
const makeAttributes = (config: FlagsSdkConfig): LdAttributes =>
  mergeDeepRight<LdAttributes>({
    /**
     * Specifies the application fetching flags
     */
    customAttributes: {},
    privateAttributes: []
  })(config.attributes ?? {});

export default makeAttributes;
