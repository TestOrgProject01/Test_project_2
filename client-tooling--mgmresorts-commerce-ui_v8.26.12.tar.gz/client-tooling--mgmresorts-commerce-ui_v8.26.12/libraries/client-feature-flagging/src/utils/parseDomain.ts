import {
  parseDomain as _parseDomain,
  fromUrl,
  ParseResultType,
  ParseResult
} from 'parse-domain';
import * as RX from 'rambdax';
import { match } from 'ts-pattern';

const parseDomainFromUrl = RX.pipe(fromUrl, _parseDomain);

const concatenateDomainWithTLD = RX.ifElse(
  ([d, tlds]: [string | undefined, string[]]) =>
    RX.or(RX.isNil(d), RX.isEmpty(tlds)),
  RX.always(undefined),
  ([d, tlds]) => RX.join('.', [d, ...tlds])
);

const matchHostname = (parseResult: ParseResult) =>
  match(parseResult)
    .with({ type: ParseResultType.Invalid }, RX.always(undefined))
    .with({ type: ParseResultType.Ip }, RX.prop('hostname'))
    .with({ type: ParseResultType.Listed }, ({ domain, topLevelDomains }) =>
      concatenateDomainWithTLD([domain, topLevelDomains])
    )
    .with({ type: ParseResultType.Reserved }, RX.prop('hostname'))
    .with({ type: ParseResultType.NotListed }, RX.prop('hostname'))
    .exhaustive();

export const parseDomain = RX.pipe(parseDomainFromUrl, matchHostname);
