import * as RX from 'rambdax';
import { describe, expect, it } from 'vitest';

import { parseDomain } from './parseDomain';

const mgmBrandedSubdomains = [
  'aria',
  'beaurivage',
  'bellagio',
  'borgata',
  'delanolasvegas',
  'empirecitycasino',
  'excalibur',
  'goldstrike',
  'luxor',
  'mandalaybay',
  'mgmgrand',
  'mgmgranddetroit',
  'mgmnationalharbor',
  'mgmnorthfieldpark',
  'mgmspringfield',
  'mirage',
  'newyorknewyork',
  'nomadlasvegas',
  'parkmgm',
  'signaturemgmgrand',
  'vdara',
  'www'
];

const makeMgmFullDomainTable = (domain: string) =>
  RX.map((x) => [`${x}.${domain}`, domain], mgmBrandedSubdomains);

describe('parseDomain', () => {
  it.each([
    ...makeMgmFullDomainTable('mgmresorts.com'),
    ...makeMgmFullDomainTable('devtest.vegas'),
    ...[
      ['https://mgmresorts.com', 'mgmresorts.com'],
      ['https://www.mgmresorts.com', 'mgmresorts.com'],
      ['https://dev.devtest.vegas', 'devtest.vegas'],
      ['https://qa4-bellagio.devtest.vegas', 'devtest.vegas'],
      ['http://localhost:3000', 'localhost']
    ]
  ])('parses %p to %p', (v, e) => {
    expect(parseDomain(v)).toBe(e);
  });
});
