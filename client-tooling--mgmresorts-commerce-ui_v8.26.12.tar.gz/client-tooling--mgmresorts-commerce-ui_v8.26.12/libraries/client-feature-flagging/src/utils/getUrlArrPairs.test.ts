import { describe, expect, it } from 'vitest';

import { getUrlArrPairs } from './getUrlArrPairs';

describe('getUrlArrPairs', () => {
  it('should return a correctly formatted object', async () => {
    const result = getUrlArrPairs(`?_f[v1]=true&_f[v2]=&_f[v2?]=true`, '_f');

    expect(Object.keys(result).length).toEqual(2);

    Object.keys(result).map((key: string) => {
      expect(key.startsWith('v')).toEqual(true);
      expect(typeof result[key]).toBe('boolean');
    });
  });

  it('should correctly handle encoded parameters', async () => {
    const result = getUrlArrPairs(
      `?_f%5Bv1%5D=true&_f%5Bv2%5D=&_f%5Bv2?%5D=true`,
      '_f'
    );

    expect(Object.keys(result).length).toEqual(2);

    Object.keys(result).map((key: string) => {
      expect(key.startsWith('v')).toEqual(true);
      expect(typeof result[key]).toBe('boolean');
    });
  });
});
