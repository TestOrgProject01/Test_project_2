import { Environment } from '../types/Environment';

const selectValueByApiEnv = <U, E extends Environment>(
  e: E,
  d: {
    [key in Environment | 'fallback']: U;
  }
) => d[e || 'fallback'];

export default selectValueByApiEnv;
