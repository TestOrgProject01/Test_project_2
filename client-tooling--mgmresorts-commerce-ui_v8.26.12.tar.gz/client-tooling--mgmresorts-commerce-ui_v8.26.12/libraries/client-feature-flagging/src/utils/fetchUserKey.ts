import { addYears, differenceInDays } from 'date-fns';
import Cookies from 'js-cookie';
import * as RX from 'rambdax';
import { match, P } from 'ts-pattern';

import {
  LD_USER_KEY_COOKIE_KEY_V1,
  LD_USER_KEY_COOKIE_KEY_V2
} from '../constants';
import { getUniqueIdentifier, hasWindow } from '../utils';

import { parseDomain } from './parseDomain';

const createLDUserKeyCookie =
  (origin: string) =>
  (value: string): string | undefined => {
    const domain = parseDomain(origin);
    const secure = RX.contains(new URL(origin).protocol, 'https:');
    /**
     * Two (2) year expiry
     */
    const expires = differenceInDays(addYears(new Date(), 2), new Date());

    // Careful to only set cookie if root domain exists to avoid gating the
    // cookie to some subdomain.
    if (domain) {
      Cookies.set(LD_USER_KEY_COOKIE_KEY_V2, value, {
        domain,
        expires,
        hostOnly: false,
        httpOnly: false,
        path: '/',
        secure
      });

      return value;
    }
  };

/**
 * Fetch or generate an internally managed cookie to identify user with
 * LaunchDarkly.
 *
 * @example
 * ```ts
 * const key = fetchUserKey()
 * ```
 *
 * @remarks
 * Past version `2.y.z` this will uses a new cookie key and inherits the old
 * key if it exists. This function no longer relies on polling Adobe
 * for the assigned marketing ID, because Adobe is unreliable.
 *
 * @public
 */
const fetchUserKey = (): string => {
  // We need a window in context to grab the origin
  if (!hasWindow()) {
    throw Error('window is not defined');
  }

  const createCookie = createLDUserKeyCookie(window.location.origin);

  const currentUserKeyV1 = Cookies.get(LD_USER_KEY_COOKIE_KEY_V1);
  const currentUserKeyV2 = Cookies.get(LD_USER_KEY_COOKIE_KEY_V2);

  return match({ currentUserKeyV1, currentUserKeyV2 })
    .with(
      {
        currentUserKeyV1: P.nullish,
        currentUserKeyV2: P.string
      },
      // Only V2 exists: use it.
      ({ currentUserKeyV1: _, currentUserKeyV2 }) => currentUserKeyV2
    )
    .with(
      {
        currentUserKeyV1: P.string,
        currentUserKeyV2: P.nullish
      },
      // Only V1 exists: use it for V2 creation.
      ({ currentUserKeyV1, currentUserKeyV2: _ }) => {
        createCookie(currentUserKeyV1);

        return currentUserKeyV1;
      }
    )
    .with(
      {
        currentUserKeyV1: P.string,
        currentUserKeyV2: P.string
      },
      // V1 and V2 exist: ignore V1 and use V2.
      ({ currentUserKeyV1: _, currentUserKeyV2 }) => currentUserKeyV2
    )
    .with(
      {
        currentUserKeyV1: P.nullish,
        currentUserKeyV2: P.nullish
      },
      // Neither exists: create and use V2.
      (_) => createCookie(getUniqueIdentifier()) ?? ''
    )
    .exhaustive();
};

export default fetchUserKey;
