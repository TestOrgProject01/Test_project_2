import * as RX from 'rambdax';

/**
 * Split at first ? and ignore remainder
 */
const splitAtFirstQuestionMark = (str: string) => {
  const index = str.indexOf('?');

  return index < 0 ? [str] : [str.slice(0, index), str.slice(index + 1)];
};

/**
 * Provides the ability to extract an array of key value pairs
 * from a string-like URL
 *
 * @public
 */
export const getUrlArrPairs = (
  url: string,
  paramKey: string
): Record<string, boolean | string> =>
  RX.pipe(
    /*
     * Split the URL at the '?' to get the query string
     */
    splitAtFirstQuestionMark,

    /*
     * Get the query string (last part of the split array)
     */
    RX.last,

    /*
     * Split the search params at '&' to get key-value pairs
     */
    RX.split('&'),

    /**
     * Extract the key and value from each pair and decode them
     */
    RX.map((pair) => {
      const [key, value] = RX.split('=')(pair);

      return [decodeURIComponent(key), decodeURIComponent(value)];
    }),

    /*
     * Filter for keys starting with the provided paramKey and empty values
     */
    RX.filter(
      ([key, val]) => key.startsWith(`${paramKey}[`) && !RX.isEmpty(val)
    ),

    /*
     * Reduce to an object with flag names as keys and values (true/false)
     */
    RX.reduce((acc, [key, value]) => {
      const name = RX.slice(paramKey.length + 1, -1)(key);

      return {
        ...acc,
        [name]: value === 'true' ? true : value === 'false' ? false : value
      };
    }, {})
  )(url);
