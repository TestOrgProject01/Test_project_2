// mocks must be at the top of the file; needs lint enforcement
const MOCK_UUID = 'mock-uuid';

import Cookies from 'js-cookie';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';

import {
  LD_USER_KEY_COOKIE_KEY_V1,
  LD_USER_KEY_COOKIE_KEY_V2
} from '../constants';

import fetchUserKey from './fetchUserKey';
import { getUniqueIdentifier } from './getUniqueIdentifier';

vi.mock('./getUniqueIdentifier', () => ({
  getUniqueIdentifier: () => MOCK_UUID
}));

// global mocking
const url = 'https://www.example.com';

describe('fetchUserKey', () => {
  beforeAll(() => {
    vi.stubGlobal('location', {
      href: url,
      origin: url
    });
  });

  afterAll(() => {
    vi.unstubAllGlobals();
  });

  it('throws an error if window is not defined', () => {
    const setCookieSpy = vi.spyOn(Cookies, 'set');
    const getCookieSpy = vi.spyOn(Cookies, 'get');
    const tempWindow = global.window;
    delete (global as any).window;
    expect(() => fetchUserKey()).toThrow('window is not defined');
    expect(setCookieSpy).toHaveBeenCalledTimes(0);
    expect(getCookieSpy).toHaveBeenCalledTimes(0);
    global.window = tempWindow;
  });

  it('mocks getUniqueIdentifier', () => {
    expect(getUniqueIdentifier()).toBe(MOCK_UUID);
  });

  it('uses the v2 cookie if v1 does not exist', () => {
    const setCookieSpy = vi.spyOn(Cookies, 'set');
    const getCookieSpy = vi.spyOn(Cookies, 'get');
    // @ts-expect-error
    getCookieSpy.mockReturnValueOnce(undefined).mockReturnValueOnce('v2');
    const key = fetchUserKey();
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V1);
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V2);
    expect(key).toBe('v2');
    expect(setCookieSpy).toHaveBeenCalledTimes(0);
  });

  it('inherits the v1 cookie if v2 does not exist', () => {
    const setCookieSpy = vi.spyOn(Cookies, 'set');
    const getCookieSpy = vi.spyOn(Cookies, 'get');
    // @ts-expect-error
    getCookieSpy.mockReturnValueOnce('v1').mockReturnValueOnce(undefined);
    const key = fetchUserKey();
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V1);
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V2);
    expect(key).toBe('v1');
    expect(setCookieSpy).toHaveBeenCalledTimes(1);

    expect(setCookieSpy).toHaveBeenCalledWith(
      LD_USER_KEY_COOKIE_KEY_V2,
      'v1',
      expect.objectContaining({
        domain: 'example.com',
        hostOnly: false,
        httpOnly: false,
        path: '/',
        secure: true
      })
    );
  });

  it('uses the v2 cookie both exist', () => {
    const setCookieSpy = vi.spyOn(Cookies, 'set');
    const getCookieSpy = vi.spyOn(Cookies, 'get');
    // @ts-expect-error
    getCookieSpy.mockReturnValueOnce('v1').mockReturnValueOnce('v2');
    const key = fetchUserKey();
    expect(key).toBe('v2');
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V1);
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V2);
    expect(setCookieSpy).toHaveBeenCalledTimes(0);
  });

  it('creates the v2 cookie if neither exist', () => {
    const setCookieSpy = vi.spyOn(Cookies, 'set');
    const getCookieSpy = vi.spyOn(Cookies, 'get');
    // @ts-expect-error
    getCookieSpy.mockReturnValueOnce(undefined).mockReturnValueOnce(undefined);
    const key = fetchUserKey();
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V1);
    expect(getCookieSpy).toHaveBeenCalledWith(LD_USER_KEY_COOKIE_KEY_V2);
    expect(key).toBe(MOCK_UUID);
    expect(setCookieSpy).toHaveBeenCalledTimes(1);

    expect(setCookieSpy).toHaveBeenCalledWith(
      LD_USER_KEY_COOKIE_KEY_V2,
      MOCK_UUID,
      expect.objectContaining({
        domain: 'example.com',
        hostOnly: false,
        httpOnly: false,
        path: '/',
        secure: true
      })
    );
  });
});
