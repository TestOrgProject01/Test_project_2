const delay = async (ms: number) =>
  new Promise((resolve) => {
    setTimeout(resolve, Math.max(0, ms));
  });

export default delay;
