import * as RX from 'rambdax';

/**
 * Provides the ability to take an key, value list and return
 * and array of featue flags.
 *
 * @public
 */
export const makeFlagSchema = RX.pipe(
  /*
   * Convert list to array of arrays
   */
  RX.toPairs,

  /**
   * Create an array that matches GQL schema
   */
  RX.map(([key, value]) => ({
    flagKey: key,
    flagValue: value
  }))
);
