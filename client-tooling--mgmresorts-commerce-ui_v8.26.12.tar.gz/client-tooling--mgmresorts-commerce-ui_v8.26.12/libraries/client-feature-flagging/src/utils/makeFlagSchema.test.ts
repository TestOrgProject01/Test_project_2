import { describe, expect, it } from 'vitest';

import { makeFlagSchema } from './makeFlagSchema';

describe('makeFlagSchema', () => {
  it('should return a correctly formatted object', async () => {
    const result = makeFlagSchema({ v1: true, v2: false });

    expect(Object.keys(result).length).toEqual(2);

    result.map((e: any) => {
      expect(Object.keys(e).length).toEqual(2);
    });
  });
});
