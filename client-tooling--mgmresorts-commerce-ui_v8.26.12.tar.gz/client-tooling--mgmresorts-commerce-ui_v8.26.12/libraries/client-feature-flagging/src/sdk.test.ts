import { describe, it, expect, vi, afterEach } from 'vitest';

import { FlagsSdkConfig, FlagsSdk } from './sdk';

describe('FlagsSdk', () => {
  const defaultConfig: FlagsSdkConfig = {
    authToken: 'authToken',
    environment: 'PROD',
    name: 'name'
  };

  it.skip('creates singleton with helper', () => {});

  it('should build with sane defaults', () => {
    const sdk = FlagsSdk.init(defaultConfig);
    const config = sdk.debug;

    expect(config.environment).toBe('PROD');

    expect(config.attributes).toStrictEqual({
      customAttributes: {},
      privateAttributes: []
    });
  });

  it('should build with attributes including defaults', () => {
    const sdk = FlagsSdk.init({
      ...defaultConfig,
      attributes: {
        customAttributes: {
          firstName: 'John',
          lastName: 'Doe'
        }
      }
    });

    const config = sdk.debug;

    expect(Object.keys(config.attributes?.customAttributes).length).toBe(2);
  });

  it('should correctly handle flag overrides from URL params', () => {
    global.window = Object.create(window);

    Object.defineProperty(window, 'location', {
      value: {
        search: '?_f[v1]=true&_f[v2]=false'
      }
    });

    const sdk = FlagsSdk.init(defaultConfig);
    const config = sdk.debug;

    expect(Object.keys(config.flagsFromURL as {}).length).toBe(2);
  });

  describe('fetch', () => {
    vi.stubGlobal('location', {
      origin: 'https://www.mgmresorts.com'
    });

    afterEach(() => {
      vi.resetAllMocks();
    });

    it('should handle resolve', async () => {
      const fetchSpy = vi
        .spyOn(FlagsSdk, 'fetch')
        .mockImplementation(() => Promise.resolve([]));

      FlagsSdk.init(defaultConfig);
      FlagsSdk.userKey('userKey');
      FlagsSdk.flags(['flagKey']);

      expect(fetchSpy).toHaveBeenCalledTimes(0);

      await FlagsSdk.fetch();

      expect(fetchSpy).toHaveBeenCalledTimes(1);

      // Can't test hard private fields; TODO test impl
      // expect(FlagsSdk.#client.query).toHaveBeenCalledTimes(1);
    });

    it('should handle reject', () => {});

    it.skip('should filter flags', () => {
      const flags = ['client-feature-flagging'];
      const result = FlagsSdk.init(defaultConfig).flags(flags).fetch();

      // expect only keys in `flags` to be returned
      expect(result).toBeTruthy();
    });
  });
});
