/**
 * MGM's web SDK for fetching feature flags.
 *
 * @remarks
 * The `@mgmresorts/client-feature-flagging` defines the {@link FlagsSdk}
 * singleton instance which is used to configure and fetch feature flags.
 *
 * {@link FlagsSdkSingleton} is exported for the sake of documentation and
 * should not be used directly.
 *
 * @packageDocumentation
 */
export { FlagsSdk, FlagsSdkSingleton } from './sdk';
export { fetchUserKey } from './utils/index';
export { default as getClient } from './api/getClient';

export type { FlagsSdkConfig } from './sdk';
export type {
  ClientChannelIdAttributeName,
  ClientChannelId
} from './types/Attributes';
export type { Environment } from './types/Environment';
export type { LdAttributes } from './types/Attributes';
