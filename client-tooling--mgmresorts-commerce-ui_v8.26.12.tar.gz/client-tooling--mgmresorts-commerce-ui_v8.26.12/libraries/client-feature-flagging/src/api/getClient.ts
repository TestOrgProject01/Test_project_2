import { Exchanges } from '@mgmresorts/urql';
import { createClient as createUrqlClient } from '@urql/core';

import { GRAPHQL_ENDPOINTS } from '../constants';
import { Environment } from '../types/Environment';
import { selectValueByApiEnv } from '../utils';

/**
 * Create a GQL request client with appropriate headers.
 *
 * @public
 */
const getClient = ({
  authToken,
  environment,
  name
}: {
  authToken: string;
  environment: Environment;
  name: string;
}) => {
  /**
   * This is a closure so that correlation ID is re-evaluated for each request.
   */

  // adding bypass for server side scenarios or runners
  const isNonBrowser = typeof window === 'undefined' || (window && (window as any)?.Cypress);
  
  const fetchOptions = () => ({
    headers: {
      Authorization: authToken ? `Bearer ${authToken}` : '',
      ...(isNonBrowser ? { 'x-mgm-integration-auth-bypass': 'web-mfe-shell' } : {})
    }
  });

  return createUrqlClient({
    exchanges: [
      Exchanges.makeAppendOperationNameExchange(),
      Exchanges.makeCorrelationExchange({
        channel: 'web',
        clientName: name,
        clientVersion: undefined,
        source: undefined
      })
    ],
    fetchOptions,
    url: selectValueByApiEnv(environment, {
      ...GRAPHQL_ENDPOINTS,
      fallback: GRAPHQL_ENDPOINTS.PROD
    })
  });
};

export default getClient;
