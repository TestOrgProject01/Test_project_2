// Note that SWC 1.3.14 doesn't like '.' as an import.
// It thinks it's the root.
import { graphql } from './index';

export const FeatureFlagsQueryDocument = graphql(`
  query FeatureFlagsQuery(
    $contextKind: String
    $userKey: String
    $attributes: FeatureFlagVariationsAttributes
  ) {
    featureFlagVariationDetails(
      contextKind: $contextKind
      userKey: $userKey
      attributes: $attributes
    ) {
      flagKey
      flagValue
      userKey
    }
  }
`);
