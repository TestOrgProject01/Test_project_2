import { Environment } from './types/Environment';

export const GRAPHQL_ENDPOINTS: { [K in Environment]: string } = {
  DEV: 'https://dev-api.devtest.vegas/graphql-next',
  PREPROD: 'https://preprod-api.devtest.vegas/graphql-next',
  PROD: 'https://api.mgmresorts.com/graphql-next',
  QA3: 'https://qa3-api.devtest.vegas/graphql-next',
  QA4: 'https://qa4-api.devtest.vegas/graphql-next',
  UAT: 'https://uat-api.devtest.vegas/graphql-next'
};

export const LD_USER_KEY_COOKIE_KEY_V1 = '__mgm-ld-id';
export const LD_USER_KEY_COOKIE_KEY_V2 = '__mgm-ld-id2';
