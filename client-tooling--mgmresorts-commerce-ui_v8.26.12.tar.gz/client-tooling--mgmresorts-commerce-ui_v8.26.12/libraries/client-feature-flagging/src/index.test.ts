import { describe, expect, it } from 'vitest';

describe('hello world', () => {
  it('runs', () => {
    expect(true).toBe(true);
  });
});
