/**
 * Client channel IDs definitions
 *
 * @public
 */
export type ClientChannelIdAttributeName = 'WEB_clientChannelId';

/**
 * Client channel IDs definitions
 *
 * @public
 */
export type ClientChannelId = 'mgm-web' | 'mgm-mobile' | 'mgm-ice' | 'vendor';

/**
 * Launch Darkly attributes
 *
 * @public
 */
export interface LdAttributes {
  customAttributes?: any;
  privateAttributes?: Array<string>;
}
