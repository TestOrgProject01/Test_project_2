/**
 * API environments
 *
 * @public
 */
export type Environment = 'DEV' | 'UAT' | 'QA3' | 'PREPROD' | 'QA4' | 'PROD';
