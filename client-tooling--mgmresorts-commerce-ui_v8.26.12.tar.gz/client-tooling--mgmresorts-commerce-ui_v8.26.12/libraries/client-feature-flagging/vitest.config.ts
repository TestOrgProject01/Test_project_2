import shared from '@mgmresorts/build-tools-ng/vitest.shared.js';
import { defineConfig, mergeConfig } from 'vitest/config';

const config = defineConfig({
  test: {
    environment: 'happy-dom',
    globals: true,
    include: ['src/**/*.test.ts']
  }
});

export default mergeConfig(shared.default, config);
