# MGM URQL

[:book:](https://mgmresorts.github.io/client-tooling)