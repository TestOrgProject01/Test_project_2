// This is a workaround for https://github.com/eslint/eslint/issues/3458
require('@mgmresorts/eslint-config-cet/patch/modern-module-resolution');

/**
 * @type {import("eslint").Linter.Config}
 */
module.exports = {
  extends: [
    '@mgmresorts/eslint-config-cet/profiles/web-app/recommended',
    '@mgmresorts/eslint-config-cet/mixins/nx'
    //'plugin:@effect/recommended'
  ],
  overrides: [
    {
      files: ['*.ts', '*.tsx'],
      settings: {
        tsdoc: {
          configFile: './tsdoc.json'
        }
      }
    }
  ],
  parserOptions: {
    EXPERIMENTAL_useProjectService: true, // see https://github.com/typescript-eslint/typescript-eslint/issues/2094
    ecmaVersion: 2018,
    project: './tsconfig.json',
    sourceType: 'module'
  },
  rules: {
    '@effect/dprint': 0,
    '@typescript-eslint/no-namespace': 0,
    'tsdoc/syntax': 0
  }
};
