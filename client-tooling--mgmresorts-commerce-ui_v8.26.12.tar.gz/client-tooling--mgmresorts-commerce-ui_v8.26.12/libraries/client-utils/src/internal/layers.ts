import { KeyValueStore } from '@effect/platform';
import { BrowserKeyValueStore } from '@effect/platform-browser';
import { Layer } from 'effect/Layer';

import * as GlobalThis from '../GlobalThis.js';

/**
 * Provides a {@link KeyValueStore} layer for browser *or* Node contexts.
 *
 * @internal
 */
export const Storage: Layer<KeyValueStore.KeyValueStore> =
  GlobalThis.hasWindow()
    ? BrowserKeyValueStore.layerSessionStorage
    : KeyValueStore.layerMemory;
