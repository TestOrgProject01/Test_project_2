import { KeyValueStore } from '@effect/platform';
import { PlatformError } from '@effect/platform/Error';
import { Data, Effect, Option, pipe } from 'effect';
import { v4 as uuidv4 } from 'uuid';

/** @internal */
const JOURNEY_KEY_V1 = 'journeyId';

/** @internal */
export class JourneyNotSetError extends Data.TaggedError('KeyUnset')<{
  message: string;
}> {}

/** @internal */
export const get: Effect.Effect<
  string,
  JourneyNotSetError | PlatformError,
  KeyValueStore.KeyValueStore
> = pipe(
  KeyValueStore.KeyValueStore,
  Effect.andThen((storage) => storage.get(JOURNEY_KEY_V1)),
  Effect.flatMap(
    Option.match({
      onNone: () =>
        Effect.fail(
          new JourneyNotSetError({
            message: 'journeyId does not exist in storage'
          })
        ),
      onSome: Effect.succeed
    })
  )
);

/** @internal */
export const set: Effect.Effect<
  string,
  PlatformError,
  KeyValueStore.KeyValueStore
> = pipe(
  KeyValueStore.KeyValueStore,
  Effect.andThen((storage) =>
    pipe(
      Effect.sync(uuidv4),
      Effect.tap((x) => storage.set(JOURNEY_KEY_V1, x))
    )
  )
);

/** @internal */
export const provision: Effect.Effect<
  string,
  PlatformError,
  KeyValueStore.KeyValueStore
> = pipe(
  get,
  Effect.catchTag('KeyUnset', () => set)
);
