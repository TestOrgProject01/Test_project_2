import { pathOr, includes, pipe, split } from 'rambdax';

import { withWindowCheck } from '../GlobalThis.js';
import { PRIVACY_WINDOW_GROUPS, PRIVACY_WINDOW_OBJECT } from '../Privacy.js';

/**
 * Determines if a specific group exists as part of the
 * OneTrust initialization
 *
 * @internal
 */
export const checkOnetrustActiveGroups = withWindowCheck(
  (requiredValue: string) =>
    pipe(
      pathOr('', [PRIVACY_WINDOW_GROUPS]),
      split(','),
      includes(requiredValue)
    )(window)
);

/**
 * Helper function to call methods on the vendor window object
 *
 * @internal
 */
export const callVendorMethod = withWindowCheck(
  <T>(methodName: string, defaultValue: T): T =>
    pathOr(defaultValue, [PRIVACY_WINDOW_OBJECT, methodName], window)
);
