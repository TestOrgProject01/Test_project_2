import { Equal } from 'effect';
import * as A from 'effect/Array';
import * as Effect from 'effect/Effect';
import { flow, pipe, dual } from 'effect/Function';
import * as Match from 'effect/Match';
import * as O from 'effect/Option';
import * as S from 'effect/String';
import { fromUrl, parseDomain } from 'parse-domain';

import * as Branding from '../Branding.js';
import * as GlobalThis from '../GlobalThis.js';

/** @internal */
const parseDomainFromUrl = flow(fromUrl, parseDomain);

/** @internal */
export const getSubdomainsFromUrl: Effect.Effect<readonly string[], string> =
  pipe(
    GlobalThis.origin,
    Effect.flatMap(
      flow(
        parseDomainFromUrl,
        Match.value,
        Match.when({ subDomains: A.isNonEmptyArray }, ({ subDomains }) =>
          Effect.succeed(subDomains)
        ),
        Match.orElse(() => Effect.succeed([]))
      )
    )
  );

export const findPropertyBySlug: (
  subdomain: string
) => O.Option<Branding.Property.Key> = (
  subdomain: string
): O.Option<Branding.Property.Key> =>
  pipe(
    Branding.Property.Config,
    Object.getOwnPropertySymbols,
    (symbols) =>
      (symbols as Branding.Property.Key[]).filter((key) =>
        S.includes(Branding.slugOf(key))(subdomain)
      ),
    A.head
  );

/** @internal */
export const getPropertyFromUrl: Effect.Effect<
  Branding.Property.Key,
  string,
  never
> = pipe(
  getSubdomainsFromUrl,
  Effect.map(
    flow(
      A.map(findPropertyBySlug),
      A.head,
      O.flatten,
      O.getOrElse<Branding.Property.Key>(() => Branding.Property.Mgm)
    )
  )
);

/** internal */
export const matchProp = <T extends keyof Branding.Property.Data>(
  prop: T
): {
  (a: Branding.Property.Key): (self: Branding.Property.Data[T]) => boolean;
  (self: Branding.Property.Data[T], a: Branding.Property.Key): boolean;
} =>
  dual(2, (self: Branding.Property.Data[T], a: Branding.Property.Key) =>
    pipe(Branding.Property.Config[a][prop], Equal.equals(self))
  );
