export type Replace<T, From, To> = T extends From ? To : T;

export enum PrivacyCategories {
  stricly = 'C0001',
  performance = 'C0002',
  functional = 'C0003',
  targeting = 'C0004'
}
