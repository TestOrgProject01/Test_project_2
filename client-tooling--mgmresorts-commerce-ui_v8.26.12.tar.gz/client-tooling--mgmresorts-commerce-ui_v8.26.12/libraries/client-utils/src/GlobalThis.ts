/**
 * This module provides utilities for working with the `globalThis` objects in a
 * browser context.
 *
 * @since 0.0.0
 */

import { pipe } from 'effect';
import * as Effect from 'effect/Effect';
import { always, ifElse } from 'rambdax';

/**
 * Determine if `window` exists in the global context.
 *
 * @since 0.0.0
 */
export const hasWindow: () => boolean = () =>
  typeof globalThis.window !== 'undefined';

/**
 * Determine if `document` exists in the global context.
 *
 * @since 0.0.0
 */
export const hasDocument: () => boolean = () =>
  typeof globalThis.document !== 'undefined';

/**
 * Safely provides the window origin if it exists.
 *
 * @since 0.0.0
 */
export const origin: Effect.Effect<string, string> = pipe(
  Effect.sync(
    () => 'location' in globalThis && globalThis.location.origin !== undefined
  ),
  Effect.flatMap(
    Effect.if({
      onFalse: () => Effect.fail('no location.origin in globalThis'),
      onTrue: () => Effect.succeed(globalThis.location.origin)
    })
  )
);

/**
 * A higher-order function that wraps another function, `fn`, and ensures it is only executed
 * if the `window` object is defined. If `window` is undefined, the function returns `false`.
 *
 * @since 0.0.0
 */
export const withWindowCheck = <T extends (...args: any[]) => any>(fn: T): T =>
  ((...args: Parameters<T>): ReturnType<T> =>
    ifElse(
      () => typeof window === 'undefined',
      always(false as ReturnType<T>),
      () => fn(...args)
    )()) as T;
