/**
 * This module provides utilities for tracking requests, such as with
 * correlation identifiers.
 *
 * @since 0.0.0
 */

import * as Effect from 'effect/Effect';
import { pipe } from 'effect/Function';

import * as Branding from './Branding.js';

/**
 * Application domain.
 *
 * @since 0.0.0
 */
export type Channel = 'web' | 'mobile' | 'ice';

/**
 * Derive the source (`x-mgm-source`) for the URL in context.
 *
 * @since 0.0.0
 */
export const sourceFromUrl: Effect.Effect<
  Branding.Property.Source,
  string,
  never
> = pipe(Branding.getPropertyFromUrl, Effect.map(Branding.sourceOf));
