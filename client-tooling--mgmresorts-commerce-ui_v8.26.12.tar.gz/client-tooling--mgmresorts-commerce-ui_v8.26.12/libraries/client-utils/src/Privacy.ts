import { pathOr, anyFalse } from 'rambdax';

import { withWindowCheck } from './GlobalThis.js';
import {
  callVendorMethod,
  checkOnetrustActiveGroups
} from './internal/privacy.js';
import { PrivacyCategories } from './internal/types.js';

export const PRIVACY_WINDOW_OBJECT = 'OneTrust';
export const PRIVACY_WINDOW_GROUPS = 'OnetrustActiveGroups';
export const PRIVACY_WINDOW_UPDATED_EVENT = 'OnConsentChanged';
export const PRIVACY_ALLOWED_COUNTRIES = ['US'];

/**
 * Check if each tracking cookie category is enabled
 *
 * @since 0.0.0
 */
export const strictlyCookieEnabled = withWindowCheck(() =>
  checkOnetrustActiveGroups(PrivacyCategories.stricly)
);

export const performanceCookieEnabled = withWindowCheck(() =>
  checkOnetrustActiveGroups(PrivacyCategories.performance)
);

export const functionalCookieEnabled = withWindowCheck(() =>
  checkOnetrustActiveGroups(PrivacyCategories.functional)
);

export const targetingCookieEnabled = withWindowCheck(() =>
  checkOnetrustActiveGroups(PrivacyCategories.targeting)
);

/**
 * Determines if a user is within the allowed countries of tracking
 *
 * @since 0.0.0
 */
export const userInAllowedCountry = withWindowCheck(() => {
  const geolocationData = callVendorMethod<
    () => { country: string; state: string }
  >('getGeolocationData', () => ({ country: '', state: '' }));

  return PRIVACY_ALLOWED_COUNTRIES.includes(geolocationData().country);
});

/**
 * Access vendor event for cookie changes
 *
 * @since 0.0.0
 */
export const privacyPreferencesUpdated = withWindowCheck((cb: () => void) => {
  const onConsentChanged = pathOr<(cb: () => void) => void>(
    () => {},
    `${PRIVACY_WINDOW_OBJECT}.OnConsentChanged`,
    window
  );

  onConsentChanged(() => cb());
});

/**
 * Checks to determine if tracking should be disabled
 *
 * 1. If user is outside US, always disable tracking
 * 2. LR Should be initialized by default
 * 3. Depending on usecase verify the cookie category status
 *
 * @since 0.0.0
 */
export const isStricklyCookieDisabled = () =>
  anyFalse(userInAllowedCountry, strictlyCookieEnabled);

export const isPerformanceCookieDisabled = () =>
  anyFalse(userInAllowedCountry, performanceCookieEnabled);

export const isFunctionalCookieDisabled = () =>
  anyFalse(userInAllowedCountry, functionalCookieEnabled);

export const isTargetingCookieDisabled = () =>
  anyFalse(userInAllowedCountry, targetingCookieEnabled);
