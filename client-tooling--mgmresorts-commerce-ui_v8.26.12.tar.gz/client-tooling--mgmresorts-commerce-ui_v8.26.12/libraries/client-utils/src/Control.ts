import { path } from 'rambdax';

/**
 * Function to wait for predicates.
 *
 * @since 0.0.0
 */
export const waitFor = (
  paths: string[][],
  timeout?: number,
  maxRetries: number = 10
): Promise<void> =>
  new Promise((resolve, reject) => {
    if (typeof window === 'undefined') {
      return reject();
    }

    const predicate = () => paths.every((p) => path(p, window) !== undefined);
    let retries = 0;

    const check = () => {
      if (predicate()) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        clearInterval(interval);
        resolve();
      }

      if (maxRetries && retries >= maxRetries) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        clearInterval(interval);
        reject();
      }

      retries++;
    };

    const interval = setInterval(check, 150);
    check();

    if (timeout) {
      setTimeout(() => {
        clearInterval(interval);
        reject();
      }, timeout);
    }
  });
