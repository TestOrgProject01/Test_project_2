/**
 * This module provides utilities for tracking requests, such as with
 * correlation identifiers.
 *
 * @since 0.0.0
 */

import { PlatformError } from '@effect/platform/Error';
import { Effect, pipe } from 'effect';

import * as internal from './internal/journey.js';
import * as layers from './internal/layers.js';

/**
 * Provision a Journey ID using session storage.
 *
 * @example
 * import * as Journey from "@mgmresorts/client-utils/Journey"
 * import { Effect, pipe } from "effect";
 *
 * // Traditional Approach
 * let journeyId: string = '';
 * try {
 *   journeyId = Effect.runSync(Journey.provision)
 * } catch (e) {
 *   throw new Error('could not provision journeyId');
 * }
 *
 * // Enlightened Approach
 * const program = pipe(
 *   Journey.provision,
 *   Effect.mapError((e) => new Error('no journeyId'))
 * )
 * const result = Effect.runSyncExit(program)
 *
 * console.log(result)
 * // Output: 'some uuid'
 *
 *
 * @since 0.0.0
 */
export const provision: Effect.Effect<string, PlatformError> = pipe(
  internal.provision,
  Effect.provide(layers.Storage)
);
