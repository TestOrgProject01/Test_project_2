/**
 * A collection of utilites for satisfying common behaviors exhibited by MGM web
 * clients.
 *
 * @since 0.0.0
 */

/**
 * This module provides utilities for tracking requests, such as with
 * correlation identifiers.
 *
 * @since 0.0.0
 */
export * as Tracking from './Tracking.js';

/**
 * This module provides utilities for tracking requests, such as with
 * correlation identifiers.
 *
 * @since 0.0.0
 */
export * as Journey from './Journey.js';

/**
 * This module provides utilities for working with property-specific or resort
 * branded requirements.
 *
 * @since 0.0.0
 */
export * as Branding from './Branding.js';

/**
 * This module provides utilities for working with the `globalThis` objects in a
 * browser context.
 *
 * @since 0.0.0
 */
export * as GlobalThis from './GlobalThis.js';

/**
 * This module provides utilities for handling privacy
 * in our web apps.
 *
 * @since 0.0.0
 */
export * as Privacy from './Privacy.js';

/**
 * This module provides control flow utilities.
 * It is used to manage the timing and sequencing of code execution.
 *
 * @since 0.0.0
 */
export * as Control from './Control.js';
