/**
 * This module provides utilities for working with property-specific or resort
 * branded requirements.
 *
 * @since 0.0.0
 */

import type * as Effect from 'effect/Effect';
import { pipe } from 'effect/Function';
import type * as Option from 'effect/Option';
import * as Struct from 'effect/Struct';

import * as internal from './internal/branding.js';

/**
 * Property definitions and types.
 *
 * @category models
 * @since 0.0.2
 */
export namespace Property {
  export const Aria = Symbol('Aria');
  export const BeauRivage = Symbol('BeauRivage');
  export const Bellagio = Symbol('Bellagio');
  export const Borgata = Symbol('Borgata');
  export const Cosmopolitan = Symbol('Cosmopolitan');
  export const Delano = Symbol('Delano');
  export const EmpireCity = Symbol('EmpireCity');
  export const Excalibur = Symbol('Excalibur');
  export const Grand = Symbol('Grand');
  export const GrandDetroit = Symbol('GrandDetroit');
  export const Luxor = Symbol('Luxor');
  export const MandalayBay = Symbol('MandalayBay');
  export const Mgm = Symbol('Mgm');
  export const NationalHarbor = Symbol('NationalHarbor');
  export const NewYorkNewYork = Symbol('NewYorkNewYork');
  export const Nomad = Symbol('Nomad');
  export const NorthfieldPark = Symbol('NorthfieldPark');
  export const ParkMgm = Symbol('ParkMgm');
  export const Signature = Symbol('Signature');
  export const Springfield = Symbol('Springfield');
  export const Vdara = Symbol('Vdara');
  export const WLasVegas = Symbol('WLasVegas');

  /**
   * A structure of common property/resort specific data.
   *
   * @category models
   * @since 0.0.0
   */
  export interface Data {
    /**
     * Unique Idetifier
     */
    readonly id: string;
    /**
     * Region Identifier
     */
    readonly regionId: string;
    /**
     * Customer-facing name
     */
    readonly websiteTitle: string;
    readonly isMultiPropertyWebsite: boolean;
    /**
     * Identifier for analytics.
     */
    readonly ticker: string;
    /**
     * Slug where property is branded.
     *
     * @example
     * Aria is branded at `aria.mgmresorts.com`, hence `aria` is the slug.
     */
    readonly slug: string;
    /**
     * Source descriptor.
     */
    readonly source: string;
  }

  export const Config = {
    [Property.Aria]: {
      id: 'e2704b04-d515-45b0-8afd-4fa1424ff0a8',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'aria',
      source: 'e2704b04-d515-45b0-8afd-4fa1424ff0a8',
      ticker: 'aria',
      websiteTitle: 'ARIA Resort & Casino'
    },
    [Property.BeauRivage]: {
      id: '13b178b0-8beb-43d5-af25-1738b7267e63',
      isMultiPropertyWebsite: false,
      regionId: 'mississippi',
      slug: 'beaurivage',
      source: '13b178b0-8beb-43d5-af25-1738b7267e63',
      ticker: 'beau',
      websiteTitle: 'Beau Rivage Resort & Casino'
    },
    [Property.Bellagio]: {
      id: '44e610ab-c209-4232-8bb4-51f7b9b13a75',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'bellagio',
      source: '44e610ab-c209-4232-8bb4-51f7b9b13a75',
      ticker: 'bell',
      websiteTitle: 'Bellagio Hotel & Casino'
    },
    [Property.Borgata]: {
      id: '773000cc-468a-4d86-a38f-7ae78ecfa6aa',
      isMultiPropertyWebsite: false,
      regionId: 'new-jersey',
      slug: 'borgata',
      source: '773000cc-468a-4d86-a38f-7ae78ecfa6aa',
      ticker: 'borg',
      websiteTitle: 'Borgata Hotel & Casino'
    },
    [Property.Cosmopolitan]: {
      id: 'e5d3f1c9-833a-83f1-e053-d303fe0ad83c',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'cosmopolitanlasvegas',
      source: 'e5d3f1c9-833a-83f1-e053-d303fe0ad83c',
      ticker: 'tcolv',
      websiteTitle: 'The Cosmopolitan of Las Vegas'
    },
    [Property.Delano]: {
      id: '8bf670c2-3e89-412b-9372-6c87a215e442',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'delanolasvegas',
      source: '8bf670c2-3e89-412b-9372-6c87a215e442',
      ticker: 'dlno',
      websiteTitle: 'Delano Las Vegas'
    },
    [Property.EmpireCity]: {
      id: 'e0ef39b2-5eea-43ff-a734-b10217571eaa',
      isMultiPropertyWebsite: false,
      regionId: 'new-york',
      slug: 'empirecitycasino',
      source: 'e0ef39b2-5eea-43ff-a734-b10217571eaa',
      ticker: 'empr',
      websiteTitle: 'Empire City Casino'
    },
    [Property.Excalibur]: {
      id: 'f8d6a944-7816-412f-a39a-9a63aad26833',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'excalibur',
      source: 'f8d6a944-7816-412f-a39a-9a63aad26833',
      ticker: 'exca',
      websiteTitle: 'Excalibur Hotel & Casino'
    },
    [Property.Luxor]: {
      id: '607c07e7-3e31-4e4c-a4e1-f55dca66fea2',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'luxor',
      source: '607c07e7-3e31-4e4c-a4e1-f55dca66fea2',
      ticker: 'luxr',
      websiteTitle: 'Luxor Hotel & Casino'
    },
    [Property.Mgm]: {
      id: 'mgmresorts',
      isMultiPropertyWebsite: true,
      regionId: 'las-vegas',
      slug: 'www',
      source: 'mgmri',
      ticker: 'mgmr',
      websiteTitle: 'MGM Resorts'
    },
    [Property.MandalayBay]: {
      id: 'e0f70eb3-7e27-4c33-8bcd-f30bf3b1103a',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'mandalaybay',
      source: 'e0f70eb3-7e27-4c33-8bcd-f30bf3b1103a',
      ticker: 'mbay',
      websiteTitle: 'Mandalay Bay'
    },
    [Property.GrandDetroit]: {
      id: '4a65a92a-962b-433e-841c-37e18dc5d68d',
      isMultiPropertyWebsite: false,
      regionId: 'detroit',
      slug: 'mgmgranddetroit',
      source: '4a65a92a-962b-433e-841c-37e18dc5d68d',
      ticker: 'mgmgd',
      websiteTitle: 'MGM Grand Detroit'
    },
    [Property.Grand]: {
      id: '66964e2b-2550-4476-84c3-1a4c0c5c067f',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'mgmgrand',
      source: '66964e2b-2550-4476-84c3-1a4c0c5c067f',
      ticker: 'mgmg',
      websiteTitle: 'MGM Grand Las Vegas'
    },
    [Property.NationalHarbor]: {
      id: '0990fdce-7fc8-41b1-b8b6-9a25dce3db55',
      isMultiPropertyWebsite: false,
      regionId: 'maryland',
      slug: 'mgmnationalharbor',
      source: '0990fdce-7fc8-41b1-b8b6-9a25dce3db55',
      ticker: 'mgmnh',
      websiteTitle: 'MGM National Harbor'
    },
    [Property.NewYorkNewYork]: {
      id: 'dc00e77f-d6bb-4dd7-a8ea-dc33ee9675ad',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'newyorknewyork',
      source: 'dc00e77f-d6bb-4dd7-a8ea-dc33ee9675ad',
      ticker: 'nyny',
      websiteTitle: 'New York-New York Hotel & Casino'
    },
    [Property.Nomad]: {
      id: '2159252c-60d3-47db-bbae-b1db6bb15072',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'nomadlasvegas',
      source: '2159252c-60d3-47db-bbae-b1db6bb15072',
      ticker: 'nomd',
      websiteTitle: 'NoMad Las Vegas'
    },
    [Property.NorthfieldPark]: {
      id: '00ccdea6-7d78-410b-b0f0-5983bdf44cc2',
      isMultiPropertyWebsite: false,
      regionId: 'ohio',
      slug: 'mgmnorthfieldpark',
      source: '00ccdea6-7d78-410b-b0f0-5983bdf44cc2',
      ticker: 'mgmnp',
      websiteTitle: 'MGM Northfield Park'
    },
    [Property.ParkMgm]: {
      id: 'bee81f88-286d-43dd-91b5-3917d9d62a68',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'parkmgm',
      source: 'bee81f88-286d-43dd-91b5-3917d9d62a68',
      ticker: 'pmgm',
      websiteTitle: 'Park MGM'
    },
    [Property.Springfield]: {
      id: '40b61feb-750a-45df-ae68-e23e6272b16b',
      isMultiPropertyWebsite: false,
      regionId: 'massachusetts',
      slug: 'mgmspringfield',
      source: '40b61feb-750a-45df-ae68-e23e6272b16b',
      ticker: 'mgmsp',
      websiteTitle: 'MGM Springfield'
    },
    [Property.Signature]: {
      id: '1f3ed672-3f8f-44d8-9215-81da3c845d83',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'signaturemgmgrand',
      source: '1f3ed672-3f8f-44d8-9215-81da3c845d83',
      ticker: 'sign',
      websiteTitle: 'The Signature at MGM Grand'
    },
    [Property.Vdara]: {
      id: '6c5cff3f-f01a-4f9b-87ab-8395ae8108db',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'vdara',
      source: '6c5cff3f-f01a-4f9b-87ab-8395ae8108db',
      ticker: 'vdar',
      websiteTitle: 'Vdara Hotel & Spa'
    },
    [Property.WLasVegas]: {
      id: '8bf670c2-3e89-412b-9372-6c87a215e442',
      isMultiPropertyWebsite: false,
      regionId: 'las-vegas',
      slug: 'wlasvegas',
      source: '8bf670c2-3e89-412b-9372-6c87a215e442',
      ticker: 'wlv',
      websiteTitle: 'W Las Vegas'
    }
  } as const satisfies { [_: string]: Data };

  /**
   * Raw property configuration data.
   *
   * @category models
   * @since 0.0.2
   */
  export type Config = typeof Config;

  /**
   * Properties
   *
   * @since 0.1.0
   */
  export type Key = keyof Config;
  /**
   * Traffic source.
   *
   * @remarks
   * For all branded properties, this is equivalent to the subdomain name. Only
   * for the non-branded MGM Resorts flow is this equivalent to `mgmri` as a
   * special case.
   *
   * @since 0.0.2
   */
  export type Slug = Config[Key]['slug'];
  /**
   * Property identifier UUID.
   * @since 0.0.2
   */
  export type Id = Config[Key]['id'];
  /**
   * Region identifier string.
   * @since 0.0.2
   */
  export type RegionId = Config[Key]['regionId'];
  /**
   * `x-mgm-source` header.
   * @since 0.0.2
   */
  export type Source = Config[Key]['source'];
  /**
   * Ticker for analytics.
   * @since 0.0.2
   */
  export type Ticker = Config[Key]['ticker'];
  /**
   * Website title.
   * @since 0.0.2
   */
  export type Title = Config[Key]['websiteTitle'];
}

/**
 * Matches a {@link Property.Id} to a given {@link Property.Key}.
 *
 * @example
 * import * as Branding from "@mgmresorts/client-utils/Branding"
 *
 * const isAria: (self: string) => boolean =
 *   Branding.matchId(Branding.Property.Aria)
 *
 * assert.deepStrictEqual(
 *   isAria("e2704b04-d515-45b0-8afd-4fa1424ff0a8"),
 *   true
 * )
 *
 * @category refinements
 * @since 0.0.0
 */
export const matchId = internal.matchProp('id');
/**
 * Matches the `slug` of a given {@link Property.Key}.
 *
 * @example
 * import * as Branding from "@mgmresorts/client-utils/Branding"
 *
 * const hasAriaSlug: (self: string) => boolean =
 *   Branding.matchSlug(Branding.Property.Aria)
 *
 * const result = hasAriaSlug('aria') === true
 *
 * @category refinements
 * @since 0.0.0
 */
export const matchSlug = internal.matchProp('slug');
/**
 * Matches the analytics ticker of a given @see {@link Property}.
 *
 * @category refinements
 * @since 0.0.0
 */
export const matchTicker = internal.matchProp('ticker');

/**
 * Provides the ID of a given @see {@link Property}.
 *
 * @category accessors
 * @since 0.0.0
 */
export const idOf = (key: Property.Key) =>
  pipe(Property.Config[key], Struct.get('id'));

/**
 * Provides the analytics ticker of a given @see {@link Property}.
 *
 * @category accessors
 * @since 0.0.0
 */
export const tickerOf = (key: Property.Key) =>
  pipe(Property.Config[key], Struct.get('ticker'));

/**
 * Provides the URL subdomain slug of a given @see {@link Property}.
 *
 * @category accessors
 * @since 0.0.0
 */
export const slugOf = (key: Property.Key) =>
  pipe(Property.Config[key], Struct.get('slug'));

/**
 * `x-mgm-source` for a given {@link Property.Key}
 *
 * @category accessors
 * @since 0.0.0
 */
export const sourceOf = (key: Property.Key) =>
  pipe(Property.Config[key], Struct.get('source'));

/**
 * Provides the title, suitable for webpage title, of a given @see {@link
 * Property}.
 *
 * @category accessors
 * @since 0.0.0
 */
export const titleOf = (key: Property.Key) =>
  pipe(Property.Config[key], Struct.get('websiteTitle'));

/**
 * Extract the property identifier from a browser context subdomain.
 *
 * @example
 * import * as Branding from "@mgmresorts/client-utils/Branding"
 * import * as Effect from "effect/Effect"
 * import { pipe } from "effect/Function"
 *
 * const getPropertyIdFromUrl = pipe(
 *   Branding.getPropertyFromUrl,
 *   Effect.map(Branding.idOf),
 * )
 *
 * @category utils
 * @since 0.0.0
 */
export const getPropertyFromUrl: Effect.Effect<Property.Key, string, never> =
  internal.getPropertyFromUrl;

/**
 * Determines if a property slug exists in the property listing.
 *
 * @deprecated
 * @category utils
 * @since 0.0.0
 */
export const findPropertyBySlug: (s: string) => Option.Option<Property.Key> =
  internal.findPropertyBySlug;
