## 0.2.1 (2025-04-03)

### 🚀 Features

- **logroket:** start tracking LD userKey (MINOR) (CET-443) ([#590](https://github.com/MGMResorts/client-tooling/pull/590))

### 🩹 Fixes

- update typedoc dependency to fix build issues ([79eaab42](https://github.com/MGMResorts/client-tooling/commit/79eaab42))
- test update on eslint config cet  lib to fix issue on build ([1d2d5bc9](https://github.com/MGMResorts/client-tooling/commit/1d2d5bc9))
- remove dependency on markdown ([75ca9659](https://github.com/MGMResorts/client-tooling/commit/75ca9659))
- added themes to markdown libs ([#604](https://github.com/MGMResorts/client-tooling/pull/604))
- **commerce-ui:** Remove extra spaces from class names (PATCH) (DBXB-4711) ([#568](https://github.com/MGMResorts/client-tooling/pull/568))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.1

### ❤️ Thank You

- Agus Garcia @agustin-mgm
- Daniel Roma @danielromafsl
- Guido Quispe @guido-mgm

## 0.2.0 (2025-01-22)

### 🚀 Features

- integrate NX build tool (MINOR) (CET-492) ([#490](https://github.com/MGMResorts/client-tooling/pull/490))
- **client-utils:** adding wlasvegas property ([#451](https://github.com/MGMResorts/client-tooling/pull/451))
- moved privacy logic to client-utils (CET-430) (MINOR) ([#314](https://github.com/MGMResorts/client-tooling/pull/314))
- **client-utils,urql,build-tools-ng:** initial commit ([#277](https://github.com/MGMResorts/client-tooling/pull/277))
- **urql,client-utils,build-tools-ng:** initial commit (PATCH) (NONE) ([#227](https://github.com/MGMResorts/client-tooling/pull/227))

### 🩹 Fixes

- **urql,client-utils:** provision source header correctly for URQL (PATCH (NONE) ([#284](https://github.com/MGMResorts/client-tooling/pull/284))

### 🧱 Updated Dependencies

- Updated eslint-config-cet to 3.2.0

### ❤️ Thank You

- David Watts @davidwatts-mgm
- Eric Hegnes @ehegnes-mgm
- Rob Fyffe @rfyffe-mgmresorts

# Change Log - @mgmresorts/client-utils

This log was last generated on Mon, 28 Oct 2024 18:15:56 GMT and should not be manually modified.

## 0.1.4
Fri, 06 Sep 2024 15:02:12 GMT

### Patches

- Republish (no change)

## 0.1.2
Tue, 03 Sep 2024 18:45:27 GMT

_Version update only_

## 0.1.1
Mon, 02 Sep 2024 20:14:42 GMT

_Version update only_

## 0.1.0
Wed, 28 Aug 2024 21:37:10 GMT

### Minor changes

- added privacy and control utils

## 0.0.2
Sat, 10 Aug 2024 03:47:47 GMT

### Patches

- Refactor `Branding` module with safe fallbacks.

## 0.0.1
Wed, 07 Aug 2024 20:50:00 GMT

### Patches

- Initial commit

