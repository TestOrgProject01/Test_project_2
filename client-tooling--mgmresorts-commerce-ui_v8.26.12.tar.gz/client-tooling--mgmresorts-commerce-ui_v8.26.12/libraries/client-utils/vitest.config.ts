import shared from '@mgmresorts/build-tools-ng/vitest.shared.js';
import { mergeConfig, type UserConfigExport } from 'vitest/config';

const config: UserConfigExport = {
  test: {
    environment: 'happy-dom',
    includeTaskLocation: true,
    // XXX: see https://github.com/nrwl/nx/issues/21259#issuecomment-2121841354
    setupFiles: ['./setupTests.ts']
  }
};

// XXX: For some reason, the esbuild-register transform is applying a nested
//      `default` module declaration which does not reflect in the type system.
// eslint-disable-next-line import/no-default-export
export default mergeConfig(shared.default, config);
