import { afterEach, describe, expect, it, vi } from '@effect/vitest';
import * as Journey from '@mgmresorts/client-utils/Journey';
import { Effect } from 'effect';

import * as utils from '../test/util.js';

describe('Journey', () => {
  describe.sequential('provision', () => {
    afterEach(() => {
      sessionStorage.clear();
      vi.clearAllMocks();
    });

    it.effect('provisions only once once when journeyId is unset', () =>
      Effect.gen(function* () {
        const getSpy = vi.spyOn(sessionStorage, 'getItem');
        const setSpy = vi.spyOn(sessionStorage, 'setItem');
        const result = yield* Journey.provision;

        expect(result).toStrictEqual(expect.stringMatching(utils.uuidRegex));
        expect(getSpy).toHaveBeenCalledTimes(1);
        expect(setSpy).toHaveBeenCalledTimes(1);

        const _result = yield* Journey.provision;

        expect(_result).toStrictEqual(result);
        expect(getSpy).toHaveBeenCalledTimes(2);
        expect(setSpy).toHaveBeenCalledTimes(1);

        expect(sessionStorage.getItem('journeyId')).toStrictEqual(result);
      })
    );
  });
});
