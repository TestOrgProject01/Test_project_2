import { it, describe, beforeEach, expect, vi } from '@effect/vitest';
import * as Branding from '@mgmresorts/client-utils/Branding';
import { Effect, pipe } from 'effect';
import * as O from 'effect/Option';

describe('Branding', () => {
  describe('getPropertyFromUrl', () => {
    beforeEach(() => {
      vi.unstubAllGlobals();
    });

    const cases: Array<[string, Branding.Property.Key]> = [
      ['https://bellagio.mgmresorts.com', Branding.Property.Bellagio],
      ['https://preview-bellagio.mgmresorts.com', Branding.Property.Bellagio],
      [
        'https://dev-cosmopolitanlasvegas.mgmresorts.com',
        Branding.Property.Cosmopolitan
      ],
      ['https://preview-www.mgmresorts.com', Branding.Property.Mgm],
      ['https://www.mgmresorts.com', Branding.Property.Mgm],
      ['https://dev.devtest.vegas', Branding.Property.Mgm]
    ];

    it.effect.each(cases)('parses %s to %o', ([origin, expected]) =>
      Effect.gen(function* () {
        vi.stubGlobal('location', { origin });

        const result = yield* pipe(Branding.getPropertyFromUrl);

        expect(result).toStrictEqual(expected);
      })
    );
  });

  describe('findPropertyBySlug', () => {
    const cases: Array<[string, O.Option<Branding.Property.Key>]> = [
      ['bellagio', O.some(Branding.Property.Bellagio)],
      ['dev-bellagio', O.some(Branding.Property.Bellagio)],
      ['www', O.some(Branding.Property.Mgm)],
      ['preview-www', O.some(Branding.Property.Mgm)],
      ['dev', O.none()],
      ['', O.none()]
    ];

    it.each(cases)('parses "%s" to %o', (subdomain, expected) => {
      const result = Branding.findPropertyBySlug(subdomain as any);

      expect(result).toMatchObject(expected);
    });
  });
});
