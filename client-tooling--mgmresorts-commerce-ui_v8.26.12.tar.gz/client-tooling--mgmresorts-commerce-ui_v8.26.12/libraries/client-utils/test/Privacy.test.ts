import { vi, describe, it, expect } from 'vitest';

import { Privacy } from '../src/index.js';

const mockedGeoCallback = vi.fn(() => ({ country: 'US', state: 'CA' }));
const mockedEventCallback = vi.fn();

vi.stubGlobal('window', {
  [Privacy.PRIVACY_WINDOW_GROUPS]: ',C0001,C0002,C0003,C0004,',
  [Privacy.PRIVACY_WINDOW_OBJECT]: {
    [Privacy.PRIVACY_WINDOW_UPDATED_EVENT]: mockedEventCallback,
    getGeolocationData: mockedGeoCallback
  }
});

describe('trackingHandler', () => {
  describe('userInAllowedCountry', () => {
    it('should return true for allowed country', () => {
      const resp = Privacy.userInAllowedCountry();
      expect(resp).toBe(true);
    });
  });

  describe('privacyPreferencesUpdated', () => {
    it('should fire callback on event triggered', () => {
      Privacy.privacyPreferencesUpdated(mockedEventCallback());
      expect(mockedEventCallback).toHaveBeenCalled();
    });
  });

  describe('isPerformanceCookieDisabled', () => {
    const originalWindow = {
      ...window
    };

    it('should return tracking disabled when window not defined', () => {
      (window as any) = undefined;

      const resp = Privacy.isPerformanceCookieDisabled();
      expect(resp).toBe(true);
    });

    it('should return false when tracking not disabled', () => {
      (window as any) = originalWindow;

      const resp = Privacy.isPerformanceCookieDisabled();
      expect(resp).toBe(false);
    });

    it('should return true tracking disabled', () => {
      (window as any)[Privacy.PRIVACY_WINDOW_GROUPS] = '';

      const resp = Privacy.isPerformanceCookieDisabled();
      expect(resp).toBe(true);
    });
  });
});
