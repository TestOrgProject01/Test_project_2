import { it, describe, beforeEach, expect, vi } from '@effect/vitest';
import * as Branding from '@mgmresorts/client-utils/Branding';
import * as Tracking from '@mgmresorts/client-utils/Tracking';
import { Effect } from 'effect';

describe('Tracking', () => {
  describe('sourceFromUrl', () => {
    beforeEach(() => {
      vi.unstubAllGlobals();
    });

    const cases: Array<[string, Branding.Property.Source]> = [
      [
        'https://bellagio.mgmresorts.com',
        Branding.sourceOf(Branding.Property.Bellagio)
      ],
      [
        'https://preview-bellagio.mgmresorts.com',
        Branding.sourceOf(Branding.Property.Bellagio)
      ],
      [
        'https://dev-cosmopolitanlasvegas.mgmresorts.com',
        Branding.sourceOf(Branding.Property.Cosmopolitan)
      ],
      [
        'https://preview-www.mgmresorts.com',
        Branding.sourceOf(Branding.Property.Mgm)
      ],
      ['https://www.mgmresorts.com', Branding.sourceOf(Branding.Property.Mgm)],
      ['https://dev.devtest.vegas', Branding.sourceOf(Branding.Property.Mgm)],
      ['https://example.com', Branding.sourceOf(Branding.Property.Mgm)]
    ];

    it.effect.each(cases)('%s derives to %o', ([origin, expected]) =>
      Effect.gen(function* () {
        vi.stubGlobal('location', { origin });

        const result = yield* Tracking.sourceFromUrl;

        expect(result).toStrictEqual(expected);
      })
    );
  });
});
