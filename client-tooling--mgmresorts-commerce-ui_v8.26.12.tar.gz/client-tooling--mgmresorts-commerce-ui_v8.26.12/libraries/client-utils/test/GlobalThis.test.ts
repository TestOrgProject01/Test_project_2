import { vi, it, expect, describe, beforeEach } from '@effect/vitest';
import * as GlobalThis from '@mgmresorts/client-utils/GlobalThis';
import { Effect } from 'effect';

describe('GlobalThis', () => {
  describe('origin', () => {
    beforeEach(() => {
      vi.unstubAllGlobals();
    });

    it.effect('default', () =>
      Effect.gen(function* () {
        const result = yield* GlobalThis.origin;
        expect(result).toStrictEqual('http://localhost:3000');
      })
    );

    it.effect('with custom window.location.origin', () =>
      Effect.gen(function* () {
        const origin = 'https://www.mgmresorts.com';
        vi.stubGlobal('location', { origin });

        const result = yield* GlobalThis.origin;

        expect(globalThis.location.origin).toStrictEqual(origin);
        expect(result).toStrictEqual(origin);
      })
    );
  });

  describe('hasWindow', () => {
    beforeEach(() => {
      vi.unstubAllGlobals();
    });

    it('sees window defined', () => {
      expect(GlobalThis.hasWindow()).toStrictEqual(true);
    });

    it('sees window undefined', () => {
      vi.stubGlobal('window', undefined);
      expect(GlobalThis.hasWindow()).toStrictEqual(false);
    });
  });

  describe('hasDocument', () => {
    beforeEach(() => {
      vi.unstubAllGlobals();
    });

    it('sees document defined', () => {
      expect(GlobalThis.hasDocument()).toStrictEqual(true);
    });

    it('sees document undefined', () => {
      vi.stubGlobal('document', undefined);
      expect(GlobalThis.hasDocument()).toStrictEqual(false);
    });
  });
});
