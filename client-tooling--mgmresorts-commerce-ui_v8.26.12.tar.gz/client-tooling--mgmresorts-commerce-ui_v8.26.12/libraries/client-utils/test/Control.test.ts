import { vi, describe, it, expect } from 'vitest';

import { GlobalThis } from '../src/index.js';

const mockedEventCallback = vi.fn();

vi.stubGlobal('window', {});

describe('withWindowCheck', () => {
  it('should fire callback', () => {
    GlobalThis.withWindowCheck(mockedEventCallback)();
    expect(mockedEventCallback).toHaveBeenCalledTimes(1);
  });

  it('should return false when window undefined', () => {
    (window as any) = undefined;
    const resp = GlobalThis.withWindowCheck(mockedEventCallback)();

    expect(mockedEventCallback).toHaveBeenCalledTimes(1);
    expect(resp).toBe(false);
  });
});
