---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: 'Client Tooling'
  text: 'A magical collection of client contributions.'
  image:
    src: /tooling.png
    alt: Client Tooling
  actions:
    - theme: brand
      text: Documentation
      link: /introduction
#    - theme: alt
#      text: API
#      link: /api/modules

features:
  - title: NX Build System
    link: https://nx.dev/
    linkText: Learn More
    icon:
      src: /nx.png
    details: Build system, optimized for monorepos, with plugins for popular frameworks and tools.
  - title: Getting Started
    link: /project-setup.html
    linkText: Learn More
    icon: ⚡
    details: Step-by-step guide on getting started with this project.
---
