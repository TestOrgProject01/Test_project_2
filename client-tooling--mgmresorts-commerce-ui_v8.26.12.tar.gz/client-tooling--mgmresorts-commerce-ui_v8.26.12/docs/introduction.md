<script setup>
import { VPTeamMembers } from 'vitepress/theme'

const members = [
  {
    avatar: "https://avatars.githubusercontent.com/u/99454131?v=4",
    name: 'Robert Fyffe',
    links: [
      { icon: 'github', link: 'https://github.com/rfyffe-mgmresorts' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/119354207?v=4',
    name: 'Lukas Machado',
    links: [
      { icon: 'github', link: 'https://github.com/lukasmachado-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/77301801?v=4',
    name: 'Eric Hegnes',
    links: [
      { icon: 'github', link: 'https://github.com/ehegnes-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/93849664?v=4',
    name: 'Gustavo Arellano',
    links: [
      { icon: 'github', link: 'https://github.com/GustavoFSLCo' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/127118128?v=4',
    name: 'Daniel Silva',
    links: [
      { icon: 'github', link: 'https://github.com/dsilvamgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/135377639?v=4',
    name: 'Italo Andrade',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/italoiz-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/97263449?v=4',
    name: 'David Morales',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/davidamorales' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/17753220?v=4',
    name: 'Matheus Laureano',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/matheeeusl' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/80552051?v=4',
    name: 'Thomas Kelly',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/tkelly-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/124182249?v=4',
    name: 'Agus Garcia',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/agustin-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/106542343?v=4',
    name: 'Guido Quispe',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/guido-mgm' },
    ]
  },
  {
    avatar: 'https://avatars.githubusercontent.com/u/105729795?v=4',
    name: 'Renan Britz',
    title: '',
    links: [
      { icon: 'github', link: 'https://github.com/renan-britz-mgm' },
    ]
  },
].sort(((map) => (a, b) =>
  (map.get(a) ?? map.set(a, Math.random()).get(a)) -
    (map.get(b) ?? map.set(b, Math.random()).get(b))
)(new Map))

// Shuffle implementation credit of Thomas Kelly @tkelly-mgm

</script>

# Projects

## Public

### `@mgmresorts/commerce-ui`  
Provides reusable UI components for web applications outside the scope of MGM UI. This library emphasizes performance and utilizes `@mgmresort/vega-tailwind`.

**Source:** [`libraries/commerce-ui`][commerce-ui]

### `@mgmresorts/client-utils`  
Provides common utilities for web applicaitons.

**Source:** [`libraries/client-utils`][client-utils]

### `@mgmresorts/urql`
Provides MGM-specifc infrastructure for satisfying `urql` integration needs.

**Source:** [`libraries/urql`][urql]

### `@mgmresorts/vega-tailwind`
Provides TailwindCSS themeing for the Vega Design Specification.                                                                                               | 

**Source:** [`libraries/vega-tailwind`][vega-tailwind]

### `@mgmresorts/eslint-config-cet`
Provides ESLint configuration owned by the Commerce Experience Team. Web
Platform also utilizes this configuration. **All contributors are welcome.**

**Source:** [`libraries/eslint-config-cet`][eslint-config-cet]

## Internal

### `@mgmresorts/build-tools-ng`
Next-generation build tools inspired by `effect`. Suitable for TS-only projects
meant to be ESM transpiled by a consuming bundler.

**Source:** [`tools/build-tools-ng`][build-tools-ng]

### `@mgmresorts/markdown`
Provides a Markdown React component for rendering Markdown and HTML strings as React elements.
It includes sanitization, parsing, and optional customization for element mapping. This library utilizes `@mgmresort/markdown-to-html`.

**Source:** [`tools/markdown`][markdown]

### `@mgmresorts/markdown-to-html`
Converts markdown content into HTML output. It takes markdown content as an input and returns valid and sanitized HTML string as a response.

**Source:** [`tools/markdown-to-html`][markdown-to-html]


# Meet Our Team

<VPTeamMembers size="small" :members="members" />

[vega-tailwind]: https://github.com/MGMResorts/client-tooling/tree/main/libraries/vega-tailwind
[client-utils]: https://github.com/MGMResorts/client-tooling/tree/main/libraries/client-utils
[commerce-ui]: https://github.com/MGMResorts/client-tooling/tree/main/libraries/commerce-ui
[urql]: https://github.com/MGMResorts/client-tooling/tree/main/libraries/urql
[eslint-config-cet]: https://github.com/MGMResorts/client-tooling/tree/main/libraries/eslint-config-cet
[build-tools-ng]: https://github.com/MGMResorts/client-tooling/tree/main/tools/build-tools-ng